import React, { useState, useEffect } from 'react';
import { useParams, Link } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from '@/components/ui/accordion';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { Progress } from '@/components/ui/progress';
import { Separator } from '@/components/ui/separator';
import { useCart } from '../contexts/CartContext';
import { useAuth } from '../contexts/AuthContext';
import { apiDatabaseService } from '../services/ApiDatabaseService';
import { useToast } from '@/hooks/use-toast';
import { setupCartNotifications } from '../utils/cartNotifications';
import { Course } from '../../shared/database';
import { getCourseContent, CourseContent, Lesson } from '@shared/courseContent';
import QRCodePayment from '../components/QRCodePayment';
import CourseClassDisplay from '../components/CourseClassDisplay';
import {
  Play,
  Pause,
  Star,
  Users,
  Clock,
  BookOpen,
  Download,
  Lock,
  Check,
  ShoppingCart,
  PlayCircle,
  FileText,
  Code,
  Award,
  Globe,
  Calendar,
  Target,
  ChevronRight,
  Maximize,
  Minimize
} from 'lucide-react';

// This will be replaced with dynamic course content

export default function CourseDetail() {
  const { id } = useParams<{ id: string }>();
  const [orders, setOrders] = useState<any[]>([]);
  const { user } = useAuth();
  const [course, setCourse] = useState<Course | null>(null);
  const [courseContent, setCourseContent] = useState<CourseContent | null>(null);
  const [loading, setLoading] = useState(false);
  const [courseNotFound, setCourseNotFound] = useState(false);

  // Load course from database with localStorage fallback
  const loadCourse = async (courseId: string) => {
    try {
      setLoading(true);
      setCourseNotFound(false); // Reset not found state

      console.log(`🔍 Loading course: ${courseId}`);

      // First try to load from database
      const result = await apiDatabaseService.getCourse(courseId);

      console.log('Database query result:', {
        success: result.success,
        hasData: !!result.data,
        error: result.error
      });

      if (result.success && result.data) {
        console.log('✅ Course found in database:', result.data.title);
        setCourse(result.data);

        // Also get the course content for compatibility
        const content = getCourseContent(courseId);
        setCourseContent(content);
        return; // Success, exit early
      }

      // If database call failed or no data, try localStorage fallback
      console.log('⚠️ Course not found in database, checking localStorage...');
      await loadCourseFromLocalStorage(courseId);

    } catch (error) {
      console.error('❌ Error loading course from database:', error);
      // On any error, try localStorage fallback
      await loadCourseFromLocalStorage(courseId);
    } finally {
      setLoading(false);
    }
  };

  // Separate function for localStorage fallback
  const loadCourseFromLocalStorage = async (courseId: string) => {
    try {
      const localCourses = localStorage.getItem('edumaster_courses');

      if (localCourses) {
        const courses = JSON.parse(localCourses);
        const foundCourse = courses.find((c: any) => c.id === courseId);

        if (foundCourse) {
          console.log('✅ Course found in localStorage:', foundCourse.title);
          setCourse(foundCourse);

          // Get course content for compatibility
          const content = getCourseContent(courseId);
          setCourseContent(content);

          // Silent fallback to localStorage without user notification
          console.log('🔄 Course loaded from localStorage (migration available at /admin/database)');
          console.log('📋 Course data:', {
            id: foundCourse.id,
            title: foundCourse.title,
            published: foundCourse.isPublished
          });

          return; // Success
        }
      }

      // If we reach here, course not found anywhere
      console.error('❌ Course not found in database or localStorage');
      setCourseNotFound(true);

    } catch (error) {
      console.error('❌ Error loading course from localStorage:', error);
      setCourseNotFound(true);
    }
  };

  // Load orders (simplified for now)
  const loadOrders = async () => {
    try {
      const result = await apiDatabaseService.getOrders();
      if (result.success && result.data) {
        setOrders(result.data.data || []);
      }
    } catch (error) {
      console.error('Error loading orders:', error);
    }
  };
  const [currentVideo, setCurrentVideo] = useState<any>(null);
  const [isPlaying, setIsPlaying] = useState(false);
  const [isPurchased, setIsPurchased] = useState(false);
  const [isFullscreen, setIsFullscreen] = useState(false);
  const [isUPIPaymentOpen, setIsUPIPaymentOpen] = useState(false);

  const { addToCart, isInCart } = useCart();
  const { toast } = useToast();

  useEffect(() => {
    // Setup cart notifications
    const cleanupCartNotifications = setupCartNotifications(toast);

    if (id) {
      // Load course from database
      loadCourse(id);
      loadOrders();
    }

    return cleanupCartNotifications;
  }, [id, user, toast]);

  // Check purchase status when course or orders change
  useEffect(() => {
    if (course && user) {
      const hasPurchased = orders.some(order =>
        order.userId === user.id &&
        order.courseId === course.id &&
        order.paymentStatus === 'completed'
      );

      // Show success message when course is newly unlocked
      if (hasPurchased && !isPurchased) {
        console.log('✅ Course unlocked for user:', user.id);
        toast({
          title: "🎉 Course Unlocked!",
          description: `Welcome to "${course.title}"! Enjoy your learning journey.`,
          duration: 5000
        });
      }

      setIsPurchased(hasPurchased);

      // Set first video
      if (course.classes && course.classes.length > 0) {
        for (const classItem of course.classes) {
          if (classItem.videos && classItem.videos.length > 0) {
            setCurrentVideo(classItem.videos[0]);
            break;
          }
        }
      }

      // Get course content for compatibility
      const content = getCourseContent(course.id);
      if (content) {
        setCourseContent(content);
        if (!currentVideo) {
          setCurrentVideo(content.lessons[0]);
        }
      }
    }
  }, [course, orders, user, isPurchased, toast]);

  // Listen for fullscreen changes
  useEffect(() => {
    const handleFullscreenChange = () => {
      setIsFullscreen(!!document.fullscreenElement);
    };

    document.addEventListener('fullscreenchange', handleFullscreenChange);
    return () => {
      document.removeEventListener('fullscreenchange', handleFullscreenChange);
    };
  }, []);

  const handleAddToCart = () => {
    if (course && !isInCart(course.id)) {
      addToCart(course);
      // Success notification is automatically handled by cart context
    }
  };

  const handleBuyCourse = () => {
    console.log('���� Buy Now clicked!', { user, course });

    if (!user) {
      toast({
        title: "Login Required",
        description: "Please login to purchase the course.",
        variant: "destructive"
      });
      return;
    }

    if (!course) {
      toast({
        title: "Course Not Found",
        description: "Course information is not available.",
        variant: "destructive"
      });
      return;
    }

    console.log('✅ Opening payment modal for:', course.title);
    setIsUPIPaymentOpen(true);

    toast({
      title: "Payment Modal Opening",
      description: `Ready to purchase "${course.title}" for ₹${course.price}`,
      duration: 2000
    });
  };

  const handlePaymentSuccess = () => {
    toast({
      title: "Payment Submitted!",
      description: "Your payment is being verified. Course will be unlocked once approved.",
    });
    setIsUPIPaymentOpen(false);
  };

  const playLesson = (lesson: Lesson) => {
    if (lesson.isPreview || isPurchased || (course && course.isFree)) {
      setCurrentVideo(lesson);
      setIsPlaying(true);
    } else {
      toast({
        title: "Lesson locked",
        description: "Purchase the course to access this lesson.",
        variant: "destructive",
      });
    }
  };

  const downloadNotes = (lesson: Lesson, noteIndex?: number) => {
    if (lesson.isPreview || isPurchased || (course && course.isFree)) {
      const noteTitle = noteIndex !== undefined ? lesson.notes[noteIndex].title : `${lesson.title} notes`;
      toast({
        title: "Downloading notes",
        description: `${noteTitle} are being downloaded.`,
      });
    } else {
      toast({
        title: "Notes locked",
        description: "Purchase the course to access notes.",
        variant: "destructive",
      });
    }
  };

  const toggleFullscreen = async () => {
    const videoContainer = document.getElementById('video-container');
    if (!videoContainer) return;

    // Check if fullscreen API is available and allowed
    if (!document.fullscreenEnabled) {
      toast({
        title: "Fullscreen not available",
        description: "Fullscreen is disabled in this environment. Try opening in a new tab.",
        variant: "destructive"
      });
      return;
    }

    try {
      if (!document.fullscreenElement) {
        // Check if we have permission before requesting fullscreen
        await videoContainer.requestFullscreen();
        setIsFullscreen(true);
        toast({
          title: "Fullscreen enabled",
          description: "Press ESC to exit fullscreen mode.",
        });
      } else {
        await document.exitFullscreen();
        setIsFullscreen(false);
        toast({
          title: "Fullscreen disabled",
          description: "Video returned to normal view.",
        });
      }
    } catch (err) {
      console.error('Fullscreen error:', err);

      // Handle specific error types
      if (err.message.includes('permissions policy')) {
        toast({
          title: "Fullscreen blocked",
          description: "Fullscreen is disabled by browser policy. Try opening the page in a new tab.",
          variant: "destructive"
        });
      } else {
        toast({
          title: "Fullscreen unavailable",
          description: "Could not enable fullscreen mode.",
          variant: "destructive"
        });
      }
    }
  };

  // Early return after all hooks are called
  if (!course && !loading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-center max-w-md mx-auto p-6">
          <div className="mb-6">
            <BookOpen className="w-16 h-16 mx-auto text-gray-400 mb-4" />
            <h2 className="text-2xl font-bold mb-2">Course Not Found</h2>
            <p className="text-gray-600 mb-4">
              The course you're looking for might have been moved or is being migrated to our new database system.
            </p>
            {courseNotFound && (
              <div className="bg-yellow-50 border border-yellow-200 rounded-lg p-4 mb-4">
                <p className="text-sm text-yellow-800">
                  <strong>Note:</strong> If you recently created this course, it may need to be migrated to our database.
                  Please visit the admin panel to sync your data.
                </p>
              </div>
            )}
          </div>
          <div className="space-y-2">
            <Button asChild className="w-full">
              <Link to="/courses">Browse All Courses</Link>
            </Button>
            <Button variant="outline" asChild className="w-full">
              <Link to="/">Back to Home</Link>
            </Button>
          </div>
        </div>
      </div>
    );
  }

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600 mx-auto mb-4"></div>
          <p className="text-gray-600">Loading course...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen">
      {/* Video Player Section */}
      <div className="bg-black">
        <div className="container mx-auto px-4 py-8">
          <div
            id="video-container"
            className={`aspect-video bg-gray-900 rounded-lg overflow-hidden relative group ${
              isFullscreen ? 'fixed inset-0 z-50 rounded-none' : ''
            }`}
          >
            {currentVideo ? (
              <>
                {/* Check if videoUrl/fileUrl is a URL or file key */}
                {(currentVideo.videoUrl || currentVideo.fileUrl)?.startsWith('http') ? (
                  <iframe
                    src={`${currentVideo.videoUrl || currentVideo.fileUrl}?autoplay=1&rel=0`}
                    title={currentVideo.title}
                    className="w-full h-full"
                    allowFullScreen
                    allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
                  />
                ) : (
                  /* For uploaded files, show video element */
                  <div className="w-full h-full flex items-center justify-center bg-gray-800">
                    {(() => {
                      try {
                        // Try multiple possible keys where video might be stored
                        const fileKey = currentVideo.fileUrl || currentVideo.videoUrl || currentVideo.videoKey || currentVideo.url;
                        console.log('Video Debug:', {
                          currentVideo,
                          fileKey,
                          hasFileKey: !!fileKey,
                          availableKeys: Object.keys(currentVideo)
                        });

                        if (fileKey) {
                          let fileInfo = localStorage.getItem(fileKey);
                          console.log('File Info:', fileInfo ? 'Found' : 'Not found', fileKey);

                          // If not found by direct key, try searching localStorage for video files
                          if (!fileInfo) {
                            console.log('Searching localStorage for video files...');
                            const videoTitle = currentVideo.title || '';

                            for (let i = 0; i < localStorage.length; i++) {
                              const key = localStorage.key(i);
                              if (key && key.includes('video-file')) {
                                try {
                                  const item = localStorage.getItem(key);
                                  if (item) {
                                    const parsed = JSON.parse(item);
                                    // Match by title or filename
                                    if (parsed.name && (
                                      parsed.name.toLowerCase().includes(videoTitle.toLowerCase()) ||
                                      videoTitle.toLowerCase().includes(parsed.name.toLowerCase().split('.')[0])
                                    )) {
                                      fileInfo = item;
                                      console.log('Found video by search:', { key, name: parsed.name });
                                      break;
                                    }
                                  }
                                } catch (e) {
                                  // Skip invalid entries
                                }
                              }
                            }
                          }

                          if (fileInfo) {
                            const { dataUrl, name } = JSON.parse(fileInfo);
                            console.log('Data URL type:', dataUrl ? dataUrl.substring(0, 50) : 'No dataUrl');

                            // Check if file exists and has valid data
                            if (dataUrl && name) {
                              console.log('Video file found:', {
                                name,
                                dataUrlType: dataUrl.substring(0, 50),
                                dataUrlLength: dataUrl.length
                              });

                              // Check if it's a video file by extension
                              const isVideoByExtension = name.toLowerCase().match(/\.(mov|mp4|avi|webm|mkv|flv)$/);

                              if (isVideoByExtension || dataUrl.startsWith('data:video/')) {
                                // Check if it's a MOV file which might have compatibility issues
                                const isMOVFile = name.toLowerCase().endsWith('.mov');

                                return (
                                  <div className="w-full h-full relative">
                                    <video
                                      controls
                                      className="w-full h-full"
                                      poster="/placeholder-video-thumbnail.jpg"
                                      onError={(e) => {
                                        console.error('Video playback error:', e);
                                        console.log('Failed video details:', { name, dataUrl: dataUrl.substring(0, 100) });

                                        // Show error message to user
                                        toast({
                                          title: "Video playback failed",
                                          description: `${name} cannot be played. Try downloading and converting to MP4.`,
                                          variant: "destructive"
                                        });
                                      }}
                                      onLoadStart={() => console.log('Video loading started')}
                                      onLoadedData={() => {
                                        console.log('Video data loaded successfully');
                                        toast({
                                          title: "Video loaded!",
                                          description: `${name} is ready to play.`,
                                        });
                                      }}
                                      onCanPlay={() => console.log('Video can play')}
                                      preload="metadata"
                                    >
                                      {/* Multiple source formats for better compatibility */}
                                      <source src={dataUrl} type="video/mp4" />
                                      <source src={dataUrl} type="video/quicktime" />
                                      <source src={dataUrl} type="video/webm" />
                                      Your browser does not support the video tag.
                                    </video>

                                    {/* Format warning for MOV files */}
                                    {isMOVFile && (
                                      <div className="absolute bottom-4 left-4 bg-black/80 text-white px-3 py-2 rounded-lg text-sm max-w-xs">
                                        <div className="flex items-center gap-2 mb-1">
                                          <span>⚠️</span>
                                          <span className="font-medium">MOV Format Detected</span>
                                        </div>
                                        <p className="text-xs">
                                          If video doesn't play, download and convert to MP4 for better browser support.
                                        </p>
                                      </div>
                                    )}

                                    {/* Video info overlay */}
                                    <div className="absolute top-4 left-4 bg-black/60 text-white px-2 py-1 rounded text-xs">
                                      📹 {name}
                                    </div>
                                  </div>
                                );
                              }
                            } else {
                              return (
                                <div className="text-center text-white">
                                  <PlayCircle className="w-16 h-16 mx-auto mb-4 opacity-50" />
                                  <p className="text-lg">Video: {currentVideo.title}</p>
                                  <p className="text-sm opacity-75">Duration: {currentVideo.duration}</p>
                                  <p className="text-xs mt-2 opacity-50">Video format not supported</p>
                                  <p className="text-xs mt-1 opacity-30">File: {name || 'Unknown'}</p>
                                  <div className="mt-2">
                                    <Button
                                      variant="outline"
                                      size="sm"
                                      onClick={() => {
                                        const debugInfo = {
                                          fileName: name,
                                          fileKey: fileKey,
                                          dataUrlPresent: !!dataUrl,
                                          dataUrlType: dataUrl?.substring(0, 50),
                                          dataUrlLength: dataUrl?.length,
                                          isVideoExtension: name?.toLowerCase().match(/\.(mov|mp4|avi|webm)$/),
                                        };
                                        console.log('Detailed Debug Info:', debugInfo);
                                        toast({
                                          title: "Video Debug Info",
                                          description: `File: ${name || 'Unknown'} | Data: ${dataUrl ? 'Present' : 'Missing'} | Type: ${dataUrl?.substring(5, 30) || 'Unknown'}`,
                                        });
                                      }}
                                      className="text-white border-white hover:bg-white hover:text-black"
                                    >
                                      🔍 Debug Info
                                    </Button>

                                    {dataUrl && (
                                      <Button
                                        variant="outline"
                                        size="sm"
                                        onClick={() => {
                                          const link = document.createElement('a');
                                          link.href = dataUrl;
                                          link.download = name || 'video-file';
                                          document.body.appendChild(link);
                                          link.click();
                                          document.body.removeChild(link);
                                          toast({
                                            title: "Download started",
                                            description: "Video file is downloading...",
                                          });
                                        }}
                                        className="text-white border-white hover:bg-white hover:text-black ml-2"
                                      >
                                        📥 Download Video
                                      </Button>
                                    )}
                                  </div>
                                </div>
                              );
                            }
                          } else {
                          // Debug: Show what video files are available
                          const availableVideoFiles = Array.from({length: localStorage.length}, (_, i) => localStorage.key(i))
                            .filter(key => key && key.includes('video-file'));

                          console.log('Video file not found. Available video files:', availableVideoFiles);

                          return (
                            <div className="text-center text-white">
                              <PlayCircle className="w-16 h-16 mx-auto mb-4 opacity-50" />
                              <p className="text-lg">Video: {currentVideo.title}</p>
                              <p className="text-sm opacity-75">Duration: {currentVideo.duration}</p>
                              <p className="text-xs mt-2 opacity-50">Video file not found in storage</p>
                              <p className="text-xs mt-1 opacity-30">Key: {fileKey}</p>
                              <p className="text-xs mt-1 opacity-30">Available videos: {availableVideoFiles.length}</p>
                              <Button
                                variant="outline"
                                size="sm"
                                onClick={() => {
                                  console.log('Available video files:', availableVideoFiles.map(key => {
                                    try {
                                      const item = localStorage.getItem(key);
                                      return { key, data: item ? JSON.parse(item) : null };
                                    } catch (e) {
                                      return { key, error: e.message };
                                    }
                                  }));
                                  toast({
                                    title: "Video Debug",
                                    description: `Found ${availableVideoFiles.length} video files in storage. Check console for details.`,
                                  });
                                }}
                                className="mt-2 text-white border-white hover:bg-white hover:text-black"
                              >
                                🔍 Debug Storage
                              </Button>
                            </div>
                          );
                        }
                        }
                        // Check if there are any video files in storage that might match
                        const availableVideoFiles = Array.from({length: localStorage.length}, (_, i) => localStorage.key(i))
                          .filter(key => key && key.includes('video-file'));

                        return (
                          <div className="text-center text-white">
                            <PlayCircle className="w-16 h-16 mx-auto mb-4 opacity-50" />
                            <p className="text-lg">Video: {currentVideo.title}</p>
                            <p className="text-sm opacity-75">Duration: {currentVideo.duration}</p>
                            <p className="text-xs mt-2 opacity-50">No video file key specified</p>
                            <p className="text-xs mt-1 opacity-30">
                              Available videos in storage: {availableVideoFiles.length}
                            </p>
                            {availableVideoFiles.length > 0 && (
                              <Button
                                variant="outline"
                                size="sm"
                                onClick={() => {
                                  // Try to match the first available video file
                                  const firstVideoKey = availableVideoFiles[0];
                                  if (firstVideoKey) {
                                    try {
                                      const item = localStorage.getItem(firstVideoKey);
                                      if (item) {
                                        const parsed = JSON.parse(item);
                                        console.log('Attempting to use first available video:', parsed);

                                        // Update current video with found file
                                        const updatedVideo = {
                                          ...currentVideo,
                                          videoUrl: firstVideoKey,
                                          fileUrl: firstVideoKey
                                        };
                                        setCurrentVideo(updatedVideo);

                                        toast({
                                          title: "Video Found!",
                                          description: `Using: ${parsed.name}`,
                                        });
                                      }
                                    } catch (e) {
                                      console.error('Error loading video:', e);
                                    }
                                  }
                                }}
                                className="mt-2 text-white border-white hover:bg-white hover:text-black"
                              >
                                🎬 Try Load Video
                              </Button>
                            )}
                          </div>
                        );
                      } catch (error) {
                        console.error('Video render error:', error);
                        return (
                          <div className="text-center text-white">
                            <PlayCircle className="w-16 h-16 mx-auto mb-4 opacity-50" />
                            <p className="text-lg">{currentVideo.title}</p>
                            <p className="text-sm opacity-75">Video error occurred</p>
                            <p className="text-xs mt-1 opacity-30">{error.message}</p>
                          </div>
                        );
                      }
                    })()}
                  </div>
                )}

                {/* Fullscreen Toggle Button - Only show if fullscreen is available */}
                {document.fullscreenEnabled && (
                  <Button
                    variant="ghost"
                    size="sm"
                    className={`absolute top-4 right-4 bg-black/50 text-white hover:bg-black/70 opacity-0 group-hover:opacity-100 transition-opacity ${
                      isFullscreen ? 'opacity-100' : ''
                    }`}
                    onClick={toggleFullscreen}
                    title={isFullscreen ? "Exit fullscreen (ESC)" : "Enter fullscreen"}
                  >
                    {isFullscreen ? (
                      <Minimize className="h-4 w-4" />
                    ) : (
                      <Maximize className="h-4 w-4" />
                    )}
                  </Button>
                )}
              </>
            ) : (
              <div className="flex items-center justify-center h-full">
                <div className="text-center text-white">
                  <PlayCircle className="w-16 h-16 mx-auto mb-4 opacity-50" />
                  <p className="text-lg">Select a lesson to start watching</p>
                </div>
              </div>
            )}
          </div>
          
          {currentVideo && (
            <div className="mt-4 text-white">
              <h3 className="text-xl font-semibold">{currentVideo.title}</h3>
              <p className="text-gray-300 mt-1">{currentVideo.description}</p>
              <div className="flex items-center gap-4 mt-2 text-sm text-gray-400">
                <span className="flex items-center gap-1">
                  <Clock className="w-4 h-4" />
                  {currentVideo.duration}
                </span>
                {currentVideo.notes && currentVideo.notes.length > 0 && (currentVideo.isPreview || isPurchased || (course && course.isFree)) && (
                  <div className="flex gap-2">
                    {currentVideo.notes.map((note, index) => (
                      <Button
                        key={note.id || `note-${index}`}
                        variant="outline"
                        size="sm"
                        onClick={() => downloadNotes(currentVideo, index)}
                        className="text-white border-white hover:bg-white hover:text-black"
                      >
                        <Download className="w-4 h-4 mr-2" />
                        {note.title}
                      </Button>
                    ))}
                  </div>
                )}
              </div>
            </div>
          )}
        </div>
      </div>

      {/* Course Content */}
      <div className="container mx-auto px-4 py-8">
        <div className="grid lg:grid-cols-3 gap-8">
          {/* Main Content */}
          <div className="lg:col-span-2 space-y-8">
            {/* Course Header */}
            <div>
              <div className="flex items-center gap-2 mb-4">
                <Badge>{course.category}</Badge>
                <Badge variant="outline">{course.level}</Badge>
                {course.isPopular && <Badge className="bg-orange-500">Popular</Badge>}
                {course.isFree && <Badge className="bg-success">Free</Badge>}
              </div>
              
              <h1 className="text-3xl lg:text-4xl font-bold mb-4">{course.title}</h1>
              <p className="text-lg text-muted-foreground mb-6">{course.description}</p>
              
              {/* Course Stats */}
              <div className="flex flex-wrap items-center gap-6 mb-6">
                <div className="flex items-center gap-2">
                  <Star className="w-5 h-5 fill-yellow-400 text-yellow-400" />
                  <span className="font-medium">{course.rating}</span>
                  <span className="text-muted-foreground">({course.reviewCount} reviews)</span>
                </div>
                <div className="flex items-center gap-2">
                  <Users className="w-5 h-5 text-muted-foreground" />
                  <span>{course.totalStudents.toLocaleString()} students</span>
                </div>
                <div className="flex items-center gap-2">
                  <Clock className="w-5 h-5 text-muted-foreground" />
                  <span>{course.duration} total</span>
                </div>
                <div className="flex items-center gap-2">
                  <BookOpen className="w-5 h-5 text-muted-foreground" />
                  <span>{course.totalLessons} lessons</span>
                </div>
              </div>

              {/* Instructor */}
              <div className="flex items-center gap-4 p-4 bg-muted/30 rounded-lg">
                <Avatar className="w-12 h-12">
                  <AvatarImage src={course.instructor.avatar} />
                  <AvatarFallback>{course.instructor.name[0]}</AvatarFallback>
                </Avatar>
                <div>
                  <p className="font-medium">{course.instructor.name}</p>
                  <p className="text-sm text-muted-foreground">{course.instructor.bio}</p>
                </div>
              </div>
            </div>

            {/* Course Content Tabs */}
            <Tabs defaultValue="curriculum" className="w-full">
              <TabsList className="grid w-full grid-cols-4">
                <TabsTrigger value="curriculum">Curriculum</TabsTrigger>
                <TabsTrigger value="projects">Projects</TabsTrigger>
                <TabsTrigger value="reviews">Reviews</TabsTrigger>
                <TabsTrigger value="about">About</TabsTrigger>
              </TabsList>

              {/* Curriculum Tab */}
              <TabsContent value="curriculum" className="space-y-4">
                <CourseClassDisplay
                  course={course}
                  isPurchased={isPurchased}
                  currentVideo={currentVideo}
                  setCurrentVideo={setCurrentVideo}
                  setIsPlaying={setIsPlaying}
                />
              </TabsContent>

              {/* Projects Tab */}
              <TabsContent value="projects" className="space-y-4">
                {/* Display Real Projects */}
                {course.projects && course.projects.length > 0 ? (
                  course.projects.map((project: any, projIndex: number) => (
                    <Card key={project.id || `project-${projIndex}`}>
                      <CardHeader>
                        <div className="flex items-center justify-between">
                          <CardTitle className="flex items-center gap-2">
                            <Code className="w-5 h-5" />
                            {project.title}
                          </CardTitle>
                          <Badge variant="outline">{project.difficulty}</Badge>
                        </div>
                        <CardDescription>{project.description}</CardDescription>
                      </CardHeader>
                      <CardContent className="space-y-4">
                        <div className="flex items-center justify-between">
                          <div className="flex items-center gap-4 text-sm text-muted-foreground">
                            <span className="flex items-center gap-1">
                              <FileText className="w-4 h-4" />
                              {project.codeFiles.length} code files
                            </span>
                            <span>Added: {new Date(project.uploadDate).toLocaleDateString()}</span>
                          </div>

                          <div className="flex gap-2">
                            <Button
                              variant="outline"
                              size="sm"
                              disabled={!isPurchased && !(course && course.isFree)}
                              onClick={() => {
                                if (isPurchased || (course && course.isFree)) {
                                  toast({
                                    title: "Downloading project",
                                    description: `${project.title} files are being downloaded.`,
                                  });
                                }
                              }}
                            >
                              <Download className="w-4 h-4 mr-2" />
                              Download Project
                            </Button>
                            {project.demoUrl && (
                              <Button
                                variant="outline"
                                size="sm"
                                onClick={() => window.open(project.demoUrl, '_blank')}
                              >
                                <Globe className="w-4 h-4 mr-2" />
                                Live Demo
                              </Button>
                            )}
                          </div>
                        </div>

                        {/* Code Files */}
                        <div className="grid grid-cols-2 md:grid-cols-3 gap-2">
                          {project.codeFiles.map((file: any, fileIndex: number) => (
                            <div key={`${project.id || projIndex}-file-${fileIndex}`} className="p-2 bg-muted/30 rounded text-xs">
                              <div className="font-medium">{file.fileName}</div>
                              <div className="text-muted-foreground">{file.language}</div>
                            </div>
                          ))}
                        </div>
                      </CardContent>
                    </Card>
                  ))
                ) : courseContent && courseContent.projects.length > 0 ? (
                  courseContent.projects.map((project) => (
                    <Card key={project.id}>
                      <CardHeader>
                        <div className="flex items-center justify-between">
                          <CardTitle className="flex items-center gap-2">
                            <Code className="w-5 h-5" />
                            {project.title}
                          </CardTitle>
                          <Badge variant="outline">{project.difficulty}</Badge>
                        </div>
                        <CardDescription>{project.description}</CardDescription>
                      </CardHeader>
                      <CardContent className="space-y-4">
                        <div className="p-3 bg-muted/30 rounded-lg">
                          <h5 className="font-medium mb-1">Instructions:</h5>
                          <p className="text-sm text-muted-foreground">{project.instructions}</p>
                        </div>

                        <div className="flex items-center justify-between">
                          <div className="flex items-center gap-4 text-sm text-muted-foreground">
                            <span className="flex items-center gap-1">
                              <Clock className="w-4 h-4" />
                              {project.estimatedTime}
                            </span>
                            <span className="flex items-center gap-1">
                              <FileText className="w-4 h-4" />
                              {project.files.length} files
                            </span>
                          </div>

                          <div className="flex gap-2">
                            {project.files.map((file, fileIndex) => (
                              <Button
                                key={`${project.id}-download-${fileIndex}`}
                                variant="outline"
                                size="sm"
                                disabled={!isPurchased && !(course && course.isFree)}
                                onClick={() => {
                                  if (isPurchased || (course && course.isFree)) {
                                    toast({
                                      title: "Downloading project files",
                                      description: `${file.split('/').pop()} is being downloaded.`,
                                    });
                                  }
                                }}
                              >
                                <Download className="w-4 h-4 mr-2" />
                                {file.includes('solution') ? 'Solution' : 'Starter Files'}
                              </Button>
                            ))}
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                  ))
                ) : (
                  <div className="text-center py-8 text-muted-foreground">
                    <Code className="w-12 h-12 mx-auto mb-4 opacity-50" />
                    <p>No projects available for this course</p>
                  </div>
                )}
              </TabsContent>

              {/* Reviews Tab */}
              <TabsContent value="reviews" className="space-y-4">
                <div className="grid gap-4">
                  {[1, 2, 3].map((review) => (
                    <Card key={review}>
                      <CardContent className="p-4">
                        <div className="flex items-start gap-3">
                          <Avatar>
                            <AvatarFallback>U{review}</AvatarFallback>
                          </Avatar>
                          <div className="flex-1">
                            <div className="flex items-center gap-2 mb-2">
                              <span className="font-medium">User {review}</span>
                              <div className="flex">
                                {[...Array(5)].map((_, i) => (
                                  <Star key={i} className="w-4 h-4 fill-yellow-400 text-yellow-400" />
                                ))}
                              </div>
                            </div>
                            <p className="text-sm text-muted-foreground">
                              Great course! The instructor explains everything clearly and the projects are very practical.
                            </p>
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                  ))}
                </div>
              </TabsContent>

              {/* About Tab */}
              <TabsContent value="about" className="space-y-6">
                <div>
                  <h3 className="text-lg font-semibold mb-3">What you'll learn</h3>
                  <div className="grid gap-2">
                    {course.learningOutcomes.map((outcome, index) => (
                      <div key={index} className="flex items-center gap-2">
                        <Check className="w-4 h-4 text-success flex-shrink-0" />
                        <span className="text-sm">{outcome}</span>
                      </div>
                    ))}
                  </div>
                </div>

                <div>
                  <h3 className="text-lg font-semibold mb-3">Requirements</h3>
                  <div className="grid gap-2">
                    {course.requirements.map((requirement, index) => (
                      <div key={index} className="flex items-center gap-2">
                        <ChevronRight className="w-4 h-4 text-muted-foreground flex-shrink-0" />
                        <span className="text-sm">{requirement}</span>
                      </div>
                    ))}
                  </div>
                </div>
              </TabsContent>
            </Tabs>
          </div>

          {/* Sidebar */}
          <div className="lg:col-span-1">
            <Card className="sticky top-24">
              <CardContent className="p-6">
                {/* Price */}
                <div className="mb-6">
                  {course.isFree ? (
                    <div className="text-2xl font-bold text-success">Free</div>
                  ) : (
                    <div className="flex items-center gap-2">
                      <span className="text-3xl font-bold">${course.price}</span>
                      {course.originalPrice && (
                        <span className="text-lg text-muted-foreground line-through">
                          ${course.originalPrice}
                        </span>
                      )}
                    </div>
                  )}
                </div>

                {/* Action Buttons */}
                <div className="space-y-3 mb-6">
                  {course.isFree ? (
                    <Button className="w-full" onClick={() => setIsPurchased(true)}>
                      <Play className="w-4 h-4 mr-2" />
                      Start Learning Free
                    </Button>
                  ) : isPurchased ? (
                    <Button className="w-full" disabled>
                      <Check className="w-4 h-4 mr-2" />
                      Enrolled
                    </Button>
                  ) : (
                    <>
                      <Button className="w-full" onClick={handleBuyCourse}>
                        <ShoppingCart className="w-4 h-4 mr-2" />
                        Buy Now - ₹{course.price.toLocaleString()}
                      </Button>
                      <Button
                        variant="outline"
                        className="w-full"
                        onClick={handleAddToCart}
                        disabled={isInCart(course.id)}
                      >
                        {isInCart(course.id) ? 'In Cart' : 'Add to Cart'}
                      </Button>
                    </>
                  )}
                </div>

                {/* QR Code Payment Modal */}
                <QRCodePayment
                  course={course}
                  isOpen={isUPIPaymentOpen}
                  onClose={() => setIsUPIPaymentOpen(false)}
                  onSuccess={handlePaymentSuccess}
                />

                {/* Course Info */}
                <div className="space-y-3 text-sm">
                  <div className="flex items-center justify-between">
                    <span className="text-muted-foreground">Duration</span>
                    <span>{course.duration}</span>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-muted-foreground">Lessons</span>
                    <span>{courseContent ? courseContent.lessons.length : course.totalLessons}</span>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-muted-foreground">Level</span>
                    <span className="capitalize">{course.level}</span>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-muted-foreground">Certificate</span>
                    <span>Yes</span>
                  </div>
                </div>

                <Separator className="my-4" />

                {/* Features */}
                <div className="space-y-2 text-sm">
                  {course.features.map((feature, index) => (
                    <div key={index} className="flex items-center gap-2">
                      <Check className="w-4 h-4 text-success flex-shrink-0" />
                      <span>{feature}</span>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </div>
  );
}
