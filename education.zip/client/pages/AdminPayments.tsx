import React, { useState } from 'react';
import { Button } from '../components/ui/button';
import { Input } from '../components/ui/input';
import { Card, CardContent, CardHeader, CardTitle } from '../components/ui/card';
import { Badge } from '../components/ui/badge';
import { Switch } from '../components/ui/switch';
import { Alert, AlertDescription } from '../components/ui/alert';
import { 
  CreditCard, 
  Smartphone, 
  Building2, 
  Save, 
  Eye, 
  EyeOff,
  CheckCircle,
  AlertTriangle,
  Settings,
  DollarSign
} from 'lucide-react';

interface PaymentMethod {
  id: string;
  name: string;
  type: 'upi' | 'bank' | 'card' | 'wallet';
  isEnabled: boolean;
  config: any;
  icon: string;
}

const AdminPayments: React.FC = () => {
  const [paymentMethods, setPaymentMethods] = useState<PaymentMethod[]>([
    {
      id: 'upi',
      name: 'UPI Payment',
      type: 'upi',
      isEnabled: true,
      config: {
        upiId: 'codenest@paytm',
        merchantName: 'EduMaster'
      },
      icon: '📱'
    },
    {
      id: 'card',
      name: 'Credit/Debit Card',
      type: 'card',
      isEnabled: true,
      config: {
        apiKey: 'pk_test_xxxxxxxxxxxxxxxx',
        secretKey: 'sk_test_xxxxxxxxxxxxxxxx'
      },
      icon: '💳'
    },
    {
      id: 'netbanking',
      name: 'Net Banking',
      type: 'bank',
      isEnabled: false,
      config: {
        merchantId: 'EDUMASTER001',
        secretKey: 'sk_netbank_xxxxxxxxxxxxxxxx'
      },
      icon: '🏦'
    },
    {
      id: 'wallet',
      name: 'Digital Wallet',
      type: 'wallet',
      isEnabled: false,
      config: {
        walletKey: 'wallet_xxxxxxxxxxxxxxxx'
      },
      icon: '👛'
    }
  ]);

  const [showSecrets, setShowSecrets] = useState<{[key: string]: boolean}>({});
  const [savedMessage, setSavedMessage] = useState('');

  const togglePaymentMethod = (methodId: string) => {
    setPaymentMethods(methods => 
      methods.map(method => 
        method.id === methodId 
          ? { ...method, isEnabled: !method.isEnabled }
          : method
      )
    );
  };

  const updateConfig = (methodId: string, key: string, value: string) => {
    setPaymentMethods(methods => 
      methods.map(method => 
        method.id === methodId 
          ? { 
              ...method, 
              config: { ...method.config, [key]: value }
            }
          : method
      )
    );
  };

  const toggleSecretVisibility = (key: string) => {
    setShowSecrets(prev => ({ ...prev, [key]: !prev[key] }));
  };

  const saveSettings = () => {
    // Here you would save to API
    setSavedMessage('Payment settings saved successfully!');
    setTimeout(() => setSavedMessage(''), 3000);
  };

  const getMethodIcon = (type: string) => {
    switch (type) {
      case 'upi':
        return <Smartphone className="h-5 w-5 text-blue-600" />;
      case 'card':
        return <CreditCard className="h-5 w-5 text-green-600" />;
      case 'bank':
        return <Building2 className="h-5 w-5 text-purple-600" />;
      case 'wallet':
        return <DollarSign className="h-5 w-5 text-orange-600" />;
      default:
        return <Settings className="h-5 w-5 text-gray-600" />;
    }
  };

  const maskSecret = (secret: string, show: boolean) => {
    if (show) return secret;
    return secret ? '*'.repeat(secret.length) : '';
  };

  const stats = [
    { title: 'Active Methods', value: paymentMethods.filter(m => m.isEnabled).length, total: paymentMethods.length },
    { title: 'UPI Revenue', value: '₹45,230', change: '+12%' },
    { title: 'Card Revenue', value: '₹32,450', change: '+8%' },
    { title: 'Success Rate', value: '98.5%', change: '+2%' }
  ];

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-3xl font-bold text-gray-900">Payment Settings</h1>
          <p className="text-gray-600">Configure payment methods and gateway settings</p>
        </div>
        <Button onClick={saveSettings}>
          <Save className="h-4 w-4 mr-2" />
          Save All Settings
        </Button>
      </div>

      {savedMessage && (
        <Alert>
          <CheckCircle className="h-4 w-4" />
          <AlertDescription>{savedMessage}</AlertDescription>
        </Alert>
      )}

      {/* Stats Cards */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        {stats.map((stat, index) => (
          <Card key={index}>
            <CardContent className="pt-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-gray-600">{stat.title}</p>
                  <p className="text-2xl font-bold">{stat.value}</p>
                  {stat.change && (
                    <p className="text-xs text-green-600">{stat.change} from last month</p>
                  )}
                </div>
                <div className="p-2 bg-blue-50 rounded-full">
                  <CreditCard className="h-6 w-6 text-blue-600" />
                </div>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      {/* Payment Methods Configuration */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {paymentMethods.map((method) => (
          <Card key={method.id} className={`transition-all ${method.isEnabled ? 'ring-2 ring-blue-200' : ''}`}>
            <CardHeader>
              <div className="flex items-center justify-between">
                <div className="flex items-center space-x-3">
                  {getMethodIcon(method.type)}
                  <CardTitle className="text-lg">{method.name}</CardTitle>
                </div>
                <div className="flex items-center space-x-2">
                  <Badge variant={method.isEnabled ? 'default' : 'secondary'}>
                    {method.isEnabled ? 'Active' : 'Inactive'}
                  </Badge>
                  <Switch
                    checked={method.isEnabled}
                    onCheckedChange={() => togglePaymentMethod(method.id)}
                  />
                </div>
              </div>
            </CardHeader>
            <CardContent className="space-y-4">
              {method.type === 'upi' && (
                <>
                  <div>
                    <label className="block text-sm font-medium mb-1">UPI ID</label>
                    <Input
                      value={method.config.upiId || ''}
                      onChange={(e) => updateConfig(method.id, 'upiId', e.target.value)}
                      placeholder="your-upi@bank"
                      disabled={!method.isEnabled}
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium mb-1">Merchant Name</label>
                    <Input
                      value={method.config.merchantName || ''}
                      onChange={(e) => updateConfig(method.id, 'merchantName', e.target.value)}
                      placeholder="Your Business Name"
                      disabled={!method.isEnabled}
                    />
                  </div>
                </>
              )}

              {method.type === 'card' && (
                <>
                  <div>
                    <label className="block text-sm font-medium mb-1">Publishable Key</label>
                    <div className="relative">
                      <Input
                        type={showSecrets[`${method.id}_apiKey`] ? 'text' : 'password'}
                        value={method.config.apiKey || ''}
                        onChange={(e) => updateConfig(method.id, 'apiKey', e.target.value)}
                        placeholder="pk_test_..."
                        disabled={!method.isEnabled}
                      />
                      <Button
                        variant="ghost"
                        size="sm"
                        className="absolute right-0 top-0 h-full px-3"
                        onClick={() => toggleSecretVisibility(`${method.id}_apiKey`)}
                      >
                        {showSecrets[`${method.id}_apiKey`] ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
                      </Button>
                    </div>
                  </div>
                  <div>
                    <label className="block text-sm font-medium mb-1">Secret Key</label>
                    <div className="relative">
                      <Input
                        type={showSecrets[`${method.id}_secretKey`] ? 'text' : 'password'}
                        value={method.config.secretKey || ''}
                        onChange={(e) => updateConfig(method.id, 'secretKey', e.target.value)}
                        placeholder="sk_test_..."
                        disabled={!method.isEnabled}
                      />
                      <Button
                        variant="ghost"
                        size="sm"
                        className="absolute right-0 top-0 h-full px-3"
                        onClick={() => toggleSecretVisibility(`${method.id}_secretKey`)}
                      >
                        {showSecrets[`${method.id}_secretKey`] ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
                      </Button>
                    </div>
                  </div>
                </>
              )}

              {method.type === 'bank' && (
                <>
                  <div>
                    <label className="block text-sm font-medium mb-1">Merchant ID</label>
                    <Input
                      value={method.config.merchantId || ''}
                      onChange={(e) => updateConfig(method.id, 'merchantId', e.target.value)}
                      placeholder="MERCHANT001"
                      disabled={!method.isEnabled}
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium mb-1">Secret Key</label>
                    <div className="relative">
                      <Input
                        type={showSecrets[`${method.id}_secretKey`] ? 'text' : 'password'}
                        value={method.config.secretKey || ''}
                        onChange={(e) => updateConfig(method.id, 'secretKey', e.target.value)}
                        placeholder="sk_netbank_..."
                        disabled={!method.isEnabled}
                      />
                      <Button
                        variant="ghost"
                        size="sm"
                        className="absolute right-0 top-0 h-full px-3"
                        onClick={() => toggleSecretVisibility(`${method.id}_secretKey`)}
                      >
                        {showSecrets[`${method.id}_secretKey`] ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
                      </Button>
                    </div>
                  </div>
                </>
              )}

              {method.type === 'wallet' && (
                <div>
                  <label className="block text-sm font-medium mb-1">Wallet API Key</label>
                  <div className="relative">
                    <Input
                      type={showSecrets[`${method.id}_walletKey`] ? 'text' : 'password'}
                      value={method.config.walletKey || ''}
                      onChange={(e) => updateConfig(method.id, 'walletKey', e.target.value)}
                      placeholder="wallet_..."
                      disabled={!method.isEnabled}
                    />
                    <Button
                      variant="ghost"
                      size="sm"
                      className="absolute right-0 top-0 h-full px-3"
                      onClick={() => toggleSecretVisibility(`${method.id}_walletKey`)}
                    >
                      {showSecrets[`${method.id}_walletKey`] ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
                    </Button>
                  </div>
                </div>
              )}

              {!method.isEnabled && (
                <Alert>
                  <AlertTriangle className="h-4 w-4" />
                  <AlertDescription>
                    This payment method is disabled. Enable it to start accepting payments.
                  </AlertDescription>
                </Alert>
              )}
            </CardContent>
          </Card>
        ))}
      </div>

      {/* Global Payment Settings */}
      <Card>
        <CardHeader>
          <CardTitle>Global Payment Settings</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <label className="block text-sm font-medium mb-1">Currency</label>
              <select className="w-full px-3 py-2 border border-gray-300 rounded-md text-sm">
                <option value="INR">INR (₹)</option>
                <option value="USD">USD ($)</option>
                <option value="EUR">EUR (€)</option>
              </select>
            </div>
            <div>
              <label className="block text-sm font-medium mb-1">Payment Timeout (minutes)</label>
              <Input
                type="number"
                defaultValue="15"
                placeholder="15"
              />
            </div>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <label className="block text-sm font-medium mb-1">Success URL</label>
              <Input
                defaultValue="https://yourdomain.com/payment/success"
                placeholder="Success redirect URL"
              />
            </div>
            <div>
              <label className="block text-sm font-medium mb-1">Failure URL</label>
              <Input
                defaultValue="https://yourdomain.com/payment/failure"
                placeholder="Failure redirect URL"
              />
            </div>
          </div>

          <div className="space-y-3">
            <h4 className="font-medium">Additional Settings</h4>
            <div className="flex items-center justify-between">
              <span className="text-sm">Send payment confirmation emails</span>
              <Switch defaultChecked />
            </div>
            <div className="flex items-center justify-between">
              <span className="text-sm">Enable auto-refunds for failed orders</span>
              <Switch />
            </div>
            <div className="flex items-center justify-between">
              <span className="text-sm">Log all payment transactions</span>
              <Switch defaultChecked />
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Test Payment */}
      <Card>
        <CardHeader>
          <CardTitle>Test Payment Gateway</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-gray-600">Test your payment configuration with a mock transaction</p>
            </div>
            <Button variant="outline">
              <CreditCard className="h-4 w-4 mr-2" />
              Run Test Payment
            </Button>
          </div>
        </CardContent>
      </Card>
    </div>
  );
};

export default AdminPayments;
