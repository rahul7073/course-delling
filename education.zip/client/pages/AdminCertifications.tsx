import React, { useState } from 'react';
import { Button } from '../components/ui/button';
import { Input } from '../components/ui/input';
import { Textarea } from '../components/ui/textarea';
import { Card, CardContent, CardHeader, CardTitle } from '../components/ui/card';
import { Badge } from '../components/ui/badge';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '../components/ui/dialog';
import { 
  Plus, 
  Upload, 
  Edit, 
  Trash2, 
  Download, 
  Award,
  FileText,
  Users,
  Calendar
} from 'lucide-react';

interface CertificationTemplate {
  id: string;
  courseId: string;
  courseName: string;
  templateName: string;
  backgroundImage: string;
  certificatePrice: number;
  passingScore: number;
  examQuestions: number;
  totalIssued: number;
  isActive: boolean;
  createdDate: string;
}

interface IssuedCertificate {
  id: string;
  templateId: string;
  userId: string;
  userName: string;
  userEmail: string;
  courseName: string;
  score: number;
  issueDate: string;
  certificateNumber: string;
  isPaid: boolean;
  downloadCount: number;
}

const AdminCertifications: React.FC = () => {
  const [templates, setTemplates] = useState<CertificationTemplate[]>([
    {
      id: '1',
      courseId: '1',
      courseName: 'Complete React Development Course',
      templateName: 'React Developer Certificate',
      backgroundImage: 'https://images.unsplash.com/photo-1606868306217-dbf5046868d2?w=400',
      certificatePrice: 10,
      passingScore: 90,
      examQuestions: 10,
      totalIssued: 45,
      isActive: true,
      createdDate: '2024-01-01'
    },
    {
      id: '2',
      courseId: '2',
      courseName: 'Machine Learning with Python',
      templateName: 'ML Specialist Certificate',
      backgroundImage: 'https://images.unsplash.com/photo-1606868306217-dbf5046868d2?w=400',
      certificatePrice: 10,
      passingScore: 90,
      examQuestions: 10,
      totalIssued: 23,
      isActive: true,
      createdDate: '2024-01-01'
    }
  ]);

  const [certificates, setCertificates] = useState<IssuedCertificate[]>([
    {
      id: '1',
      templateId: '1',
      userId: '1',
      userName: 'Rahul Sharma',
      userEmail: 'rahul.sharma@gmail.com',
      courseName: 'Complete React Development Course',
      score: 95,
      issueDate: '2024-01-15',
      certificateNumber: 'EDU-REACT-2024-001',
      isPaid: true,
      downloadCount: 3
    },
    {
      id: '2',
      templateId: '2',
      userId: '2',
      userName: 'Priya Patel',
      userEmail: 'priya.patel@gmail.com',
      courseName: 'Machine Learning with Python',
      score: 92,
      issueDate: '2024-01-14',
      certificateNumber: 'EDU-ML-2024-001',
      isPaid: true,
      downloadCount: 1
    },
    {
      id: '3',
      templateId: '1',
      userId: '3',
      userName: 'Amit Kumar',
      userEmail: 'amit.kumar@gmail.com',
      courseName: 'Complete React Development Course',
      score: 94,
      issueDate: '2024-01-13',
      certificateNumber: 'EDU-REACT-2024-002',
      isPaid: false,
      downloadCount: 0
    }
  ]);

  const [activeTab, setActiveTab] = useState<'templates' | 'issued'>('templates');
  const [isTemplateModalOpen, setIsTemplateModalOpen] = useState(false);
  const [selectedTemplate, setSelectedTemplate] = useState<CertificationTemplate | null>(null);
  const [formData, setFormData] = useState<Partial<CertificationTemplate>>({});

  const handleSaveTemplate = () => {
    if (selectedTemplate) {
      // Update existing template
      setTemplates(templates.map(template => 
        template.id === selectedTemplate.id 
          ? { ...template, ...formData }
          : template
      ));
    } else {
      // Add new template
      const newTemplate: CertificationTemplate = {
        id: Date.now().toString(),
        courseId: formData.courseId || '',
        courseName: formData.courseName || '',
        templateName: formData.templateName || '',
        backgroundImage: formData.backgroundImage || 'https://images.unsplash.com/photo-1606868306217-dbf5046868d2?w=400',
        certificatePrice: formData.certificatePrice || 10,
        passingScore: formData.passingScore || 90,
        examQuestions: formData.examQuestions || 10,
        totalIssued: 0,
        isActive: true,
        createdDate: new Date().toISOString().split('T')[0]
      };
      setTemplates([...templates, newTemplate]);
    }
    setIsTemplateModalOpen(false);
    setFormData({});
    setSelectedTemplate(null);
  };

  const handleEditTemplate = (template: CertificationTemplate) => {
    setSelectedTemplate(template);
    setFormData(template);
    setIsTemplateModalOpen(true);
  };

  const handleDeleteTemplate = (templateId: string) => {
    if (window.confirm('Are you sure you want to delete this template?')) {
      setTemplates(templates.filter(t => t.id !== templateId));
    }
  };

  const toggleTemplateStatus = (templateId: string) => {
    setTemplates(templates.map(template =>
      template.id === templateId
        ? { ...template, isActive: !template.isActive }
        : template
    ));
  };

  const TemplateForm = () => (
    <div className="space-y-4">
      <div className="grid grid-cols-2 gap-4">
        <div>
          <label className="block text-sm font-medium mb-1">Course ID</label>
          <Input
            value={formData.courseId || ''}
            onChange={(e) => setFormData({ ...formData, courseId: e.target.value })}
            placeholder="Enter course ID"
          />
        </div>
        <div>
          <label className="block text-sm font-medium mb-1">Course Name</label>
          <Input
            value={formData.courseName || ''}
            onChange={(e) => setFormData({ ...formData, courseName: e.target.value })}
            placeholder="Enter course name"
          />
        </div>
      </div>
      
      <div>
        <label className="block text-sm font-medium mb-1">Certificate Template Name</label>
        <Input
          value={formData.templateName || ''}
          onChange={(e) => setFormData({ ...formData, templateName: e.target.value })}
          placeholder="e.g., React Developer Certificate"
        />
      </div>
      
      <div>
        <label className="block text-sm font-medium mb-1">Background Image URL</label>
        <Input
          value={formData.backgroundImage || ''}
          onChange={(e) => setFormData({ ...formData, backgroundImage: e.target.value })}
          placeholder="Certificate background image URL"
        />
      </div>
      
      <div className="grid grid-cols-3 gap-4">
        <div>
          <label className="block text-sm font-medium mb-1">Certificate Price (₹)</label>
          <Input
            type="number"
            value={formData.certificatePrice || ''}
            onChange={(e) => setFormData({ ...formData, certificatePrice: Number(e.target.value) })}
            placeholder="10"
          />
        </div>
        <div>
          <label className="block text-sm font-medium mb-1">Passing Score (%)</label>
          <Input
            type="number"
            value={formData.passingScore || ''}
            onChange={(e) => setFormData({ ...formData, passingScore: Number(e.target.value) })}
            placeholder="90"
          />
        </div>
        <div>
          <label className="block text-sm font-medium mb-1">Exam Questions</label>
          <Input
            type="number"
            value={formData.examQuestions || ''}
            onChange={(e) => setFormData({ ...formData, examQuestions: Number(e.target.value) })}
            placeholder="10"
          />
        </div>
      </div>
      
      <div className="flex justify-end space-x-2">
        <Button variant="outline" onClick={() => {
          setIsTemplateModalOpen(false);
          setFormData({});
          setSelectedTemplate(null);
        }}>
          Cancel
        </Button>
        <Button onClick={handleSaveTemplate}>
          {selectedTemplate ? 'Update Template' : 'Create Template'}
        </Button>
      </div>
    </div>
  );

  const statsCards = [
    { title: 'Total Templates', value: templates.length, icon: FileText },
    { title: 'Active Templates', value: templates.filter(t => t.isActive).length, icon: Award },
    { title: 'Certificates Issued', value: certificates.length, icon: Users },
    { title: 'Revenue', value: `₹${certificates.filter(c => c.isPaid).length * 10}`, icon: Download }
  ];

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-3xl font-bold text-gray-900">Certification Management</h1>
          <p className="text-gray-600">Manage certificate templates and issued certificates</p>
        </div>
        {activeTab === 'templates' && (
          <Dialog open={isTemplateModalOpen} onOpenChange={setIsTemplateModalOpen}>
            <DialogTrigger asChild>
              <Button>
                <Plus className="h-4 w-4 mr-2" />
                New Template
              </Button>
            </DialogTrigger>
            <DialogContent className="max-w-2xl">
              <DialogHeader>
                <DialogTitle>
                  {selectedTemplate ? 'Edit Certificate Template' : 'Create Certificate Template'}
                </DialogTitle>
              </DialogHeader>
              <TemplateForm />
            </DialogContent>
          </Dialog>
        )}
      </div>

      {/* Stats Cards */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        {statsCards.map((stat, index) => (
          <Card key={index}>
            <CardContent className="pt-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-gray-600">{stat.title}</p>
                  <p className="text-2xl font-bold">{stat.value}</p>
                </div>
                <stat.icon className="h-8 w-8 text-gray-400" />
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      {/* Tabs */}
      <div className="border-b">
        <nav className="-mb-px flex space-x-8">
          <button
            onClick={() => setActiveTab('templates')}
            className={`py-2 px-1 border-b-2 font-medium text-sm ${
              activeTab === 'templates'
                ? 'border-blue-500 text-blue-600'
                : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'
            }`}
          >
            Certificate Templates ({templates.length})
          </button>
          <button
            onClick={() => setActiveTab('issued')}
            className={`py-2 px-1 border-b-2 font-medium text-sm ${
              activeTab === 'issued'
                ? 'border-blue-500 text-blue-600'
                : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'
            }`}
          >
            Issued Certificates ({certificates.length})
          </button>
        </nav>
      </div>

      {/* Templates Tab */}
      {activeTab === 'templates' && (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {templates.map((template) => (
            <Card key={template.id}>
              <div className="relative">
                <img
                  src={template.backgroundImage}
                  alt={template.templateName}
                  className="w-full h-48 object-cover rounded-t-lg"
                />
                <div className="absolute top-2 right-2">
                  <Badge variant={template.isActive ? 'default' : 'secondary'}>
                    {template.isActive ? 'Active' : 'Inactive'}
                  </Badge>
                </div>
              </div>
              
              <CardContent className="p-4">
                <h3 className="font-semibold text-lg mb-2">{template.templateName}</h3>
                <p className="text-gray-600 text-sm mb-3">{template.courseName}</p>
                
                <div className="space-y-2 text-sm">
                  <div className="flex justify-between">
                    <span className="text-gray-600">Price:</span>
                    <span className="font-medium">₹{template.certificatePrice}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-gray-600">Passing Score:</span>
                    <span className="font-medium">{template.passingScore}%</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-gray-600">Questions:</span>
                    <span className="font-medium">{template.examQuestions}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-gray-600">Issued:</span>
                    <span className="font-medium">{template.totalIssued}</span>
                  </div>
                </div>
                
                <div className="flex items-center space-x-2 mt-4">
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => handleEditTemplate(template)}
                    className="flex-1"
                  >
                    <Edit className="h-4 w-4 mr-1" />
                    Edit
                  </Button>
                  <Button
                    variant={template.isActive ? "secondary" : "default"}
                    size="sm"
                    onClick={() => toggleTemplateStatus(template.id)}
                  >
                    {template.isActive ? 'Deactivate' : 'Activate'}
                  </Button>
                  <Button
                    variant="destructive"
                    size="sm"
                    onClick={() => handleDeleteTemplate(template.id)}
                  >
                    <Trash2 className="h-4 w-4" />
                  </Button>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      )}

      {/* Issued Certificates Tab */}
      {activeTab === 'issued' && (
        <Card>
          <CardHeader>
            <CardTitle>Issued Certificates ({certificates.length})</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="overflow-x-auto">
              <table className="w-full">
                <thead>
                  <tr className="border-b">
                    <th className="text-left p-4">Certificate No.</th>
                    <th className="text-left p-4">Student</th>
                    <th className="text-left p-4">Course</th>
                    <th className="text-left p-4">Score</th>
                    <th className="text-left p-4">Issue Date</th>
                    <th className="text-left p-4">Payment</th>
                    <th className="text-left p-4">Downloads</th>
                    <th className="text-left p-4">Actions</th>
                  </tr>
                </thead>
                <tbody>
                  {certificates.map((cert) => (
                    <tr key={cert.id} className="border-b hover:bg-gray-50">
                      <td className="p-4">
                        <span className="font-mono text-sm">{cert.certificateNumber}</span>
                      </td>
                      <td className="p-4">
                        <div>
                          <p className="font-medium">{cert.userName}</p>
                          <p className="text-sm text-gray-600">{cert.userEmail}</p>
                        </div>
                      </td>
                      <td className="p-4">
                        <span className="text-sm">{cert.courseName}</span>
                      </td>
                      <td className="p-4">
                        <Badge variant="default">{cert.score}%</Badge>
                      </td>
                      <td className="p-4">
                        <span className="text-sm">{new Date(cert.issueDate).toLocaleDateString()}</span>
                      </td>
                      <td className="p-4">
                        <Badge variant={cert.isPaid ? 'default' : 'destructive'}>
                          {cert.isPaid ? 'Paid' : 'Unpaid'}
                        </Badge>
                      </td>
                      <td className="p-4">
                        <span className="text-sm">{cert.downloadCount}</span>
                      </td>
                      <td className="p-4">
                        <div className="flex items-center space-x-2">
                          <Button variant="outline" size="sm">
                            <Download className="h-4 w-4 mr-1" />
                            Download
                          </Button>
                          <Button variant="outline" size="sm">
                            <Edit className="h-4 w-4" />
                          </Button>
                        </div>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  );
};

export default AdminCertifications;
