import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { RadioGroup, RadioGroupItem } from '@/components/ui/radio-group';
import { Label } from '@/components/ui/label';
import { useToast } from '@/hooks/use-toast';
import { useAuth } from '../contexts/AuthContext';
import { SAMPLE_COURSES } from '@shared/types';
import { CertificatePaymentModal } from '../components/CertificatePaymentModal';
import {
  Award,
  Clock,
  Users,
  Star,
  CheckCircle,
  Play,
  Download,
  CreditCard,
  BookOpen,
  Target,
  TrendingUp,
  Lock,
  X
} from 'lucide-react';

interface Question {
  id: string;
  question: string;
  options: string[];
  correctAnswer: number;
}

interface Exam {
  courseId: string;
  questions: Question[];
  duration: number; // in minutes
  passingScore: number; // percentage
}

const examData: { [key: string]: Exam } = {
  '1': { // React Course
    courseId: '1',
    duration: 45,
    passingScore: 90,
    questions: [
      {
        id: '1-1',
        question: 'What is React?',
        options: [
          'A database management system',
          'A JavaScript library for building user interfaces',
          'A programming language',
          'A web server'
        ],
        correctAnswer: 1
      },
      {
        id: '1-2',
        question: 'What is JSX?',
        options: [
          'A CSS framework',
          'A database query language',
          'A syntax extension for JavaScript',
          'A testing library'
        ],
        correctAnswer: 2
      },
      {
        id: '1-3',
        question: 'Which hook is used for managing state in functional components?',
        options: [
          'useEffect',
          'useState',
          'useContext',
          'useReducer'
        ],
        correctAnswer: 1
      },
      {
        id: '1-4',
        question: 'What is the virtual DOM?',
        options: [
          'A real DOM element',
          'A JavaScript representation of the real DOM',
          'A CSS selector',
          'A React component'
        ],
        correctAnswer: 1
      },
      {
        id: '1-5',
        question: 'How do you pass data from parent to child component?',
        options: [
          'Using state',
          'Using context',
          'Using props',
          'Using refs'
        ],
        correctAnswer: 2
      },
      {
        id: '1-6',
        question: 'What is useEffect used for?',
        options: [
          'Managing state',
          'Handling side effects',
          'Creating components',
          'Styling components'
        ],
        correctAnswer: 1
      },
      {
        id: '1-7',
        question: 'What is the correct way to update state in React?',
        options: [
          'Directly mutating state',
          'Using setState or state setter function',
          'Using innerHTML',
          'Using jQuery'
        ],
        correctAnswer: 1
      },
      {
        id: '1-8',
        question: 'What is React Router used for?',
        options: [
          'State management',
          'Component styling',
          'Client-side routing',
          'API calls'
        ],
        correctAnswer: 2
      },
      {
        id: '1-9',
        question: 'What is the purpose of keys in React lists?',
        options: [
          'For styling',
          'For identification and optimization',
          'For event handling',
          'For data storage'
        ],
        correctAnswer: 1
      },
      {
        id: '1-10',
        question: 'What is Redux?',
        options: [
          'A CSS framework',
          'A state management library',
          'A testing framework',
          'A component library'
        ],
        correctAnswer: 1
      }
    ]
  },
  '2': { // Machine Learning Course
    courseId: '2',
    duration: 60,
    passingScore: 90,
    questions: [
      {
        id: '2-1',
        question: 'What is Machine Learning?',
        options: [
          'A programming language',
          'A subset of AI that enables computers to learn without explicit programming',
          'A database system',
          'A web framework'
        ],
        correctAnswer: 1
      },
      {
        id: '2-2',
        question: 'What are the main types of machine learning?',
        options: [
          'Supervised, Unsupervised, Reinforcement',
          'Frontend, Backend, Database',
          'Linear, Non-linear, Exponential',
          'Static, Dynamic, Interactive'
        ],
        correctAnswer: 0
      },
      {
        id: '2-3',
        question: 'What is supervised learning?',
        options: [
          'Learning without labeled data',
          'Learning with labeled training data',
          'Learning through trial and error',
          'Learning without any data'
        ],
        correctAnswer: 1
      },
      {
        id: '2-4',
        question: 'Which Python library is commonly used for machine learning?',
        options: [
          'React',
          'Angular',
          'Scikit-learn',
          'jQuery'
        ],
        correctAnswer: 2
      },
      {
        id: '2-5',
        question: 'What is overfitting in machine learning?',
        options: [
          'When a model performs well on training data but poorly on new data',
          'When a model is too simple',
          'When training takes too long',
          'When the dataset is too small'
        ],
        correctAnswer: 0
      },
      {
        id: '2-6',
        question: 'What is the purpose of train-test split?',
        options: [
          'To make training faster',
          'To evaluate model performance on unseen data',
          'To reduce dataset size',
          'To visualize data'
        ],
        correctAnswer: 1
      },
      {
        id: '2-7',
        question: 'What is linear regression used for?',
        options: [
          'Classification tasks',
          'Predicting continuous numerical values',
          'Image recognition',
          'Text analysis'
        ],
        correctAnswer: 1
      },
      {
        id: '2-8',
        question: 'What is cross-validation?',
        options: [
          'A technique to assess model performance',
          'A data cleaning method',
          'A visualization technique',
          'A feature selection method'
        ],
        correctAnswer: 0
      },
      {
        id: '2-9',
        question: 'What is a neural network?',
        options: [
          'A database structure',
          'A network of interconnected nodes that mimic the brain',
          'A programming paradigm',
          'A web protocol'
        ],
        correctAnswer: 1
      },
      {
        id: '2-10',
        question: 'What is the purpose of feature scaling?',
        options: [
          'To reduce dataset size',
          'To normalize features to similar scales',
          'To add new features',
          'To remove outliers'
        ],
        correctAnswer: 1
      }
    ]
  }
};

export default function Certifications() {
  const [selectedExam, setSelectedExam] = useState<string | null>(null);
  const [currentQuestion, setCurrentQuestion] = useState(0);
  const [answers, setAnswers] = useState<{ [key: string]: number }>({});
  const [showResults, setShowResults] = useState(false);
  const [examScore, setExamScore] = useState(0);
  const [timeLeft, setTimeLeft] = useState(0);
  const [examStarted, setExamStarted] = useState(false);
  const [isPaymentModalOpen, setIsPaymentModalOpen] = useState(false);
  const [completedExams, setCompletedExams] = useState<{ [key: string]: number }>({});

  const { user, isAuthenticated } = useAuth();
  const { toast } = useToast();

  // Timer effect
  React.useEffect(() => {
    if (examStarted && timeLeft > 0) {
      const timer = setTimeout(() => setTimeLeft(timeLeft - 1), 1000);
      return () => clearTimeout(timer);
    } else if (timeLeft === 0 && examStarted) {
      handleSubmitExam();
    }
  }, [timeLeft, examStarted]);

  const startExam = (courseId: string) => {
    if (!isAuthenticated) {
      toast({
        title: "Please sign in",
        description: "You need to be logged in to take the certification exam.",
        variant: "destructive",
      });
      return;
    }

    const exam = examData[courseId];
    if (!exam) return;

    setSelectedExam(courseId);
    setCurrentQuestion(0);
    setAnswers({});
    setShowResults(false);
    setTimeLeft(exam.duration * 60); // Convert to seconds
    setExamStarted(true);
  };

  const handleAnswerSelect = (questionId: string, answerIndex: number) => {
    setAnswers(prev => ({
      ...prev,
      [questionId]: answerIndex
    }));
  };

  const handleNextQuestion = () => {
    const exam = examData[selectedExam!];
    if (currentQuestion < exam.questions.length - 1) {
      setCurrentQuestion(currentQuestion + 1);
    }
  };

  const handlePrevQuestion = () => {
    if (currentQuestion > 0) {
      setCurrentQuestion(currentQuestion - 1);
    }
  };

  const handleSubmitExam = () => {
    const exam = examData[selectedExam!];
    let correctAnswers = 0;

    exam.questions.forEach(question => {
      if (answers[question.id] === question.correctAnswer) {
        correctAnswers++;
      }
    });

    const score = Math.round((correctAnswers / exam.questions.length) * 100);
    setExamScore(score);
    setShowResults(true);
    setExamStarted(false);

    // Save completed exam
    setCompletedExams(prev => ({
      ...prev,
      [selectedExam!]: score
    }));

    if (score >= exam.passingScore) {
      toast({
        title: "Congratulations! 🎉",
        description: `You passed with ${score}%! You can now download your certificate.`,
      });
    } else {
      toast({
        title: "Try again",
        description: `You scored ${score}%. You need ${exam.passingScore}% to pass.`,
        variant: "destructive",
      });
    }
  };

  const handleDownloadCertificate = () => {
    setIsPaymentModalOpen(true);
  };

  const formatTime = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins}:${secs.toString().padStart(2, '0')}`;
  };

  // Get available certifications
  const availableCertifications = SAMPLE_COURSES;

  if (selectedExam && !showResults) {
    const exam = examData[selectedExam];
    const course = SAMPLE_COURSES.find(c => c.id === selectedExam);
    const currentQ = exam.questions[currentQuestion];
    const progress = ((currentQuestion + 1) / exam.questions.length) * 100;

    return (
      <div className="min-h-screen py-8">
        <div className="container mx-auto px-4 max-w-4xl">
          {/* Exam Header */}
          <Card className="mb-6">
            <CardContent className="pt-6">
              <div className="flex items-center justify-between mb-4">
                <div>
                  <h1 className="text-2xl font-bold">{course?.title} Certification Exam</h1>
                  <p className="text-muted-foreground">
                    Question {currentQuestion + 1} of {exam.questions.length}
                  </p>
                </div>
                <div className="text-right">
                  <div className="text-2xl font-bold text-red-500">
                    {formatTime(timeLeft)}
                  </div>
                  <p className="text-sm text-muted-foreground">Time remaining</p>
                </div>
              </div>
              <Progress value={progress} className="w-full" />
            </CardContent>
          </Card>

          {/* Question */}
          <Card className="mb-6">
            <CardHeader>
              <CardTitle>Question {currentQuestion + 1}</CardTitle>
              <CardDescription>{currentQ.question}</CardDescription>
            </CardHeader>
            <CardContent>
              <RadioGroup
                value={answers[currentQ.id]?.toString()}
                onValueChange={(value) => handleAnswerSelect(currentQ.id, parseInt(value))}
              >
                {currentQ.options.map((option, index) => (
                  <div key={index} className="flex items-center space-x-2">
                    <RadioGroupItem value={index.toString()} id={`option-${index}`} />
                    <Label htmlFor={`option-${index}`} className="flex-1 cursor-pointer">
                      {option}
                    </Label>
                  </div>
                ))}
              </RadioGroup>
            </CardContent>
          </Card>

          {/* Navigation */}
          <div className="flex justify-between">
            <Button
              variant="outline"
              onClick={handlePrevQuestion}
              disabled={currentQuestion === 0}
            >
              Previous
            </Button>
            
            <div className="flex gap-2">
              {currentQuestion === exam.questions.length - 1 ? (
                <Button onClick={handleSubmitExam}>
                  Submit Exam
                </Button>
              ) : (
                <Button 
                  onClick={handleNextQuestion}
                  disabled={answers[currentQ.id] === undefined}
                >
                  Next
                </Button>
              )}
            </div>
          </div>
        </div>
      </div>
    );
  }

  // Results screen
  if (showResults) {
    const exam = examData[selectedExam!];
    const course = SAMPLE_COURSES.find(c => c.id === selectedExam);
    const passed = examScore >= exam.passingScore;

    return (
      <div className="min-h-screen py-8">
        <div className="container mx-auto px-4 max-w-2xl">
          <Card className="text-center">
            <CardContent className="pt-6">
              <div className={`w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4 ${
                passed ? 'bg-success/10' : 'bg-destructive/10'
              }`}>
                {passed ? (
                  <Award className="w-8 h-8 text-success" />
                ) : (
                  <X className="w-8 h-8 text-destructive" />
                )}
              </div>
              
              <h2 className="text-2xl font-bold mb-2">
                {passed ? 'Congratulations!' : 'Better luck next time!'}
              </h2>
              
              <p className="text-muted-foreground mb-6">
                You scored {examScore}% on the {course?.title} certification exam.
                {passed 
                  ? ' You can now download your certificate!' 
                  : ` You need ${exam.passingScore}% to pass.`}
              </p>

              <div className="space-y-4">
                {passed && (
                  <Button onClick={handleDownloadCertificate} className="w-full">
                    <Download className="w-4 h-4 mr-2" />
                    Download Certificate (₹10)
                  </Button>
                )}
                
                <Button 
                  variant="outline" 
                  onClick={() => startExam(selectedExam!)}
                  className="w-full"
                >
                  Retake Exam
                </Button>
                
                <Button 
                  variant="ghost" 
                  onClick={() => setSelectedExam(null)}
                  className="w-full"
                >
                  Back to Certifications
                </Button>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Payment Modal for Certificate */}
        <CertificatePaymentModal
          isOpen={isPaymentModalOpen}
          onClose={() => setIsPaymentModalOpen(false)}
          courseName={course?.title || ''}
          onSuccess={() => {
            setIsPaymentModalOpen(false);
          }}
        />
      </div>
    );
  }

  return (
    <div className="min-h-screen py-12">
      <div className="container mx-auto px-4">
        {/* Header */}
        <div className="text-center mb-12">
          <h1 className="text-4xl lg:text-5xl font-bold mb-4">EduMaster Certifications</h1>
          <p className="text-xl text-muted-foreground mb-6 max-w-3xl mx-auto">
            Validate your skills with industry-recognized certifications. Take our comprehensive exams and 
            get certified by EduMaster to boost your career prospects.
          </p>
          <Badge className="bg-primary/10 text-primary">
            90% passing score required • ₹10 certificate fee
          </Badge>
        </div>

        {/* Certification Process */}
        <div className="grid md:grid-cols-3 gap-6 mb-12">
          <Card className="text-center">
            <CardContent className="pt-6">
              <div className="w-12 h-12 bg-blue-100 rounded-full flex items-center justify-center mx-auto mb-4">
                <BookOpen className="w-6 h-6 text-blue-600" />
              </div>
              <h3 className="font-semibold mb-2">Choose Certification</h3>
              <p className="text-sm text-muted-foreground">
                Select the course you want to get certified in
              </p>
            </CardContent>
          </Card>

          <Card className="text-center">
            <CardContent className="pt-6">
              <div className="w-12 h-12 bg-orange-100 rounded-full flex items-center justify-center mx-auto mb-4">
                <Target className="w-6 h-6 text-orange-600" />
              </div>
              <h3 className="font-semibold mb-2">Take the Exam</h3>
              <p className="text-sm text-muted-foreground">
                Complete the comprehensive exam with 90% score
              </p>
            </CardContent>
          </Card>

          <Card className="text-center">
            <CardContent className="pt-6">
              <div className="w-12 h-12 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-4">
                <Award className="w-6 h-6 text-green-600" />
              </div>
              <h3 className="font-semibold mb-2">Get Certified</h3>
              <p className="text-sm text-muted-foreground">
                Download your certificate for ₹10 and share it
              </p>
            </CardContent>
          </Card>
        </div>

        {/* Available Certifications */}
        <div className="mb-8">
          <h2 className="text-2xl font-bold mb-6">Available Certifications</h2>
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
            {availableCertifications.map((course) => {
              const hasExam = examData[course.id];
              const userScore = completedExams[course.id];
              const passingScore = hasExam?.passingScore || 90;
              const hasPassed = userScore && userScore >= passingScore;

              return (
                <Card key={course.id} className="relative overflow-hidden">
                  <CardHeader>
                    <div className="flex items-center justify-between mb-2">
                      <Badge variant="secondary">{course.category}</Badge>
                      {hasPassed && (
                        <Badge className="bg-success text-success-foreground">
                          <CheckCircle className="w-3 h-3 mr-1" />
                          Certified
                        </Badge>
                      )}
                    </div>
                    <CardTitle className="text-lg">{course.title}</CardTitle>
                    <CardDescription className="line-clamp-2">
                      {course.shortDescription}
                    </CardDescription>
                  </CardHeader>

                  <CardContent>
                    <div className="space-y-3">
                      {/* Course Stats */}
                      <div className="flex items-center justify-between text-sm text-muted-foreground">
                        <div className="flex items-center gap-1">
                          <Star className="w-3 h-3 fill-yellow-400 text-yellow-400" />
                          <span>{course.rating}</span>
                        </div>
                        <div className="flex items-center gap-1">
                          <Users className="w-3 h-3" />
                          <span>{course.totalStudents.toLocaleString()}</span>
                        </div>
                      </div>

                      {/* Exam Info */}
                      {hasExam && (
                        <div className="space-y-2">
                          <div className="flex items-center justify-between text-sm">
                            <span className="flex items-center gap-1">
                              <Clock className="w-3 h-3" />
                              {hasExam.duration} minutes
                            </span>
                            <span>{hasExam.questions.length} questions</span>
                          </div>
                          
                          {userScore && (
                            <div className="text-sm">
                              <span className="text-muted-foreground">Last Score: </span>
                              <span className={userScore >= passingScore ? 'text-success font-medium' : 'text-destructive'}>
                                {userScore}%
                              </span>
                            </div>
                          )}
                        </div>
                      )}

                      {/* Action Button */}
                      <div className="pt-2">
                        {hasExam ? (
                          <Button 
                            className="w-full" 
                            onClick={() => startExam(course.id)}
                            variant={hasPassed ? "outline" : "default"}
                          >
                            {hasPassed ? (
                              <>
                                <Award className="w-4 h-4 mr-2" />
                                Retake Exam
                              </>
                            ) : userScore ? (
                              <>
                                <Play className="w-4 h-4 mr-2" />
                                Retake Exam
                              </>
                            ) : (
                              <>
                                <Play className="w-4 h-4 mr-2" />
                                Start Exam
                              </>
                            )}
                          </Button>
                        ) : (
                          <Button className="w-full" disabled>
                            <Lock className="w-4 h-4 mr-2" />
                            Coming Soon
                          </Button>
                        )}
                      </div>

                      {/* Download Certificate */}
                      {hasPassed && (
                        <Button 
                          variant="outline" 
                          className="w-full"
                          onClick={handleDownloadCertificate}
                        >
                          <Download className="w-4 h-4 mr-2" />
                          Download Certificate (₹10)
                        </Button>
                      )}
                    </div>
                  </CardContent>

                  {/* Course Image */}
                  <div className="absolute top-4 right-4 w-12 h-12 rounded overflow-hidden opacity-20">
                    <img
                      src={course.thumbnail}
                      alt={course.title}
                      className="w-full h-full object-cover"
                    />
                  </div>
                </Card>
              );
            })}
          </div>
        </div>

        {/* Stats Section */}
        {isAuthenticated && Object.keys(completedExams).length > 0 && (
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <TrendingUp className="w-5 h-5" />
                Your Certification Progress
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid md:grid-cols-3 gap-4">
                <div className="text-center">
                  <div className="text-2xl font-bold text-primary">
                    {Object.keys(completedExams).length}
                  </div>
                  <p className="text-sm text-muted-foreground">Exams Taken</p>
                </div>
                <div className="text-center">
                  <div className="text-2xl font-bold text-success">
                    {Object.values(completedExams).filter(score => score >= 90).length}
                  </div>
                  <p className="text-sm text-muted-foreground">Certifications Earned</p>
                </div>
                <div className="text-center">
                  <div className="text-2xl font-bold text-orange-500">
                    {Math.round(Object.values(completedExams).reduce((a, b) => a + b, 0) / Object.values(completedExams).length) || 0}%
                  </div>
                  <p className="text-sm text-muted-foreground">Average Score</p>
                </div>
              </div>
            </CardContent>
          </Card>
        )}
      </div>
    </div>
  );
}
