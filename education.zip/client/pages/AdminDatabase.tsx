import React, { useState, useEffect } from 'react';
import { Button } from '../components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '../components/ui/card';
import { Badge } from '../components/ui/badge';
import { Progress } from '../components/ui/progress';
import { useToast } from '@/hooks/use-toast';
import { apiDatabaseService } from '../services/ApiDatabaseService';
import { fileStorageService } from '../services/FileStorageService';
import { DataMigration } from '../utils/dataMigration';
import {
  Database,
  Upload,
  Download,
  RefreshCw,
  CheckCircle,
  AlertTriangle,
  FileText,
  HardDrive,
  Trash2,
  Settings,
  Activity,
  Users,
  BookOpen,
  ShoppingCart
} from 'lucide-react';

const AdminDatabase: React.FC = () => {
  const [loading, setLoading] = useState(false);
  const [migrationStatus, setMigrationStatus] = useState<any>(null);
  const [storageStats, setStorageStats] = useState<any>(null);
  const [dbStats, setDbStats] = useState<any>(null);
  const [connectionStatus, setConnectionStatus] = useState<boolean | null>(null);
  const { toast } = useToast();

  // Load initial data
  useEffect(() => {
    loadDatabaseStats();
    checkConnection();
    loadMigrationStatus();
    loadStorageStats();
  }, []);

  const checkConnection = async () => {
    try {
      const isConnected = await apiDatabaseService.testConnection();
      setConnectionStatus(isConnected);
    } catch (error) {
      setConnectionStatus(false);
    }
  };

  const loadDatabaseStats = async () => {
    try {
      const [coursesResult, ordersResult] = await Promise.all([
        apiDatabaseService.getCourses(),
        apiDatabaseService.getOrders()
      ]);

      setDbStats({
        courses: coursesResult.success ? coursesResult.data?.total || 0 : 0,
        orders: ordersResult.success ? ordersResult.data?.total || 0 : 0
      });
    } catch (error) {
      console.error('Failed to load database stats:', error);
    }
  };

  const loadMigrationStatus = () => {
    const status = DataMigration.getMigrationStatus();
    setMigrationStatus(status);
  };

  const loadStorageStats = () => {
    const stats = fileStorageService.getStorageStats();
    setStorageStats(stats);
  };

  const handleMigration = async () => {
    try {
      setLoading(true);
      toast({
        title: "🔄 Starting Migration",
        description: "Moving data from localStorage to database...",
      });

      const result = await DataMigration.migrateAllData();
      
      if (result.success) {
        DataMigration.markMigrationCompleted();
        toast({
          title: "✅ Migration Completed",
          description: `Successfully migrated ${result.migratedCourses} courses, ${result.migratedOrders} orders, and ${result.migratedFiles} files.`,
        });
        
        // Refresh all stats
        loadDatabaseStats();
        loadMigrationStatus();
        loadStorageStats();
      } else {
        toast({
          title: "⚠️ Migration Completed with Errors",
          description: `Migrated some data but encountered ${result.errors.length} errors. Check console for details.`,
          variant: "destructive"
        });
        console.error('Migration errors:', result.errors);
      }
    } catch (error) {
      toast({
        title: "❌ Migration Failed",
        description: error instanceof Error ? error.message : 'Unknown error',
        variant: "destructive"
      });
    } finally {
      setLoading(false);
    }
  };

  const handleCleanupFiles = async () => {
    try {
      setLoading(true);
      const cleanedCount = await fileStorageService.cleanupOrphanedFiles();
      
      toast({
        title: "🧹 Cleanup Completed",
        description: `Removed ${cleanedCount} orphaned files.`,
      });
      
      loadStorageStats();
    } catch (error) {
      toast({
        title: "❌ Cleanup Failed",
        description: error instanceof Error ? error.message : 'Unknown error',
        variant: "destructive"
      });
    } finally {
      setLoading(false);
    }
  };

  const formatBytes = (bytes: number): string => {
    if (bytes === 0) return '0 Bytes';
    const k = 1024;
    const sizes = ['Bytes', 'KB', 'MB', 'GB'];
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold">Database Management</h1>
          <p className="text-gray-600 mt-2">Manage your database connection, data migration, and storage</p>
        </div>
        
        <div className="flex items-center space-x-2">
          <div className="flex items-center space-x-2">
            <div className={`w-3 h-3 rounded-full ${
              connectionStatus === true ? 'bg-green-500' : 
              connectionStatus === false ? 'bg-red-500' : 'bg-yellow-500'
            }`} />
            <span className="text-sm font-medium">
              {connectionStatus === true ? 'Connected' : 
               connectionStatus === false ? 'Disconnected' : 'Checking...'}
            </span>
          </div>
          <Button
            variant="outline"
            size="sm"
            onClick={checkConnection}
            disabled={loading}
          >
            <RefreshCw className="w-4 h-4 mr-2" />
            Refresh
          </Button>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        {/* Database Stats */}
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Courses</CardTitle>
            <BookOpen className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{dbStats?.courses || 0}</div>
            <p className="text-xs text-muted-foreground">In database</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Orders</CardTitle>
            <ShoppingCart className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{dbStats?.orders || 0}</div>
            <p className="text-xs text-muted-foreground">In database</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Files</CardTitle>
            <FileText className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{storageStats?.totalFiles || 0}</div>
            <p className="text-xs text-muted-foreground">Stored locally</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Storage</CardTitle>
            <HardDrive className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">
              {storageStats ? formatBytes(storageStats.totalSize) : '0 B'}
            </div>
            <p className="text-xs text-muted-foreground">Used space</p>
          </CardContent>
        </Card>
      </div>

      {/* Migration Section */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center space-x-2">
            <Database className="w-5 h-5" />
            <span>Data Migration</span>
          </CardTitle>
          <CardDescription>
            Migrate your data from localStorage to the database
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="flex items-center justify-between">
            <div>
              <div className="font-medium">Migration Status</div>
              <div className="text-sm text-gray-600">
                {migrationStatus?.needed ? 
                  'Migration needed - You have data in localStorage that can be moved to the database' :
                  migrationStatus?.lastMigration ? 
                    `Last migrated: ${new Date(migrationStatus.lastMigration).toLocaleString()}` :
                    'No migration needed'
                }
              </div>
            </div>
            <Badge variant={migrationStatus?.needed ? "destructive" : "default"}>
              {migrationStatus?.needed ? 
                <AlertTriangle className="w-3 h-3 mr-1" /> :
                <CheckCircle className="w-3 h-3 mr-1" />
              }
              {migrationStatus?.needed ? 'Needed' : 'Complete'}
            </Badge>
          </div>

          {migrationStatus?.needed && (
            <Button
              onClick={handleMigration}
              disabled={loading}
              className="w-full"
            >
              {loading ? (
                <RefreshCw className="w-4 h-4 mr-2 animate-spin" />
              ) : (
                <Upload className="w-4 h-4 mr-2" />
              )}
              Start Migration
            </Button>
          )}
        </CardContent>
      </Card>

      {/* Storage Management */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center space-x-2">
            <HardDrive className="w-5 h-5" />
            <span>Storage Management</span>
          </CardTitle>
          <CardDescription>
            Manage your file storage and cleanup orphaned files
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          {storageStats && (
            <div className="space-y-3">
              <div>
                <div className="flex justify-between text-sm font-medium mb-1">
                  <span>Storage Usage</span>
                  <span>{formatBytes(storageStats.totalSize)}</span>
                </div>
                <Progress value={Math.min((storageStats.totalSize / (100 * 1024 * 1024)) * 100, 100)} />
                <div className="text-xs text-gray-500 mt-1">
                  {storageStats.totalFiles} files across {Object.keys(storageStats.folderStats).length} folders
                </div>
              </div>

              {Object.keys(storageStats.folderStats).length > 0 && (
                <div>
                  <div className="text-sm font-medium mb-2">Files by Category</div>
                  <div className="grid grid-cols-2 gap-2">
                    {Object.entries(storageStats.folderStats).map(([folder, count]) => (
                      <div key={folder} className="flex justify-between text-sm">
                        <span className="capitalize">{folder}</span>
                        <span>{count} files</span>
                      </div>
                    ))}
                  </div>
                </div>
              )}
            </div>
          )}

          <Button
            variant="outline"
            onClick={handleCleanupFiles}
            disabled={loading}
            className="w-full"
          >
            {loading ? (
              <RefreshCw className="w-4 h-4 mr-2 animate-spin" />
            ) : (
              <Trash2 className="w-4 h-4 mr-2" />
            )}
            Cleanup Orphaned Files
          </Button>
        </CardContent>
      </Card>

      {/* Database Connection */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center space-x-2">
            <Activity className="w-5 h-5" />
            <span>Database Connection</span>
          </CardTitle>
          <CardDescription>
            Monitor and manage your database connection
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="flex items-center justify-between">
            <div>
              <div className="font-medium">Connection Status</div>
              <div className="text-sm text-gray-600">
                {connectionStatus === true ? 
                  'Successfully connected to the database' :
                  connectionStatus === false ?
                    'Failed to connect to database' :
                    'Checking connection...'
                }
              </div>
            </div>
            <Badge variant={connectionStatus ? "default" : "destructive"}>
              {connectionStatus ? 
                <CheckCircle className="w-3 h-3 mr-1" /> :
                <AlertTriangle className="w-3 h-3 mr-1" />
              }
              {connectionStatus ? 'Connected' : 'Disconnected'}
            </Badge>
          </div>

          <div className="text-sm text-gray-600">
            <strong>Important:</strong> For production use, connect to a real database like Supabase. 
            You can connect to Supabase and other services through the MCP Servers panel.
          </div>
        </CardContent>
      </Card>
    </div>
  );
};

export default AdminDatabase;
