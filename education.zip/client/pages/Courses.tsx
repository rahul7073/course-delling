import React, { useState, useMemo, useEffect } from 'react';
import { Link, useSearchParams } from 'react-router-dom';
import { apiDatabaseService } from '../services/ApiDatabaseService';
import { Course } from '../../shared/database';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Checkbox } from '@/components/ui/checkbox';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Slider } from '@/components/ui/slider';
import { CourseCard } from '../components/CourseCard';
import { CATEGORIES, Course } from '@shared/types';
import CourseCleaner from '../components/CourseCleaner';
import { 
  Search, 
  Filter, 
  X, 
  Grid3X3, 
  List, 
  SlidersHorizontal,
  Star,
  Clock,
  TrendingUp,
  Users
} from 'lucide-react';

export default function Courses() {
  const [courses, setCourses] = useState<Course[]>([]);
  const [loading, setLoading] = useState(false);
  const [searchParams, setSearchParams] = useSearchParams();
  const [viewMode, setViewMode] = useState<'grid' | 'list'>('grid');
  const [showFilters, setShowFilters] = useState(false);

  // Filter states
  const [searchQuery, setSearchQuery] = useState(searchParams.get('search') || '');
  const [selectedCategories, setSelectedCategories] = useState<string[]>(
    searchParams.get('category') ? [searchParams.get('category')!] : []
  );
  const [selectedLevels, setSelectedLevels] = useState<string[]>([]);
  const [priceRange, setPriceRange] = useState<[number, number]>([0, 10000]);
  const [sortBy, setSortBy] = useState('popularity');
  const [showFreeOnly, setShowFreeOnly] = useState(searchParams.get('free') === 'true');

  // Load courses from database and merge with localStorage
  const loadCourses = async () => {
    try {
      setLoading(true);
      let allCourses: any[] = [];

      // First try to load from database
      const result = await apiDatabaseService.getCourses(true); // Only published courses

      if (result.success && result.data && result.data.data.length > 0) {
        allCourses = [...result.data.data];
        console.log(`✅ Loaded ${allCourses.length} courses from database`);
      }

      // Also check localStorage for any additional courses
      const localCourses = localStorage.getItem('edumaster_courses');
      if (localCourses) {
        const courses = JSON.parse(localCourses);
        const publishedLocalCourses = courses.filter((c: any) => c.isPublished);

        // Add localStorage courses that are not already in database
        publishedLocalCourses.forEach((localCourse: any) => {
          const existsInDb = allCourses.some(dbCourse => dbCourse.id === localCourse.id);
          if (!existsInDb) {
            allCourses.push(localCourse);
          }
        });

        console.log(`✅ Total courses after merging: ${allCourses.length}`);
      }

      setCourses(allCourses);

    } catch (error) {
      console.error('Error loading courses:', error);

      // Try localStorage as fallback on error
      const localCourses = localStorage.getItem('edumaster_courses');
      if (localCourses) {
        const courses = JSON.parse(localCourses);
        const publishedCourses = courses.filter((c: any) => c.isPublished);
        setCourses(publishedCourses);
        console.log(`Fallback: Loaded ${publishedCourses.length} courses from localStorage`);
      }
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadCourses();
  }, []);

  // Use courses from database
  const allCourses = courses;

  // Filter and sort courses
  const filteredCourses = useMemo(() => {
    let filtered = allCourses.filter(course => {
      // Search query
      if (searchQuery && !course.title.toLowerCase().includes(searchQuery.toLowerCase()) &&
          !course.description.toLowerCase().includes(searchQuery.toLowerCase()) &&
          !course.category.toLowerCase().includes(searchQuery.toLowerCase())) {
        return false;
      }

      // Category filter
      if (selectedCategories.length > 0 && !selectedCategories.includes(course.category)) {
        return false;
      }

      // Level filter
      if (selectedLevels.length > 0 && !selectedLevels.includes(course.level)) {
        return false;
      }

      // Price filter
      if (course.price < priceRange[0] || course.price > priceRange[1]) {
        return false;
      }

      // Free only filter
      if (showFreeOnly && !course.isFree) {
        return false;
      }

      return true;
    });

    // Sort courses
    switch (sortBy) {
      case 'price-low':
        filtered.sort((a, b) => a.price - b.price);
        break;
      case 'price-high':
        filtered.sort((a, b) => b.price - a.price);
        break;
      case 'rating':
        filtered.sort((a, b) => b.rating - a.rating);
        break;
      case 'newest':
        filtered.sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());
        break;
      case 'students':
        filtered.sort((a, b) => b.totalStudents - a.totalStudents);
        break;
      default: // popularity
        filtered.sort((a, b) => b.totalStudents - a.totalStudents);
    }

    return filtered;
  }, [allCourses, searchQuery, selectedCategories, selectedLevels, priceRange, sortBy, showFreeOnly]);

  const handleCategoryChange = (category: string, checked: boolean) => {
    if (checked) {
      setSelectedCategories([...selectedCategories, category]);
    } else {
      setSelectedCategories(selectedCategories.filter(c => c !== category));
    }
  };

  const handleLevelChange = (level: string, checked: boolean) => {
    if (checked) {
      setSelectedLevels([...selectedLevels, level]);
    } else {
      setSelectedLevels(selectedLevels.filter(l => l !== level));
    }
  };

  const clearFilters = () => {
    setSearchQuery('');
    setSelectedCategories([]);
    setSelectedLevels([]);
    setPriceRange([0, 200]);
    setShowFreeOnly(false);
    setSearchParams({});
  };

  const activeFiltersCount = selectedCategories.length + selectedLevels.length + 
    (showFreeOnly ? 1 : 0) + 
    (priceRange[0] > 0 || priceRange[1] < 200 ? 1 : 0);

  return (
    <div className="min-h-screen py-8">
      <div className="container mx-auto px-4">
        {/* Header */}
        <div className="mb-8">
          <div className="flex items-center justify-between mb-4">
            <div>
              <h1 className="text-3xl lg:text-4xl font-bold">All Courses</h1>
              <p className="text-muted-foreground mt-2">
                Discover {filteredCourses.length} courses to accelerate your learning
              </p>
            </div>
            
            {/* View Toggle */}
            <div className="hidden md:flex items-center space-x-2 bg-muted p-1 rounded-lg">
              <Button
                variant={viewMode === 'grid' ? 'default' : 'ghost'}
                size="sm"
                onClick={() => setViewMode('grid')}
              >
                <Grid3X3 className="w-4 h-4" />
              </Button>
              <Button
                variant={viewMode === 'list' ? 'default' : 'ghost'}
                size="sm"
                onClick={() => setViewMode('list')}
              >
                <List className="w-4 h-4" />
              </Button>
            </div>
          </div>

          {/* Search and Filter Bar */}
          <div className="flex flex-col lg:flex-row gap-4">
            {/* Search */}
            <div className="relative flex-1">
              <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
              <Input
                placeholder="Search courses, skills, instructors..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="pl-10 pr-4"
              />
            </div>

            {/* Sort */}
            <Select value={sortBy} onValueChange={setSortBy}>
              <SelectTrigger className="w-full lg:w-48">
                <SelectValue placeholder="Sort by" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="popularity">Most Popular</SelectItem>
                <SelectItem value="rating">Highest Rated</SelectItem>
                <SelectItem value="newest">Newest</SelectItem>
                <SelectItem value="price-low">Price: Low to High</SelectItem>
                <SelectItem value="price-high">Price: High to Low</SelectItem>
                <SelectItem value="students">Most Students</SelectItem>
              </SelectContent>
            </Select>

            {/* Filter Toggle */}
            <Button 
              variant="outline" 
              onClick={() => setShowFilters(!showFilters)}
              className="relative"
            >
              <SlidersHorizontal className="w-4 h-4 mr-2" />
              Filters
              {activeFiltersCount > 0 && (
                <Badge className="absolute -top-2 -right-2 h-5 w-5 rounded-full p-0 text-xs">
                  {activeFiltersCount}
                </Badge>
              )}
            </Button>
          </div>
        </div>

        <div className="grid lg:grid-cols-4 gap-8">
          {/* Filters Sidebar */}
          <div className={`lg:col-span-1 ${showFilters ? 'block' : 'hidden lg:block'}`}>
            <Card className="sticky top-24">
              <CardHeader className="flex flex-row items-center justify-between">
                <CardTitle className="text-lg">Filters</CardTitle>
                {activeFiltersCount > 0 && (
                  <Button variant="ghost" size="sm" onClick={clearFilters}>
                    <X className="w-4 h-4 mr-1" />
                    Clear All
                  </Button>
                )}
              </CardHeader>
              <CardContent className="space-y-6">
                {/* Categories */}
                <div>
                  <h3 className="font-semibold mb-3">Categories</h3>
                  <div className="space-y-2">
                    {CATEGORIES.map(category => (
                      <div key={category.id} className="flex items-center space-x-2">
                        <Checkbox
                          id={`category-${category.id}`}
                          checked={selectedCategories.includes(category.name)}
                          onCheckedChange={(checked) => 
                            handleCategoryChange(category.name, checked as boolean)
                          }
                        />
                        <Label 
                          htmlFor={`category-${category.id}`} 
                          className="text-sm font-normal cursor-pointer flex-1"
                        >
                          {category.name}
                          <span className="text-muted-foreground ml-1">
                            ({category.courseCount})
                          </span>
                        </Label>
                      </div>
                    ))}
                  </div>
                </div>

                {/* Levels */}
                <div>
                  <h3 className="font-semibold mb-3">Level</h3>
                  <div className="space-y-2">
                    {['beginner', 'intermediate', 'advanced'].map(level => (
                      <div key={level} className="flex items-center space-x-2">
                        <Checkbox
                          id={`level-${level}`}
                          checked={selectedLevels.includes(level)}
                          onCheckedChange={(checked) => 
                            handleLevelChange(level, checked as boolean)
                          }
                        />
                        <Label 
                          htmlFor={`level-${level}`} 
                          className="text-sm font-normal cursor-pointer capitalize"
                        >
                          {level}
                        </Label>
                      </div>
                    ))}
                  </div>
                </div>

                {/* Price Range */}
                <div>
                  <h3 className="font-semibold mb-3">Price Range</h3>
                  <div className="space-y-4">
                    <Slider
                      value={priceRange}
                      onValueChange={(value) => setPriceRange(value as [number, number])}
                      max={200}
                      step={10}
                      className="w-full"
                    />
                    <div className="flex items-center justify-between text-sm text-muted-foreground">
                      <span>${priceRange[0]}</span>
                      <span>${priceRange[1]}+</span>
                    </div>
                  </div>
                </div>

                {/* Free Courses */}
                <div className="flex items-center space-x-2">
                  <Checkbox
                    id="free-only"
                    checked={showFreeOnly}
                    onCheckedChange={setShowFreeOnly}
                  />
                  <Label htmlFor="free-only" className="text-sm font-normal cursor-pointer">
                    Free courses only
                  </Label>
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Course Grid */}
          <div className="lg:col-span-3">
            {filteredCourses.length === 0 ? (
              <Card className="text-center py-12">
                <CardContent>
                  <div className="text-muted-foreground mb-4">
                    <Search className="w-12 h-12 mx-auto mb-4 opacity-50" />
                    <h3 className="text-lg font-semibold mb-2">No courses found</h3>
                    <p>Try adjusting your filters or search terms</p>
                  </div>
                  <Button onClick={clearFilters}>Clear Filters</Button>
                </CardContent>
              </Card>
            ) : (
              <div className={
                viewMode === 'grid' 
                  ? "grid md:grid-cols-2 xl:grid-cols-3 gap-6" 
                  : "space-y-6"
              }>
                {filteredCourses.map(course => (
                  <CourseCard 
                    key={course.id} 
                    course={course} 
                    variant={viewMode === 'list' ? 'compact' : 'default'}
                  />
                ))}
              </div>
            )}

            {/* Load More */}
            {filteredCourses.length > 0 && (
              <div className="text-center mt-12">
                <Button variant="outline" size="lg">
                  Load More Courses
                </Button>
              </div>
            )}
          </div>
        </div>
      </div>

      {/* Course Cleaner - Temporary utility for fresh start */}
      <CourseCleaner />
    </div>
  );
}
