import React, { useState } from 'react';
import { Button } from '../components/ui/button';
import { Input } from '../components/ui/input';
import { Textarea } from '../components/ui/textarea';
import { Card, CardContent, CardHeader, CardTitle } from '../components/ui/card';
import { Badge } from '../components/ui/badge';
import { Switch } from '../components/ui/switch';
import { Alert, AlertDescription } from '../components/ui/alert';
import { useAdmin } from '../contexts/AdminContext';
import { 
  Save, 
  Shield, 
  Bell, 
  Mail, 
  Globe, 
  Users, 
  Database,
  Key,
  Eye,
  EyeOff,
  CheckCircle,
  Settings as SettingsIcon
} from 'lucide-react';

const AdminSettings: React.FC = () => {
  const { admin } = useAdmin();
  const [savedMessage, setSavedMessage] = useState('');
  const [showApiKey, setShowApiKey] = useState(false);

  const [settings, setSettings] = useState({
    // Site Settings
    siteName: 'EduMaster',
    siteDescription: 'Learn skills that matter with expert-led courses',
    siteUrl: 'https://edumaster.com',
    supportEmail: 'support@edumaster.com',
    
    // Security Settings
    enableTwoFA: false,
    sessionTimeout: 30,
    passwordPolicy: 'strong',
    apiKey: 'edu_sk_xxxxxxxxxxxxxxxxxxxxxxxx',
    
    // Notification Settings
    emailNotifications: true,
    orderNotifications: true,
    userRegistrationAlerts: true,
    systemAlerts: true,
    
    // Feature Settings
    allowUserRegistration: true,
    enableCertifications: true,
    enableDiscussions: false,
    enableReferrals: true,
    
    // Email Settings
    smtpHost: 'smtp.gmail.com',
    smtpPort: 587,
    smtpUsername: 'noreply@edumaster.com',
    smtpPassword: 'app_password_here',
    
    // Backup Settings
    autoBackup: true,
    backupFrequency: 'daily',
    retentionDays: 30
  });

  const updateSetting = (key: string, value: any) => {
    setSettings(prev => ({ ...prev, [key]: value }));
  };

  const saveSettings = () => {
    // Here you would save to API
    setSavedMessage('Settings saved successfully!');
    setTimeout(() => setSavedMessage(''), 3000);
  };

  const regenerateApiKey = () => {
    const newKey = 'edu_sk_' + Math.random().toString(36).substring(2, 30);
    updateSetting('apiKey', newKey);
  };

  const exportSettings = () => {
    const dataStr = JSON.stringify(settings, null, 2);
    const dataUri = 'data:application/json;charset=utf-8,'+ encodeURIComponent(dataStr);
    const exportFileDefaultName = 'edumaster-settings.json';
    
    const linkElement = document.createElement('a');
    linkElement.setAttribute('href', dataUri);
    linkElement.setAttribute('download', exportFileDefaultName);
    linkElement.click();
  };

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-3xl font-bold text-gray-900">Admin Settings</h1>
          <p className="text-gray-600">Configure your platform settings and preferences</p>
        </div>
        <div className="flex space-x-2">
          <Button variant="outline" onClick={exportSettings}>
            Export Settings
          </Button>
          <Button onClick={saveSettings}>
            <Save className="h-4 w-4 mr-2" />
            Save All
          </Button>
        </div>
      </div>

      {savedMessage && (
        <Alert>
          <CheckCircle className="h-4 w-4" />
          <AlertDescription>{savedMessage}</AlertDescription>
        </Alert>
      )}

      {/* Admin Profile */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Users className="h-5 w-5" />
            Admin Profile
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <label className="block text-sm font-medium mb-1">Name</label>
              <Input value={admin?.name || ''} readOnly />
            </div>
            <div>
              <label className="block text-sm font-medium mb-1">Email</label>
              <Input value={admin?.email || ''} readOnly />
            </div>
          </div>
          <div className="flex items-center space-x-2">
            <Badge variant="default">{admin?.role}</Badge>
            <span className="text-sm text-gray-600">Administrator Access</span>
          </div>
        </CardContent>
      </Card>

      {/* Site Settings */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Globe className="h-5 w-5" />
            Site Settings
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <label className="block text-sm font-medium mb-1">Site Name</label>
              <Input
                value={settings.siteName}
                onChange={(e) => updateSetting('siteName', e.target.value)}
              />
            </div>
            <div>
              <label className="block text-sm font-medium mb-1">Site URL</label>
              <Input
                value={settings.siteUrl}
                onChange={(e) => updateSetting('siteUrl', e.target.value)}
              />
            </div>
          </div>
          <div>
            <label className="block text-sm font-medium mb-1">Site Description</label>
            <Textarea
              value={settings.siteDescription}
              onChange={(e) => updateSetting('siteDescription', e.target.value)}
              rows={3}
            />
          </div>
          <div>
            <label className="block text-sm font-medium mb-1">Support Email</label>
            <Input
              type="email"
              value={settings.supportEmail}
              onChange={(e) => updateSetting('supportEmail', e.target.value)}
            />
          </div>
        </CardContent>
      </Card>

      {/* Security Settings */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Shield className="h-5 w-5" />
            Security Settings
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <label className="block text-sm font-medium mb-1">Session Timeout (minutes)</label>
              <Input
                type="number"
                value={settings.sessionTimeout}
                onChange={(e) => updateSetting('sessionTimeout', Number(e.target.value))}
              />
            </div>
            <div>
              <label className="block text-sm font-medium mb-1">Password Policy</label>
              <select
                value={settings.passwordPolicy}
                onChange={(e) => updateSetting('passwordPolicy', e.target.value)}
                className="w-full px-3 py-2 border border-gray-300 rounded-md text-sm"
              >
                <option value="weak">Weak (6+ characters)</option>
                <option value="medium">Medium (8+ characters, mixed case)</option>
                <option value="strong">Strong (12+ characters, symbols)</option>
              </select>
            </div>
          </div>
          
          <div>
            <label className="block text-sm font-medium mb-1">API Key</label>
            <div className="flex items-center space-x-2">
              <div className="relative flex-1">
                <Input
                  type={showApiKey ? 'text' : 'password'}
                  value={settings.apiKey}
                  readOnly
                />
                <Button
                  variant="ghost"
                  size="sm"
                  className="absolute right-0 top-0 h-full px-3"
                  onClick={() => setShowApiKey(!showApiKey)}
                >
                  {showApiKey ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
                </Button>
              </div>
              <Button variant="outline" onClick={regenerateApiKey}>
                <Key className="h-4 w-4 mr-2" />
                Regenerate
              </Button>
            </div>
          </div>

          <div className="space-y-3">
            <div className="flex items-center justify-between">
              <span className="text-sm font-medium">Enable Two-Factor Authentication</span>
              <Switch
                checked={settings.enableTwoFA}
                onCheckedChange={(checked) => updateSetting('enableTwoFA', checked)}
              />
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Feature Settings */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <SettingsIcon className="h-5 w-5" />
            Feature Settings
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="space-y-3">
            <div className="flex items-center justify-between">
              <div>
                <span className="text-sm font-medium">Allow User Registration</span>
                <p className="text-xs text-gray-600">Users can create new accounts</p>
              </div>
              <Switch
                checked={settings.allowUserRegistration}
                onCheckedChange={(checked) => updateSetting('allowUserRegistration', checked)}
              />
            </div>
            
            <div className="flex items-center justify-between">
              <div>
                <span className="text-sm font-medium">Enable Certifications</span>
                <p className="text-xs text-gray-600">Students can take exams and get certificates</p>
              </div>
              <Switch
                checked={settings.enableCertifications}
                onCheckedChange={(checked) => updateSetting('enableCertifications', checked)}
              />
            </div>
            
            <div className="flex items-center justify-between">
              <div>
                <span className="text-sm font-medium">Enable Discussions</span>
                <p className="text-xs text-gray-600">Course discussion forums</p>
              </div>
              <Switch
                checked={settings.enableDiscussions}
                onCheckedChange={(checked) => updateSetting('enableDiscussions', checked)}
              />
            </div>
            
            <div className="flex items-center justify-between">
              <div>
                <span className="text-sm font-medium">Enable Referral System</span>
                <p className="text-xs text-gray-600">Users can refer friends for rewards</p>
              </div>
              <Switch
                checked={settings.enableReferrals}
                onCheckedChange={(checked) => updateSetting('enableReferrals', checked)}
              />
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Notification Settings */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Bell className="h-5 w-5" />
            Notification Settings
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="space-y-3">
            <div className="flex items-center justify-between">
              <span className="text-sm font-medium">Email Notifications</span>
              <Switch
                checked={settings.emailNotifications}
                onCheckedChange={(checked) => updateSetting('emailNotifications', checked)}
              />
            </div>
            
            <div className="flex items-center justify-between">
              <span className="text-sm font-medium">Order Notifications</span>
              <Switch
                checked={settings.orderNotifications}
                onCheckedChange={(checked) => updateSetting('orderNotifications', checked)}
              />
            </div>
            
            <div className="flex items-center justify-between">
              <span className="text-sm font-medium">User Registration Alerts</span>
              <Switch
                checked={settings.userRegistrationAlerts}
                onCheckedChange={(checked) => updateSetting('userRegistrationAlerts', checked)}
              />
            </div>
            
            <div className="flex items-center justify-between">
              <span className="text-sm font-medium">System Alerts</span>
              <Switch
                checked={settings.systemAlerts}
                onCheckedChange={(checked) => updateSetting('systemAlerts', checked)}
              />
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Email Settings */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Mail className="h-5 w-5" />
            Email Settings (SMTP)
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <label className="block text-sm font-medium mb-1">SMTP Host</label>
              <Input
                value={settings.smtpHost}
                onChange={(e) => updateSetting('smtpHost', e.target.value)}
              />
            </div>
            <div>
              <label className="block text-sm font-medium mb-1">SMTP Port</label>
              <Input
                type="number"
                value={settings.smtpPort}
                onChange={(e) => updateSetting('smtpPort', Number(e.target.value))}
              />
            </div>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <label className="block text-sm font-medium mb-1">SMTP Username</label>
              <Input
                value={settings.smtpUsername}
                onChange={(e) => updateSetting('smtpUsername', e.target.value)}
              />
            </div>
            <div>
              <label className="block text-sm font-medium mb-1">SMTP Password</label>
              <Input
                type="password"
                value={settings.smtpPassword}
                onChange={(e) => updateSetting('smtpPassword', e.target.value)}
              />
            </div>
          </div>
          <Button variant="outline">
            Test Email Configuration
          </Button>
        </CardContent>
      </Card>

      {/* Backup Settings */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Database className="h-5 w-5" />
            Backup Settings
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="flex items-center justify-between">
            <span className="text-sm font-medium">Enable Auto Backup</span>
            <Switch
              checked={settings.autoBackup}
              onCheckedChange={(checked) => updateSetting('autoBackup', checked)}
            />
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <label className="block text-sm font-medium mb-1">Backup Frequency</label>
              <select
                value={settings.backupFrequency}
                onChange={(e) => updateSetting('backupFrequency', e.target.value)}
                className="w-full px-3 py-2 border border-gray-300 rounded-md text-sm"
              >
                <option value="daily">Daily</option>
                <option value="weekly">Weekly</option>
                <option value="monthly">Monthly</option>
              </select>
            </div>
            <div>
              <label className="block text-sm font-medium mb-1">Retention Days</label>
              <Input
                type="number"
                value={settings.retentionDays}
                onChange={(e) => updateSetting('retentionDays', Number(e.target.value))}
              />
            </div>
          </div>
          
          <div className="flex space-x-2">
            <Button variant="outline">
              Create Backup Now
            </Button>
            <Button variant="outline">
              View Backup History
            </Button>
          </div>
        </CardContent>
      </Card>
    </div>
  );
};

export default AdminSettings;
