import React, { useState, useEffect } from 'react';
import { useData } from '../contexts/DataContext';
import { Button } from '../components/ui/button';
import { Input } from '../components/ui/input';
import { Textarea } from '../components/ui/textarea';
import { Card, CardContent, CardHeader, CardTitle } from '../components/ui/card';
import { Badge } from '../components/ui/badge';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '../components/ui/dialog';
import { useToast } from '@/hooks/use-toast';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '../components/ui/select';
import { Label } from '../components/ui/label';
import StorageStatus from '../components/StorageStatus';
import {
  Plus,
  Edit,
  Trash2,
  Upload,
  Video,
  Image,
  Play,
  BookOpen,
  Users,
  Star,
  MoreHorizontal
} from 'lucide-react';

const AdminCoursesNew: React.FC = () => {
  const { 
    courses, 
    addCourse, 
    updateCourse, 
    deleteCourse,
    addCourseVideo,
    addCourseNote,
    addCourseProject 
  } = useData();
  
  const { toast } = useToast();
  const [isAddModalOpen, setIsAddModalOpen] = useState(false);
  const [selectedCourse, setSelectedCourse] = useState<any>(null);
  const [isEditModalOpen, setIsEditModalOpen] = useState(false);

  // Form states
  const [courseForm, setCourseForm] = useState({
    title: '',
    description: '',
    category: '',
    price: '',
    thumbnail: '',
    demoVideo: null as File | null
  });

  const handleAddCourse = () => {
    if (!courseForm.title || !courseForm.description || !courseForm.category || !courseForm.price) {
      toast({
        title: "❌ Required Fields Missing",
        description: "Please fill in all required fields",
        variant: "destructive"
      });
      return;
    }

    const newCourseId = addCourse({
      title: courseForm.title,
      description: courseForm.description,
      shortDescription: courseForm.description,
      instructor: {
        id: 'admin',
        name: 'Admin',
        avatar: 'https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=150',
        bio: 'Course created by admin'
      },
      tags: [courseForm.category],
      price: parseFloat(courseForm.price) || 0,
      currency: 'INR',
      category: courseForm.category,
      level: 'beginner' as 'beginner',
      duration: '0 hours',
      totalLessons: 0,
      totalStudents: 0,
      rating: 4.5,
      reviewCount: 0,
      thumbnail: courseForm.thumbnail || 'https://images.unsplash.com/photo-1516321318423-f06f85e504b3?w=400',
      isPublished: false,
      isFree: parseFloat(courseForm.price) === 0,
      features: ['Course content', 'Certificate of completion'],
      learningOutcomes: ['Learn new skills'],
      requirements: ['Basic knowledge'],
      classes: [],
      notes: [],
      videos: [],
      projects: [],
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString()
    });

    toast({
      title: "✅ Course Created",
      description: `"${courseForm.title}" has been created successfully`,
    });

    setCourseForm({
      title: '',
      description: '',
      category: '',
      price: '',
      thumbnail: '',
      demoVideo: null
    });
    setIsAddModalOpen(false);
  };

  const handleDeleteCourse = (courseId: string, courseTitle: string) => {
    if (window.confirm(`Are you sure you want to delete "${courseTitle}"?`)) {
      deleteCourse(courseId);
      toast({
        title: "🗑️ Course Deleted",
        description: `"${courseTitle}" has been deleted`,
      });
    }
  };

  const handleVideoUpload = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (file) {
      setCourseForm(prev => ({ ...prev, demoVideo: file }));
    }
  };

  const handleThumbnailUpload = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onload = (e) => {
        setCourseForm(prev => ({ ...prev, thumbnail: e.target?.result as string }));
      };
      reader.readAsDataURL(file);
    }
  };

  const togglePublish = (course: any) => {
    updateCourse(course.id, { isPublished: !course.isPublished });
    toast({
      title: course.isPublished ? "📤 Course Unpublished" : "📢 Course Published",
      description: `"${course.title}" is now ${course.isPublished ? 'hidden from' : 'visible on'} the website`,
    });
  };

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <div className="bg-white border-b border-gray-200 px-6 py-4">
        <div className="flex justify-between items-center">
          <div>
            <h1 className="text-2xl font-semibold text-gray-900">Course Management</h1>
            <p className="text-gray-600 text-sm mt-1">Manage and organize your courses</p>
          </div>
          <div className="flex items-center gap-3">
            <StorageStatus />
            <Button 
              onClick={() => setIsAddModalOpen(true)}
              className="bg-purple-600 hover:bg-purple-700 text-white"
            >
              <Plus className="w-4 h-4 mr-2" />
              Add Course
            </Button>
          </div>
        </div>
      </div>

      <div className="flex">
        {/* Left Sidebar - Course Creation Guide */}
        <div className="w-80 bg-white border-r border-gray-200 p-6">
          <div className="space-y-6">
            <div>
              <h3 className="text-lg font-semibold text-gray-900 mb-4">📚 Example Course Structure</h3>
              
              <div className="space-y-4">
                <div className="bg-gray-50 p-4 rounded-lg">
                  <h4 className="font-medium text-gray-900 mb-2">Step 1: Create Course</h4>
                  <p className="text-sm text-gray-600">Admin clicks "Add Course" button to create a new course.</p>
                </div>

                <div className="bg-gray-50 p-4 rounded-lg">
                  <h4 className="font-medium text-gray-900 mb-2">Step 2: Add Content</h4>
                  <p className="text-sm text-gray-600">Goes to "Add Content" to upload:</p>
                  <ul className="text-xs text-gray-500 mt-2 space-y-1">
                    <li>• Class 1: Introduction</li>
                    <li>• Class 2: CSS Foundations</li>
                    <li>• Class 3: JavaScript Basics</li>
                  </ul>
                </div>

                <div className="bg-green-50 p-4 rounded-lg border border-green-200">
                  <h4 className="font-medium text-green-800 mb-2">✅ Student View</h4>
                  <ul className="text-xs text-green-600 space-y-1">
                    <li>• Only Demo classes are unlocked</li>
                    <li>• Other classes show after payment</li>
                    <li>• After approval, all classes unlock</li>
                  </ul>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Main Content Area */}
        <div className="flex-1 p-6">
          <div className="bg-white rounded-lg shadow-sm border border-gray-200">
            {/* Table Header */}
            <div className="px-6 py-4 border-b border-gray-200">
              <h2 className="text-lg font-semibold text-gray-900">All Courses</h2>
            </div>

            {/* Table */}
            <div className="overflow-x-auto">
              <table className="w-full">
                <thead className="bg-gray-50 border-b border-gray-200">
                  <tr>
                    <th className="text-left py-3 px-6 text-sm font-medium text-gray-700">Course Details</th>
                    <th className="text-left py-3 px-6 text-sm font-medium text-gray-700">Classes</th>
                    <th className="text-left py-3 px-6 text-sm font-medium text-gray-700">Status</th>
                    <th className="text-left py-3 px-6 text-sm font-medium text-gray-700">Actions</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-gray-200">
                  {courses.map((course) => (
                    <tr key={course.id} className="hover:bg-gray-50">
                      <td className="py-4 px-6">
                        <div className="flex items-start space-x-4">
                          <img
                            src={course.thumbnail}
                            alt={course.title}
                            className="w-16 h-16 rounded-lg object-cover"
                          />
                          <div className="flex-1 min-w-0">
                            <h3 className="text-sm font-medium text-gray-900 truncate">
                              {course.title}
                            </h3>
                            <p className="text-xs text-gray-500 mt-1 line-clamp-2">
                              {course.description}
                            </p>
                            <div className="flex items-center mt-2 space-x-4">
                              <span className="text-sm font-semibold text-green-600">
                                ₹{course.price.toLocaleString()}
                              </span>
                              <Badge variant="secondary" className="text-xs">
                                {course.category}
                              </Badge>
                            </div>
                          </div>
                        </div>
                      </td>
                      <td className="py-4 px-6">
                        <div className="space-y-1">
                          <div className="flex items-center text-sm text-gray-600">
                            <BookOpen className="w-4 h-4 mr-2" />
                            {course.classes?.length || 0} Classes
                          </div>
                          <div className="flex items-center text-sm text-gray-600">
                            <Video className="w-4 h-4 mr-2" />
                            {course.videos?.length || 0} Videos
                          </div>
                          <div className="flex items-center text-sm text-gray-600">
                            <Users className="w-4 h-4 mr-2" />
                            {course.totalStudents || 0} Students
                          </div>
                        </div>
                      </td>
                      <td className="py-4 px-6">
                        <div className="space-y-2">
                          <Badge 
                            variant={course.isPublished ? 'default' : 'secondary'}
                            className={course.isPublished ? 'bg-green-100 text-green-800' : 'bg-gray-100 text-gray-600'}
                          >
                            {course.isPublished ? 'Published' : 'Draft'}
                          </Badge>
                          {course.isFree && (
                            <Badge variant="outline" className="border-blue-200 text-blue-700">
                              FREE
                            </Badge>
                          )}
                        </div>
                      </td>
                      <td className="py-4 px-6">
                        <div className="flex items-center space-x-2">
                          <Button
                            variant="outline"
                            size="sm"
                            onClick={() => togglePublish(course)}
                            className="text-xs"
                          >
                            {course.isPublished ? 'Unpublish' : 'Publish'}
                          </Button>
                          <Button
                            variant="outline"
                            size="sm"
                            onClick={() => {
                              setSelectedCourse(course);
                              setIsEditModalOpen(true);
                            }}
                            className="text-xs"
                          >
                            <Edit className="w-3 h-3 mr-1" />
                            Edit
                          </Button>
                          <Button
                            variant="outline"
                            size="sm"
                            onClick={() => handleDeleteCourse(course.id, course.title)}
                            className="text-xs text-red-600 hover:text-red-700 hover:bg-red-50"
                          >
                            <Trash2 className="w-3 h-3 mr-1" />
                            Delete
                          </Button>
                        </div>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
              
              {courses.length === 0 && (
                <div className="text-center py-12">
                  <BookOpen className="w-16 h-16 mx-auto text-gray-300 mb-4" />
                  <h3 className="text-lg font-medium text-gray-900 mb-2">No courses yet</h3>
                  <p className="text-gray-600 mb-4">Get started by creating your first course</p>
                  <Button onClick={() => setIsAddModalOpen(true)} className="bg-purple-600 hover:bg-purple-700">
                    <Plus className="w-4 h-4 mr-2" />
                    Add Course
                  </Button>
                </div>
              )}
            </div>
          </div>
        </div>
      </div>

      {/* Add Course Modal */}
      <Dialog open={isAddModalOpen} onOpenChange={setIsAddModalOpen}>
        <DialogContent className="max-w-lg">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <Plus className="w-5 h-5 text-purple-600" />
              Add New Course
            </DialogTitle>
            <p className="text-sm text-gray-600">Create a new course with demo video and basic information.</p>
          </DialogHeader>

          <div className="space-y-4 py-4">
            <div>
              <Label htmlFor="title">Course Title</Label>
              <Input
                id="title"
                placeholder="e.g., Full Stack Web Development"
                value={courseForm.title}
                onChange={(e) => setCourseForm(prev => ({ ...prev, title: e.target.value }))}
              />
            </div>

            <div>
              <Label htmlFor="description">Description</Label>
              <Textarea
                id="description"
                placeholder="Brief overview of what students will learn..."
                value={courseForm.description}
                onChange={(e) => setCourseForm(prev => ({ ...prev, description: e.target.value }))}
                rows={3}
              />
            </div>

            <div>
              <Label htmlFor="category">Category</Label>
              <Select value={courseForm.category} onValueChange={(value) => setCourseForm(prev => ({ ...prev, category: value }))}>
                <SelectTrigger>
                  <SelectValue placeholder="Select category" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="Web Development">Web Development</SelectItem>
                  <SelectItem value="Mobile Development">Mobile Development</SelectItem>
                  <SelectItem value="Data Science">Data Science</SelectItem>
                  <SelectItem value="Machine Learning">Machine Learning</SelectItem>
                  <SelectItem value="DevOps">DevOps</SelectItem>
                  <SelectItem value="UI/UX Design">UI/UX Design</SelectItem>
                  <SelectItem value="Programming">Programming</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div>
              <Label htmlFor="price">Price (₹)</Label>
              <div className="relative">
                <span className="absolute left-3 top-3 text-gray-500">₹</span>
                <Input
                  id="price"
                  type="number"
                  placeholder="2999"
                  className="pl-8"
                  value={courseForm.price}
                  onChange={(e) => setCourseForm(prev => ({ ...prev, price: e.target.value }))}
                />
              </div>
            </div>

            <div>
              <Label>Demo Class Video Upload</Label>
              <p className="text-xs text-gray-500 mb-2">Upload 1 free unlocked video for preview</p>
              <div className="border-2 border-dashed border-gray-300 rounded-lg p-6 text-center">
                <Video className="w-8 h-8 mx-auto text-gray-400 mb-2" />
                <p className="text-sm text-gray-600 mb-2">Click to upload demo video or drag and drop</p>
                <input
                  type="file"
                  accept="video/*"
                  onChange={handleVideoUpload}
                  className="hidden"
                  id="demo-video"
                />
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => document.getElementById('demo-video')?.click()}
                >
                  Choose File
                </Button>
                {courseForm.demoVideo && (
                  <p className="text-xs text-green-600 mt-2">✅ {courseForm.demoVideo.name}</p>
                )}
              </div>
            </div>

            <div>
              <Label>Course Thumbnail Upload</Label>
              <div className="border-2 border-dashed border-gray-300 rounded-lg p-6 text-center">
                <Image className="w-8 h-8 mx-auto text-gray-400 mb-2" />
                <p className="text-sm text-gray-600 mb-2">Click to upload thumbnail or drag and drop</p>
                <input
                  type="file"
                  accept="image/*"
                  onChange={handleThumbnailUpload}
                  className="hidden"
                  id="thumbnail"
                />
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => document.getElementById('thumbnail')?.click()}
                >
                  Choose File
                </Button>
                {courseForm.thumbnail && (
                  <div className="mt-3">
                    <img 
                      src={courseForm.thumbnail} 
                      alt="Thumbnail preview"
                      className="w-20 h-20 mx-auto rounded-lg object-cover"
                    />
                  </div>
                )}
              </div>
            </div>
          </div>

          <div className="flex gap-3 pt-4">
            <Button variant="outline" onClick={() => setIsAddModalOpen(false)} className="flex-1">
              Cancel
            </Button>
            <Button onClick={handleAddCourse} className="flex-1 bg-purple-600 hover:bg-purple-700">
              Create Course
            </Button>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
};

export default AdminCoursesNew;
