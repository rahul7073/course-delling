import React, { useState, useEffect } from 'react';
import { useData } from '../contexts/DataContext';
import { apiDatabaseService } from '../services/ApiDatabaseService';
import { Course } from '../../shared/database';
import { Button } from '../components/ui/button';
import { Input } from '../components/ui/input';
import { Textarea } from '../components/ui/textarea';
import { Card, CardContent, CardHeader, CardTitle } from '../components/ui/card';
import { Badge } from '../components/ui/badge';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '../components/ui/dialog';
import { useToast } from '@/hooks/use-toast';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '../components/ui/select';
import { Label } from '../components/ui/label';
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from '../components/ui/dropdown-menu';
import {
  Plus,
  Edit,
  Trash2,
  Upload,
  Video,
  Image,
  Play,
  BookOpen,
  Users,
  Star,
  MoreHorizontal,
  Save,
  FileText,
  Code,
  Settings,
  Eye,
  Download,
  ChevronDown
} from 'lucide-react';
import AdminInstructions from '../components/AdminInstructions';
import { clearAllCourses } from '../utils/clearCourses';

const AdminCourses: React.FC = () => {
  const [courses, setCourses] = useState<Course[]>([]);
  const [loading, setLoading] = useState(false);

  const { toast } = useToast();

  // Load courses from database
  const loadCourses = async () => {
    try {
      setLoading(true);
      const result = await apiDatabaseService.getCourses();

      if (result.success && result.data) {
        setCourses(result.data.data || []);
      } else {
        console.error('Failed to load courses:', result.error);
      }
    } catch (error) {
      console.error('Error loading courses:', error);
    } finally {
      setLoading(false);
    }
  };

  // Load courses on component mount
  useEffect(() => {
    loadCourses();
  }, []);

  // Database operations
  const handleUpdateCourse = async (courseId: string, updates: any) => {
    try {
      setLoading(true);
      const result = await apiDatabaseService.updateCourse(courseId, updates);

      if (result.success) {
        toast({
          title: "✅ Course Updated",
          description: result.message,
        });
        await loadCourses(); // Refresh courses list
      } else {
        throw new Error(result.message);
      }
    } catch (error) {
      toast({
        title: "❌ Failed to Update Course",
        description: error instanceof Error ? error.message : 'Unknown error',
        variant: "destructive"
      });
    } finally {
      setLoading(false);
    }
  };

  const handleDeleteCourse = async (courseId: string) => {
    try {
      setLoading(true);
      const result = await apiDatabaseService.deleteCourse(courseId);

      if (result.success) {
        toast({
          title: "✅ Course Deleted",
          description: result.message,
        });
        await loadCourses(); // Refresh courses list
      } else {
        throw new Error(result.message);
      }
    } catch (error) {
      toast({
        title: "❌ Failed to Delete Course",
        description: error instanceof Error ? error.message : 'Unknown error',
        variant: "destructive"
      });
    } finally {
      setLoading(false);
    }
  };

  const handlePublishCourse = async (courseId: string) => {
    try {
      setLoading(true);
      const result = await apiDatabaseService.publishCourse(courseId);

      if (result.success) {
        toast({
          title: "✅ Course Published",
          description: result.message,
        });
        await loadCourses(); // Refresh courses list
      } else {
        throw new Error(result.message);
      }
    } catch (error) {
      toast({
        title: "❌ Failed to Publish Course",
        description: error instanceof Error ? error.message : 'Unknown error',
        variant: "destructive"
      });
    } finally {
      setLoading(false);
    }
  };
  const [isAddModalOpen, setIsAddModalOpen] = useState(false);
  const [selectedCourse, setSelectedCourse] = useState<any>(null);
  const [isEditModalOpen, setIsEditModalOpen] = useState(false);
  const [isManageModalOpen, setIsManageModalOpen] = useState(false);
  const [editingClass, setEditingClass] = useState<any>(null);
  const [isClassEditModalOpen, setIsClassEditModalOpen] = useState(false);

  // Form states
  const [courseForm, setCourseForm] = useState({
    title: '',
    duration: '',
    description: '',
    category: '',
    price: '',
    thumbnail: '',
    demoVideo: null as File | null
  });

  // Class management states
  const [classForm, setClassForm] = useState({
    classNumber: '',
    duration: '',
    title: '',
    description: '',
    video: null as File | null,
    videoKey: '' as string,
    isDemo: false
  });

  // Multi-step wizard state
  const [currentStep, setCurrentStep] = useState<'class' | 'notes' | 'codes' | 'complete'>('class');

  const [noteForm, setNoteForm] = useState({
    title: '',
    description: '',
    file: null as File | null,
    fileKey: '' as string
  });

  const [projectForm, setProjectForm] = useState({
    title: '',
    description: '',
    githubUrl: '',
    liveUrl: ''
  });

  const handleAddCourse = async () => {
    if (!courseForm.title || !courseForm.description || !courseForm.category || !courseForm.price) {
      toast({
        title: "❌ Required Fields Missing",
        description: "Please fill in all required fields",
        variant: "destructive"
      });
      return;
    }

    setLoading(true);
    try {
      const courseData = {
        title: courseForm.title,
        description: courseForm.description,
        price: parseFloat(courseForm.price) || 0,
        duration: courseForm.duration || '0 hours',
        category: courseForm.category,
        thumbnail: courseForm.thumbnail || 'https://images.unsplash.com/photo-1516321318423-f06f85e504b3?w=400',
        isPublished: true, // Auto-publish courses created from admin
        createdBy: 'admin'
      };

      const result = await apiDatabaseService.createCourse(courseData);

      if (result.success) {
        toast({
          title: "✅ Course Created & Published",
          description: `"${courseForm.title}" has been created and is now live on your website!`,
        });

        setCourseForm({
          title: '',
          duration: '',
          description: '',
          category: '',
          price: '',
          thumbnail: '',
          demoVideo: null
        });
        setIsAddModalOpen(false);
        await loadCourses(); // Refresh courses list
      } else {
        throw new Error(result.message);
      }
    } catch (error) {
      toast({
        title: "❌ Failed to Create Course",
        description: error instanceof Error ? error.message : 'Unknown error',
        variant: "destructive"
      });
    } finally {
      setLoading(false);
    }
  };

  const handleSaveClass = async () => {
    if (!selectedCourse || !classForm.title || !classForm.classNumber || !classForm.duration) {
      toast({
        title: "❌ Required Fields Missing",
        description: "Please fill in class number, duration, and title",
        variant: "destructive"
      });
      return;
    }

    // Verify video is properly stored if uploaded
    if (classForm.video && classForm.videoKey) {
      const storedVideo = localStorage.getItem(classForm.videoKey);
      if (!storedVideo) {
        toast({
          title: "❌ Video Storage Error",
          description: "Video file not properly stored. Please try uploading the video again.",
          variant: "destructive"
        });
        return;
      }
      console.log('Video verification passed:', classForm.videoKey);
    }

    try {
      setLoading(true);
      const classNumber = parseInt(classForm.classNumber) || (selectedCourse.classes?.length || 0) + 1;

      // Prepare class data
      const classData = {
        title: classForm.title,
        description: classForm.description,
        order: classNumber,
        videos: classForm.video ? [{
          title: `${classForm.title} - Video`,
          fileName: classForm.video.name,
          fileSize: classForm.video.size,
          videoUrl: classForm.videoKey,
          videoKey: classForm.videoKey,
          classId: '', // Will be set by server
        }] : [],
        notes: [],
        projects: []
      };

      const result = await apiDatabaseService.createClass(selectedCourse.id, classData);

      if (result.success) {
        toast({
          title: "✅ Class Added",
          description: `"${classForm.title}" has been saved. Now add notes...`,
        });

        // Log the saved video for verification
        if (classForm.videoKey) {
          console.log('Class saved with video:', {
            classTitle: classForm.title,
            videoKey: classForm.videoKey,
            videoName: classForm.video?.name
          });
        }

        // Refresh the course data
        await loadCourses();
        const updatedCourse = courses.find(c => c.id === selectedCourse.id);
        if (updatedCourse) {
          setSelectedCourse(updatedCourse);
        }

        setCurrentStep('notes');
      } else {
        throw new Error(result.message);
      }
    } catch (error) {
      toast({
        title: "❌ Failed to Save Class",
        description: error instanceof Error ? error.message : 'Unknown error',
        variant: "destructive"
      });
    } finally {
      setLoading(false);
    }
  };

  const handleSaveNote = () => {
    if (!selectedCourse || !noteForm.title) {
      toast({
        title: "❌ Note Title Required",
        description: "Please enter a note title",
        variant: "destructive"
      });
      return;
    }

    // For now, just add the note to the current class's state
    // In a full implementation, this would be saved to the database when the class is saved
    console.log('Note added:', {
      title: noteForm.title,
      description: noteForm.description,
      fileKey: noteForm.fileKey,
      fileSize: noteForm.file?.size
    });

    toast({
      title: "✅ Note Added",
      description: `"${noteForm.title}" has been added. Now add codes...`,
    });

    setNoteForm({ title: '', description: '', file: null, fileKey: '' });
    setCurrentStep('codes');
  };

  const handleSaveProject = () => {
    if (!selectedCourse || !projectForm.title) {
      toast({
        title: "❌ Project Title Required",
        description: "Please enter a project title",
        variant: "destructive"
      });
      return;
    }

    const classNumber = parseInt(classForm.classNumber) || 1;

    addCourseProject(selectedCourse.id, {
      title: projectForm.title,
      description: projectForm.description,
      codeFiles: [{
        fileName: 'README.md',
        fileUrl: projectForm.githubUrl || '#',
        language: 'markdown'
      }],
      projectUrl: projectForm.githubUrl,
      demoUrl: projectForm.liveUrl,
      uploadDate: new Date().toISOString(),
      difficulty: 'medium',
      classNumber: classNumber
    });

    // Update the selectedCourse with the new project
    const updatedCourse = courses.find(course => course.id === selectedCourse.id);
    if (updatedCourse) {
      setSelectedCourse(updatedCourse);
    }

    toast({
      title: "🎉 Content Added Successfully!",
      description: `Class "${classForm.title}" with notes and codes has been added. You can continue adding more content.`,
    });

    // Reset forms and go to completion step
    setClassForm({ classNumber: '', duration: '', title: '', description: '', video: null, videoKey: '', isDemo: false });
    setNoteForm({ title: '', description: '', file: null, fileKey: '' });
    setProjectForm({ title: '', description: '', githubUrl: '', liveUrl: '' });
    setCurrentStep('complete');
  };

  const handleOpenEditModal = (course: any) => {
    setSelectedCourse(course);
    setCourseForm({
      title: course.title,
      duration: course.duration || '',
      description: course.description,
      category: course.category,
      price: course.price.toString(),
      thumbnail: course.thumbnail,
      demoVideo: null
    });
    setIsEditModalOpen(true);
  };

  const handleEditCourse = async () => {
    if (!selectedCourse || !courseForm.title || !courseForm.description || !courseForm.category || !courseForm.price) {
      toast({
        title: "❌ Required Fields Missing",
        description: "Please fill in all required fields",
        variant: "destructive"
      });
      return;
    }

    const updates = {
      title: courseForm.title,
      description: courseForm.description,
      category: courseForm.category,
      price: parseFloat(courseForm.price) || 0,
      duration: courseForm.duration || selectedCourse.duration,
      thumbnail: courseForm.thumbnail || selectedCourse.thumbnail
    };

    await handleUpdateCourse(selectedCourse.id, updates);

    setCourseForm({
      title: '',
      duration: '',
      description: '',
      category: '',
      price: '',
      thumbnail: '',
      demoVideo: null
    });
    setIsEditModalOpen(false);
    setSelectedCourse(null);
  };

  const handleEditClass = (classItem: any) => {
    setEditingClass(classItem);
    setClassForm({
      classNumber: classItem.classNumber.toString(),
      duration: classItem.duration || '',
      title: classItem.title,
      description: classItem.description || '',
      video: null,
      isDemo: classItem.isDemo || false
    });
    setIsClassEditModalOpen(true);
  };

  const handleUpdateClass = async () => {
    if (!selectedCourse || !editingClass || !classForm.title || !classForm.classNumber) {
      toast({
        title: "❌ Required Fields Missing",
        description: "Please fill in class number and title",
        variant: "destructive"
      });
      return;
    }

    const updatedClasses = selectedCourse.classes?.map((cls: any) =>
      cls.classNumber === editingClass.classNumber
        ? {
            ...cls,
            classNumber: parseInt(classForm.classNumber),
            title: classForm.title,
            description: classForm.description,
            duration: classForm.duration,
            isDemo: classForm.isDemo
          }
        : cls
    ) || [];

    await handleUpdateCourse(selectedCourse.id, {
      classes: updatedClasses,
      updatedAt: new Date().toISOString()
    });

    toast({
      title: "✅ Class Updated",
      description: `"${classForm.title}" has been updated successfully`,
    });

    setEditingClass(null);
    setClassForm({
      classNumber: '',
      duration: '',
      title: '',
      description: '',
      video: null,
      isDemo: false
    });
    setIsClassEditModalOpen(false);
  };

  const handleDeleteCourseConfirm = async (courseId: string, courseTitle: string) => {
    if (window.confirm(`Are you sure you want to delete "${courseTitle}"?\n\nThis will permanently delete the course and all its content (classes, notes, projects).`)) {
      await handleDeleteCourse(courseId);
    }
  };

  const handleDeleteClass = async (classItem: any) => {
    if (!selectedCourse) return;

    if (window.confirm(`Are you sure you want to delete "Class ${classItem.classNumber}: ${classItem.title}"?\n\nThis will permanently delete the class and all its content.`)) {
      const updatedClasses = selectedCourse.classes?.filter((cls: any) =>
        cls.classNumber !== classItem.classNumber
      ) || [];

      await handleUpdateCourse(selectedCourse.id, {
        classes: updatedClasses,
        updatedAt: new Date().toISOString()
      });

      toast({
        title: "🗑️ Class Deleted",
        description: `"Class ${classItem.classNumber}: ${classItem.title}" has been deleted`,
      });

      // Close class edit modal if it's open for this class
      if (editingClass?.classNumber === classItem.classNumber) {
        setIsClassEditModalOpen(false);
        setEditingClass(null);
        setClassForm({
          classNumber: '',
          duration: '',
          title: '',
          description: '',
          video: null,
          videoKey: '',
          isDemo: false
        });
      }
    }
  };

  const handleDeleteAllContent = async (courseId: string, courseTitle: string) => {
    if (window.confirm(`Are you sure you want to delete ALL CONTENT from "${courseTitle}"?\n\nThis will delete all classes, notes, and projects but keep the course itself.`)) {
      try {
        await handleUpdateCourse(courseId, {
          classes: [],
          notes: [],
          projects: [],
          videos: [],
          updatedAt: new Date().toISOString()
        });

        toast({
          title: "🗑️ All Content Deleted",
          description: `All content from "${courseTitle}" has been deleted`,
        });
      } catch (error) {
        toast({
          title: "❌ Failed to delete content",
          description: error instanceof Error ? error.message : 'Unknown error',
          variant: "destructive"
        });
      }
    }
  };

  const handleVideoUpload = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (file) {
      setCourseForm(prev => ({ ...prev, demoVideo: file }));
    }
  };

  const handleThumbnailUpload = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onload = (e) => {
        setCourseForm(prev => ({ ...prev, thumbnail: e.target?.result as string }));
      };
      reader.readAsDataURL(file);
    }
  };

  const handleClassVideoUpload = async (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (file) {
      try {
        // Convert file to data URL for proper storage and download
        const { fileToDataURL } = await import('../utils/fileDownload');
        const dataUrl = await fileToDataURL(file, 50); // Allow larger video files (50MB)

        // Store file info for later download
        const fileInfo = {
          dataUrl,
          name: file.name,
          size: file.size,
          type: file.type,
          uploadDate: new Date().toISOString()
        };

        // Create a unique key for this file
        const fileKey = `video-file-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`;

        // Store in localStorage
        localStorage.setItem(fileKey, JSON.stringify(fileInfo));

        // Verify storage worked
        const verification = localStorage.getItem(fileKey);
        if (!verification) {
          throw new Error('Failed to save video to storage');
        }

        console.log('Video stored successfully:', {
          key: fileKey,
          name: file.name,
          size: `${(file.size / 1024 / 1024).toFixed(2)} MB`,
          dataUrlLength: dataUrl.length
        });

        setClassForm(prev => ({
          ...prev,
          video: file,
          videoKey: fileKey // Store the key for later retrieval
        }));

        toast({
          title: "✅ Video Ready",
          description: `${file.name} is ready for upload`,
        });
      } catch (error) {
        console.error('Video upload error:', error);
        toast({
          title: "❌ Video Processing Failed",
          description: error.message || "Please try a smaller video file",
          variant: "destructive"
        });
      }
    }
  };

  const handleNoteFileUpload = async (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (file) {
      try {
        // Convert file to data URL for proper storage and download
        const { fileToDataURL } = await import('../utils/fileDownload');
        const dataUrl = await fileToDataURL(file);

        // Store file info for later download
        const fileInfo = {
          dataUrl,
          name: file.name,
          size: file.size,
          type: file.type,
          uploadDate: new Date().toISOString()
        };

        // Create a unique key for this file
        const fileKey = `note-file-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`;

        // Store in localStorage
        localStorage.setItem(fileKey, JSON.stringify(fileInfo));

        // Verify storage worked
        const verification = localStorage.getItem(fileKey);
        if (!verification) {
          throw new Error('Failed to save file to storage');
        }

        console.log('File stored successfully:', {
          key: fileKey,
          name: file.name,
          size: `${(file.size / 1024 / 1024).toFixed(2)} MB`,
          dataUrlLength: dataUrl.length
        });

        setNoteForm(prev => ({
          ...prev,
          file,
          fileKey // Store the key for later retrieval
        }));

        toast({
          title: "✅ File Ready",
          description: `${file.name} is ready for upload`,
        });
      } catch (error) {
        toast({
          title: "❌ File Processing Failed",
          description: "Please try a smaller file or different format",
          variant: "destructive"
        });
      }
    }
  };

  const togglePublish = async (course: any) => {
    try {
      const newPublishStatus = !course.isPublished;
      await handleUpdateCourse(course.id, { isPublished: newPublishStatus });

      toast({
        title: newPublishStatus ? "📢 Course Published" : "📤 Course Unpublished",
        description: `"${course.title}" is now ${newPublishStatus ? 'visible on' : 'hidden from'} the website`,
      });
    } catch (error) {
      toast({
        title: "❌ Failed to update course",
        description: error instanceof Error ? error.message : 'Unknown error',
        variant: "destructive"
      });
    }
  };

  return (
    <div className="min-h-screen bg-white">
      {/* Header */}
      <div className="bg-white border-b border-gray-200 px-8 py-6">
        <div className="flex justify-between items-center">
          <h1 className="text-2xl font-bold text-gray-900">Course Management</h1>
          <div className="flex items-center gap-2">
            <Button
              variant="ghost"
              className="text-gray-600 hover:text-gray-900"
              onClick={() => window.open('/courses', '_blank')}
            >
              <Eye className="w-4 h-4 mr-2" />
              View Courses on Website
            </Button>
            <Button
              variant="ghost"
              size="sm"
              className="text-blue-600 hover:text-blue-900"
              onClick={() => {
                const videoKeys = Array.from({length: localStorage.length}, (_, i) => localStorage.key(i))
                  .filter(key => key?.includes('video-file'));

                console.log('Stored video files:', videoKeys.map(key => {
                  try {
                    const data = JSON.parse(localStorage.getItem(key) || '{}');
                    return { key, name: data.name, size: data.size };
                  } catch (e) {
                    return { key, error: 'Parse error' };
                  }
                }));

                toast({
                  title: "🎥 Video Debug",
                  description: `Found ${videoKeys.length} video files in storage. Check console for details.`,
                });
              }}
            >
              🎬 Test Videos
            </Button>
          </div>
        </div>
      </div>

      {/* Informational Banner */}
      <div className="px-8 py-4 bg-blue-50 border-b border-blue-200">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 bg-blue-100 rounded-full flex items-center justify-center">
            <Eye className="w-5 h-5 text-blue-600" />
          </div>
          <div className="flex-1">
            <h3 className="text-sm font-semibold text-blue-900">✅ Your admin uploads will appear on website:</h3>
            <p className="text-xs text-blue-700 mt-1">
              📚 <strong>Courses:</strong> Auto-published to website • 📝 <strong>Classes/Notes/Code:</strong> Instantly visible to users • 📥 <strong>Downloads:</strong> Work perfectly for users
            </p>
            <p className="text-xs text-blue-600 mt-1 font-medium">
              ✅ Files are stored as downloadable data and saved to user's Downloads folder when clicked
            </p>
            <p className="text-xs text-blue-500 mt-1">
              Storage: {(() => {
                const fileKeys = Array.from({length: localStorage.length}, (_, i) => localStorage.key(i))
                  .filter(key => key?.includes('file'));
                const videoKeys = fileKeys.filter(key => key?.includes('video-file'));
                const noteKeys = fileKeys.filter(key => key?.includes('note-file'));
                return `${fileKeys.length} files stored (${videoKeys.length} videos, ${noteKeys.length} notes)`;
              })()} • Click files on course pages to test downloads
            </p>
          </div>
          <Button
            variant="outline"
            size="sm"
            onClick={() => window.open('/courses', '_blank')}
            className="border-blue-300 text-blue-700 hover:bg-blue-100"
          >
            <Eye className="w-4 h-4 mr-2" />
            View Website
          </Button>
        </div>
      </div>

      {/* Action Buttons */}
      <div className="px-8 py-6">
        <div className="flex items-center gap-4">
          <Button
            onClick={() => setIsAddModalOpen(true)}
            className="bg-purple-600 hover:bg-purple-700 text-white px-6 py-2 rounded-lg font-medium"
          >
            <Plus className="w-4 h-4 mr-2" />
            Add Course
          </Button>

          {courses.length > 0 && (
            <Button
              variant="destructive"
              onClick={() => {
                if (window.confirm('🗑️ Clear all existing courses for fresh start?\n\nThis will delete all current courses, classes, notes, and uploaded files.\n\nUse this if you want to start fresh with new admin uploads.')) {
                  clearAllCourses();
                }
              }}
              className="bg-red-600 hover:bg-red-700 text-white px-4 py-2 rounded-lg font-medium"
            >
              <Trash2 className="w-4 h-4 mr-2" />
              Clear All & Start Fresh
            </Button>
          )}
          {courses.length > 0 ? (
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button variant="outline" className="border-gray-300 text-gray-700 hover:bg-gray-50 px-6 py-2 rounded-lg font-medium">
                  <Upload className="w-4 h-4 mr-2" />
                  Add Class + Notes + Code
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent align="start" className="w-72 bg-white border border-gray-200 shadow-lg">
                <div className="px-3 py-2 text-sm font-medium text-gray-700 border-b border-gray-200">
                  Select Course to Add Content
                </div>
                {courses.map((course) => (
                  <DropdownMenuItem
                    key={course.id}
                    onClick={() => {
                      setSelectedCourse(course);
                      setCurrentStep('class');
                      setIsManageModalOpen(true);
                    }}
                    className="hover:bg-blue-50 cursor-pointer p-3"
                  >
                    <div className="flex items-center space-x-3">
                      <img
                        src={course.thumbnail}
                        alt={course.title}
                        className="w-8 h-8 rounded object-cover"
                      />
                      <div className="flex-1 min-w-0">
                        <p className="text-sm font-medium text-gray-900 truncate">
                          {course.title}
                        </p>
                        <p className="text-xs text-gray-500">
                          {course.classes?.length || 0} classes • ₹{course.price}
                        </p>
                      </div>
                    </div>
                  </DropdownMenuItem>
                ))}
              </DropdownMenuContent>
            </DropdownMenu>
          ) : (
            <Button
              variant="outline"
              disabled
              className="border-gray-300 text-gray-400 cursor-not-allowed px-6 py-2 rounded-lg font-medium"
            >
              <Upload className="w-4 h-4 mr-2" />
              Add Class + Notes + Code
            </Button>
          )}
        </div>
      </div>

      {/* All Courses Section */}
      <div className="px-8">
        <h2 className="text-lg font-semibold text-gray-900 mb-6">All Courses</h2>
        
        {/* Table */}
        <div className="bg-white border border-gray-200 rounded-lg overflow-hidden">
          <table className="w-full">
            <thead className="bg-gray-50 border-b border-gray-200">
              <tr>
                <th className="text-left py-3 px-6 text-sm font-medium text-gray-700">Course Details</th>
                <th className="text-left py-3 px-6 text-sm font-medium text-gray-700">Category</th>
                <th className="text-left py-3 px-6 text-sm font-medium text-gray-700">Price</th>
                <th className="text-left py-3 px-6 text-sm font-medium text-gray-700">Classes</th>
                <th className="text-left py-3 px-6 text-sm font-medium text-gray-700">Notes</th>
                <th className="text-left py-3 px-6 text-sm font-medium text-gray-700">Projects Code</th>
                <th className="text-left py-3 px-6 text-sm font-medium text-gray-700">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-gray-200">
              {courses.map((course) => (
                <tr key={course.id} className="hover:bg-gray-50">
                  <td className="py-4 px-6">
                    <div className="flex items-center space-x-3">
                      <div className="flex-shrink-0">
                        <Play className="w-5 h-5 text-gray-400" />
                      </div>
                      <div className="min-w-0 flex-1">
                        <p className="text-sm font-medium text-gray-900">{course.title}</p>
                        <p className="text-sm text-gray-500 truncate">{course.description}</p>
                        <p className="text-xs text-gray-400">Created {new Date(course.createdAt).toLocaleDateString()}</p>
                      </div>
                    </div>
                  </td>
                  <td className="py-4 px-6">
                    <span className="text-sm text-gray-900">{course.category}</span>
                  </td>
                  <td className="py-4 px-6">
                    <span className="text-sm font-medium text-gray-900">₹ {course.price.toLocaleString()}</span>
                  </td>
                  <td className="py-4 px-6">
                    <div>
                      <p className="text-sm font-medium text-gray-900">{course.classes?.length || 0} Classes</p>
                      {course.classes && course.classes.length > 0 && (
                        <div className="text-xs text-gray-500 mt-1">
                          {course.classes.map((cls, index) => (
                            <div key={index}>Class {cls.classNumber}: {cls.title}</div>
                          ))}
                        </div>
                      )}
                    </div>
                  </td>
                  <td className="py-4 px-6">
                    <div>
                      <p className="text-sm font-medium text-gray-900">{course.notes?.length || 0} Notes</p>
                      {course.notes && course.notes.length > 0 && (
                        <div className="text-xs text-gray-500 mt-1">
                          {course.notes.slice(0, 2).map((note, index) => (
                            <div key={index}>{note.title}</div>
                          ))}
                          {course.notes.length > 2 && (
                            <div className="text-xs text-gray-400">+{course.notes.length - 2} more</div>
                          )}
                        </div>
                      )}
                    </div>
                  </td>
                  <td className="py-4 px-6">
                    <div>
                      <p className="text-sm font-medium text-gray-900">{course.projects?.length || 0} Projects</p>
                      {course.projects && course.projects.length > 0 && (
                        <div className="text-xs text-gray-500 mt-1">
                          {course.projects.slice(0, 2).map((project, index) => (
                            <div key={index}>{project.title}</div>
                          ))}
                          {course.projects.length > 2 && (
                            <div className="text-xs text-gray-400">+{course.projects.length - 2} more</div>
                          )}
                        </div>
                      )}
                    </div>
                  </td>
                  <td className="py-4 px-6">
                    <div className="flex items-center space-x-2">
                      {/* Quick Publish Toggle */}
                      <Button
                        variant={course.isPublished ? "default" : "outline"}
                        size="sm"
                        onClick={() => togglePublish(course)}
                        className={course.isPublished
                          ? "text-white bg-green-600 hover:bg-green-700 h-8 px-3"
                          : "text-gray-600 border-orange-300 hover:bg-orange-50 h-8 px-3"
                        }
                        title={course.isPublished
                          ? "Course is live on website"
                          : "Click to publish course to website"
                        }
                      >
                        {course.isPublished ? '✅ Published' : '📤 Publish'}
                      </Button>

                      <DropdownMenu>
                        <DropdownMenuTrigger asChild>
                          <Button variant="ghost" size="sm" className="text-gray-600 hover:text-gray-900">
                            <Edit className="w-4 h-4 mr-1" />
                            Edit
                            <ChevronDown className="w-3 h-3 ml-1" />
                          </Button>
                        </DropdownMenuTrigger>
                        <DropdownMenuContent align="end" className="w-56">
                          <DropdownMenuItem
                            onClick={() => handleOpenEditModal(course)}
                          >
                            <Settings className="w-4 h-4 mr-2" />
                            Edit Course Details
                          </DropdownMenuItem>
                          <DropdownMenuItem
                            onClick={() => {
                              setSelectedCourse(course);
                              setCurrentStep('class');
                              setIsManageModalOpen(true);
                            }}
                          >
                            <Plus className="w-4 h-4 mr-2" />
                            Add Class/Notes/Projects
                          </DropdownMenuItem>
                          <DropdownMenuItem
                            onClick={() => window.open(`/courses`, '_blank')}
                          >
                            <Eye className="w-4 h-4 mr-2" />
                            Preview on Website
                          </DropdownMenuItem>
                          {course.classes && course.classes.some(c => c.videos && c.videos.length > 0) && (
                            <DropdownMenuItem
                              onClick={() => {
                                const classesWithVideos = course.classes.filter(c => c.videos && c.videos.length > 0);
                                const videoDetails = classesWithVideos.map(c => ({
                                  class: c.title,
                                  videos: c.videos.map(v => ({
                                    title: v.title,
                                    key: v.videoUrl || v.fileUrl,
                                    stored: !!(v.videoUrl && localStorage.getItem(v.videoUrl))
                                  }))
                                }));

                                console.log('Course video details:', videoDetails);

                                const totalVideos = videoDetails.reduce((sum, c) => sum + c.videos.length, 0);
                                const storedVideos = videoDetails.reduce((sum, c) =>
                                  sum + c.videos.filter(v => v.stored).length, 0);

                                toast({
                                  title: "��� Video Status",
                                  description: `${storedVideos}/${totalVideos} videos properly stored`,
                                });
                              }}
                            >
                              <Play className="w-4 h-4 mr-2" />
                              Test Videos ({course.classes.filter(c => c.videos && c.videos.length > 0).length} classes)
                            </DropdownMenuItem>
                          )}
                          {course.classes && course.classes.length > 0 && (
                            <>
                              <div className="border-t border-gray-200 my-1"></div>
                              <div className="px-2 py-1 text-xs font-medium text-gray-500 uppercase">Edit Classes:</div>
                              {course.classes.map((classItem: any, index: number) => (
                                <DropdownMenuItem
                                  key={index}
                                  onClick={() => {
                                    setSelectedCourse(course);
                                    handleEditClass(classItem);
                                  }}
                                  className="pl-6"
                                >
                                  <Edit className="w-3 h-3 mr-2" />
                                  Class {classItem.classNumber}: {classItem.title}
                                </DropdownMenuItem>
                              ))}
                            </>
                          )}
                        </DropdownMenuContent>
                      </DropdownMenu>
                      
                      <DropdownMenu>
                        <DropdownMenuTrigger asChild>
                          <Button variant="ghost" size="sm" className="text-red-600 hover:text-red-700">
                            <Trash2 className="w-4 h-4 mr-1" />
                            Delete
                            <ChevronDown className="w-3 h-3 ml-1" />
                          </Button>
                        </DropdownMenuTrigger>
                        <DropdownMenuContent align="end" className="w-64">
                          <DropdownMenuItem
                            onClick={() => handleDeleteCourseConfirm(course.id, course.title)}
                            className="text-red-600 hover:bg-red-50"
                          >
                            <Trash2 className="w-4 h-4 mr-2" />
                            Delete Entire Course
                          </DropdownMenuItem>
                          <DropdownMenuItem
                            onClick={() => handleDeleteAllContent(course.id, course.title)}
                            className="text-orange-600 hover:bg-orange-50"
                          >
                            <Trash2 className="w-4 h-4 mr-2" />
                            Delete All Content Only
                          </DropdownMenuItem>
                          {course.classes && course.classes.length > 0 && (
                            <>
                              <div className="border-t border-gray-200 my-1"></div>
                              <div className="px-2 py-1 text-xs font-medium text-gray-500 uppercase">Delete Classes:</div>
                              {course.classes.map((classItem: any, index: number) => (
                                <DropdownMenuItem
                                  key={index}
                                  onClick={() => {
                                    setSelectedCourse(course);
                                    handleDeleteClass(classItem);
                                  }}
                                  className="text-red-600 hover:bg-red-50 pl-6"
                                >
                                  <Trash2 className="w-3 h-3 mr-2" />
                                  Class {classItem.classNumber}: {classItem.title}
                                </DropdownMenuItem>
                              ))}
                            </>
                          )}
                        </DropdownMenuContent>
                      </DropdownMenu>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
          
          {courses.length === 0 && (
            <div className="text-center py-12">
              <BookOpen className="w-12 h-12 mx-auto text-gray-300 mb-4" />
              <h3 className="text-lg font-medium text-gray-900 mb-2">No courses yet</h3>
              <p className="text-gray-600 mb-6">Get started by creating your first course</p>
              <Button
                onClick={() => setIsAddModalOpen(true)}
                className="bg-purple-600 hover:bg-purple-700 text-white px-6 py-2 rounded-lg font-medium"
              >
                <Plus className="w-4 h-4 mr-2" />
                Create Course
              </Button>
            </div>
          )}
        </div>
      </div>

      {/* Example Workflow Section */}
      <div className="px-8 py-8">
        <div className="bg-gray-50 rounded-lg p-6">
          <h3 className="text-lg font-semibold text-gray-900 mb-4 flex items-center">
            <Star className="w-5 h-5 text-red-500 mr-2" />
            Example Workflow
          </h3>
          
          <div className="space-y-4">
            <div>
              <h4 className="text-sm font-medium text-gray-900 mb-2">Step 1: Create Course</h4>
              <p className="text-sm text-gray-600">
                Admin clicks "Add Course" → Fills "Web Dev Course" with Demo Video → Saves
              </p>
            </div>
            
            <div>
              <h4 className="text-sm font-medium text-gray-900 mb-2">Step 2: Add Classes</h4>
              <p className="text-sm text-gray-600">
                Admin clicks "Add Class + Notes + Code" → Select course → Add class content
              </p>
            </div>
          </div>
        </div>
      </div>

      {/* Add Course Modal */}
      <Dialog open={isAddModalOpen} onOpenChange={setIsAddModalOpen}>
        <DialogContent className="max-w-md max-h-[85vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <Plus className="w-5 h-5 text-purple-600" />
              Add New Course
            </DialogTitle>
          </DialogHeader>

          <div className="space-y-3 py-3">
            {/* Title and Duration on same line */}
            <div className="grid grid-cols-2 gap-3">
              <div>
                <Label htmlFor="title" className="text-sm">Course Title</Label>
                <Input
                  id="title"
                  placeholder="Full Stack Web Development"
                  value={courseForm.title}
                  onChange={(e) => setCourseForm(prev => ({ ...prev, title: e.target.value }))}
                  className="h-8 text-sm"
                />
              </div>
              <div>
                <Label htmlFor="duration" className="text-sm">Duration</Label>
                <Input
                  id="duration"
                  placeholder="20 hours"
                  value={courseForm.duration}
                  onChange={(e) => setCourseForm(prev => ({ ...prev, duration: e.target.value }))}
                  className="h-8 text-sm"
                />
              </div>
            </div>

            {/* Description */}
            <div>
              <Label htmlFor="description" className="text-sm">Description</Label>
              <Textarea
                id="description"
                placeholder="Brief overview of what students will learn..."
                value={courseForm.description}
                onChange={(e) => setCourseForm(prev => ({ ...prev, description: e.target.value }))}
                rows={2}
                className="text-sm resize-none"
              />
            </div>

            {/* Category and Price on same line */}
            <div className="grid grid-cols-2 gap-3">
              <div>
                <Label htmlFor="category" className="text-sm">Category</Label>
                <Select value={courseForm.category} onValueChange={(value) => setCourseForm(prev => ({ ...prev, category: value }))}>
                  <SelectTrigger className="h-8 text-sm">
                    <SelectValue placeholder="Select category" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="Web Development">Web Development</SelectItem>
                    <SelectItem value="Mobile Development">Mobile Development</SelectItem>
                    <SelectItem value="Data Science">Data Science</SelectItem>
                    <SelectItem value="Machine Learning">Machine Learning</SelectItem>
                    <SelectItem value="DevOps">DevOps</SelectItem>
                    <SelectItem value="UI/UX Design">UI/UX Design</SelectItem>
                    <SelectItem value="Programming">Programming</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div>
                <Label htmlFor="price" className="text-sm">Price (₹)</Label>
                <div className="relative">
                  <span className="absolute left-2 top-2 text-gray-500 text-sm">₹</span>
                  <Input
                    id="price"
                    type="number"
                    placeholder="2999"
                    className="pl-6 h-8 text-sm"
                    value={courseForm.price}
                    onChange={(e) => setCourseForm(prev => ({ ...prev, price: e.target.value }))}
                  />
                </div>
              </div>
            </div>

            {/* Video Upload */}
            <div>
              <Label className="text-sm">Video Upload</Label>
              <div className="border-2 border-dashed border-gray-300 rounded-lg p-3 text-center">
                <Video className="w-6 h-6 mx-auto text-gray-400 mb-1" />
                <p className="text-xs text-gray-600 mb-2">Upload demo video</p>
                <input
                  type="file"
                  accept="video/*"
                  onChange={handleVideoUpload}
                  className="hidden"
                  id="demo-video"
                />
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => document.getElementById('demo-video')?.click()}
                  className="h-7 text-xs"
                >
                  Choose Video
                </Button>
                {courseForm.demoVideo && (
                  <p className="text-xs text-green-600 mt-1">✅ {courseForm.demoVideo.name}</p>
                )}
              </div>
            </div>

            {/* Thumbnail Upload */}
            <div>
              <Label className="text-sm">Thumbnail</Label>
              <div className="border-2 border-dashed border-gray-300 rounded-lg p-3 text-center">
                <Image className="w-6 h-6 mx-auto text-gray-400 mb-1" />
                <p className="text-xs text-gray-600 mb-2">Upload course thumbnail</p>
                <input
                  type="file"
                  accept="image/*"
                  onChange={handleThumbnailUpload}
                  className="hidden"
                  id="thumbnail"
                />
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => document.getElementById('thumbnail')?.click()}
                  className="h-7 text-xs"
                >
                  Choose Image
                </Button>
                {courseForm.thumbnail && (
                  <div className="mt-2">
                    <img 
                      src={courseForm.thumbnail} 
                      alt="Thumbnail preview"
                      className="w-16 h-16 mx-auto rounded-lg object-cover"
                    />
                  </div>
                )}
              </div>
            </div>
          </div>

          {/* Save Button - Always visible */}
          <div className="flex gap-3 pt-3 border-t">
            <Button variant="outline" onClick={() => setIsAddModalOpen(false)} className="flex-1 h-8 text-sm">
              Cancel
            </Button>
            <Button
              onClick={handleAddCourse}
              className="flex-1 bg-purple-600 hover:bg-purple-700 text-white h-8 text-sm rounded-lg font-medium shadow-sm"
            >
              <Save className="w-3 h-3 mr-1" />
              Save Course
            </Button>
          </div>
        </DialogContent>
      </Dialog>

      {/* Edit Course Modal */}
      <Dialog open={isEditModalOpen} onOpenChange={setIsEditModalOpen}>
        <DialogContent className="max-w-4xl max-h-[85vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <Edit className="w-5 h-5 text-blue-600" />
              Edit Course: {selectedCourse?.title}
            </DialogTitle>
          </DialogHeader>

          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 py-4">
            {/* Left Column - Course Details */}
            <div className="space-y-4">
              <h3 className="text-lg font-semibold text-gray-900 border-b pb-2">Course Details</h3>

              {/* Title and Duration */}
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <Label htmlFor="editTitle" className="text-sm">Course Title</Label>
                  <Input
                    id="editTitle"
                    placeholder="Full Stack Web Development"
                    value={courseForm.title}
                    onChange={(e) => setCourseForm(prev => ({ ...prev, title: e.target.value }))}
                    className="h-8 text-sm"
                  />
                </div>
                <div>
                  <Label htmlFor="editDuration" className="text-sm">Duration</Label>
                  <Input
                    id="editDuration"
                    placeholder="20 hours"
                    value={courseForm.duration}
                    onChange={(e) => setCourseForm(prev => ({ ...prev, duration: e.target.value }))}
                    className="h-8 text-sm"
                  />
                </div>
              </div>

              {/* Description */}
              <div>
                <Label htmlFor="editDescription" className="text-sm">Description</Label>
                <Textarea
                  id="editDescription"
                  placeholder="Brief overview of what students will learn..."
                  value={courseForm.description}
                  onChange={(e) => setCourseForm(prev => ({ ...prev, description: e.target.value }))}
                  rows={3}
                  className="text-sm resize-none"
                />
              </div>

              {/* Category and Price */}
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <Label htmlFor="editCategory" className="text-sm">Category</Label>
                  <Select value={courseForm.category} onValueChange={(value) => setCourseForm(prev => ({ ...prev, category: value }))}>
                    <SelectTrigger className="h-8 text-sm">
                      <SelectValue placeholder="Select category" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="Web Development">Web Development</SelectItem>
                      <SelectItem value="Mobile Development">Mobile Development</SelectItem>
                      <SelectItem value="Data Science">Data Science</SelectItem>
                      <SelectItem value="Machine Learning">Machine Learning</SelectItem>
                      <SelectItem value="DevOps">DevOps</SelectItem>
                      <SelectItem value="UI/UX Design">UI/UX Design</SelectItem>
                      <SelectItem value="Programming">Programming</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div>
                  <Label htmlFor="editPrice" className="text-sm">Price (₹)</Label>
                  <div className="relative">
                    <span className="absolute left-2 top-2 text-gray-500 text-sm">₹</span>
                    <Input
                      id="editPrice"
                      type="number"
                      placeholder="2999"
                      className="pl-6 h-8 text-sm"
                      value={courseForm.price}
                      onChange={(e) => setCourseForm(prev => ({ ...prev, price: e.target.value }))}
                    />
                  </div>
                </div>
              </div>

              {/* Update Course Button */}
              <Button
                onClick={handleEditCourse}
                className="w-full bg-blue-600 hover:bg-blue-700 text-white h-9 text-sm rounded-lg font-medium shadow-sm"
              >
                <Save className="w-4 h-4 mr-2" />
                Update Course
              </Button>
            </div>

            {/* Right Column - Classes */}
            <div className="space-y-4">
              <h3 className="text-lg font-semibold text-gray-900 border-b pb-2 flex items-center justify-between">
                Classes ({selectedCourse?.classes?.length || 0})
                <span className="text-xs text-gray-500 font-normal">Click any class to edit</span>
              </h3>

              {/* Classes List */}
              <div className="space-y-2 max-h-96 overflow-y-auto">
                {selectedCourse?.classes && selectedCourse.classes.length > 0 ? (
                  selectedCourse.classes.map((classItem: any, index: number) => (
                    <div
                      key={index}
                      className="p-3 rounded-lg border cursor-pointer transition-colors border-gray-200 hover:bg-blue-50 hover:border-blue-300"
                      onClick={() => handleEditClass(classItem)}
                    >
                      <div className="flex justify-between items-start">
                        <div>
                          <h4 className="text-sm font-medium text-gray-900">
                            Class {classItem.classNumber}: {classItem.title}
                          </h4>
                          <p className="text-xs text-gray-500 mt-1">{classItem.description}</p>
                          <div className="flex items-center mt-1 space-x-3">
                            <span className="text-xs text-gray-500">{classItem.duration}</span>
                            {classItem.isDemo && (
                              <Badge variant="outline" className="text-xs">Demo</Badge>
                            )}
                          </div>
                        </div>
                        <Edit className="w-4 h-4 text-blue-500" />
                      </div>
                    </div>
                  ))
                ) : (
                  <div className="text-center py-6 text-gray-500">
                    <BookOpen className="w-8 h-8 mx-auto mb-2 text-gray-300" />
                    <p className="text-sm">No classes added yet</p>
                  </div>
                )}
              </div>
            </div>
          </div>

          {/* Close Button */}
          <div className="flex justify-end pt-4 border-t">
            <Button
              variant="outline"
              onClick={() => {
                setIsEditModalOpen(false);
                setEditingClass(null);
                setSelectedCourse(null);
                setCourseForm({
                  title: '',
                  duration: '',
                  description: '',
                  category: '',
                  price: '',
                  thumbnail: '',
                  demoVideo: null
                });
              }}
              className="px-6"
            >
              Close
            </Button>
          </div>
        </DialogContent>
      </Dialog>

      {/* Class Edit Modal */}
      <Dialog open={isClassEditModalOpen} onOpenChange={setIsClassEditModalOpen}>
        <DialogContent className="max-w-2xl max-h-[85vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <BookOpen className="w-5 h-5 text-blue-600" />
              Edit Class {editingClass?.classNumber}: {editingClass?.title}
            </DialogTitle>
            <p className="text-sm text-gray-600">
              Course: {selectedCourse?.title}
            </p>
          </DialogHeader>

          <div className="py-4 space-y-4">
            {/* Class Number and Duration */}
            <div className="grid grid-cols-2 gap-4">
              <div>
                <Label htmlFor="classNumber" className="text-sm font-medium">Class Number</Label>
                <Input
                  id="classNumber"
                  type="number"
                  placeholder="1"
                  value={classForm.classNumber}
                  onChange={(e) => setClassForm(prev => ({ ...prev, classNumber: e.target.value }))}
                  className="h-9 text-sm mt-1"
                />
              </div>
              <div>
                <Label htmlFor="classDuration" className="text-sm font-medium">Duration</Label>
                <Input
                  id="classDuration"
                  placeholder="45 min"
                  value={classForm.duration}
                  onChange={(e) => setClassForm(prev => ({ ...prev, duration: e.target.value }))}
                  className="h-9 text-sm mt-1"
                />
              </div>
            </div>

            {/* Class Title */}
            <div>
              <Label htmlFor="classTitle" className="text-sm font-medium">Class Title</Label>
              <Input
                id="classTitle"
                placeholder="Introduction to React"
                value={classForm.title}
                onChange={(e) => setClassForm(prev => ({ ...prev, title: e.target.value }))}
                className="h-9 text-sm mt-1"
              />
            </div>

            {/* Class Description */}
            <div>
              <Label htmlFor="classDesc" className="text-sm font-medium">Class Description</Label>
              <Textarea
                id="classDesc"
                placeholder="What will students learn in this class?"
                value={classForm.description}
                onChange={(e) => setClassForm(prev => ({ ...prev, description: e.target.value }))}
                rows={4}
                className="text-sm resize-none mt-1"
              />
            </div>

            {/* Video Upload */}
            <div>
              <Label className="text-sm font-medium">Update Class Video (Optional)</Label>
              <div className="border-2 border-dashed border-gray-300 rounded-lg p-4 text-center mt-1">
                <Video className="w-8 h-8 mx-auto text-gray-400 mb-2" />
                <p className="text-sm text-gray-600 mb-2">Upload new class video</p>
                <input
                  type="file"
                  accept="video/*"
                  onChange={handleClassVideoUpload}
                  className="hidden"
                  id="edit-class-video"
                />
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => document.getElementById('edit-class-video')?.click()}
                  className="h-8 text-xs"
                >
                  Choose Video
                </Button>
                {classForm.video && (
                  <p className="text-xs text-green-600 mt-2">✅ {classForm.video.name}</p>
                )}
              </div>
            </div>

            {/* Demo Class Toggle */}
            <div className="flex items-center space-x-3 p-3 bg-gray-50 rounded-lg">
              <input
                type="checkbox"
                id="isDemoClass"
                checked={classForm.isDemo}
                onChange={(e) => setClassForm(prev => ({ ...prev, isDemo: e.target.checked }))}
                className="h-4 w-4 text-blue-600"
              />
              <div>
                <Label htmlFor="isDemoClass" className="text-sm font-medium cursor-pointer">
                  Make this a demo class (free preview)
                </Label>
                <p className="text-xs text-gray-500">Demo classes are available to all users for free</p>
              </div>
            </div>

            {/* Class Stats */}
            <div className="grid grid-cols-3 gap-4 p-4 bg-blue-50 rounded-lg border border-blue-200">
              <div className="text-center">
                <p className="text-sm font-medium text-blue-900">Videos</p>
                <p className="text-lg font-bold text-blue-600">{editingClass?.videos?.length || 0}</p>
              </div>
              <div className="text-center">
                <p className="text-sm font-medium text-blue-900">Notes</p>
                <p className="text-lg font-bold text-blue-600">{editingClass?.notes?.length || 0}</p>
              </div>
              <div className="text-center">
                <p className="text-sm font-medium text-blue-900">Projects</p>
                <p className="text-lg font-bold text-blue-600">{editingClass?.projects?.length || 0}</p>
              </div>
            </div>
          </div>

          {/* Action Buttons */}
          <div className="flex gap-3 pt-4 border-t">
            <Button
              variant="outline"
              onClick={() => {
                setIsClassEditModalOpen(false);
                setEditingClass(null);
                setClassForm({
                  classNumber: '',
                  duration: '',
                  title: '',
                  description: '',
                  video: null,
                  videoKey: '',
                  isDemo: false
                });
              }}
              className="h-9"
            >
              Cancel
            </Button>
            <Button
              variant="outline"
              onClick={() => {
                if (editingClass) {
                  handleDeleteClass(editingClass);
                }
              }}
              className="h-9 text-red-600 border-red-200 hover:bg-red-50 hover:border-red-300"
            >
              <Trash2 className="w-4 h-4 mr-2" />
              Delete Class
            </Button>
            <Button
              onClick={handleUpdateClass}
              className="flex-1 bg-blue-600 hover:bg-blue-700 text-white h-9 font-medium shadow-sm"
            >
              <Save className="w-4 h-4 mr-2" />
              Update Class
            </Button>
          </div>
        </DialogContent>
      </Dialog>

      {/* Course Management Modal - Multi-step Wizard */}
      <Dialog open={isManageModalOpen} onOpenChange={setIsManageModalOpen}>
        <DialogContent className="max-w-lg max-h-[85vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              {currentStep === 'class' && <BookOpen className="w-5 h-5 text-blue-600" />}
              {currentStep === 'notes' && <FileText className="w-5 h-5 text-green-600" />}
              {currentStep === 'codes' && <Code className="w-5 h-5 text-orange-600" />}
              {currentStep === 'complete' && <Star className="w-5 h-5 text-purple-600" />}
              {currentStep === 'class' && 'Step 1: Add Class'}
              {currentStep === 'notes' && 'Step 2: Add Notes'}
              {currentStep === 'codes' && 'Step 3: Add Codes'}
              {currentStep === 'complete' && 'Content Added Successfully!'}
            </DialogTitle>
            <p className="text-sm text-gray-600">
              Course: {selectedCourse?.title}
            </p>
          </DialogHeader>

          <div className="py-4">
            {/* Step 1: Add Class */}
            {currentStep === 'class' && (
              <div className="space-y-3">
                {/* Class Number and Duration */}
                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <Label htmlFor="classNumber" className="text-sm">Class Number</Label>
                    <Input
                      id="classNumber"
                      placeholder="1"
                      type="number"
                      value={classForm.classNumber}
                      onChange={(e) => setClassForm(prev => ({ ...prev, classNumber: e.target.value }))}
                      className="h-8 text-sm"
                    />
                  </div>
                  <div>
                    <Label htmlFor="classDuration" className="text-sm">Duration</Label>
                    <Input
                      id="classDuration"
                      placeholder="45 min"
                      value={classForm.duration}
                      onChange={(e) => setClassForm(prev => ({ ...prev, duration: e.target.value }))}
                      className="h-8 text-sm"
                    />
                  </div>
                </div>

                {/* Title */}
                <div>
                  <Label htmlFor="classTitle" className="text-sm">Title</Label>
                  <Input
                    id="classTitle"
                    placeholder="Introduction to React"
                    value={classForm.title}
                    onChange={(e) => setClassForm(prev => ({ ...prev, title: e.target.value }))}
                    className="h-8 text-sm"
                  />
                </div>

                {/* Description */}
                <div>
                  <Label htmlFor="classDesc" className="text-sm">Description</Label>
                  <Textarea
                    id="classDesc"
                    placeholder="What will students learn in this class?"
                    value={classForm.description}
                    onChange={(e) => setClassForm(prev => ({ ...prev, description: e.target.value }))}
                    rows={2}
                    className="text-sm resize-none"
                  />
                </div>

                {/* Video Upload */}
                <div>
                  <Label className="text-sm">Video Upload</Label>
                  <div className="border-2 border-dashed border-gray-300 rounded-lg p-3 text-center">
                    <Video className="w-6 h-6 mx-auto text-gray-400 mb-1" />
                    <p className="text-xs text-gray-600 mb-2">Upload class video</p>
                    <input
                      type="file"
                      accept="video/*"
                      onChange={handleClassVideoUpload}
                      className="hidden"
                      id="class-video"
                    />
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => document.getElementById('class-video')?.click()}
                      className="h-7 text-xs"
                    >
                      Choose Video
                    </Button>
                    {classForm.video && (
                      <div className="mt-2 p-2 bg-green-50 rounded border border-green-200">
                        <p className="text-xs text-green-800 font-medium">✅ Video Ready: {classForm.video.name}</p>
                        <p className="text-xs text-green-600">
                          Size: {(classForm.video.size / 1024 / 1024).toFixed(2)} MB •
                          Type: {classForm.video.type || 'Unknown'} •
                          Ready for streaming
                        </p>
                      </div>
                    )}
                  </div>
                </div>

                {/* Demo checkbox */}
                <div className="flex items-center space-x-2">
                  <input
                    type="checkbox"
                    id="isDemo"
                    checked={classForm.isDemo}
                    onChange={(e) => setClassForm(prev => ({ ...prev, isDemo: e.target.checked }))}
                    className="h-4 w-4"
                  />
                  <Label htmlFor="isDemo" className="text-sm">Make this a demo class (free preview)</Label>
                </div>

                <Button
                  onClick={handleSaveClass}
                  className="w-full bg-blue-600 hover:bg-blue-700 text-white h-8 text-sm rounded-lg font-medium shadow-sm"
                >
                  <Save className="w-3 h-3 mr-1" />
                  Save Class & Continue to Notes
                </Button>
              </div>
            )}

            {/* Step 2: Add Notes */}
            {currentStep === 'notes' && (
              <div className="space-y-3">
                <div>
                  <Label htmlFor="noteTitle" className="text-sm">Note Title</Label>
                  <Input
                    id="noteTitle"
                    placeholder="Class 1 - React Basics Notes"
                    value={noteForm.title}
                    onChange={(e) => setNoteForm(prev => ({ ...prev, title: e.target.value }))}
                    className="h-8 text-sm"
                  />
                </div>
                <div>
                  <Label htmlFor="noteDesc" className="text-sm">Note Description</Label>
                  <Textarea
                    id="noteDesc"
                    placeholder="Brief description of the note content"
                    value={noteForm.description}
                    onChange={(e) => setNoteForm(prev => ({ ...prev, description: e.target.value }))}
                    rows={2}
                    className="text-sm resize-none"
                  />
                </div>
                <div>
                  <Label className="text-sm">Upload Note File</Label>
                  <div className="border-2 border-dashed border-gray-300 rounded-lg p-3 text-center">
                    <FileText className="w-6 h-6 mx-auto text-gray-400 mb-1" />
                    <p className="text-xs text-gray-600 mb-2">Upload PDF, DOC, or TXT file</p>
                    <input
                      type="file"
                      accept=".pdf,.doc,.docx,.txt"
                      onChange={handleNoteFileUpload}
                      className="hidden"
                      id="note-file"
                    />
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => document.getElementById('note-file')?.click()}
                      className="h-7 text-xs"
                    >
                      Choose File
                    </Button>
                    {noteForm.file && (
                      <div className="mt-2 p-2 bg-green-50 rounded border border-green-200">
                        <p className="text-xs text-green-800 font-medium">✅ File Ready: {noteForm.file.name}</p>
                        <p className="text-xs text-green-600">
                          Size: {(noteForm.file.size / 1024 / 1024).toFixed(2)} MB •
                          Type: {noteForm.file.type || 'Unknown'} •
                          Ready for download
                        </p>
                      </div>
                    )}
                  </div>
                </div>
                <Button
                  onClick={handleSaveNote}
                  className="w-full bg-green-600 hover:bg-green-700 text-white h-8 text-sm rounded-lg font-medium shadow-sm"
                >
                  <Save className="w-3 h-3 mr-1" />
                  Save Notes & Continue to Codes
                </Button>
              </div>
            )}

            {/* Step 3: Add Codes */}
            {currentStep === 'codes' && (
              <div className="space-y-3">
                <div>
                  <Label htmlFor="projectTitle" className="text-sm">Code Project Title</Label>
                  <Input
                    id="projectTitle"
                    placeholder="Class 1 - React Components Code"
                    value={projectForm.title}
                    onChange={(e) => setProjectForm(prev => ({ ...prev, title: e.target.value }))}
                    className="h-8 text-sm"
                  />
                </div>
                <div>
                  <Label htmlFor="projectDesc" className="text-sm">Code Description</Label>
                  <Textarea
                    id="projectDesc"
                    placeholder="Describe what this code teaches"
                    value={projectForm.description}
                    onChange={(e) => setProjectForm(prev => ({ ...prev, description: e.target.value }))}
                    rows={2}
                    className="text-sm resize-none"
                  />
                </div>
                <div>
                  <Label htmlFor="githubUrl" className="text-sm">GitHub Repository URL</Label>
                  <Input
                    id="githubUrl"
                    placeholder="https://github.com/username/repository"
                    value={projectForm.githubUrl}
                    onChange={(e) => setProjectForm(prev => ({ ...prev, githubUrl: e.target.value }))}
                    className="h-8 text-sm"
                  />
                </div>
                <div>
                  <Label htmlFor="liveUrl" className="text-sm">Live Demo URL (Optional)</Label>
                  <Input
                    id="liveUrl"
                    placeholder="https://your-project.netlify.app"
                    value={projectForm.liveUrl}
                    onChange={(e) => setProjectForm(prev => ({ ...prev, liveUrl: e.target.value }))}
                    className="h-8 text-sm"
                  />
                </div>
                <Button
                  onClick={handleSaveProject}
                  className="w-full bg-orange-600 hover:bg-orange-700 text-white h-8 text-sm rounded-lg font-medium shadow-sm"
                >
                  <Save className="w-3 h-3 mr-1" />
                  Save Code & Complete
                </Button>
              </div>
            )}

            {/* Step 4: Completion */}
            {currentStep === 'complete' && (
              <div className="text-center space-y-4 py-6">
                <div className="w-16 h-16 bg-green-100 rounded-full flex items-center justify-center mx-auto">
                  <Star className="w-8 h-8 text-green-600" />
                </div>
                <h3 className="text-lg font-semibold text-gray-900">Content Added Successfully!</h3>
                <p className="text-gray-600">
                  Your class, notes, and code have been added to the course.
                </p>

                {/* Updated Course Stats */}
                <div className="grid grid-cols-3 gap-4 p-4 bg-gray-50 rounded-lg">
                  <div className="text-center">
                    <p className="text-sm font-medium text-gray-700">Classes</p>
                    <p className="text-xl font-bold text-blue-600">{selectedCourse?.classes?.length || 0}</p>
                  </div>
                  <div className="text-center">
                    <p className="text-sm font-medium text-gray-700">Notes</p>
                    <p className="text-xl font-bold text-green-600">{selectedCourse?.notes?.length || 0}</p>
                  </div>
                  <div className="text-center">
                    <p className="text-sm font-medium text-gray-700">Projects</p>
                    <p className="text-xl font-bold text-orange-600">{selectedCourse?.projects?.length || 0}</p>
                  </div>
                </div>

                {/* Action Buttons */}
                <div className="flex gap-3">
                  <Button
                    onClick={() => {
                      setCurrentStep('class');
                    }}
                    className="flex-1 bg-blue-600 hover:bg-blue-700 text-white h-9 font-medium"
                  >
                    <Plus className="w-4 h-4 mr-2" />
                    Add More Content
                  </Button>
                  <Button
                    onClick={() => {
                      setIsManageModalOpen(false);
                      setCurrentStep('class');
                      setSelectedCourse(null);
                    }}
                    variant="outline"
                    className="flex-1 h-9"
                  >
                    Finish & Close
                  </Button>
                </div>
              </div>
            )}
          </div>

          {/* Progress Indicator */}
          <div className="flex justify-center space-x-2 pt-2 border-t">
            <div className={`w-2 h-2 rounded-full ${currentStep === 'class' ? 'bg-blue-600' : currentStep === 'complete' ? 'bg-green-300' : 'bg-gray-300'}`}></div>
            <div className={`w-2 h-2 rounded-full ${currentStep === 'notes' ? 'bg-green-600' : currentStep === 'complete' ? 'bg-green-300' : 'bg-gray-300'}`}></div>
            <div className={`w-2 h-2 rounded-full ${currentStep === 'codes' ? 'bg-orange-600' : currentStep === 'complete' ? 'bg-green-300' : 'bg-gray-300'}`}></div>
            <div className={`w-2 h-2 rounded-full ${currentStep === 'complete' ? 'bg-purple-600' : 'bg-gray-300'}`}></div>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
};

export default AdminCourses;
