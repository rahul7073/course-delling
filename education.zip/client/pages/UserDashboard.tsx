import React, { useState, useEffect } from 'react';
import { useAuth } from '../contexts/AuthContext';
import { useData } from '../contexts/DataContext';
import { Button } from '../components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '../components/ui/card';
import { Badge } from '../components/ui/badge';
import { Progress } from '../components/ui/progress';
import { useToast } from '@/hooks/use-toast';
import { useNavigate } from 'react-router-dom';
import {
  BookOpen,
  Play,
  CheckCircle2,
  Clock,
  Download,
  Trophy,
  TrendingUp,
  Users,
  Calendar,
  Star,
  ArrowRight,
  PlayCircle
} from 'lucide-react';

const UserDashboard: React.FC = () => {
  const { user } = useAuth();
  const { courses, orders, getUserProgress, userProgress } = useData();
  const { toast } = useToast();
  const navigate = useNavigate();
  const [activeTab, setActiveTab] = useState<'overview' | 'courses' | 'progress'>('overview');

  // Get user's unlocked courses
  const unlockedCourses = React.useMemo(() => {
    if (!user) return [];
    
    const userOrders = orders.filter(order => 
      order.userId === user.id && 
      order.paymentStatus === 'completed' && 
      order.isUnlocked
    );
    
    return userOrders.map(order => {
      const course = courses.find(c => c.id === order.courseId);
      const progress = getUserProgress(user.id, order.courseId);
      return { course, order, progress };
    }).filter(item => item.course);
  }, [user, orders, courses, getUserProgress]);

  // Calculate overall stats
  const stats = React.useMemo(() => {
    if (!user) return { totalCourses: 0, completedCourses: 0, totalProgress: 0, totalTimeSpent: 0 };
    
    const totalCourses = unlockedCourses.length;
    const completedCourses = unlockedCourses.filter(item => 
      item.progress && item.progress.progressPercentage >= 100
    ).length;
    
    const totalProgress = totalCourses > 0 
      ? unlockedCourses.reduce((sum, item) => sum + (item.progress?.progressPercentage || 0), 0) / totalCourses
      : 0;
      
    const totalTimeSpent = unlockedCourses.reduce((sum, item) => 
      sum + (item.progress?.totalTimeSpent || 0), 0
    );
    
    return { totalCourses, completedCourses, totalProgress, totalTimeSpent };
  }, [user, unlockedCourses]);

  const formatTime = (minutes: number) => {
    const hours = Math.floor(minutes / 60);
    const mins = minutes % 60;
    return hours > 0 ? `${hours}h ${mins}m` : `${mins}m`;
  };

  const handleContinueCourse = (courseId: string) => {
    navigate(`/course/${courseId}`);
  };

  if (!user) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <Card className="w-full max-w-md">
          <CardContent className="p-6 text-center">
            <BookOpen className="w-12 h-12 mx-auto mb-4 text-muted-foreground" />
            <h2 className="text-xl font-semibold mb-2">Please Login</h2>
            <p className="text-muted-foreground mb-4">You need to be logged in to view your dashboard.</p>
            <Button onClick={() => navigate('/login')}>
              Login to Continue
            </Button>
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50">
      <div className="container mx-auto px-4 py-8">
        {/* Header */}
        <div className="mb-8">
          <h1 className="text-3xl font-bold mb-2">Welcome back, {user.name}!</h1>
          <p className="text-muted-foreground">Continue your learning journey</p>
        </div>

        {/* Stats Cards */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
          <Card>
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-muted-foreground">Total Courses</p>
                  <p className="text-2xl font-bold">{stats.totalCourses}</p>
                </div>
                <BookOpen className="w-8 h-8 text-blue-600" />
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-muted-foreground">Completed</p>
                  <p className="text-2xl font-bold">{stats.completedCourses}</p>
                </div>
                <Trophy className="w-8 h-8 text-yellow-600" />
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-muted-foreground">Avg Progress</p>
                  <p className="text-2xl font-bold">{Math.round(stats.totalProgress)}%</p>
                </div>
                <TrendingUp className="w-8 h-8 text-green-600" />
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-muted-foreground">Time Spent</p>
                  <p className="text-2xl font-bold">{formatTime(stats.totalTimeSpent)}</p>
                </div>
                <Clock className="w-8 h-8 text-purple-600" />
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Navigation Tabs */}
        <div className="flex space-x-1 bg-muted p-1 rounded-lg mb-6 w-fit">
          <Button
            variant={activeTab === 'overview' ? 'default' : 'ghost'}
            size="sm"
            onClick={() => setActiveTab('overview')}
          >
            Overview
          </Button>
          <Button
            variant={activeTab === 'courses' ? 'default' : 'ghost'}
            size="sm"
            onClick={() => setActiveTab('courses')}
          >
            My Courses
          </Button>
          <Button
            variant={activeTab === 'progress' ? 'default' : 'ghost'}
            size="sm"
            onClick={() => setActiveTab('progress')}
          >
            Progress
          </Button>
        </div>

        {/* Tab Content */}
        {activeTab === 'overview' && (
          <div className="space-y-6">
            {/* Continue Learning Section */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <PlayCircle className="w-5 h-5" />
                  Continue Learning
                </CardTitle>
              </CardHeader>
              <CardContent>
                {unlockedCourses.length > 0 ? (
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    {unlockedCourses.slice(0, 4).map((item) => (
                      <Card key={item.course?.id} className="hover:shadow-md transition-shadow">
                        <CardContent className="p-4">
                          <div className="flex items-start gap-4">
                            <img
                              src={item.course?.thumbnail}
                              alt={item.course?.title}
                              className="w-16 h-16 rounded-lg object-cover"
                            />
                            <div className="flex-1 min-w-0">
                              <h3 className="font-medium truncate">{item.course?.title}</h3>
                              <p className="text-sm text-muted-foreground mb-2">
                                {item.course?.instructor.name}
                              </p>
                              <div className="space-y-2">
                                <Progress
                                  value={item.progress?.progressPercentage || 0}
                                  className="h-2"
                                />
                                <div className="flex items-center justify-between text-xs">
                                  <span>{Math.round(item.progress?.progressPercentage || 0)}% complete</span>
                                  <Button
                                    size="sm"
                                    variant="outline"
                                    onClick={() => handleContinueCourse(item.course?.id!)}
                                  >
                                    Continue
                                    <ArrowRight className="w-3 h-3 ml-1" />
                                  </Button>
                                </div>
                              </div>
                            </div>
                          </div>
                        </CardContent>
                      </Card>
                    ))}
                  </div>
                ) : (
                  <div className="text-center py-8">
                    <BookOpen className="w-12 h-12 mx-auto mb-4 text-muted-foreground opacity-50" />
                    <h3 className="font-medium mb-2">No courses yet</h3>
                    <p className="text-muted-foreground mb-4">Explore our courses and start learning!</p>
                    <Button onClick={() => navigate('/courses')}>
                      Browse Courses
                    </Button>
                  </div>
                )}
              </CardContent>
            </Card>

            {/* Recent Activity */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Clock className="w-5 h-5" />
                  Recent Activity
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {unlockedCourses.slice(0, 3).map((item) => (
                    <div key={item.course?.id} className="flex items-center gap-3 p-3 bg-muted/30 rounded-lg">
                      <CheckCircle2 className="w-5 h-5 text-green-600" />
                      <div>
                        <p className="font-medium">Started learning {item.course?.title}</p>
                        <p className="text-sm text-muted-foreground">
                          {new Date(item.progress?.lastAccessed || item.order.orderDate).toLocaleDateString()}
                        </p>
                      </div>
                    </div>
                  ))}
                  {unlockedCourses.length === 0 && (
                    <p className="text-muted-foreground text-center py-4">No recent activity</p>
                  )}
                </div>
              </CardContent>
            </Card>
          </div>
        )}

        {activeTab === 'courses' && (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {unlockedCourses.map((item) => (
              <Card key={item.course?.id} className="hover:shadow-lg transition-shadow">
                <CardContent className="p-6">
                  <img
                    src={item.course?.thumbnail}
                    alt={item.course?.title}
                    className="w-full h-40 object-cover rounded-lg mb-4"
                  />
                  <h3 className="font-semibold text-lg mb-2">{item.course?.title}</h3>
                  <p className="text-sm text-muted-foreground mb-3">
                    {item.course?.instructor.name}
                  </p>
                  
                  <div className="space-y-3 mb-4">
                    <Progress
                      value={item.progress?.progressPercentage || 0}
                      className="h-2"
                    />
                    <div className="flex items-center justify-between text-sm">
                      <span>{Math.round(item.progress?.progressPercentage || 0)}% complete</span>
                      <span>{item.course?.totalLessons} lessons</span>
                    </div>
                  </div>

                  <div className="flex gap-2">
                    <Button
                      className="flex-1"
                      onClick={() => handleContinueCourse(item.course?.id!)}
                    >
                      <Play className="w-4 h-4 mr-2" />
                      Continue
                    </Button>
                    {(item.progress?.progressPercentage || 0) >= 100 && (
                      <Badge variant="secondary" className="bg-green-100 text-green-700">
                        <Trophy className="w-3 h-3 mr-1" />
                        Completed
                      </Badge>
                    )}
                  </div>
                </CardContent>
              </Card>
            ))}
            
            {unlockedCourses.length === 0 && (
              <div className="col-span-full text-center py-12">
                <BookOpen className="w-16 h-16 mx-auto mb-4 text-muted-foreground opacity-50" />
                <h3 className="text-xl font-semibold mb-2">No unlocked courses</h3>
                <p className="text-muted-foreground mb-6">Purchase courses to start your learning journey!</p>
                <Button onClick={() => navigate('/courses')}>
                  Explore Courses
                </Button>
              </div>
            )}
          </div>
        )}

        {activeTab === 'progress' && (
          <div className="space-y-6">
            {unlockedCourses.map((item) => (
              <Card key={item.course?.id}>
                <CardHeader>
                  <div className="flex items-center justify-between">
                    <div>
                      <CardTitle>{item.course?.title}</CardTitle>
                      <p className="text-muted-foreground">{item.course?.instructor.name}</p>
                    </div>
                    <Badge 
                      variant={
                        (item.progress?.progressPercentage || 0) >= 100 ? 'default' : 'secondary'
                      }
                    >
                      {Math.round(item.progress?.progressPercentage || 0)}% Complete
                    </Badge>
                  </div>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    <Progress
                      value={item.progress?.progressPercentage || 0}
                      className="h-3"
                    />
                    <div className="grid grid-cols-2 md:grid-cols-4 gap-4 text-sm">
                      <div>
                        <p className="text-muted-foreground">Classes Completed</p>
                        <p className="font-medium">
                          {item.progress?.completedClasses?.length || 0} / {item.course?.classes?.length || 0}
                        </p>
                      </div>
                      <div>
                        <p className="text-muted-foreground">Time Spent</p>
                        <p className="font-medium">{formatTime(item.progress?.totalTimeSpent || 0)}</p>
                      </div>
                      <div>
                        <p className="text-muted-foreground">Last Accessed</p>
                        <p className="font-medium">
                          {item.progress?.lastAccessed 
                            ? new Date(item.progress.lastAccessed).toLocaleDateString()
                            : 'Not started'
                          }
                        </p>
                      </div>
                      <div>
                        <p className="text-muted-foreground">Current Class</p>
                        <p className="font-medium">
                          {item.progress?.currentClass || 'Not started'}
                        </p>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        )}
      </div>
    </div>
  );
};

export default UserDashboard;
