import React, { useState, useEffect } from 'react';
import { apiDatabaseService } from '../services/ApiDatabaseService';
import { Order, Course } from '../../shared/database';
import { Button } from '../components/ui/button';
import { Input } from '../components/ui/input';
import { Card, CardContent, CardHeader, CardTitle } from '../components/ui/card';
import { Badge } from '../components/ui/badge';
import { Avatar, AvatarFallback, AvatarImage } from '../components/ui/avatar';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '../components/ui/dialog';
import { 
  Search, 
  Filter, 
  MoreHorizontal, 
  Eye, 
  CheckCircle, 
  X, 
  Download,
  Clock,
  DollarSign,
  User,
  BookOpen,
  Calendar
} from 'lucide-react';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from '../components/ui/dropdown-menu';

const AdminOrders: React.FC = () => {
  const [orders, setOrders] = useState<Order[]>([]);
  const [courses, setCourses] = useState<Course[]>([]);
  const [loading, setLoading] = useState(false);
  
  const [searchTerm, setSearchTerm] = useState('');
  const [statusFilter, setStatusFilter] = useState<string>('all');
  const [selectedOrder, setSelectedOrder] = useState<any>(null);
  const [isOrderModalOpen, setIsOrderModalOpen] = useState(false);

  // Load data from database
  const loadOrders = async () => {
    try {
      setLoading(true);
      const result = await apiDatabaseService.getOrders();

      if (result.success && result.data) {
        setOrders(result.data.data || []);
      }
    } catch (error) {
      console.error('Error loading orders:', error);
    } finally {
      setLoading(false);
    }
  };

  const loadCourses = async () => {
    try {
      const result = await apiDatabaseService.getCourses();

      if (result.success && result.data) {
        setCourses(result.data.data || []);
      }
    } catch (error) {
      console.error('Error loading courses:', error);
    }
  };

  useEffect(() => {
    loadOrders();
    loadCourses();
  }, []);

  // Enhanced orders with course details
  const enhancedOrders = orders.map(order => {
    const course = courses.find(c => c.id === order.courseId);
    
    return {
      ...order,
      userName: user?.name || 'Unknown User',
      userEmail: user?.email || 'unknown@email.com',
      userAvatar: user?.avatar || 'https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=150',
      courseTitle: course?.title || 'Unknown Course',
      courseThumbnail: course?.thumbnail || 'https://images.unsplash.com/photo-1516321318423-f06f85e504b3?w=400'
    };
  });

  const filteredOrders = enhancedOrders.filter(order => {
    const matchesSearch = order.userName.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         order.userEmail.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         order.courseTitle.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         order.id.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesStatus = statusFilter === 'all' || order.paymentStatus === statusFilter;
    return matchesSearch && matchesStatus;
  });

  const updatePaymentStatus = (orderId: string, status: 'completed' | 'failed' | 'refunded') => {
    updateOrder(orderId, {
      paymentStatus: status,
      paymentDate: status === 'completed' ? new Date().toISOString() : undefined,
      isUnlocked: status === 'completed'
    });
  };

  const toggleCourseAccess = (orderId: string) => {
    const order = orders.find(o => o.id === orderId);
    if (order) {
      updateOrder(orderId, {
        isUnlocked: !order.isUnlocked
      });
    }
  };

  const viewOrderDetails = (order: any) => {
    setSelectedOrder(order);
    setIsOrderModalOpen(true);
  };

  const getStatusBadge = (status: string) => {
    switch (status) {
      case 'completed':
        return <Badge className="bg-green-100 text-green-800">Completed</Badge>;
      case 'pending':
        return <Badge variant="secondary">Pending</Badge>;
      case 'failed':
        return <Badge variant="destructive">Failed</Badge>;
      case 'refunded':
        return <Badge className="bg-orange-100 text-orange-800">Refunded</Badge>;
      default:
        return <Badge variant="outline">Unknown</Badge>;
    }
  };

  const getPaymentMethodIcon = (method: string) => {
    switch (method.toLowerCase()) {
      case 'upi':
        return '📱';
      case 'credit card':
        return '💳';
      case 'debit card':
        return '💳';
      case 'net banking':
        return '🏦';
      default:
        return '💰';
    }
  };

  const completedOrders = orders.filter(o => o.paymentStatus === 'completed');
  const totalRevenue = completedOrders.reduce((sum, o) => sum + o.amount, 0);
  const todayOrders = orders.filter(order => 
    order.orderDate.startsWith(new Date().toISOString().split('T')[0])
  );

  const statsCards = [
    { 
      title: 'Total Orders', 
      value: orders.length, 
      icon: '📦',
      color: 'bg-blue-50 text-blue-700'
    },
    { 
      title: 'Completed', 
      value: completedOrders.length, 
      icon: '✅',
      color: 'bg-green-50 text-green-700'
    },
    { 
      title: 'Pending', 
      value: orders.filter(o => o.paymentStatus === 'pending').length, 
      icon: '⏳',
      color: 'bg-yellow-50 text-yellow-700'
    },
    { 
      title: 'Total Revenue', 
      value: `₹${totalRevenue.toLocaleString()}`, 
      icon: '💰',
      color: 'bg-purple-50 text-purple-700'
    }
  ];

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-3xl font-bold text-gray-900">Order Management</h1>
        <p className="text-gray-600">Track payments, manage course access, and handle transactions</p>
      </div>

      {/* Real-time Stats Cards */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        {statsCards.map((stat, index) => (
          <Card key={index}>
            <CardContent className="pt-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-gray-600">{stat.title}</p>
                  <p className="text-2xl font-bold">{typeof stat.value === 'string' ? stat.value : stat.value}</p>
                  {stat.title === 'Total Orders' && (
                    <p className="text-xs text-muted-foreground">
                      <span className="text-green-600">+{todayOrders.length}</span> today
                    </p>
                  )}
                </div>
                <div className={`p-2 rounded-full ${stat.color}`}>
                  <span className="text-xl">{stat.icon}</span>
                </div>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      {/* Search and Filters */}
      <Card>
        <CardContent className="pt-6">
          <div className="flex flex-col sm:flex-row gap-4">
            <div className="relative flex-1">
              <Search className="absolute left-3 top-3 h-4 w-4 text-gray-400" />
              <Input
                placeholder="Search by order ID, user name, email, or course..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="pl-10"
              />
            </div>
            <div className="flex items-center space-x-2">
              <Filter className="h-4 w-4 text-gray-400" />
              <select
                value={statusFilter}
                onChange={(e) => setStatusFilter(e.target.value)}
                className="px-3 py-2 border border-gray-300 rounded-md text-sm"
              >
                <option value="all">All Status</option>
                <option value="completed">Completed</option>
                <option value="pending">Pending</option>
                <option value="failed">Failed</option>
                <option value="refunded">Refunded</option>
              </select>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Orders Table */}
      <Card>
        <CardHeader>
          <CardTitle>Orders ({filteredOrders.length})</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead>
                <tr className="border-b">
                  <th className="text-left p-4">Order ID</th>
                  <th className="text-left p-4">Customer</th>
                  <th className="text-left p-4">Course</th>
                  <th className="text-left p-4">Amount</th>
                  <th className="text-left p-4">Payment</th>
                  <th className="text-left p-4">Status</th>
                  <th className="text-left p-4">Access</th>
                  <th className="text-left p-4">Date</th>
                  <th className="text-left p-4">Actions</th>
                </tr>
              </thead>
              <tbody>
                {filteredOrders.map((order) => (
                  <tr key={order.id} className="border-b hover:bg-gray-50">
                    <td className="p-4">
                      <span className="font-mono text-sm font-medium">{order.id}</span>
                    </td>
                    <td className="p-4">
                      <div className="flex items-center space-x-3">
                        <Avatar className="w-8 h-8">
                          <AvatarImage src={order.userAvatar} />
                          <AvatarFallback>{order.userName.charAt(0)}</AvatarFallback>
                        </Avatar>
                        <div>
                          <p className="font-medium text-sm">{order.userName}</p>
                          <p className="text-xs text-gray-600">{order.userEmail}</p>
                        </div>
                      </div>
                    </td>
                    <td className="p-4">
                      <div className="flex items-center space-x-2">
                        <img 
                          src={order.courseThumbnail} 
                          alt={order.courseTitle}
                          className="w-10 h-10 rounded object-cover"
                        />
                        <div>
                          <p className="font-medium text-sm line-clamp-2">{order.courseTitle}</p>
                        </div>
                      </div>
                    </td>
                    <td className="p-4">
                      <span className="font-bold">₹{order.amount.toLocaleString()}</span>
                    </td>
                    <td className="p-4">
                      <div className="flex items-center space-x-1">
                        <span>{getPaymentMethodIcon(order.paymentMethod)}</span>
                        <span className="text-sm">{order.paymentMethod}</span>
                      </div>
                    </td>
                    <td className="p-4">{getStatusBadge(order.paymentStatus)}</td>
                    <td className="p-4">
                      <Badge variant={order.isUnlocked ? 'default' : 'outline'}>
                        {order.isUnlocked ? 'Unlocked' : 'Locked'}
                      </Badge>
                    </td>
                    <td className="p-4">
                      <span className="text-sm">
                        {new Date(order.orderDate).toLocaleDateString()}
                      </span>
                    </td>
                    <td className="p-4">
                      <DropdownMenu>
                        <DropdownMenuTrigger asChild>
                          <Button variant="ghost" size="sm">
                            <MoreHorizontal className="h-4 w-4" />
                          </Button>
                        </DropdownMenuTrigger>
                        <DropdownMenuContent align="end">
                          <DropdownMenuItem onClick={() => viewOrderDetails(order)}>
                            <Eye className="h-4 w-4 mr-2" />
                            View Details
                          </DropdownMenuItem>
                          {order.paymentStatus === 'pending' && (
                            <>
                              <DropdownMenuItem onClick={() => updatePaymentStatus(order.id, 'completed')}>
                                <CheckCircle className="h-4 w-4 mr-2" />
                                Mark as Paid
                              </DropdownMenuItem>
                              <DropdownMenuItem onClick={() => updatePaymentStatus(order.id, 'failed')}>
                                <X className="h-4 w-4 mr-2" />
                                Mark as Failed
                              </DropdownMenuItem>
                            </>
                          )}
                          {order.paymentStatus === 'completed' && (
                            <DropdownMenuItem onClick={() => toggleCourseAccess(order.id)}>
                              {order.isUnlocked ? '🔒' : '🔓'} {order.isUnlocked ? 'Lock' : 'Unlock'} Course
                            </DropdownMenuItem>
                          )}
                          <DropdownMenuItem>
                            <Download className="h-4 w-4 mr-2" />
                            Download Receipt
                          </DropdownMenuItem>
                        </DropdownMenuContent>
                      </DropdownMenu>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </CardContent>
      </Card>

      {/* Order Details Modal */}
      <Dialog open={isOrderModalOpen} onOpenChange={setIsOrderModalOpen}>
        <DialogContent className="max-w-2xl">
          <DialogHeader>
            <DialogTitle>Order Details</DialogTitle>
          </DialogHeader>
          {selectedOrder && (
            <div className="space-y-6">
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <h4 className="font-semibold mb-2">Order Information</h4>
                  <div className="space-y-2 text-sm">
                    <p><span className="text-gray-600">Order ID:</span> {selectedOrder.id}</p>
                    <p><span className="text-gray-600">Order Date:</span> {new Date(selectedOrder.orderDate).toLocaleString()}</p>
                    {selectedOrder.paymentDate && (
                      <p><span className="text-gray-600">Payment Date:</span> {new Date(selectedOrder.paymentDate).toLocaleString()}</p>
                    )}
                    <p><span className="text-gray-600">Transaction ID:</span> {selectedOrder.transactionId}</p>
                  </div>
                </div>
                <div>
                  <h4 className="font-semibold mb-2">Customer Information</h4>
                  <div className="flex items-center space-x-3 mb-2">
                    <Avatar>
                      <AvatarImage src={selectedOrder.userAvatar} />
                      <AvatarFallback>{selectedOrder.userName.charAt(0)}</AvatarFallback>
                    </Avatar>
                    <div>
                      <p className="font-medium">{selectedOrder.userName}</p>
                      <p className="text-sm text-gray-600">{selectedOrder.userEmail}</p>
                    </div>
                  </div>
                </div>
              </div>

              <div>
                <h4 className="font-semibold mb-2">Course Information</h4>
                <div className="flex items-center space-x-3 p-3 bg-gray-50 rounded-lg">
                  <img 
                    src={selectedOrder.courseThumbnail} 
                    alt={selectedOrder.courseTitle}
                    className="w-16 h-16 rounded object-cover"
                  />
                  <div className="flex-1">
                    <p className="font-medium">{selectedOrder.courseTitle}</p>
                    <p className="text-lg font-bold text-green-600">₹{selectedOrder.amount.toLocaleString()}</p>
                  </div>
                  <div className="text-right">
                    {getStatusBadge(selectedOrder.paymentStatus)}
                    <div className="mt-1">
                      <Badge variant={selectedOrder.isUnlocked ? 'default' : 'outline'}>
                        {selectedOrder.isUnlocked ? 'Unlocked' : 'Locked'}
                      </Badge>
                    </div>
                  </div>
                </div>
              </div>

              <div>
                <h4 className="font-semibold mb-2">Payment Details</h4>
                <div className="grid grid-cols-2 gap-4 text-sm">
                  <div>
                    <p><span className="text-gray-600">Payment Method:</span> {selectedOrder.paymentMethod}</p>
                    <p><span className="text-gray-600">Amount:</span> ₹{selectedOrder.amount.toLocaleString()}</p>
                  </div>
                  <div>
                    <p><span className="text-gray-600">Status:</span> {selectedOrder.paymentStatus}</p>
                    <p><span className="text-gray-600">Course Access:</span> {selectedOrder.isUnlocked ? 'Granted' : 'Pending'}</p>
                  </div>
                </div>
              </div>

              <div className="flex justify-end space-x-2">
                <Button variant="outline" onClick={() => setIsOrderModalOpen(false)}>
                  Close
                </Button>
                {selectedOrder.paymentStatus === 'pending' && (
                  <>
                    <Button 
                      onClick={() => {
                        updatePaymentStatus(selectedOrder.id, 'completed');
                        setIsOrderModalOpen(false);
                      }}
                    >
                      Mark as Paid
                    </Button>
                    <Button 
                      variant="destructive"
                      onClick={() => {
                        updatePaymentStatus(selectedOrder.id, 'failed');
                        setIsOrderModalOpen(false);
                      }}
                    >
                      Mark as Failed
                    </Button>
                  </>
                )}
                {selectedOrder.paymentStatus === 'completed' && (
                  <Button 
                    variant={selectedOrder.isUnlocked ? 'destructive' : 'default'}
                    onClick={() => {
                      toggleCourseAccess(selectedOrder.id);
                      setIsOrderModalOpen(false);
                    }}
                  >
                    {selectedOrder.isUnlocked ? 'Lock Course' : 'Unlock Course'}
                  </Button>
                )}
              </div>
            </div>
          )}
        </DialogContent>
      </Dialog>
    </div>
  );
};

export default AdminOrders;
