import React, { useState, useEffect } from 'react';
import { useData } from '../contexts/DataContext';
import { Link } from 'react-router-dom';
import { Card, CardContent, CardHeader, CardTitle } from '../components/ui/card';
import { Badge } from '../components/ui/badge';
import PreviewStatus from '../components/PreviewStatus';
import {
  Users,
  BookOpen,
  ShoppingCart,
  DollarSign,
  Award,
  MessageSquare,
  TrendingUp,
  Eye,
  Activity,
  Clock,
  Bell,
  AlertTriangle,
  CheckCircle,
  ExternalLink
} from 'lucide-react';

const AdminDashboard: React.FC = () => {
  const { users, courses, orders, getStats } = useData();
  const [stats, setStats] = useState(getStats());
  const [currentTime, setCurrentTime] = useState(new Date());

  // Update stats in real-time
  useEffect(() => {
    setStats(getStats());
  }, [users, courses, orders, getStats]);

  // Real-time updates
  useEffect(() => {
    const handleDataUpdate = () => {
      setStats(getStats());
    };
    
    window.addEventListener('dataUpdated', handleDataUpdate);
    return () => window.removeEventListener('dataUpdated', handleDataUpdate);
  }, [getStats]);

  // Update time every second
  useEffect(() => {
    const timer = setInterval(() => {
      setCurrentTime(new Date());
    }, 1000);
    
    return () => clearInterval(timer);
  }, []);

  // Get pending payments
  const pendingPayments = orders.filter(order => order.paymentStatus === 'pending');

  // Get recent orders (last 5)
  const recentOrders = orders
    .sort((a, b) => new Date(b.orderDate).getTime() - new Date(a.orderDate).getTime())
    .slice(0, 5)
    .map(order => {
      const user = users.find(u => u.id === order.userId);
      const course = courses.find(c => c.id === order.courseId);
      return {
        ...order,
        userName: user?.name || 'Unknown User',
        courseName: course?.title || 'Unknown Course'
      };
    });

  // Get top courses by student count
  const topCourses = [...courses]
    .sort((a, b) => b.students - a.students)
    .slice(0, 4)
    .map(course => ({
      name: course.title,
      enrollments: course.students,
      revenue: course.students * course.price
    }));

  // Today's stats
  const today = new Date().toISOString().split('T')[0];
  const todayOrders = orders.filter(order => 
    order.orderDate.startsWith(today)
  ).length;

  const newUsersToday = users.filter(user => 
    user.joinDate === today
  ).length;

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-3xl font-bold text-gray-900">Dashboard</h1>
          <p className="text-gray-600">Welcome to your EduMaster admin panel</p>
        </div>
        <div className="text-right">
          <div className="flex items-center space-x-2 text-sm text-gray-600">
            <Clock className="h-4 w-4" />
            <span>{currentTime.toLocaleTimeString()}</span>
          </div>
          <div className="flex items-center space-x-2 text-sm text-gray-500">
            <Activity className="h-4 w-4" />
            <span>{stats.onlineUsers} users online</span>
          </div>
        </div>
      </div>

      {/* Real-time Stats Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Total Users</CardTitle>
            <Users className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{stats.totalUsers.toLocaleString()}</div>
            <p className="text-xs text-muted-foreground">
              <span className="text-green-600">+{newUsersToday}</span> new today
            </p>
            <div className="mt-2">
              <div className="flex items-center space-x-2 text-xs">
                <div className="w-2 h-2 bg-green-500 rounded-full"></div>
                <span>{stats.onlineUsers} online now</span>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Total Courses</CardTitle>
            <BookOpen className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{stats.totalCourses}</div>
            <p className="text-xs text-muted-foreground">
              {courses.filter(c => c.isPublished).length} published
            </p>
            <div className="mt-2">
              <div className="flex items-center space-x-2 text-xs">
                <div className="w-2 h-2 bg-blue-500 rounded-full"></div>
                <span>{courses.filter(c => c.isFree).length} free courses</span>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Total Orders</CardTitle>
            <ShoppingCart className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{stats.totalOrders}</div>
            <p className="text-xs text-muted-foreground">
              <span className="text-green-600">+{todayOrders}</span> today
            </p>
            <div className="mt-2">
              <div className="flex items-center space-x-2 text-xs">
                <div className="w-2 h-2 bg-orange-500 rounded-full"></div>
                <span>{orders.filter(o => o.paymentStatus === 'pending').length} pending</span>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Total Revenue</CardTitle>
            <DollarSign className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">₹{stats.totalRevenue.toLocaleString()}</div>
            <p className="text-xs text-muted-foreground">
              <span className="text-green-600">+12.5%</span> from last month
            </p>
            <div className="mt-2">
              <div className="flex items-center space-x-2 text-xs">
                <div className="w-2 h-2 bg-green-500 rounded-full"></div>
                <span>₹{Math.round(stats.totalRevenue / stats.totalOrders || 0)} avg order</span>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Pending Payments Alert */}
      {pendingPayments.length > 0 && (
        <Card className="border-orange-200 bg-orange-50">
          <CardHeader>
            <CardTitle className="flex items-center gap-2 text-orange-700">
              <Bell className="h-5 w-5 animate-pulse" />
              Pending Payment Approvals ({pendingPayments.length})
              <Badge variant="secondary" className="bg-orange-200 text-orange-800">
                Requires Action
              </Badge>
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              {pendingPayments.slice(0, 3).map((payment) => {
                const user = users.find(u => u.id === payment.userId);
                const course = courses.find(c => c.id === payment.courseId);
                const timeAgo = Math.floor((Date.now() - new Date(payment.orderDate).getTime()) / (1000 * 60));

                return (
                  <div key={payment.id} className="flex items-center justify-between p-3 bg-white rounded-lg border border-orange-200">
                    <div className="flex items-center gap-3">
                      <AlertTriangle className="h-5 w-5 text-orange-600" />
                      <div>
                        <p className="font-medium text-sm">{user?.name || 'Unknown User'}</p>
                        <p className="text-xs text-gray-600">{course?.title || 'Unknown Course'}</p>
                        <p className="text-xs text-orange-600">{timeAgo} min ago • ₹{payment.amount.toLocaleString()}</p>
                      </div>
                    </div>
                    <div className="flex items-center gap-2">
                      <Badge variant="outline" className="text-xs">
                        {payment.transactionId?.substring(0, 8)}...
                      </Badge>
                    </div>
                  </div>
                );
              })}

              {pendingPayments.length > 3 && (
                <div className="text-center pt-2">
                  <p className="text-sm text-orange-600">
                    +{pendingPayments.length - 3} more pending payments
                  </p>
                </div>
              )}

              <div className="flex justify-center pt-2">
                <Link to="/admin/payment-approval">
                  <button className="flex items-center gap-2 px-4 py-2 bg-orange-600 text-white rounded-lg hover:bg-orange-700 transition-colors">
                    <CheckCircle className="h-4 w-4" />
                    Review & Approve Payments
                    <ExternalLink className="h-4 w-4" />
                  </button>
                </Link>
              </div>
            </div>
          </CardContent>
        </Card>
      )}

      {/* Real-time Activity */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Recent Orders */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <ShoppingCart className="h-5 w-5" />
              Recent Orders ({recentOrders.length})
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {recentOrders.length > 0 ? recentOrders.map((order) => (
                <div key={order.id} className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                  <div>
                    <p className="font-medium">{order.userName}</p>
                    <p className="text-sm text-gray-600">{order.courseName}</p>
                    <p className="text-xs text-gray-500">{new Date(order.orderDate).toLocaleString()}</p>
                  </div>
                  <div className="text-right">
                    <p className="font-medium">₹{order.amount.toLocaleString()}</p>
                    <Badge variant={order.paymentStatus === 'completed' ? 'default' : order.paymentStatus === 'pending' ? 'secondary' : 'destructive'}>
                      {order.paymentStatus}
                    </Badge>
                  </div>
                </div>
              )) : (
                <div className="text-center py-8 text-gray-500">
                  <ShoppingCart className="h-12 w-12 mx-auto mb-4 text-gray-300" />
                  <p>No orders yet</p>
                </div>
              )}
            </div>
          </CardContent>
        </Card>

        {/* Top Courses */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <TrendingUp className="h-5 w-5" />
              Top Performing Courses
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {topCourses.length > 0 ? topCourses.map((course, index) => (
                <div key={index} className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                  <div className="flex items-center space-x-3">
                    <div className="w-8 h-8 bg-blue-100 rounded-full flex items-center justify-center text-sm font-bold text-blue-600">
                      {index + 1}
                    </div>
                    <div>
                      <p className="font-medium">{course.name}</p>
                      <p className="text-sm text-gray-600">{course.enrollments} students</p>
                    </div>
                  </div>
                  <div className="text-right">
                    <p className="font-medium">₹{course.revenue.toLocaleString()}</p>
                  </div>
                </div>
              )) : (
                <div className="text-center py-8 text-gray-500">
                  <BookOpen className="h-12 w-12 mx-auto mb-4 text-gray-300" />
                  <p>No courses yet</p>
                </div>
              )}
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Quick Stats */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Award className="h-5 w-5" />
              Certifications
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold mb-2">
              {users.reduce((total, user) => total + (user.certificates?.length || 0), 0)}
            </div>
            <p className="text-sm text-gray-600">Total certificates issued</p>
            <div className="mt-3 space-y-1">
              <div className="flex justify-between text-sm">
                <span>React Certificates:</span>
                <span className="font-medium">
                  {users.filter(u => u.certificates?.includes('1')).length}
                </span>
              </div>
              <div className="flex justify-between text-sm">
                <span>ML Certificates:</span>
                <span className="font-medium">
                  {users.filter(u => u.certificates?.includes('2')).length}
                </span>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <MessageSquare className="h-5 w-5" />
              Support Status
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold mb-2 text-green-600">All Clear</div>
            <p className="text-sm text-gray-600">No pending support tickets</p>
            <div className="mt-3 space-y-1">
              <div className="flex justify-between text-sm">
                <span>Response Time:</span>
                <span className="font-medium text-green-600">&lt; 2 hours</span>
              </div>
              <div className="flex justify-between text-sm">
                <span>Satisfaction:</span>
                <span className="font-medium">98.5%</span>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Eye className="h-5 w-5" />
              Platform Status
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold mb-2 text-green-600">Online</div>
            <p className="text-sm text-gray-600">All systems operational</p>
            <div className="mt-3 space-y-1">
              <div className="flex justify-between text-sm">
                <span>Uptime:</span>
                <span className="font-medium">99.9%</span>
              </div>
              <div className="flex justify-between text-sm">
                <span>Load Time:</span>
                <span className="font-medium">1.2s</span>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Website Preview Status */}
      <div className="mt-8">
        <h2 className="text-2xl font-bold mb-6">📢 Website Preview & Publishing Status</h2>
        <PreviewStatus />
      </div>
    </div>
  );
};

export default AdminDashboard;
