import React, { useState } from 'react';
import { Button } from '../components/ui/button';
import { Input } from '../components/ui/input';
import { Textarea } from '../components/ui/textarea';
import { Card, CardContent, CardHeader, CardTitle } from '../components/ui/card';
import { Badge } from '../components/ui/badge';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '../components/ui/dialog';
import { 
  Search, 
  Filter, 
  MessageSquare, 
  Reply, 
  Trash2, 
  Star,
  Clock,
  CheckCircle,
  AlertCircle,
  MoreHorizontal
} from 'lucide-react';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from '../components/ui/dropdown-menu';

interface ContactMessage {
  id: string;
  name: string;
  email: string;
  subject: string;
  message: string;
  status: 'new' | 'read' | 'replied' | 'resolved';
  priority: 'low' | 'medium' | 'high';
  createdAt: string;
  repliedAt?: string;
  reply?: string;
  category: 'general' | 'technical' | 'billing' | 'course' | 'certificate';
}

const AdminMessages: React.FC = () => {
  const [messages, setMessages] = useState<ContactMessage[]>([
    {
      id: '1',
      name: 'Rahul Sharma',
      email: 'rahul.sharma@gmail.com',
      subject: 'Course Access Issue',
      message: 'Hi, I purchased the React course but cannot access the videos. Please help.',
      status: 'new',
      priority: 'high',
      createdAt: '2024-01-15T10:30:00Z',
      category: 'technical'
    },
    {
      id: '2',
      name: 'Priya Patel',
      email: 'priya.patel@gmail.com',
      subject: 'Certificate Download Problem',
      message: 'I completed my exam and paid for the certificate but the download link is not working.',
      status: 'read',
      priority: 'medium',
      createdAt: '2024-01-15T09:15:00Z',
      category: 'certificate'
    },
    {
      id: '3',
      name: 'Amit Kumar',
      email: 'amit.kumar@gmail.com',
      subject: 'Refund Request',
      message: 'I want to request a refund for the ML course as it did not meet my expectations.',
      status: 'replied',
      priority: 'high',
      createdAt: '2024-01-14T16:45:00Z',
      repliedAt: '2024-01-14T17:30:00Z',
      reply: 'Hi Amit, I understand your concern. Please share more details about what specific aspects did not meet your expectations so we can help you better.',
      category: 'billing'
    },
    {
      id: '4',
      name: 'Sneha Singh',
      email: 'sneha.singh@gmail.com',
      subject: 'Course Recommendation',
      message: 'I am a beginner in programming. Which course would you recommend for me to start with?',
      status: 'resolved',
      priority: 'low',
      createdAt: '2024-01-14T11:20:00Z',
      repliedAt: '2024-01-14T14:15:00Z',
      reply: 'Hi Sneha, I would recommend starting with our JavaScript Fundamentals course as it provides a solid foundation for web development.',
      category: 'course'
    },
    {
      id: '5',
      name: 'Arjun Mehta',
      email: 'arjun.mehta@gmail.com',
      subject: 'Bulk Purchase Inquiry',
      message: 'Hi, I represent a company and we want to purchase courses for 50 employees. Do you offer corporate discounts?',
      status: 'new',
      priority: 'high',
      createdAt: '2024-01-15T14:00:00Z',
      category: 'billing'
    }
  ]);

  const [searchTerm, setSearchTerm] = useState('');
  const [statusFilter, setStatusFilter] = useState<string>('all');
  const [priorityFilter, setPriorityFilter] = useState<string>('all');
  const [categoryFilter, setCategoryFilter] = useState<string>('all');
  const [selectedMessage, setSelectedMessage] = useState<ContactMessage | null>(null);
  const [isMessageModalOpen, setIsMessageModalOpen] = useState(false);
  const [replyText, setReplyText] = useState('');

  const filteredMessages = messages.filter(msg => {
    const matchesSearch = msg.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         msg.email.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         msg.subject.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesStatus = statusFilter === 'all' || msg.status === statusFilter;
    const matchesPriority = priorityFilter === 'all' || msg.priority === priorityFilter;
    const matchesCategory = categoryFilter === 'all' || msg.category === categoryFilter;
    
    return matchesSearch && matchesStatus && matchesPriority && matchesCategory;
  });

  const updateMessageStatus = (messageId: string, status: ContactMessage['status']) => {
    setMessages(messages.map(msg => 
      msg.id === messageId ? { ...msg, status } : msg
    ));
  };

  const deleteMessage = (messageId: string) => {
    if (window.confirm('Are you sure you want to delete this message?')) {
      setMessages(messages.filter(msg => msg.id !== messageId));
    }
  };

  const sendReply = () => {
    if (selectedMessage && replyText.trim()) {
      setMessages(messages.map(msg => 
        msg.id === selectedMessage.id 
          ? { 
              ...msg, 
              status: 'replied',
              reply: replyText,
              repliedAt: new Date().toISOString()
            }
          : msg
      ));
      setReplyText('');
      setIsMessageModalOpen(false);
    }
  };

  const viewMessage = (message: ContactMessage) => {
    setSelectedMessage(message);
    setIsMessageModalOpen(true);
    if (message.status === 'new') {
      updateMessageStatus(message.id, 'read');
    }
  };

  const getStatusBadge = (status: string) => {
    switch (status) {
      case 'new':
        return <Badge variant="destructive">New</Badge>;
      case 'read':
        return <Badge variant="secondary">Read</Badge>;
      case 'replied':
        return <Badge className="bg-blue-100 text-blue-800">Replied</Badge>;
      case 'resolved':
        return <Badge className="bg-green-100 text-green-800">Resolved</Badge>;
      default:
        return <Badge variant="outline">Unknown</Badge>;
    }
  };

  const getPriorityBadge = (priority: string) => {
    switch (priority) {
      case 'high':
        return <Badge variant="destructive">High</Badge>;
      case 'medium':
        return <Badge className="bg-yellow-100 text-yellow-800">Medium</Badge>;
      case 'low':
        return <Badge variant="secondary">Low</Badge>;
      default:
        return <Badge variant="outline">Normal</Badge>;
    }
  };

  const getCategoryIcon = (category: string) => {
    switch (category) {
      case 'technical':
        return '🔧';
      case 'billing':
        return '💰';
      case 'course':
        return '📚';
      case 'certificate':
        return '🏆';
      default:
        return '💬';
    }
  };

  const statsCards = [
    { title: 'Total Messages', value: messages.length, color: 'bg-blue-50 text-blue-700' },
    { title: 'New Messages', value: messages.filter(m => m.status === 'new').length, color: 'bg-red-50 text-red-700' },
    { title: 'Pending Reply', value: messages.filter(m => m.status === 'read').length, color: 'bg-yellow-50 text-yellow-700' },
    { title: 'Resolved', value: messages.filter(m => m.status === 'resolved').length, color: 'bg-green-50 text-green-700' }
  ];

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-3xl font-bold text-gray-900">Contact Messages</h1>
        <p className="text-gray-600">Manage customer inquiries and support requests</p>
      </div>

      {/* Stats Cards */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        {statsCards.map((stat, index) => (
          <Card key={index}>
            <CardContent className="pt-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-gray-600">{stat.title}</p>
                  <p className="text-2xl font-bold">{stat.value}</p>
                </div>
                <div className={`p-2 rounded-full ${stat.color}`}>
                  <MessageSquare className="h-6 w-6" />
                </div>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      {/* Filters */}
      <Card>
        <CardContent className="pt-6">
          <div className="grid grid-cols-1 md:grid-cols-5 gap-4">
            <div className="relative">
              <Search className="absolute left-3 top-3 h-4 w-4 text-gray-400" />
              <Input
                placeholder="Search messages..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="pl-10"
              />
            </div>
            <select
              value={statusFilter}
              onChange={(e) => setStatusFilter(e.target.value)}
              className="px-3 py-2 border border-gray-300 rounded-md text-sm"
            >
              <option value="all">All Status</option>
              <option value="new">New</option>
              <option value="read">Read</option>
              <option value="replied">Replied</option>
              <option value="resolved">Resolved</option>
            </select>
            <select
              value={priorityFilter}
              onChange={(e) => setPriorityFilter(e.target.value)}
              className="px-3 py-2 border border-gray-300 rounded-md text-sm"
            >
              <option value="all">All Priority</option>
              <option value="high">High</option>
              <option value="medium">Medium</option>
              <option value="low">Low</option>
            </select>
            <select
              value={categoryFilter}
              onChange={(e) => setCategoryFilter(e.target.value)}
              className="px-3 py-2 border border-gray-300 rounded-md text-sm"
            >
              <option value="all">All Categories</option>
              <option value="general">General</option>
              <option value="technical">Technical</option>
              <option value="billing">Billing</option>
              <option value="course">Course</option>
              <option value="certificate">Certificate</option>
            </select>
            <div className="text-sm text-gray-500 flex items-center">
              {filteredMessages.length} messages
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Messages List */}
      <Card>
        <CardHeader>
          <CardTitle>Messages ({filteredMessages.length})</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {filteredMessages.map((message) => (
              <div
                key={message.id}
                className={`p-4 border rounded-lg cursor-pointer hover:bg-gray-50 transition-colors ${
                  message.status === 'new' ? 'border-red-200 bg-red-50' : 'border-gray-200'
                }`}
                onClick={() => viewMessage(message)}
              >
                <div className="flex items-start justify-between">
                  <div className="flex-1">
                    <div className="flex items-center space-x-3 mb-2">
                      <span className="text-lg">{getCategoryIcon(message.category)}</span>
                      <h3 className="font-semibold text-lg">{message.subject}</h3>
                      {getStatusBadge(message.status)}
                      {getPriorityBadge(message.priority)}
                    </div>
                    <div className="flex items-center space-x-4 text-sm text-gray-600 mb-2">
                      <span className="font-medium">{message.name}</span>
                      <span>{message.email}</span>
                      <span>{new Date(message.createdAt).toLocaleDateString()}</span>
                    </div>
                    <p className="text-gray-700 line-clamp-2">{message.message}</p>
                  </div>
                  <div className="flex items-center space-x-2">
                    <DropdownMenu>
                      <DropdownMenuTrigger asChild>
                        <Button variant="ghost" size="sm" onClick={(e) => e.stopPropagation()}>
                          <MoreHorizontal className="h-4 w-4" />
                        </Button>
                      </DropdownMenuTrigger>
                      <DropdownMenuContent align="end">
                        <DropdownMenuItem onClick={() => updateMessageStatus(message.id, 'resolved')}>
                          <CheckCircle className="h-4 w-4 mr-2" />
                          Mark as Resolved
                        </DropdownMenuItem>
                        <DropdownMenuItem onClick={() => updateMessageStatus(message.id, 'new')}>
                          <AlertCircle className="h-4 w-4 mr-2" />
                          Mark as New
                        </DropdownMenuItem>
                        <DropdownMenuItem onClick={() => deleteMessage(message.id)} className="text-red-600">
                          <Trash2 className="h-4 w-4 mr-2" />
                          Delete
                        </DropdownMenuItem>
                      </DropdownMenuContent>
                    </DropdownMenu>
                  </div>
                </div>
              </div>
            ))}
            {filteredMessages.length === 0 && (
              <div className="text-center py-8 text-gray-500">
                No messages found matching your filters.
              </div>
            )}
          </div>
        </CardContent>
      </Card>

      {/* Message Details Modal */}
      <Dialog open={isMessageModalOpen} onOpenChange={setIsMessageModalOpen}>
        <DialogContent className="max-w-3xl">
          <DialogHeader>
            <DialogTitle>Message Details</DialogTitle>
          </DialogHeader>
          {selectedMessage && (
            <div className="space-y-6">
              <div className="border-b pb-4">
                <div className="flex items-center justify-between mb-3">
                  <h3 className="text-xl font-semibold">{selectedMessage.subject}</h3>
                  <div className="flex items-center space-x-2">
                    {getStatusBadge(selectedMessage.status)}
                    {getPriorityBadge(selectedMessage.priority)}
                  </div>
                </div>
                <div className="flex items-center space-x-4 text-sm text-gray-600">
                  <span className="font-medium">From: {selectedMessage.name}</span>
                  <span>{selectedMessage.email}</span>
                  <span>{new Date(selectedMessage.createdAt).toLocaleString()}</span>
                </div>
              </div>

              <div>
                <h4 className="font-semibold mb-2">Message:</h4>
                <div className="bg-gray-50 p-4 rounded-lg">
                  <p className="whitespace-pre-wrap">{selectedMessage.message}</p>
                </div>
              </div>

              {selectedMessage.reply && (
                <div>
                  <h4 className="font-semibold mb-2">Your Reply:</h4>
                  <div className="bg-blue-50 p-4 rounded-lg">
                    <p className="whitespace-pre-wrap">{selectedMessage.reply}</p>
                    <p className="text-xs text-gray-600 mt-2">
                      Sent on {selectedMessage.repliedAt ? new Date(selectedMessage.repliedAt).toLocaleString() : ''}
                    </p>
                  </div>
                </div>
              )}

              <div>
                <h4 className="font-semibold mb-2">Send Reply:</h4>
                <Textarea
                  value={replyText}
                  onChange={(e) => setReplyText(e.target.value)}
                  placeholder="Type your reply here..."
                  rows={4}
                  className="mb-4"
                />
                <div className="flex justify-end space-x-2">
                  <Button variant="outline" onClick={() => setIsMessageModalOpen(false)}>
                    Close
                  </Button>
                  <Button 
                    onClick={() => updateMessageStatus(selectedMessage.id, 'resolved')}
                    variant="secondary"
                  >
                    Mark as Resolved
                  </Button>
                  <Button onClick={sendReply} disabled={!replyText.trim()}>
                    <Reply className="h-4 w-4 mr-2" />
                    Send Reply
                  </Button>
                </div>
              </div>
            </div>
          )}
        </DialogContent>
      </Dialog>
    </div>
  );
};

export default AdminMessages;
