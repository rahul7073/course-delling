import React from 'react';
import { Link } from 'react-router-dom';
import { useData } from '../contexts/DataContext';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Card, CardContent } from '@/components/ui/card';
import { CourseCard } from '../components/CourseCard';
import { CATEGORIES } from '@shared/types';
import { 
  Play, 
  Users, 
  Award, 
  BookOpen, 
  Star, 
  TrendingUp,
  Clock,
  CheckCircle,
  ArrowRight,
  Target,
  Brain,
  Globe
} from 'lucide-react';

export default function Index() {
  const { courses, users, getStats } = useData();
  const stats = getStats();

  // Get featured courses (published courses with highest ratings)
  const featuredCourses = courses
    .filter(course => course.isPublished)
    .sort((a, b) => b.rating - a.rating)
    .slice(0, 4);

  const popularCategories = CATEGORIES.slice(0, 6);

  return (
    <div className="min-h-screen">
      {/* Hero Section */}
      <section className="relative bg-gradient-to-br from-brand-50 via-background to-brand-50/30 py-20 lg:py-28">
        <div className="container mx-auto px-4">
          <div className="grid lg:grid-cols-2 gap-12 items-center">
            <div className="space-y-8">
              <div className="space-y-4">
                <Badge className="bg-brand-100 text-brand-700 hover:bg-brand-200">
                  🚀 Join 50,000+ Students Worldwide
                </Badge>
                <h1 className="text-4xl lg:text-6xl font-bold text-foreground leading-tight">
                  Master New Skills with 
                  <span className="text-primary"> Expert-Led</span> Courses
                </h1>
                <p className="text-xl text-muted-foreground leading-relaxed max-w-lg">
                  Unlock your potential with high-quality online courses. Learn at your own pace, 
                  get certified, and advance your career with industry professionals.
                </p>
              </div>

              <div className="flex flex-col sm:flex-row gap-4">
                <Button size="lg" className="text-lg px-8" asChild>
                  <Link to="/courses">
                    <Play className="w-5 h-5 mr-2" />
                    Start Learning Today
                  </Link>
                </Button>
                <Button size="lg" variant="outline" className="text-lg px-8" asChild>
                  <Link to="/courses?free=true">
                    <BookOpen className="w-5 h-5 mr-2" />
                    Browse Free Courses
                  </Link>
                </Button>
              </div>

              {/* Real-time Trust indicators */}
              <div className="flex items-center space-x-8 pt-4">
                <div className="text-center">
                  <div className="text-2xl font-bold text-primary">{stats.totalUsers.toLocaleString()}+</div>
                  <div className="text-sm text-muted-foreground">Students</div>
                </div>
                <div className="text-center">
                  <div className="text-2xl font-bold text-primary">{stats.totalCourses}+</div>
                  <div className="text-sm text-muted-foreground">Courses</div>
                </div>
                <div className="text-center">
                  <div className="text-2xl font-bold text-primary">4.8</div>
                  <div className="flex items-center justify-center mt-1">
                    {[...Array(5)].map((_, i) => (
                      <Star key={i} className="w-3 h-3 fill-yellow-400 text-yellow-400" />
                    ))}
                  </div>
                </div>
              </div>
            </div>

            {/* Hero Image/Video */}
            <div className="relative">
              <div className="aspect-video bg-gradient-to-br from-brand-100 to-brand-200 rounded-2xl overflow-hidden shadow-2xl">
                <img
                  src="https://images.unsplash.com/photo-1522202176988-66273c2fd55f?w=800"
                  alt="Students learning online"
                  className="w-full h-full object-cover"
                />
                <div className="absolute inset-0 bg-black/20 flex items-center justify-center">
                  <Button size="lg" className="rounded-full h-16 w-16 p-0">
                    <Play className="w-6 h-6" />
                  </Button>
                </div>
              </div>

              {/* Floating cards */}
              <Card className="absolute -bottom-4 -left-4 w-48 shadow-lg">
                <CardContent className="p-4">
                  <div className="flex items-center space-x-3">
                    <div className="w-10 h-10 bg-success/10 rounded-full flex items-center justify-center">
                      <CheckCircle className="w-5 h-5 text-success" />
                    </div>
                    <div>
                      <div className="font-semibold">Course Completed!</div>
                      <div className="text-sm text-muted-foreground">React Development</div>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card className="absolute -top-4 -right-4 w-40 shadow-lg">
                <CardContent className="p-4">
                  <div className="text-center">
                    <div className="text-2xl font-bold text-primary">98%</div>
                    <div className="text-sm text-muted-foreground">Success Rate</div>
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section className="py-20 bg-muted/20">
        <div className="container mx-auto px-4">
          <div className="text-center mb-12">
            <h2 className="text-3xl lg:text-4xl font-bold mb-4">
              Why Choose EduMaster?
            </h2>
            <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
              We provide everything you need to succeed in your learning journey
            </p>
          </div>

          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
            <Card className="text-center p-6 border-0 shadow-sm">
              <CardContent className="space-y-4">
                <div className="w-16 h-16 bg-brand-100 rounded-full flex items-center justify-center mx-auto">
                  <Target className="w-8 h-8 text-brand-600" />
                </div>
                <h3 className="text-xl font-semibold">Expert Instructors</h3>
                <p className="text-muted-foreground">
                  Learn from industry professionals with years of real-world experience
                </p>
              </CardContent>
            </Card>

            <Card className="text-center p-6 border-0 shadow-sm">
              <CardContent className="space-y-4">
                <div className="w-16 h-16 bg-brand-100 rounded-full flex items-center justify-center mx-auto">
                  <Brain className="w-8 h-8 text-brand-600" />
                </div>
                <h3 className="text-xl font-semibold">AI-Powered Learning</h3>
                <p className="text-muted-foreground">
                  Get personalized recommendations and instant doubt resolution with AI
                </p>
              </CardContent>
            </Card>

            <Card className="text-center p-6 border-0 shadow-sm">
              <CardContent className="space-y-4">
                <div className="w-16 h-16 bg-brand-100 rounded-full flex items-center justify-center mx-auto">
                  <Award className="w-8 h-8 text-brand-600" />
                </div>
                <h3 className="text-xl font-semibold">Certificates</h3>
                <p className="text-muted-foreground">
                  Earn industry-recognized certificates to boost your career prospects
                </p>
              </CardContent>
            </Card>

            <Card className="text-center p-6 border-0 shadow-sm">
              <CardContent className="space-y-4">
                <div className="w-16 h-16 bg-brand-100 rounded-full flex items-center justify-center mx-auto">
                  <Clock className="w-8 h-8 text-brand-600" />
                </div>
                <h3 className="text-xl font-semibold">Flexible Learning</h3>
                <p className="text-muted-foreground">
                  Study at your own pace with lifetime access to course materials
                </p>
              </CardContent>
            </Card>

            <Card className="text-center p-6 border-0 shadow-sm">
              <CardContent className="space-y-4">
                <div className="w-16 h-16 bg-brand-100 rounded-full flex items-center justify-center mx-auto">
                  <Users className="w-8 h-8 text-brand-600" />
                </div>
                <h3 className="text-xl font-semibold">Community Support</h3>
                <p className="text-muted-foreground">
                  Connect with peers and get help through our active learning community
                </p>
              </CardContent>
            </Card>

            <Card className="text-center p-6 border-0 shadow-sm">
              <CardContent className="space-y-4">
                <div className="w-16 h-16 bg-brand-100 rounded-full flex items-center justify-center mx-auto">
                  <Globe className="w-8 h-8 text-brand-600" />
                </div>
                <h3 className="text-xl font-semibold">Global Access</h3>
                <p className="text-muted-foreground">
                  Access courses from anywhere, anytime on any device
                </p>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      {/* Popular Categories */}
      <section className="py-20">
        <div className="container mx-auto px-4">
          <div className="text-center mb-12">
            <h2 className="text-3xl lg:text-4xl font-bold mb-4">
              Explore Popular Categories
            </h2>
            <p className="text-lg text-muted-foreground">
              Find the perfect course in your field of interest
            </p>
          </div>

          <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-6">
            {popularCategories.map((category) => (
              <Link
                key={category.id}
                to={`/courses?category=${category.name}`}
                className="group"
              >
                <Card className="text-center p-6 hover:shadow-lg transition-all duration-300 border-0 shadow-sm group-hover:scale-105">
                  <CardContent className="space-y-3">
                    <div className="text-4xl">{category.icon}</div>
                    <h3 className="font-semibold text-sm">{category.name}</h3>
                    <p className="text-xs text-muted-foreground">
                      {category.courseCount} courses
                    </p>
                  </CardContent>
                </Card>
              </Link>
            ))}
          </div>
        </div>
      </section>

      {/* Featured Courses */}
      <section className="py-20 bg-muted/20">
        <div className="container mx-auto px-4">
          <div className="flex items-center justify-between mb-12">
            <div>
              <h2 className="text-3xl lg:text-4xl font-bold mb-4">
                Featured Courses
              </h2>
              <p className="text-lg text-muted-foreground">
                Hand-picked courses by our experts
              </p>
            </div>
            <Button variant="outline" asChild>
              <Link to="/courses">
                View All Courses
                <ArrowRight className="w-4 h-4 ml-2" />
              </Link>
            </Button>
          </div>

          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
            {featuredCourses.map((course) => (
              <CourseCard key={course.id} course={course} />
            ))}
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-20 bg-primary text-primary-foreground">
        <div className="container mx-auto px-4 text-center">
          <div className="max-w-3xl mx-auto space-y-6">
            <h2 className="text-3xl lg:text-4xl font-bold">
              Ready to Start Your Learning Journey?
            </h2>
            <p className="text-xl opacity-90">
              Join thousands of students who have transformed their careers with our courses
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <Button size="lg" variant="secondary" className="text-lg px-8" asChild>
                <Link to="/register">
                  Get Started Free
                </Link>
              </Button>
              <Button size="lg" variant="outline" className="text-lg px-8 border-primary-foreground text-primary-foreground hover:bg-primary-foreground hover:text-primary">
                <BookOpen className="w-5 h-5 mr-2" />
                Browse Courses
              </Button>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
}
