import React, { useState, useEffect } from 'react';
import { useData } from '../contexts/DataContext';
import { Button } from '../components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '../components/ui/card';
import { Badge } from '../components/ui/badge';
import { Input } from '../components/ui/input';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '../components/ui/tabs';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '../components/ui/dialog';
import { useToast } from '@/hooks/use-toast';
import {
  CheckCircle,
  XCircle,
  Clock,
  Search,
  Eye,
  Smartphone,
  DollarSign,
  User,
  Calendar,
  RefreshCw,
  AlertTriangle
} from 'lucide-react';

const AdminPaymentApproval: React.FC = () => {
  const { orders, updateOrder, users, courses, getUserById, getCourseById } = useData();
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedOrder, setSelectedOrder] = useState<any>(null);
  const [isViewModalOpen, setIsViewModalOpen] = useState(false);
  const { toast } = useToast();

  // Filter orders by status
  const pendingOrders = orders.filter(order => order.paymentStatus === 'pending');
  const completedOrders = orders.filter(order => order.paymentStatus === 'completed');
  const failedOrders = orders.filter(order => order.paymentStatus === 'failed');

  // Search functionality
  const filterOrders = (ordersList: any[]) => {
    if (!searchTerm) return ordersList;
    
    return ordersList.filter(order => {
      const user = getUserById(order.userId);
      const course = getCourseById(order.courseId);
      
      return (
        order.id.toLowerCase().includes(searchTerm.toLowerCase()) ||
        order.transactionId?.toLowerCase().includes(searchTerm.toLowerCase()) ||
        user?.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
        user?.email.toLowerCase().includes(searchTerm.toLowerCase()) ||
        course?.title.toLowerCase().includes(searchTerm.toLowerCase())
      );
    });
  };

  const handleApprovePayment = (orderId: string) => {
    updateOrder(orderId, {
      paymentStatus: 'completed',
      paymentDate: new Date().toISOString(),
      isUnlocked: true
    });
    
    toast({
      title: "Payment Approved!",
      description: "Course access has been granted to the user.",
    });
    
    // Send notification (in real app, this would trigger email/SMS)
    const order = orders.find(o => o.id === orderId);
    if (order) {
      const user = getUserById(order.userId);
      const course = getCourseById(order.courseId);
      
      console.log(`Notification sent to ${user?.email}: Course "${course?.title}" is now unlocked!`);
    }
  };

  const handleRejectPayment = (orderId: string) => {
    updateOrder(orderId, {
      paymentStatus: 'failed'
    });
    
    toast({
      title: "Payment Rejected",
      description: "User has been notified about the payment rejection.",
      variant: "destructive"
    });
  };

  const handleViewOrder = (order: any) => {
    setSelectedOrder(order);
    setIsViewModalOpen(true);
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'pending': return 'orange';
      case 'completed': return 'green';
      case 'failed': return 'red';
      default: return 'gray';
    }
  };

  const OrderCard = ({ order }: { order: any }) => {
    const user = getUserById(order.userId);
    const course = getCourseById(order.courseId);
    
    return (
      <Card className="mb-4">
        <CardContent className="p-4">
          <div className="flex items-center justify-between mb-3">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 bg-primary/10 rounded-full flex items-center justify-center">
                <DollarSign className="w-5 h-5 text-primary" />
              </div>
              <div>
                <h3 className="font-medium">{course?.title || 'Unknown Course'}</h3>
                <p className="text-sm text-muted-foreground">
                  Order #{order.id}
                </p>
              </div>
            </div>
            <Badge 
              variant="outline" 
              className={`border-${getStatusColor(order.paymentStatus)}-500 text-${getStatusColor(order.paymentStatus)}-700`}
            >
              {order.paymentStatus.toUpperCase()}
            </Badge>
          </div>

          <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-4 text-sm">
            <div>
              <span className="text-muted-foreground">Customer:</span>
              <p className="font-medium">{user?.name || 'Unknown User'}</p>
              <p className="text-xs text-muted-foreground">{user?.email}</p>
            </div>
            <div>
              <span className="text-muted-foreground">Amount:</span>
              <p className="font-medium text-lg">₹{order.amount.toLocaleString()}</p>
            </div>
            <div>
              <span className="text-muted-foreground">Payment Method:</span>
              <p className="font-medium flex items-center gap-1">
                <Smartphone className="w-4 h-4" />
                {order.paymentMethod}
              </p>
            </div>
            <div>
              <span className="text-muted-foreground">Date:</span>
              <p className="font-medium">{new Date(order.orderDate).toLocaleDateString()}</p>
              <p className="text-xs text-muted-foreground">
                {new Date(order.orderDate).toLocaleTimeString()}
              </p>
            </div>
          </div>

          <div className="mb-4 space-y-2">
            {order.transactionId && (
              <div className="p-2 bg-muted/30 rounded">
                <span className="text-xs text-muted-foreground">Transaction ID:</span>
                <code className="block font-mono text-xs">{order.transactionId}</code>
              </div>
            )}
            {order.utrNumber && (
              <div className="p-2 bg-blue-50 rounded">
                <span className="text-xs text-blue-700">UTR Number:</span>
                <code className="block font-mono text-xs text-blue-800">{order.utrNumber}</code>
              </div>
            )}
            {order.paymentScreenshot && (
              <div className="p-2 bg-green-50 rounded">
                <span className="text-xs text-green-700 flex items-center gap-1">
                  <CheckCircle className="w-3 h-3" />
                  Payment proof uploaded
                </span>
              </div>
            )}
          </div>

          <div className="flex items-center justify-between">
            <Button
              variant="outline"
              size="sm"
              onClick={() => handleViewOrder(order)}
            >
              <Eye className="w-4 h-4 mr-2" />
              View Details
            </Button>

            {order.paymentStatus === 'pending' && (
              <div className="flex gap-2">
                <Button
                  variant="destructive"
                  size="sm"
                  onClick={() => handleRejectPayment(order.id)}
                >
                  <XCircle className="w-4 h-4 mr-2" />
                  Reject
                </Button>
                <Button
                  size="sm"
                  onClick={() => handleApprovePayment(order.id)}
                >
                  <CheckCircle className="w-4 h-4 mr-2" />
                  Approve
                </Button>
              </div>
            )}
          </div>
        </CardContent>
      </Card>
    );
  };

  const OrderViewModal = () => (
    <Dialog open={isViewModalOpen} onOpenChange={setIsViewModalOpen}>
      <DialogContent className="max-w-2xl">
        <DialogHeader>
          <DialogTitle>Payment Details - Order #{selectedOrder?.id}</DialogTitle>
        </DialogHeader>
        
        {selectedOrder && (
          <div className="space-y-6">
            <div className="grid grid-cols-2 gap-6">
              {/* Customer Info */}
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg flex items-center gap-2">
                    <User className="w-5 h-5" />
                    Customer Information
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-2">
                  <div>
                    <span className="text-sm text-muted-foreground">Name:</span>
                    <p className="font-medium">{getUserById(selectedOrder.userId)?.name}</p>
                  </div>
                  <div>
                    <span className="text-sm text-muted-foreground">Email:</span>
                    <p className="font-medium">{getUserById(selectedOrder.userId)?.email}</p>
                  </div>
                  <div>
                    <span className="text-sm text-muted-foreground">Phone:</span>
                    <p className="font-medium">{getUserById(selectedOrder.userId)?.phone || 'Not provided'}</p>
                  </div>
                  <div>
                    <span className="text-sm text-muted-foreground">Join Date:</span>
                    <p className="font-medium">
                      {new Date(getUserById(selectedOrder.userId)?.joinDate || '').toLocaleDateString()}
                    </p>
                  </div>
                </CardContent>
              </Card>

              {/* Payment Info */}
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg flex items-center gap-2">
                    <DollarSign className="w-5 h-5" />
                    Payment Information
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-2">
                  <div>
                    <span className="text-sm text-muted-foreground">Amount:</span>
                    <p className="font-medium text-xl">₹{selectedOrder.amount.toLocaleString()}</p>
                  </div>
                  <div>
                    <span className="text-sm text-muted-foreground">Payment Method:</span>
                    <p className="font-medium">{selectedOrder.paymentMethod}</p>
                  </div>
                  <div>
                    <span className="text-sm text-muted-foreground">Status:</span>
                    <Badge className={`ml-2 border-${getStatusColor(selectedOrder.paymentStatus)}-500`}>
                      {selectedOrder.paymentStatus.toUpperCase()}
                    </Badge>
                  </div>
                  <div>
                    <span className="text-sm text-muted-foreground">Order Date:</span>
                    <p className="font-medium">
                      {new Date(selectedOrder.orderDate).toLocaleString()}
                    </p>
                  </div>
                  {selectedOrder.paymentDate && (
                    <div>
                      <span className="text-sm text-muted-foreground">Payment Date:</span>
                      <p className="font-medium">
                        {new Date(selectedOrder.paymentDate).toLocaleString()}
                      </p>
                    </div>
                  )}
                </CardContent>
              </Card>
            </div>

            {/* Course Info */}
            <Card>
              <CardHeader>
                <CardTitle className="text-lg">Course Information</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="flex items-start gap-4">
                  <img
                    src={getCourseById(selectedOrder.courseId)?.thumbnail}
                    alt="Course thumbnail"
                    className="w-24 h-16 object-cover rounded"
                  />
                  <div className="flex-1">
                    <h3 className="font-medium text-lg">
                      {getCourseById(selectedOrder.courseId)?.title}
                    </h3>
                    <p className="text-sm text-muted-foreground mb-2">
                      {getCourseById(selectedOrder.courseId)?.description}
                    </p>
                    <div className="flex items-center gap-4 text-sm">
                      <span>Category: {getCourseById(selectedOrder.courseId)?.category}</span>
                      <span>Level: {getCourseById(selectedOrder.courseId)?.level}</span>
                      <span>Duration: {getCourseById(selectedOrder.courseId)?.duration}</span>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Transaction Details */}
            <Card>
              <CardHeader>
                <CardTitle className="text-lg">Transaction Details</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="bg-muted/30 p-4 rounded font-mono text-sm">
                  <div className="grid grid-cols-2 gap-2">
                    <span>Transaction ID:</span>
                    <span>{selectedOrder.transactionId || 'Not provided'}</span>
                    <span>UTR Number:</span>
                    <span>{selectedOrder.utrNumber || 'Not provided'}</span>
                    <span>Order ID:</span>
                    <span>{selectedOrder.id}</span>
                    <span>Course Access:</span>
                    <span>{selectedOrder.isUnlocked ? 'Unlocked' : 'Locked'}</span>
                  </div>
                </div>

                {/* Payment Screenshot */}
                {selectedOrder.paymentScreenshot && (
                  <div className="mt-4">
                    <h4 className="font-medium mb-2">Payment Screenshot:</h4>
                    <img
                      src={selectedOrder.paymentScreenshot}
                      alt="Payment proof"
                      className="max-w-full max-h-64 object-contain border rounded-lg"
                    />
                  </div>
                )}
              </CardContent>
            </Card>

            {/* Action Buttons */}
            {selectedOrder.paymentStatus === 'pending' && (
              <div className="flex justify-end gap-3">
                <Button
                  variant="destructive"
                  onClick={() => {
                    handleRejectPayment(selectedOrder.id);
                    setIsViewModalOpen(false);
                  }}
                >
                  <XCircle className="w-4 h-4 mr-2" />
                  Reject Payment
                </Button>
                <Button
                  onClick={() => {
                    handleApprovePayment(selectedOrder.id);
                    setIsViewModalOpen(false);
                  }}
                >
                  <CheckCircle className="w-4 h-4 mr-2" />
                  Approve Payment
                </Button>
              </div>
            )}
          </div>
        )}
      </DialogContent>
    </Dialog>
  );

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-3xl font-bold text-foreground">Payment Approval</h1>
          <p className="text-muted-foreground">Review and approve UPI payments</p>
        </div>
        <Button variant="outline">
          <RefreshCw className="h-4 w-4 mr-2" />
          Refresh
        </Button>
      </div>

      {/* Search */}
      <Card>
        <CardContent className="pt-6">
          <div className="relative">
            <Search className="absolute left-3 top-3 h-4 w-4 text-gray-400" />
            <Input
              placeholder="Search by order ID, transaction ID, customer name, or course..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="pl-10"
            />
          </div>
        </CardContent>
      </Card>

      {/* Stats Cards */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground">Pending Approvals</p>
                <p className="text-2xl font-bold text-orange-600">{pendingOrders.length}</p>
              </div>
              <Clock className="w-8 h-8 text-orange-600" />
            </div>
          </CardContent>
        </Card>
        
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground">Approved Today</p>
                <p className="text-2xl font-bold text-green-600">
                  {completedOrders.filter(o => 
                    new Date(o.paymentDate || '').toDateString() === new Date().toDateString()
                  ).length}
                </p>
              </div>
              <CheckCircle className="w-8 h-8 text-green-600" />
            </div>
          </CardContent>
        </Card>
        
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground">Revenue Today</p>
                <p className="text-2xl font-bold text-blue-600">
                  ₹{completedOrders
                    .filter(o => new Date(o.paymentDate || '').toDateString() === new Date().toDateString())
                    .reduce((sum, o) => sum + o.amount, 0)
                    .toLocaleString()}
                </p>
              </div>
              <DollarSign className="w-8 h-8 text-blue-600" />
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Payment Lists */}
      <Tabs defaultValue="pending" className="w-full">
        <TabsList className="grid w-full grid-cols-3">
          <TabsTrigger value="pending" className="flex items-center gap-2">
            <AlertTriangle className="w-4 h-4" />
            Pending ({pendingOrders.length})
          </TabsTrigger>
          <TabsTrigger value="completed" className="flex items-center gap-2">
            <CheckCircle className="w-4 h-4" />
            Completed ({completedOrders.length})
          </TabsTrigger>
          <TabsTrigger value="failed" className="flex items-center gap-2">
            <XCircle className="w-4 h-4" />
            Failed ({failedOrders.length})
          </TabsTrigger>
        </TabsList>

        <TabsContent value="pending" className="space-y-4">
          {filterOrders(pendingOrders).length > 0 ? (
            filterOrders(pendingOrders).map(order => (
              <OrderCard key={order.id} order={order} />
            ))
          ) : (
            <div className="text-center py-8 text-muted-foreground">
              <Clock className="w-12 w-12 mx-auto mb-4 opacity-50" />
              <p>No pending payments</p>
            </div>
          )}
        </TabsContent>

        <TabsContent value="completed" className="space-y-4">
          {filterOrders(completedOrders).length > 0 ? (
            filterOrders(completedOrders).map(order => (
              <OrderCard key={order.id} order={order} />
            ))
          ) : (
            <div className="text-center py-8 text-muted-foreground">
              <CheckCircle className="w-12 w-12 mx-auto mb-4 opacity-50" />
              <p>No completed payments</p>
            </div>
          )}
        </TabsContent>

        <TabsContent value="failed" className="space-y-4">
          {filterOrders(failedOrders).length > 0 ? (
            filterOrders(failedOrders).map(order => (
              <OrderCard key={order.id} order={order} />
            ))
          ) : (
            <div className="text-center py-8 text-muted-foreground">
              <XCircle className="w-12 w-12 mx-auto mb-4 opacity-50" />
              <p>No failed payments</p>
            </div>
          )}
        </TabsContent>
      </Tabs>

      <OrderViewModal />
    </div>
  );
};

export default AdminPaymentApproval;
