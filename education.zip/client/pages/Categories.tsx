import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { CATEGORIES } from '@shared/types';
import { Search, ArrowRight, TrendingUp, Users, BookOpen } from 'lucide-react';

export default function Categories() {
  const [searchQuery, setSearchQuery] = useState('');
  const [sortBy, setSortBy] = useState<'name' | 'courses'>('name');

  // Filter and sort categories
  const filteredCategories = CATEGORIES
    .filter(category => 
      category.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      category.description.toLowerCase().includes(searchQuery.toLowerCase())
    )
    .sort((a, b) => {
      if (sortBy === 'name') {
        return a.name.localeCompare(b.name);
      } else {
        return b.courseCount - a.courseCount;
      }
    });

  const totalCourses = CATEGORIES.reduce((total, category) => total + category.courseCount, 0);
  const popularCategories = CATEGORIES.filter(cat => cat.courseCount > 70);

  return (
    <div className="min-h-screen py-12">
      <div className="container mx-auto px-4">
        {/* Header */}
        <div className="text-center mb-12">
          <h1 className="text-4xl lg:text-5xl font-bold mb-4">Course Categories</h1>
          <p className="text-xl text-muted-foreground mb-6 max-w-2xl mx-auto">
            Explore our diverse range of {CATEGORIES.length} categories with over {totalCourses.toLocaleString()} courses to accelerate your learning journey
          </p>
          
          {/* Search and Sort */}
          <div className="flex flex-col sm:flex-row gap-4 max-w-md mx-auto">
            <div className="relative flex-1">
              <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
              <Input
                placeholder="Search categories..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="pl-10"
              />
            </div>
            <div className="flex gap-2">
              <Button
                variant={sortBy === 'name' ? 'default' : 'outline'}
                size="sm"
                onClick={() => setSortBy('name')}
              >
                A-Z
              </Button>
              <Button
                variant={sortBy === 'courses' ? 'default' : 'outline'}
                size="sm"
                onClick={() => setSortBy('courses')}
              >
                <TrendingUp className="w-4 h-4 mr-1" />
                Popular
              </Button>
            </div>
          </div>
        </div>

        {/* Stats Cards */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-12">
          <Card className="text-center">
            <CardContent className="pt-6">
              <div className="text-3xl font-bold text-primary mb-2">{CATEGORIES.length}</div>
              <p className="text-muted-foreground">Total Categories</p>
            </CardContent>
          </Card>
          <Card className="text-center">
            <CardContent className="pt-6">
              <div className="text-3xl font-bold text-primary mb-2">{totalCourses.toLocaleString()}</div>
              <p className="text-muted-foreground">Total Courses</p>
            </CardContent>
          </Card>
          <Card className="text-center">
            <CardContent className="pt-6">
              <div className="text-3xl font-bold text-primary mb-2">{popularCategories.length}</div>
              <p className="text-muted-foreground">Popular Categories</p>
            </CardContent>
          </Card>
        </div>

        {/* Popular Categories Section */}
        {searchQuery === '' && (
          <div className="mb-12">
            <h2 className="text-2xl font-bold mb-6 flex items-center gap-2">
              <TrendingUp className="w-6 h-6 text-primary" />
              Most Popular Categories
            </h2>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {popularCategories.slice(0, 6).map((category) => (
                <Link
                  key={category.id}
                  to={`/courses?category=${encodeURIComponent(category.name)}`}
                  className="group"
                >
                  <Card className="h-full hover:shadow-lg transition-all duration-300 group-hover:scale-105 border-2 border-primary/20 bg-gradient-to-br from-primary/5 to-transparent">
                    <CardHeader className="text-center">
                      <div className="text-4xl mb-3 group-hover:scale-110 transition-transform">
                        {category.icon}
                      </div>
                      <CardTitle className="group-hover:text-primary transition-colors">
                        {category.name}
                      </CardTitle>
                      <CardDescription>{category.description}</CardDescription>
                    </CardHeader>
                    <CardContent className="pt-0">
                      <div className="flex items-center justify-between">
                        <Badge variant="secondary" className="flex items-center gap-1">
                          <BookOpen className="w-3 h-3" />
                          {category.courseCount} courses
                        </Badge>
                        <ArrowRight className="w-4 h-4 text-muted-foreground group-hover:text-primary group-hover:translate-x-1 transition-all" />
                      </div>
                    </CardContent>
                  </Card>
                </Link>
              ))}
            </div>
          </div>
        )}

        {/* All Categories Grid */}
        <div className="mb-8">
          <div className="flex items-center justify-between mb-6">
            <h2 className="text-2xl font-bold">
              {searchQuery ? `Search Results (${filteredCategories.length})` : 'All Categories'}
            </h2>
            <div className="text-sm text-muted-foreground">
              Sorted by {sortBy === 'name' ? 'Name' : 'Popularity'}
            </div>
          </div>

          {filteredCategories.length === 0 ? (
            <Card className="text-center py-12">
              <CardContent>
                <Search className="w-12 h-12 mx-auto mb-4 text-muted-foreground/50" />
                <h3 className="text-lg font-semibold mb-2">No categories found</h3>
                <p className="text-muted-foreground mb-4">
                  Try adjusting your search terms or browse all categories
                </p>
                <Button onClick={() => setSearchQuery('')}>
                  View All Categories
                </Button>
              </CardContent>
            </Card>
          ) : (
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
              {filteredCategories.map((category) => (
                <Link
                  key={category.id}
                  to={`/courses?category=${encodeURIComponent(category.name)}`}
                  className="group"
                >
                  <Card className="h-full hover:shadow-lg transition-all duration-300 group-hover:scale-105">
                    <CardHeader className="text-center pb-4">
                      <div className="text-3xl mb-3 group-hover:scale-110 transition-transform">
                        {category.icon}
                      </div>
                      <CardTitle className="text-lg group-hover:text-primary transition-colors">
                        {category.name}
                      </CardTitle>
                      <CardDescription className="text-sm">
                        {category.description}
                      </CardDescription>
                    </CardHeader>
                    <CardContent className="pt-0">
                      <div className="flex items-center justify-between">
                        <div className="flex items-center gap-1 text-sm text-muted-foreground">
                          <BookOpen className="w-3 h-3" />
                          <span>{category.courseCount} courses</span>
                        </div>
                        <ArrowRight className="w-4 h-4 text-muted-foreground group-hover:text-primary group-hover:translate-x-1 transition-all" />
                      </div>
                      
                      {/* Popularity indicator */}
                      {category.courseCount > 70 && (
                        <Badge className="mt-2 bg-orange-500 text-white">
                          Popular
                        </Badge>
                      )}
                      
                      {/* New categories indicator */}
                      {parseInt(category.id) > 6 && (
                        <Badge className="mt-2 bg-blue-500 text-white">
                          New
                        </Badge>
                      )}
                    </CardContent>
                  </Card>
                </Link>
              ))}
            </div>
          )}
        </div>

        {/* Call to Action */}
        <Card className="bg-gradient-to-r from-primary/10 via-transparent to-primary/10 border-primary/20">
          <CardContent className="text-center py-12">
            <h3 className="text-2xl font-bold mb-4">Ready to Start Learning?</h3>
            <p className="text-muted-foreground mb-6 max-w-md mx-auto">
              Browse our complete course catalog and find the perfect learning path for your goals
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <Button size="lg" asChild>
                <Link to="/courses">
                  <BookOpen className="w-5 h-5 mr-2" />
                  Browse All Courses
                </Link>
              </Button>
              <Button size="lg" variant="outline" asChild>
                <Link to="/courses?free=true">
                  Start with Free Courses
                </Link>
              </Button>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
