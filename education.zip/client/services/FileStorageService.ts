// File Storage Service for handling uploads and downloads
interface FileInfo {
  id: string;
  name: string;
  size: number;
  type: string;
  url: string;
  key: string;
  folder: string;
  uploadedAt: string;
}

interface UploadResult {
  success: boolean;
  fileInfo?: FileInfo;
  error?: string;
}

class FileStorageService {
  private baseUrl: string;

  constructor(baseUrl: string = '') {
    this.baseUrl = baseUrl;
  }

  // Upload file to server (with fallback to localStorage)
  async uploadFile(file: File, folder: string = 'general'): Promise<UploadResult> {
    try {
      console.log(`📤 Uploading file: ${file.name} to folder: ${folder}`);

      // For now, use base64 encoding and localStorage as primary storage
      // In a real implementation, this would upload to cloud storage
      const dataUrl = await this.fileToDataURL(file);
      const fileKey = `${folder}-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`;
      
      const fileInfo: FileInfo = {
        id: fileKey,
        name: file.name,
        size: file.size,
        type: file.type,
        url: dataUrl,
        key: fileKey,
        folder,
        uploadedAt: new Date().toISOString()
      };

      // Store in localStorage
      localStorage.setItem(fileKey, JSON.stringify(fileInfo));
      
      // Also store a reference for easy lookup
      const folderIndex = this.getFolderIndex(folder);
      folderIndex.push(fileKey);
      localStorage.setItem(`folder_${folder}`, JSON.stringify(folderIndex));

      console.log(`✅ File uploaded successfully: ${fileKey}`);
      
      return {
        success: true,
        fileInfo
      };
    } catch (error) {
      console.error('❌ File upload failed:', error);
      return {
        success: false,
        error: error instanceof Error ? error.message : 'Upload failed'
      };
    }
  }

  // Upload multiple files
  async uploadFiles(files: FileList | File[], folder: string = 'general'): Promise<UploadResult[]> {
    const results: UploadResult[] = [];
    const fileArray = Array.from(files);

    for (const file of fileArray) {
      const result = await this.uploadFile(file, folder);
      results.push(result);
    }

    return results;
  }

  // Get file by key
  async getFile(key: string): Promise<FileInfo | null> {
    try {
      const stored = localStorage.getItem(key);
      if (stored) {
        return JSON.parse(stored);
      }
      
      // If not found in localStorage, try API
      const response = await fetch(`${this.baseUrl}/api/files/${key}`);
      if (response.ok) {
        return await response.json();
      }
      
      return null;
    } catch (error) {
      console.error('Error getting file:', error);
      return null;
    }
  }

  // Get files by folder
  async getFilesByFolder(folder: string): Promise<FileInfo[]> {
    try {
      const folderIndex = this.getFolderIndex(folder);
      const files: FileInfo[] = [];

      for (const key of folderIndex) {
        const file = await this.getFile(key);
        if (file) {
          files.push(file);
        }
      }

      return files;
    } catch (error) {
      console.error('Error getting files by folder:', error);
      return [];
    }
  }

  // Delete file
  async deleteFile(key: string): Promise<boolean> {
    try {
      const file = await this.getFile(key);
      if (!file) {
        return false;
      }

      // Remove from localStorage
      localStorage.removeItem(key);
      
      // Remove from folder index
      const folderIndex = this.getFolderIndex(file.folder);
      const updatedIndex = folderIndex.filter(k => k !== key);
      localStorage.setItem(`folder_${file.folder}`, JSON.stringify(updatedIndex));

      console.log(`🗑️ File deleted: ${key}`);
      return true;
    } catch (error) {
      console.error('Error deleting file:', error);
      return false;
    }
  }

  // Get download URL for file
  getDownloadUrl(key: string): string {
    return `/api/files/${key}/download`;
  }

  // Helper: Convert file to data URL
  private fileToDataURL(file: File, maxSizeMB: number = 50): Promise<string> {
    return new Promise((resolve, reject) => {
      // Check file size
      const maxSizeBytes = maxSizeMB * 1024 * 1024;
      if (file.size > maxSizeBytes) {
        reject(new Error(`File size exceeds ${maxSizeMB}MB limit`));
        return;
      }

      const reader = new FileReader();
      
      reader.onload = () => {
        const result = reader.result as string;
        resolve(result);
      };
      
      reader.onerror = () => {
        reject(new Error('Failed to read file'));
      };
      
      reader.readAsDataURL(file);
    });
  }

  // Helper: Get folder index
  private getFolderIndex(folder: string): string[] {
    const stored = localStorage.getItem(`folder_${folder}`);
    return stored ? JSON.parse(stored) : [];
  }

  // Upload video with specific handling
  async uploadVideo(file: File): Promise<UploadResult> {
    // Validate video file
    if (!file.type.startsWith('video/')) {
      return {
        success: false,
        error: 'File is not a video'
      };
    }

    // Check video size (limit to 500MB for videos)
    const maxSize = 500 * 1024 * 1024; // 500MB
    if (file.size > maxSize) {
      return {
        success: false,
        error: 'Video file is too large (max 500MB)'
      };
    }

    return this.uploadFile(file, 'videos');
  }

  // Upload document (PDF, Word, etc.)
  async uploadDocument(file: File): Promise<UploadResult> {
    const allowedTypes = [
      'application/pdf',
      'application/msword',
      'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
      'text/plain',
      'application/zip',
      'application/x-zip-compressed'
    ];

    if (!allowedTypes.includes(file.type)) {
      return {
        success: false,
        error: 'Document type not supported'
      };
    }

    // Check document size (limit to 50MB)
    const maxSize = 50 * 1024 * 1024; // 50MB
    if (file.size > maxSize) {
      return {
        success: false,
        error: 'Document file is too large (max 50MB)'
      };
    }

    return this.uploadFile(file, 'documents');
  }

  // Upload image with specific handling
  async uploadImage(file: File): Promise<UploadResult> {
    // Validate image file
    if (!file.type.startsWith('image/')) {
      return {
        success: false,
        error: 'File is not an image'
      };
    }

    // Check image size (limit to 10MB)
    const maxSize = 10 * 1024 * 1024; // 10MB
    if (file.size > maxSize) {
      return {
        success: false,
        error: 'Image file is too large (max 10MB)'
      };
    }

    return this.uploadFile(file, 'images');
  }

  // Get storage statistics
  getStorageStats(): { totalFiles: number; totalSize: number; folderStats: Record<string, number> } {
    const stats = {
      totalFiles: 0,
      totalSize: 0,
      folderStats: {} as Record<string, number>
    };

    // Check all localStorage keys
    for (let i = 0; i < localStorage.length; i++) {
      const key = localStorage.key(i);
      if (key && !key.startsWith('folder_') && !key.startsWith('edumaster_')) {
        try {
          const item = localStorage.getItem(key);
          if (item) {
            const parsed = JSON.parse(item);
            if (parsed.size && parsed.folder) {
              stats.totalFiles++;
              stats.totalSize += parsed.size;
              stats.folderStats[parsed.folder] = (stats.folderStats[parsed.folder] || 0) + 1;
            }
          }
        } catch (error) {
          // Ignore invalid JSON
        }
      }
    }

    return stats;
  }

  // Clean up orphaned files
  async cleanupOrphanedFiles(): Promise<number> {
    let cleanedCount = 0;
    const now = Date.now();
    const maxAge = 7 * 24 * 60 * 60 * 1000; // 7 days

    for (let i = 0; i < localStorage.length; i++) {
      const key = localStorage.key(i);
      if (key && !key.startsWith('folder_') && !key.startsWith('edumaster_')) {
        try {
          const item = localStorage.getItem(key);
          if (item) {
            const parsed = JSON.parse(item);
            if (parsed.uploadedAt) {
              const uploadTime = new Date(parsed.uploadedAt).getTime();
              if (now - uploadTime > maxAge) {
                localStorage.removeItem(key);
                cleanedCount++;
              }
            }
          }
        } catch (error) {
          // Remove invalid entries
          localStorage.removeItem(key!);
          cleanedCount++;
        }
      }
    }

    console.log(`🧹 Cleaned up ${cleanedCount} orphaned files`);
    return cleanedCount;
  }
}

// Create singleton instance
export const fileStorageService = new FileStorageService();

export default FileStorageService;
export type { FileInfo, UploadResult };
