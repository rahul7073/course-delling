// Database Service for syncing data between localStorage and server
interface DatabaseSyncOptions {
  endpoint?: string;
  autoSync?: boolean;
  syncInterval?: number;
}

interface SyncResult {
  success: boolean;
  message: string;
  syncedItems?: number;
  errors?: any[];
}

class DatabaseService {
  private endpoint: string;
  private autoSync: boolean;
  private syncInterval: number;
  private syncIntervalId?: NodeJS.Timeout;

  constructor(options: DatabaseSyncOptions = {}) {
    this.endpoint = options.endpoint || '/api/sync';
    this.autoSync = options.autoSync || false;
    this.syncInterval = options.syncInterval || 30000; // 30 seconds

    if (this.autoSync) {
      this.startAutoSync();
    }
  }

  // Sync courses to database
  async syncCourses(): Promise<SyncResult> {
    try {
      console.log('🔄 Syncing courses to database...');
      
      const courses = this.getLocalCourses();
      const publishedCourses = courses.filter(course => course.isPublished);

      // In real implementation, this would call your backend API
      const response = await this.mockDatabaseSync('courses', publishedCourses);
      
      if (response.success) {
        // Mark courses as synced
        this.markAsSynced('courses', publishedCourses.map(c => c.id));
        
        console.log(`✅ Successfully synced ${publishedCourses.length} published courses`);
        return {
          success: true,
          message: `Synced ${publishedCourses.length} published courses to database`,
          syncedItems: publishedCourses.length
        };
      } else {
        throw new Error(response.message);
      }
    } catch (error) {
      console.error('❌ Database sync failed:', error);
      return {
        success: false,
        message: `Sync failed: ${error instanceof Error ? error.message : 'Unknown error'}`,
        errors: [error]
      };
    }
  }

  // Sync orders to database
  async syncOrders(): Promise<SyncResult> {
    try {
      const orders = this.getLocalOrders();
      const completedOrders = orders.filter(order => order.paymentStatus === 'completed');

      const response = await this.mockDatabaseSync('orders', completedOrders);
      
      if (response.success) {
        this.markAsSynced('orders', completedOrders.map(o => o.id));
        
        return {
          success: true,
          message: `Synced ${completedOrders.length} completed orders`,
          syncedItems: completedOrders.length
        };
      } else {
        throw new Error(response.message);
      }
    } catch (error) {
      return {
        success: false,
        message: `Order sync failed: ${error instanceof Error ? error.message : 'Unknown error'}`,
        errors: [error]
      };
    }
  }

  // Sync all data
  async syncAll(): Promise<SyncResult> {
    try {
      console.log('🚀 Starting full database sync...');
      
      const courseResult = await this.syncCourses();
      const orderResult = await this.syncOrders();
      
      const totalSynced = (courseResult.syncedItems || 0) + (orderResult.syncedItems || 0);
      const hasErrors = !courseResult.success || !orderResult.success;
      
      if (!hasErrors) {
        return {
          success: true,
          message: `Successfully synced ${totalSynced} items to database`,
          syncedItems: totalSynced
        };
      } else {
        return {
          success: false,
          message: 'Partial sync completed with errors',
          syncedItems: totalSynced,
          errors: [...(courseResult.errors || []), ...(orderResult.errors || [])]
        };
      }
    } catch (error) {
      return {
        success: false,
        message: 'Full sync failed',
        errors: [error]
      };
    }
  }

  // Publish specific course
  async publishCourse(courseId: string): Promise<SyncResult> {
    try {
      const courses = this.getLocalCourses();
      const course = courses.find(c => c.id === courseId);
      
      if (!course) {
        throw new Error('Course not found');
      }

      // Note: We'll mark the course as published during the process

      // Validate course has required content
      console.log('🔍 Validating course for publishing:', {
        title: course.title,
        price: course.price,
        description: course.description?.length || 0,
        classesCount: course.classes?.length || 0,
        classes: course.classes?.map((cls: any) => ({
          title: cls.title,
          videosCount: cls.videos?.length || 0,
          notesCount: cls.notes?.length || 0,
          projectsCount: cls.projects?.length || 0
        }))
      });

      const validation = this.validateCourseForPublishing(course);
      if (!validation.valid) {
        console.error('❌ Course validation failed:', validation.errors);
        throw new Error(`Course validation failed: ${validation.errors.join(', ')}`);
      } else {
        console.log('✅ Course validation passed');
      }

      console.log(`📢 Publishing course: ${course.title}`);
      
      const response = await this.mockDatabaseSync('course', [course]);
      
      if (response.success) {
        this.markAsSynced('courses', [courseId]);
        
        return {
          success: true,
          message: `Course "${course.title}" published successfully`,
          syncedItems: 1
        };
      } else {
        throw new Error(response.message);
      }
    } catch (error) {
      return {
        success: false,
        message: `Failed to publish course: ${error instanceof Error ? error.message : 'Unknown error'}`,
        errors: [error]
      };
    }
  }

  // Validate course before publishing - More flexible validation
  private validateCourseForPublishing(course: any): { valid: boolean; errors: string[] } {
    const errors: string[] = [];
    const warnings: string[] = [];

    // Required fields
    if (!course.title?.trim()) {
      errors.push('Course title is required');
    }

    if (!course.price && course.price !== 0) {
      errors.push('Course price is required');
    }

    // Optional but recommended fields
    if (!course.description?.trim()) {
      warnings.push('Course description is recommended');
    }

    // Classes validation - more flexible
    if (!course.classes || course.classes.length === 0) {
      // Allow publishing without classes for basic course creation
      warnings.push('No classes found - you can add content after publishing');
    } else {
      // Check if at least one class has a title
      const validClasses = course.classes.filter((cls: any) => cls.title?.trim());

      if (validClasses.length === 0) {
        errors.push('Classes must have titles');
      } else {
        // Check content but don't make it required
        const classesWithContent = course.classes.filter((cls: any) =>
          (cls.videos && cls.videos.length > 0) ||
          (cls.notes && cls.notes.length > 0) ||
          (cls.projects && cls.projects.length > 0)
        );

        if (classesWithContent.length === 0) {
          warnings.push('Classes have no content yet - you can add videos, notes, and projects after publishing');
        }
      }
    }

    // Log warnings but don't block publishing
    if (warnings.length > 0) {
      console.warn('Publishing warnings:', warnings);
    }

    return {
      valid: errors.length === 0,
      errors
    };
  }

  // Mock database sync (replace with real API calls)
  private async mockDatabaseSync(type: string, data: any[]): Promise<{ success: boolean; message: string }> {
    // Simulate API delay
    await new Promise(resolve => setTimeout(resolve, 1000 + Math.random() * 2000));
    
    // Simulate occasional failures for testing
    if (Math.random() < 0.1) { // 10% failure rate
      return {
        success: false,
        message: 'Network error or database unavailable'
      };
    }
    
    // Log what would be synced
    console.log(`📊 Database sync simulation - ${type}:`, {
      count: data.length,
      items: data.map(item => ({
        id: item.id,
        title: item.title || item.courseName || 'N/A'
      }))
    });
    
    return {
      success: true,
      message: `Successfully synced ${data.length} ${type} items`
    };
  }

  // Get local data
  private getLocalCourses(): any[] {
    const saved = localStorage.getItem('edumaster_courses');
    return saved ? JSON.parse(saved) : [];
  }

  private getLocalOrders(): any[] {
    const saved = localStorage.getItem('edumaster_orders');
    return saved ? JSON.parse(saved) : [];
  }

  // Mark items as synced
  private markAsSynced(type: string, ids: string[]) {
    const syncRecord = {
      type,
      ids,
      syncedAt: new Date().toISOString()
    };
    
    const existing = localStorage.getItem('edumaster_sync_log');
    const syncLog = existing ? JSON.parse(existing) : [];
    syncLog.push(syncRecord);
    
    // Keep only last 100 sync records
    if (syncLog.length > 100) {
      syncLog.splice(0, syncLog.length - 100);
    }
    
    localStorage.setItem('edumaster_sync_log', JSON.stringify(syncLog));
  }

  // Auto sync
  private startAutoSync() {
    this.syncIntervalId = setInterval(async () => {
      console.log('🔄 Auto-sync triggered...');
      await this.syncAll();
    }, this.syncInterval);
  }

  public stopAutoSync() {
    if (this.syncIntervalId) {
      clearInterval(this.syncIntervalId);
      this.syncIntervalId = undefined;
    }
  }

  // Get sync status
  public getSyncStatus(): { lastSync?: string; syncedItems: number } {
    const syncLog = localStorage.getItem('edumaster_sync_log');
    if (!syncLog) {
      return { syncedItems: 0 };
    }
    
    const log = JSON.parse(syncLog);
    const lastSync = log.length > 0 ? log[log.length - 1].syncedAt : undefined;
    const syncedItems = log.reduce((total: number, record: any) => total + record.ids.length, 0);
    
    return { lastSync, syncedItems };
  }
}

// Create singleton instance
export const databaseService = new DatabaseService({
  autoSync: false, // Enable if you want automatic syncing
  syncInterval: 60000 // 1 minute
});

export default DatabaseService;
