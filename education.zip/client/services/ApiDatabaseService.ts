// Real Database Service using API endpoints
import { Course, CourseClass, Order, User, Certification, DatabaseResponse, PaginatedResponse } from '../../shared/database';

interface SyncResult {
  success: boolean;
  message: string;
  syncedItems?: number;
  errors?: any[];
}

class ApiDatabaseService {
  private baseUrl: string;

  constructor(baseUrl: string = '') {
    this.baseUrl = baseUrl;
  }

  // Helper method for API calls
  private async apiCall<T>(endpoint: string, options?: RequestInit): Promise<DatabaseResponse<T>> {
    try {
      const response = await fetch(`${this.baseUrl}/api${endpoint}`, {
        headers: {
          'Content-Type': 'application/json',
          ...options?.headers
        },
        ...options
      });

      if (!response.ok) {
        const errorData = await response.json().catch(() => ({}));

        // For 404 (not found), return structured error instead of throwing
        if (response.status === 404) {
          return {
            success: false,
            error: errorData.error || 'Not found'
          };
        }

        // For other errors, still throw
        throw new Error(errorData.error || `HTTP ${response.status}`);
      }

      const data = await response.json();
      return { success: true, data };
    } catch (error) {
      console.error(`API call failed for ${endpoint}:`, error);
      return {
        success: false,
        error: error instanceof Error ? error.message : 'Unknown error'
      };
    }
  }

  // Course methods
  async createCourse(courseData: any): Promise<SyncResult> {
    try {
      console.log('🆕 Creating course via API...', courseData);
      
      const result = await this.apiCall<Course>('/courses', {
        method: 'POST',
        body: JSON.stringify(courseData)
      });

      if (result.success) {
        console.log('✅ Course created successfully:', result.data);
        return {
          success: true,
          message: `Course "${result.data?.title}" created successfully`,
          syncedItems: 1
        };
      } else {
        throw new Error(result.error);
      }
    } catch (error) {
      console.error('❌ Failed to create course:', error);
      return {
        success: false,
        message: `Failed to create course: ${error instanceof Error ? error.message : 'Unknown error'}`,
        errors: [error]
      };
    }
  }

  async getCourse(id: string): Promise<DatabaseResponse<Course>> {
    console.log('🔍 Fetching course:', id);
    return this.apiCall<Course>(`/courses/${id}`);
  }

  async getCourses(published?: boolean): Promise<DatabaseResponse<PaginatedResponse<Course>>> {
    console.log('📚 Fetching courses, published:', published);
    const query = published !== undefined ? `?published=${published}` : '';
    return this.apiCall<PaginatedResponse<Course>>(`/courses${query}`);
  }

  async updateCourse(id: string, updates: any): Promise<SyncResult> {
    try {
      console.log('✏️ Updating course:', id, updates);
      
      const result = await this.apiCall<Course>(`/courses/${id}`, {
        method: 'PUT',
        body: JSON.stringify(updates)
      });

      if (result.success) {
        console.log('✅ Course updated successfully:', result.data);
        return {
          success: true,
          message: `Course "${result.data?.title}" updated successfully`,
          syncedItems: 1
        };
      } else {
        throw new Error(result.error);
      }
    } catch (error) {
      console.error('❌ Failed to update course:', error);
      return {
        success: false,
        message: `Failed to update course: ${error instanceof Error ? error.message : 'Unknown error'}`,
        errors: [error]
      };
    }
  }

  async deleteCourse(id: string): Promise<SyncResult> {
    try {
      console.log('🗑️ Deleting course:', id);
      
      const result = await this.apiCall<boolean>(`/courses/${id}`, {
        method: 'DELETE'
      });

      if (result.success) {
        console.log('✅ Course deleted successfully');
        return {
          success: true,
          message: 'Course deleted successfully',
          syncedItems: 1
        };
      } else {
        throw new Error(result.error);
      }
    } catch (error) {
      console.error('❌ Failed to delete course:', error);
      return {
        success: false,
        message: `Failed to delete course: ${error instanceof Error ? error.message : 'Unknown error'}`,
        errors: [error]
      };
    }
  }

  async publishCourse(id: string): Promise<SyncResult> {
    try {
      console.log('📢 Publishing course:', id);
      
      const result = await this.apiCall<Course>(`/courses/${id}/publish`, {
        method: 'POST'
      });

      if (result.success) {
        console.log('✅ Course published successfully:', result.data);
        return {
          success: true,
          message: `Course "${result.data?.title}" published successfully`,
          syncedItems: 1
        };
      } else {
        throw new Error(result.error);
      }
    } catch (error) {
      console.error('❌ Failed to publish course:', error);
      return {
        success: false,
        message: `Failed to publish course: ${error instanceof Error ? error.message : 'Unknown error'}`,
        errors: [error]
      };
    }
  }

  // Class methods
  async createClass(courseId: string, classData: any): Promise<SyncResult> {
    try {
      console.log('🆕 Creating class via API...', classData);
      
      const result = await this.apiCall<CourseClass>('/classes', {
        method: 'POST',
        body: JSON.stringify({ ...classData, courseId })
      });

      if (result.success) {
        console.log('✅ Class created successfully:', result.data);
        return {
          success: true,
          message: `Class "${result.data?.title}" created successfully`,
          syncedItems: 1
        };
      } else {
        throw new Error(result.error);
      }
    } catch (error) {
      console.error('❌ Failed to create class:', error);
      return {
        success: false,
        message: `Failed to create class: ${error instanceof Error ? error.message : 'Unknown error'}`,
        errors: [error]
      };
    }
  }

  async getClassesByCourse(courseId: string): Promise<DatabaseResponse<CourseClass[]>> {
    console.log('🔍 Fetching classes for course:', courseId);
    return this.apiCall<CourseClass[]>(`/courses/${courseId}/classes`);
  }

  // Order methods
  async createOrder(orderData: any): Promise<SyncResult> {
    try {
      console.log('🆕 Creating order via API...', orderData);
      
      const result = await this.apiCall<Order>('/orders', {
        method: 'POST',
        body: JSON.stringify(orderData)
      });

      if (result.success) {
        console.log('✅ Order created successfully:', result.data);
        return {
          success: true,
          message: `Order created successfully`,
          syncedItems: 1
        };
      } else {
        throw new Error(result.error);
      }
    } catch (error) {
      console.error('❌ Failed to create order:', error);
      return {
        success: false,
        message: `Failed to create order: ${error instanceof Error ? error.message : 'Unknown error'}`,
        errors: [error]
      };
    }
  }

  async getOrders(): Promise<DatabaseResponse<PaginatedResponse<Order>>> {
    console.log('📋 Fetching orders');
    return this.apiCall<PaginatedResponse<Order>>('/orders');
  }

  async updateOrderStatus(id: string, status: string, transactionId?: string): Promise<SyncResult> {
    try {
      console.log('��️ Updating order status:', id, status);
      
      const result = await this.apiCall<Order>(`/orders/${id}/status`, {
        method: 'PUT',
        body: JSON.stringify({ status, transactionId })
      });

      if (result.success) {
        console.log('✅ Order status updated successfully:', result.data);
        return {
          success: true,
          message: `Order status updated to ${status}`,
          syncedItems: 1
        };
      } else {
        throw new Error(result.error);
      }
    } catch (error) {
      console.error('❌ Failed to update order status:', error);
      return {
        success: false,
        message: `Failed to update order status: ${error instanceof Error ? error.message : 'Unknown error'}`,
        errors: [error]
      };
    }
  }

  // Legacy methods for compatibility with existing localStorage-based code
  async syncCourses(): Promise<SyncResult> {
    try {
      console.log('🔄 Syncing courses from localStorage to database...');
      
      // Get courses from localStorage
      const localCourses = this.getLocalCourses();
      const publishedCourses = localCourses.filter(course => course.isPublished);

      if (publishedCourses.length === 0) {
        return {
          success: true,
          message: 'No published courses to sync',
          syncedItems: 0
        };
      }

      let syncedCount = 0;
      const errors: any[] = [];

      // Sync each course
      for (const course of publishedCourses) {
        try {
          const result = await this.createCourse(course);
          if (result.success) {
            syncedCount++;
          } else {
            errors.push(result.errors);
          }
        } catch (error) {
          errors.push(error);
        }
      }

      if (errors.length === 0) {
        console.log(`✅ Successfully synced ${syncedCount} courses`);
        return {
          success: true,
          message: `Synced ${syncedCount} published courses to database`,
          syncedItems: syncedCount
        };
      } else {
        return {
          success: false,
          message: `Partial sync completed - ${syncedCount} successful, ${errors.length} failed`,
          syncedItems: syncedCount,
          errors
        };
      }
    } catch (error) {
      console.error('❌ Course sync failed:', error);
      return {
        success: false,
        message: `Sync failed: ${error instanceof Error ? error.message : 'Unknown error'}`,
        errors: [error]
      };
    }
  }

  async syncOrders(): Promise<SyncResult> {
    try {
      console.log('🔄 Syncing orders from localStorage to database...');
      
      // Get orders from localStorage
      const localOrders = this.getLocalOrders();
      const completedOrders = localOrders.filter(order => order.paymentStatus === 'completed');

      if (completedOrders.length === 0) {
        return {
          success: true,
          message: 'No completed orders to sync',
          syncedItems: 0
        };
      }

      let syncedCount = 0;
      const errors: any[] = [];

      // Sync each order
      for (const order of completedOrders) {
        try {
          const result = await this.createOrder(order);
          if (result.success) {
            syncedCount++;
          } else {
            errors.push(result.errors);
          }
        } catch (error) {
          errors.push(error);
        }
      }

      if (errors.length === 0) {
        console.log(`✅ Successfully synced ${syncedCount} orders`);
        return {
          success: true,
          message: `Synced ${syncedCount} completed orders`,
          syncedItems: syncedCount
        };
      } else {
        return {
          success: false,
          message: `Partial sync completed - ${syncedCount} successful, ${errors.length} failed`,
          syncedItems: syncedCount,
          errors
        };
      }
    } catch (error) {
      console.error('❌ Order sync failed:', error);
      return {
        success: false,
        message: `Sync failed: ${error instanceof Error ? error.message : 'Unknown error'}`,
        errors: [error]
      };
    }
  }

  async syncAll(): Promise<SyncResult> {
    try {
      console.log('🚀 Starting full database sync...');
      
      const courseResult = await this.syncCourses();
      const orderResult = await this.syncOrders();
      
      const totalSynced = (courseResult.syncedItems || 0) + (orderResult.syncedItems || 0);
      const hasErrors = !courseResult.success || !orderResult.success;
      
      if (!hasErrors) {
        return {
          success: true,
          message: `Successfully synced ${totalSynced} items to database`,
          syncedItems: totalSynced
        };
      } else {
        return {
          success: false,
          message: 'Partial sync completed with errors',
          syncedItems: totalSynced,
          errors: [...(courseResult.errors || []), ...(orderResult.errors || [])]
        };
      }
    } catch (error) {
      return {
        success: false,
        message: 'Full sync failed',
        errors: [error]
      };
    }
  }

  // Helper methods for localStorage access (for migration)
  private getLocalCourses(): any[] {
    const saved = localStorage.getItem('edumaster_courses');
    return saved ? JSON.parse(saved) : [];
  }

  private getLocalOrders(): any[] {
    const saved = localStorage.getItem('edumaster_orders');
    return saved ? JSON.parse(saved) : [];
  }

  // Migration helper - move data from localStorage to database
  async migrateFromLocalStorage(): Promise<SyncResult> {
    console.log('🔄 Starting migration from localStorage to database...');
    return this.syncAll();
  }

  // Check connection to database
  async testConnection(): Promise<boolean> {
    try {
      const response = await fetch(`${this.baseUrl}/api/ping`);
      return response.ok;
    } catch (error) {
      console.error('Database connection test failed:', error);
      return false;
    }
  }
}

// Create singleton instance
export const apiDatabaseService = new ApiDatabaseService();

export default ApiDatabaseService;
