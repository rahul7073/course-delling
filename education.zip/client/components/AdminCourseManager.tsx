import React, { useState, useCallback } from 'react';
import { useData } from '../contexts/DataContext';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Textarea } from './ui/textarea';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Badge } from './ui/badge';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from './ui/dialog';
import { Tabs, TabsContent, TabsList, TabsTrigger } from './ui/tabs';
import { Switch } from './ui/switch';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from './ui/select';
import { useToast } from '@/hooks/use-toast';
import { fileToDataURL, formatFileSize, getFileIcon } from '../utils/fileDownload';
import CourseDataDebug from './CourseDataDebug';
import SaveTestButton from './SaveTestButton';
import ContentVerification from './ContentVerification';
import WebsitePreviewButton from './WebsitePreviewButton';
import { useSaveSuccessToast } from './SaveSuccessToast';
import {
  Plus,
  Edit,
  Trash2, 
  Search, 
  Upload,
  FileText,
  Play,
  Code,
  FolderOpen,
  Eye,
  Lock,
  Unlock,
  Save,
  X,
  Download,
  BookOpen
} from 'lucide-react';

interface AdminCourseManagerProps {
  course: any;
  isOpen: boolean;
  onClose: () => void;
}

const AdminCourseManager: React.FC<AdminCourseManagerProps> = ({ course, isOpen, onClose }) => {
  const {
    updateCourse,
    addCourseClass,
    updateCourseClass,
    deleteCourseClass
  } = useData();

  const { showVideoSaveSuccess, showNotesSaveSuccess, showProjectSaveSuccess } = useSaveSuccessToast();
  
  const [activeTab, setActiveTab] = useState('classes');
  const [selectedClass, setSelectedClass] = useState<any>(null);
  const [isAddClassOpen, setIsAddClassOpen] = useState(false);
  const [isEditClassOpen, setIsEditClassOpen] = useState(false);
  const [uploadProgress, setUploadProgress] = useState<{[key: string]: number}>({});
  
  // Class form data
  const [classFormData, setClassFormData] = useState<any>({
    classNumber: 1,
    title: '',
    description: '',
    isDemo: false,
    videos: [],
    notes: [],
    projects: []
  });
  
  // Content form data
  const [videoFormData, setVideoFormData] = useState<any>({});
  const [noteFormData, setNoteFormData] = useState<any>({});
  const [projectFormData, setProjectFormData] = useState<any>({});
  const [codeFiles, setCodeFiles] = useState<any[]>([]);
  
  const { toast } = useToast();

  // File upload simulation (in real app, this would upload to server/cloud storage)
  const simulateFileUpload = (file: File, type: string): Promise<string> => {
    return new Promise((resolve) => {
      const uploadKey = `${type}_${Date.now()}`;
      setUploadProgress(prev => ({ ...prev, [uploadKey]: 0 }));
      
      // Simulate upload progress
      const interval = setInterval(() => {
        setUploadProgress(prev => {
          const currentProgress = prev[uploadKey] || 0;
          if (currentProgress >= 100) {
            clearInterval(interval);
            resolve(`/uploads/${type}/${file.name}`);
            return { ...prev, [uploadKey]: 100 };
          }
          return { ...prev, [uploadKey]: currentProgress + 10 };
        });
      }, 200);
    });
  };

  const handleFileUpload = async (file: File, type: 'video' | 'note' | 'project') => {
    try {
      toast({
        title: "Processing file...",
        description: `Processing ${file.name} (${formatFileSize(file.size)})`,
      });

      // Convert file to data URL for storage
      const dataUrl = await fileToDataURL(file);

      // Store file info in localStorage for real downloads
      const fileInfo = {
        name: file.name,
        size: file.size,
        type: file.type,
        dataUrl: dataUrl,
        uploadDate: new Date().toISOString(),
        courseId: course.id,
        fileType: type
      };

      // Store in localStorage with a unique key
      const fileKey = `edumaster_file_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
      localStorage.setItem(fileKey, JSON.stringify(fileInfo));

      toast({
        title: "File ready!",
        description: `${file.name} is ready for download`,
      });

      return fileKey; // Return the storage key as fileUrl
    } catch (error) {
      toast({
        title: "Processing failed",
        description: "Please try again",
        variant: "destructive"
      });
      throw error;
    }
  };

  const handleAddClass = () => {
    if (!classFormData.title || !classFormData.description) {
      toast({
        title: "Required fields missing",
        description: "Please fill in class title and description",
        variant: "destructive"
      });
      return;
    }

    addCourseClass(course.id, {
      classNumber: classFormData.classNumber,
      title: classFormData.title,
      description: classFormData.description,
      isDemo: classFormData.isDemo,
      videos: [],
      notes: [],
      projects: []
    });

    setClassFormData({
      classNumber: (course.classes?.length || 0) + 2,
      title: '',
      description: '',
      isDemo: false,
      videos: [],
      notes: [],
      projects: []
    });
    
    setIsAddClassOpen(false);
    
    toast({
      title: "Class added!",
      description: `Class ${classFormData.classNumber} has been created`,
    });
  };

  const handleDeleteClass = (classId: string, classNumber: number) => {
    if (window.confirm(`Are you sure you want to delete Class ${classNumber}?`)) {
      deleteCourseClass(course.id, classId);
      toast({
        title: "Class deleted",
        description: `Class ${classNumber} has been removed`,
      });
    }
  };

  const handleAddVideoToClass = async () => {
    const classId = selectedClass?.id;
    if (!videoFormData.title || !videoFormData.videoFile) {
      toast({
        title: "Missing video data",
        description: "Please provide video title and file",
        variant: "destructive"
      });
      return;
    }

    try {
      const videoUrl = await handleFileUpload(videoFormData.videoFile, 'video');
      
      const newVideo = {
        id: Date.now().toString(),
        title: videoFormData.title,
        description: videoFormData.description || '',
        videoUrl: videoUrl,
        duration: videoFormData.duration || '00:00',
        thumbnailUrl: videoFormData.thumbnailUrl,
        uploadDate: new Date().toISOString().split('T')[0],
        order: 1,
        isPreview: false,
        classNumber: selectedClass.classNumber
      };

      const updatedClass = {
        ...selectedClass,
        videos: [...(selectedClass.videos || []), newVideo]
      };

      updateCourseClass(course.id, classId, updatedClass);
      setVideoFormData({});

      // Force re-render by updating course state
      setTimeout(() => {
        setSelectedClass(prevClass => ({
          ...prevClass,
          videos: [...(prevClass.videos || []), newVideo]
        }));
      }, 100);

      toast({
        title: "Video added successfully!",
        description: `Video "${newVideo.title}" added to Class ${selectedClass.classNumber}`,
      });
    } catch (error) {
      // Error already handled in handleFileUpload
    }
  };

  const handleAddNoteToClass = async () => {
    const classId = selectedClass?.id;
    if (!noteFormData.title || !noteFormData.noteFile) {
      toast({
        title: "Missing note data",
        description: "Please provide note title and file",
        variant: "destructive"
      });
      return;
    }

    try {
      const fileUrl = await handleFileUpload(noteFormData.noteFile, 'note');
      
      const newNote = {
        id: Date.now().toString(),
        title: noteFormData.title,
        description: noteFormData.description || '',
        fileUrl: fileUrl,
        fileSize: `${(noteFormData.noteFile.size / 1024 / 1024).toFixed(1)} MB`,
        uploadDate: new Date().toISOString().split('T')[0],
        classNumber: selectedClass.classNumber
      };

      const updatedClass = {
        ...selectedClass,
        notes: [...(selectedClass.notes || []), newNote]
      };

      updateCourseClass(course.id, classId, updatedClass);
      setNoteFormData({});

      // Force re-render by updating class state
      setTimeout(() => {
        setSelectedClass(prevClass => ({
          ...prevClass,
          notes: [...(prevClass.notes || []), newNote]
        }));
      }, 100);

      toast({
        title: "Notes added successfully!",
        description: `Notes "${newNote.title}" added to Class ${selectedClass.classNumber}`,
      });
    } catch (error) {
      // Error already handled in handleFileUpload
    }
  };

  const handleAddProjectToClass = async () => {
    const classId = selectedClass?.id;
    if (!projectFormData.title || codeFiles.length === 0) {
      toast({
        title: "Missing project data",
        description: "Please provide project title and code files",
        variant: "destructive"
      });
      return;
    }

    try {
      // Upload all code files
      const uploadedFiles = await Promise.all(
        codeFiles.map(async (file) => ({
          fileName: file.fileName,
          fileUrl: await handleFileUpload(file.file, 'project'),
          language: file.language
        }))
      );

      const newProject = {
        id: Date.now().toString(),
        title: projectFormData.title,
        description: projectFormData.description || '',
        codeFiles: uploadedFiles,
        projectUrl: projectFormData.projectUrl,
        demoUrl: projectFormData.demoUrl,
        uploadDate: new Date().toISOString().split('T')[0],
        difficulty: projectFormData.difficulty || 'easy',
        classNumber: selectedClass.classNumber
      };

      const updatedClass = {
        ...selectedClass,
        projects: [...(selectedClass.projects || []), newProject]
      };

      updateCourseClass(course.id, classId, updatedClass);
      setProjectFormData({});
      setCodeFiles([]);

      // Force re-render by updating class state
      setTimeout(() => {
        setSelectedClass(prevClass => ({
          ...prevClass,
          projects: [...(prevClass.projects || []), newProject]
        }));
      }, 100);

      toast({
        title: "Project added successfully!",
        description: `Project "${newProject.title}" added to Class ${selectedClass.classNumber}`,
      });
    } catch (error) {
      // Error already handled in handleFileUpload
    }
  };

  const addCodeFile = () => {
    setCodeFiles(prev => [...prev, { fileName: '', file: null, language: 'javascript' }]);
  };

  const updateCodeFile = (index: number, field: string, value: any) => {
    setCodeFiles(prev => prev.map((file, i) =>
      i === index ? { ...file, [field]: value } : file
    ));
  };

  const removeCodeFile = (index: number) => {
    setCodeFiles(prev => prev.filter((_, i) => i !== index));
  };

  // Optimized form handlers
  const handleClassFormChange = useCallback((field: string, value: any) => {
    setClassFormData(prev => ({ ...prev, [field]: value }));
  }, []);

  const handleVideoFormChange = useCallback((field: string, value: any) => {
    setVideoFormData(prev => ({ ...prev, [field]: value }));
  }, []);

  const handleNoteFormChange = useCallback((field: string, value: any) => {
    setNoteFormData(prev => ({ ...prev, [field]: value }));
  }, []);

  const handleProjectFormChange = useCallback((field: string, value: any) => {
    setProjectFormData(prev => ({ ...prev, [field]: value }));
  }, []);

  const handleManageClass = (classItem: any) => {
    setSelectedClass(classItem);
    setActiveTab('content');
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-7xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <BookOpen className="w-5 h-5" />
              Manage Course: {course?.title}
            </div>
            <div className="flex items-center gap-4">
              <div className="flex items-center gap-2">
                <Badge variant={course.isPublished ? "default" : "secondary"}>
                  {course.isPublished ? "🟢 Published" : "⚪ Draft"}
                </Badge>
                <WebsitePreviewButton courseId={course.id} courseName={course.title} />
                <Button
                  variant={course.isPublished ? "destructive" : "default"}
                  size="sm"
                  onClick={() => {
                    updateCourse(course.id, { isPublished: !course.isPublished });
                    toast({
                      title: course.isPublished ? "Course Unpublished" : "🚀 Course Published!",
                      description: course.isPublished
                        ? "Course is now hidden from students"
                        : "Course is now live and available to students on the website!",
                    });
                  }}
                >
                  {course.isPublished ? "📤 Unpublish" : "🚀 Publish Course"}
                </Button>
              </div>
            </div>
          </DialogTitle>
        </DialogHeader>
        
        <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
          <TabsList className="grid w-full grid-cols-2">
            <TabsTrigger value="classes">��� Classes ({course.classes?.length || 0})</TabsTrigger>
            <TabsTrigger value="content" disabled={!selectedClass}>
              🎯 Class Content {selectedClass ? `- Class ${selectedClass.classNumber}` : ''}
            </TabsTrigger>
          </TabsList>

          {/* Classes Management Tab */}
          <TabsContent value="classes" className="space-y-6">
            {/* Course Statistics Summary */}
            <Card className="bg-gradient-to-r from-blue-50 to-green-50 border-2 border-blue-200">
              <CardContent className="p-4">
                <div className="grid grid-cols-4 gap-4 text-center">
                  <div>
                    <div className="text-2xl font-bold text-blue-600">
                      {course.classes?.length || 0}
                    </div>
                    <div className="text-sm text-gray-600">Classes</div>
                  </div>
                  <div>
                    <div className="text-2xl font-bold text-green-600">
                      {course.classes?.reduce((total, cls) => total + (cls.videos?.length || 0), 0) || 0}
                    </div>
                    <div className="text-sm text-gray-600">Videos</div>
                  </div>
                  <div>
                    <div className="text-2xl font-bold text-purple-600">
                      {course.classes?.reduce((total, cls) => total + (cls.notes?.length || 0), 0) || 0}
                    </div>
                    <div className="text-sm text-gray-600">Notes</div>
                  </div>
                  <div>
                    <div className="text-2xl font-bold text-orange-600">
                      {course.classes?.reduce((total, cls) => total + (cls.projects?.length || 0), 0) || 0}
                    </div>
                    <div className="text-sm text-gray-600">Projects</div>
                  </div>
                </div>
                <div className="mt-4 text-center">
                  <Badge variant="outline" className="text-lg px-4 py-1">
                    📊 Total Content: {
                      (course.classes?.reduce((total, cls) =>
                        total + (cls.videos?.length || 0) + (cls.notes?.length || 0) + (cls.projects?.length || 0), 0) || 0)
                    } items
                  </Badge>
                </div>
              </CardContent>
            </Card>

            <div className="flex justify-between items-center">
              <h3 className="text-lg font-semibold">Course Classes</h3>
              <Dialog open={isAddClassOpen} onOpenChange={setIsAddClassOpen}>
                <DialogTrigger asChild>
                  <Button>
                    <Plus className="h-4 w-4 mr-2" />
                    Add New Class
                  </Button>
                </DialogTrigger>
                <DialogContent>
                  <DialogHeader>
                    <DialogTitle>Add New Class</DialogTitle>
                  </DialogHeader>
                  <div className="space-y-4">
                    <div className="grid grid-cols-2 gap-4">
                      <div>
                        <label className="block text-sm font-medium mb-1">Class Number</label>
                        <Input
                          type="number"
                          value={classFormData.classNumber}
                          onChange={(e) => handleClassFormChange('classNumber', Number(e.target.value))}
                          min="1"
                        />
                      </div>
                      <div className="flex items-center space-x-2 pt-6">
                        <Switch
                          checked={classFormData.isDemo}
                          onCheckedChange={(checked) => handleClassFormChange('isDemo', checked)}
                        />
                        <label className="text-sm font-medium">Demo Class (Free Preview)</label>
                      </div>
                    </div>
                    
                    <div>
                      <label className="block text-sm font-medium mb-1">Class Title</label>
                      <Input
                        value={classFormData.title}
                        onChange={(e) => handleClassFormChange('title', e.target.value)}
                        placeholder="e.g., Introduction to React"
                      />
                    </div>
                    
                    <div>
                      <label className="block text-sm font-medium mb-1">Class Description</label>
                      <Textarea
                        value={classFormData.description}
                        onChange={(e) => handleClassFormChange('description', e.target.value)}
                        placeholder="Describe what students will learn in this class"
                        rows={3}
                      />
                    </div>
                    
                    <div className="flex justify-end space-x-2">
                      <Button variant="outline" onClick={() => setIsAddClassOpen(false)}>
                        Cancel
                      </Button>
                      <Button onClick={handleAddClass}>
                        <Plus className="h-4 w-4 mr-2" />
                        Add Class
                      </Button>
                    </div>
                  </div>
                </DialogContent>
              </Dialog>
            </div>

            {/* Classes List */}
            <div className="grid gap-4">
              {course.classes && course.classes.length > 0 ? (
                course.classes
                  .sort((a: any, b: any) => a.classNumber - b.classNumber)
                  .map((classItem: any) => (
                    <Card key={classItem.id} className="overflow-hidden">
                      <CardContent className="p-4">
                        <div className="flex items-center justify-between">
                          <div className="flex items-center gap-4">
                            <div className="w-12 h-12 bg-primary/10 rounded-lg flex items-center justify-center">
                              <span className="font-bold text-primary">{classItem.classNumber}</span>
                            </div>
                            <div>
                              <h4 className="font-medium flex items-center gap-2">
                                {classItem.title}
                                {classItem.isDemo && <Badge variant="secondary">Demo</Badge>}
                              </h4>
                              <p className="text-sm text-muted-foreground">{classItem.description}</p>
                              <div className="flex items-center gap-4 mt-2 text-xs">
                                <Badge variant="outline" className={`${classItem.videos?.length > 0 ? 'bg-green-50 text-green-700' : 'bg-gray-50'}`}>
                                  🎥 {classItem.videos?.length || 0} videos
                                </Badge>
                                <Badge variant="outline" className={`${classItem.notes?.length > 0 ? 'bg-blue-50 text-blue-700' : 'bg-gray-50'}`}>
                                  📝 {classItem.notes?.length || 0} notes
                                </Badge>
                                <Badge variant="outline" className={`${classItem.projects?.length > 0 ? 'bg-purple-50 text-purple-700' : 'bg-gray-50'}`}>
                                  💻 {classItem.projects?.length || 0} projects
                                </Badge>
                                {(classItem.videos?.length > 0 || classItem.notes?.length > 0 || classItem.projects?.length > 0) && (
                                  <Badge className="bg-green-100 text-green-800">
                                    ✅ Content Saved
                                  </Badge>
                                )}
                              </div>
                            </div>
                          </div>
                          
                          <div className="flex items-center gap-2">
                            <Button
                              variant="outline"
                              size="sm"
                              onClick={() => handleManageClass(classItem)}
                            >
                              <Edit className="h-4 w-4 mr-1" />
                              Manage Content
                            </Button>
                            <Button
                              variant="destructive"
                              size="sm"
                              onClick={() => handleDeleteClass(classItem.id, classItem.classNumber)}
                            >
                              <Trash2 className="h-4 w-4" />
                            </Button>
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                  ))
              ) : (
                <div className="text-center py-8 text-muted-foreground">
                  <BookOpen className="h-12 w-12 mx-auto mb-4 opacity-50" />
                  <p>No classes created yet. Add your first class to get started!</p>
                </div>
              )}
            </div>
          </TabsContent>

          {/* Class Content Management Tab */}
          <TabsContent value="content" className="space-y-6">
            {selectedClass && (
              <>
                <div className="flex items-center justify-between">
                  <div>
                    <h3 className="text-lg font-semibold">
                      Class {selectedClass.classNumber}: {selectedClass.title}
                    </h3>
                    <div className="flex items-center gap-2 mt-1">
                      <Badge variant={selectedClass.isDemo ? "secondary" : "default"}>
                        {selectedClass.isDemo ? "Demo Class" : "Paid Class"}
                      </Badge>
                      <Badge className="bg-green-100 text-green-800">
                        📊 {(selectedClass.videos?.length || 0) + (selectedClass.notes?.length || 0) + (selectedClass.projects?.length || 0)} items saved
                      </Badge>
                    </div>
                  </div>
                  <Button
                    variant="outline"
                    onClick={() => {
                      const totalContent = (selectedClass.videos?.length || 0) +
                                         (selectedClass.notes?.length || 0) +
                                         (selectedClass.projects?.length || 0);
                      toast({
                        title: "💾 Content Status",
                        description: `Class ${selectedClass.classNumber} has ${totalContent} saved items ready for students on the website.`,
                      });
                    }}
                    className="bg-blue-50 border-blue-200 text-blue-700 hover:bg-blue-100"
                  >
                    📈 Check Save Status
                  </Button>
                </div>

                <Tabs defaultValue="videos" className="w-full">
                  <TabsList className="grid w-full grid-cols-3">
                    <TabsTrigger value="videos">🎥 Videos</TabsTrigger>
                    <TabsTrigger value="notes">📄 Notes</TabsTrigger>
                    <TabsTrigger value="projects">💻 Projects</TabsTrigger>
                  </TabsList>

                  {/* Videos Tab */}
                  <TabsContent value="videos" className="space-y-4">
                    <Card>
                      <CardHeader>
                        <CardTitle className="text-lg">Add Video</CardTitle>
                      </CardHeader>
                      <CardContent className="space-y-4">
                        <div className="grid grid-cols-2 gap-4">
                          <div>
                            <label className="block text-sm font-medium mb-1">Video Title</label>
                            <Input
                              value={videoFormData.title || ''}
                              onChange={(e) => handleVideoFormChange('title', e.target.value)}
                              placeholder="e.g., Introduction to Concepts"
                            />
                          </div>
                          <div>
                            <label className="block text-sm font-medium mb-1">Duration</label>
                            <Input
                              value={videoFormData.duration || ''}
                              onChange={(e) => handleVideoFormChange('duration', e.target.value)}
                              placeholder="e.g., 15:30"
                            />
                          </div>
                        </div>

                        <div>
                          <label className="block text-sm font-medium mb-1">Description</label>
                          <Textarea
                            value={videoFormData.description || ''}
                            onChange={(e) => handleVideoFormChange('description', e.target.value)}
                            placeholder="Describe what this video covers"
                            rows={2}
                          />
                        </div>

                        <div>
                          <label className="block text-sm font-medium mb-1">Upload Video File</label>
                          <div className="flex items-center space-x-2">
                            <input
                              type="file"
                              accept="video/*"
                              className="flex-1 p-2 border border-border rounded-md"
                              onChange={(e) => {
                                const file = e.target.files?.[0];
                                if (file) {
                                  handleVideoFormChange('videoFile', file);

                                  // Show format warning for MOV files
                                  if (file.name.toLowerCase().endsWith('.mov')) {
                                    toast({
                                      title: "⚠️ MOV Format Detected",
                                      description: "MOV files may have compatibility issues. MP4 format is recommended for best browser support.",
                                      variant: "destructive"
                                    });
                                  }
                                }
                              }}
                            />
                            <Button variant="outline" size="sm">
                              <Upload className="h-4 w-4 mr-2" />
                              Browse
                            </Button>
                          </div>
                          <p className="text-xs text-muted-foreground mt-1">
                            📝 <strong>Recommended:</strong> MP4 format for best compatibility across all browsers
                          </p>
                        </div>
                        
                        <div className="flex justify-end space-x-2">
                          <Button
                            variant="outline"
                            onClick={() => setVideoFormData({})}
                          >
                            Clear
                          </Button>
                          <Button
                            onClick={async () => {
                              try {
                                await handleAddVideoToClass();
                                showVideoSaveSuccess(selectedClass.classNumber, videoFormData.title);
                              } catch (error) {
                                toast({
                                  title: "❌ Save Failed",
                                  description: "Please try again or check file format",
                                  variant: "destructive"
                                });
                              }
                            }}
                            disabled={!videoFormData.title || !videoFormData.videoFile}
                            className="bg-green-600 hover:bg-green-700"
                          >
                            <Upload className="h-4 w-4 mr-2" />
                            💾 Save Video Content
                          </Button>
                        </div>
                      </CardContent>
                    </Card>

                    {/* Videos List */}
                    <Card>
                      <CardHeader>
                        <CardTitle className="text-lg">Class Videos ({selectedClass.videos?.length || 0})</CardTitle>
                      </CardHeader>
                      <CardContent>
                        {selectedClass.videos && selectedClass.videos.length > 0 ? (
                          <div className="space-y-3">
                            {selectedClass.videos.map((video: any) => (
                              <div key={video.id} className="flex items-center justify-between p-3 bg-muted/30 rounded-lg">
                                <div className="flex items-center space-x-3">
                                  <Play className="h-5 w-5 text-red-600" />
                                  <div>
                                    <h4 className="font-medium">{video.title}</h4>
                                    <p className="text-sm text-muted-foreground">{video.description}</p>
                                    <p className="text-xs text-muted-foreground">Duration: {video.duration}</p>
                                  </div>
                                </div>
                                <Button variant="destructive" size="sm">
                                  <Trash2 className="h-4 w-4" />
                                </Button>
                              </div>
                            ))}
                          </div>
                        ) : (
                          <div className="text-center py-8 text-muted-foreground">
                            <Play className="h-12 w-12 mx-auto mb-4 opacity-50" />
                            <p>No videos uploaded yet</p>
                          </div>
                        )}
                      </CardContent>
                    </Card>
                  </TabsContent>

                  {/* Notes Tab */}
                  <TabsContent value="notes" className="space-y-4">
                    <Card>
                      <CardHeader>
                        <CardTitle className="text-lg">Add Note</CardTitle>
                      </CardHeader>
                      <CardContent className="space-y-4">
                        <div>
                          <label className="block text-sm font-medium mb-1">Note Title</label>
                          <Input
                            value={noteFormData.title || ''}
                            onChange={(e) => handleNoteFormChange('title', e.target.value)}
                            placeholder="e.g., Class Notes - Introduction"
                          />
                        </div>

                        <div>
                          <label className="block text-sm font-medium mb-1">Description</label>
                          <Textarea
                            value={noteFormData.description || ''}
                            onChange={(e) => handleNoteFormChange('description', e.target.value)}
                            placeholder="Describe what this note covers"
                            rows={2}
                          />
                        </div>

                        <div>
                          <label className="block text-sm font-medium mb-1">Upload Note File</label>
                          <div className="flex items-center space-x-2">
                            <input
                              type="file"
                              accept=".pdf,.doc,.docx,.txt"
                              className="flex-1 p-2 border border-border rounded-md"
                              onChange={(e) => {
                                const file = e.target.files?.[0];
                                if (file) {
                                  handleNoteFormChange('noteFile', file);
                                }
                              }}
                            />
                            <Button variant="outline" size="sm">
                              <Upload className="h-4 w-4 mr-2" />
                              Browse
                            </Button>
                          </div>
                        </div>
                        
                        <div className="flex justify-end space-x-2">
                          <Button
                            variant="outline"
                            onClick={() => setNoteFormData({})}
                          >
                            Clear
                          </Button>
                          <Button
                            onClick={async () => {
                              try {
                                await handleAddNoteToClass();
                                showNotesSaveSuccess(selectedClass.classNumber, noteFormData.title);
                              } catch (error) {
                                toast({
                                  title: "❌ Save Failed",
                                  description: "Please try again or check file format",
                                  variant: "destructive"
                                });
                              }
                            }}
                            disabled={!noteFormData.title || !noteFormData.noteFile}
                            className="bg-blue-600 hover:bg-blue-700"
                          >
                            <FileText className="h-4 w-4 mr-2" />
                            💾 Save Notes Content
                          </Button>
                        </div>
                      </CardContent>
                    </Card>

                    {/* Notes List */}
                    <Card>
                      <CardHeader>
                        <CardTitle className="text-lg">Class Notes ({selectedClass.notes?.length || 0})</CardTitle>
                      </CardHeader>
                      <CardContent>
                        {selectedClass.notes && selectedClass.notes.length > 0 ? (
                          <div className="space-y-3">
                            {selectedClass.notes.map((note: any) => (
                              <div key={note.id} className="flex items-center justify-between p-3 bg-muted/30 rounded-lg">
                                <div className="flex items-center space-x-3">
                                  <FileText className="h-5 w-5 text-blue-600" />
                                  <div>
                                    <h4 className="font-medium">{note.title}</h4>
                                    <p className="text-sm text-muted-foreground">{note.description}</p>
                                    <p className="text-xs text-muted-foreground">Size: {note.fileSize}</p>
                                  </div>
                                </div>
                                <div className="flex items-center space-x-2">
                                  <Button variant="outline" size="sm">
                                    <Download className="h-4 w-4" />
                                  </Button>
                                  <Button variant="destructive" size="sm">
                                    <Trash2 className="h-4 w-4" />
                                  </Button>
                                </div>
                              </div>
                            ))}
                          </div>
                        ) : (
                          <div className="text-center py-8 text-muted-foreground">
                            <FileText className="h-12 w-12 mx-auto mb-4 opacity-50" />
                            <p>No notes uploaded yet</p>
                          </div>
                        )}
                      </CardContent>
                    </Card>
                  </TabsContent>

                  {/* Projects Tab */}
                  <TabsContent value="projects" className="space-y-4">
                    <Card>
                      <CardHeader>
                        <CardTitle className="text-lg">Add Project</CardTitle>
                      </CardHeader>
                      <CardContent className="space-y-4">
                        <div className="grid grid-cols-2 gap-4">
                          <div>
                            <label className="block text-sm font-medium mb-1">Project Title</label>
                            <Input
                              value={projectFormData.title || ''}
                              onChange={(e) => handleProjectFormChange('title', e.target.value)}
                              placeholder="e.g., Todo App Project"
                            />
                          </div>
                          <div>
                            <label className="block text-sm font-medium mb-1">Difficulty</label>
                            <Select 
                              value={projectFormData.difficulty || 'easy'} 
                              onValueChange={(value) => handleProjectFormChange('difficulty', value)}
                            >
                              <SelectTrigger>
                                <SelectValue />
                              </SelectTrigger>
                              <SelectContent>
                                <SelectItem value="easy">Easy</SelectItem>
                                <SelectItem value="medium">Medium</SelectItem>
                                <SelectItem value="hard">Hard</SelectItem>
                              </SelectContent>
                            </Select>
                          </div>
                        </div>

                        <div>
                          <label className="block text-sm font-medium mb-1">Description</label>
                          <Textarea
                            value={projectFormData.description || ''}
                            onChange={(e) => handleProjectFormChange('description', e.target.value)}
                            placeholder="Describe the project and what students will build"
                            rows={2}
                          />
                        </div>
                        
                        <div>
                          <div className="flex justify-between items-center mb-2">
                            <label className="block text-sm font-medium">Code Files</label>
                            <Button variant="outline" size="sm" onClick={addCodeFile}>
                              <Plus className="h-4 w-4 mr-2" />
                              Add Code File
                            </Button>
                          </div>
                          <div className="space-y-2 max-h-48 overflow-y-auto">
                            {codeFiles.map((file, index) => (
                              <div key={index} className="grid grid-cols-4 gap-2 p-2 border rounded">
                                <Input
                                  placeholder="File name"
                                  value={file.fileName}
                                  onChange={(e) => updateCodeFile(index, 'fileName', e.target.value)}
                                />
                                <input
                                  type="file"
                                  className="p-1 border rounded text-xs"
                                  onChange={(e) => {
                                    const selectedFile = e.target.files?.[0];
                                    if (selectedFile) {
                                      updateCodeFile(index, 'file', selectedFile);
                                    }
                                  }}
                                />
                                <Select 
                                  value={file.language} 
                                  onValueChange={(value) => updateCodeFile(index, 'language', value)}
                                >
                                  <SelectTrigger className="text-xs">
                                    <SelectValue />
                                  </SelectTrigger>
                                  <SelectContent>
                                    <SelectItem value="javascript">JavaScript</SelectItem>
                                    <SelectItem value="python">Python</SelectItem>
                                    <SelectItem value="java">Java</SelectItem>
                                    <SelectItem value="cpp">C++</SelectItem>
                                    <SelectItem value="html">HTML</SelectItem>
                                    <SelectItem value="css">CSS</SelectItem>
                                  </SelectContent>
                                </Select>
                                <Button variant="destructive" size="sm" onClick={() => removeCodeFile(index)}>
                                  <X className="h-4 w-4" />
                                </Button>
                              </div>
                            ))}
                          </div>
                        </div>
                        
                        <div className="flex justify-end space-x-2">
                          <Button
                            variant="outline"
                            onClick={() => {
                              setProjectFormData({});
                              setCodeFiles([]);
                            }}
                          >
                            Clear
                          </Button>
                          <Button
                            onClick={async () => {
                              try {
                                await handleAddProjectToClass();
                                showProjectSaveSuccess(selectedClass.classNumber, projectFormData.title, codeFiles.length);
                              } catch (error) {
                                toast({
                                  title: "❌ Save Failed",
                                  description: "Please try again or check file formats",
                                  variant: "destructive"
                                });
                              }
                            }}
                            disabled={!projectFormData.title || codeFiles.length === 0}
                            className="bg-purple-600 hover:bg-purple-700"
                          >
                            <Code className="h-4 w-4 mr-2" />
                            💾 Save Project Content
                          </Button>
                        </div>
                      </CardContent>
                    </Card>

                    {/* Projects List */}
                    <Card>
                      <CardHeader>
                        <CardTitle className="text-lg">Class Projects ({selectedClass.projects?.length || 0})</CardTitle>
                      </CardHeader>
                      <CardContent>
                        {selectedClass.projects && selectedClass.projects.length > 0 ? (
                          <div className="space-y-3">
                            {selectedClass.projects.map((project: any) => (
                              <div key={project.id} className="p-4 bg-muted/30 rounded-lg">
                                <div className="flex items-start justify-between">
                                  <div className="flex items-start space-x-3">
                                    <Code className="h-5 w-5 text-purple-600 mt-1" />
                                    <div>
                                      <h4 className="font-medium">{project.title}</h4>
                                      <p className="text-sm text-muted-foreground mb-2">{project.description}</p>
                                      <div className="flex items-center gap-4 text-xs text-muted-foreground mb-2">
                                        <Badge variant="outline">{project.difficulty}</Badge>
                                        <span>{project.codeFiles.length} files</span>
                                      </div>
                                      <div className="flex flex-wrap gap-1">
                                        {project.codeFiles.map((file: any, i: number) => (
                                          <Badge key={i} variant="secondary" className="text-xs">
                                            {file.fileName}
                                          </Badge>
                                        ))}
                                      </div>
                                    </div>
                                  </div>
                                  <Button variant="destructive" size="sm">
                                    <Trash2 className="h-4 w-4" />
                                  </Button>
                                </div>
                              </div>
                            ))}
                          </div>
                        ) : (
                          <div className="text-center py-8 text-muted-foreground">
                            <FolderOpen className="h-12 w-12 mx-auto mb-4 opacity-50" />
                            <p>No projects uploaded yet</p>
                          </div>
                        )}
                      </CardContent>
                    </Card>
                  </TabsContent>
                </Tabs>
              </>
            )}
          </TabsContent>
        </Tabs>

        {/* Content Verification - Shows if content will display on website */}
        <ContentVerification courseId={course.id} />

        {/* Debug Component - Shows current course data */}
        <CourseDataDebug courseId={course.id} />
      </DialogContent>
    </Dialog>
  );
};

export default AdminCourseManager;
