import React, { useEffect, useState } from 'react';
import { Button } from './ui/button';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from './ui/dialog';
import { Badge } from './ui/badge';
import { useToast } from '@/hooks/use-toast';
import { storageManager } from '../utils/storageManager';
import {
  AlertTriangle,
  HardDrive,
  Trash2,
  RefreshCw,
  CheckCircle,
  X
} from 'lucide-react';

const StorageErrorHandler: React.FC = () => {
  const [isOpen, setIsOpen] = useState(false);
  const [errorMessage, setErrorMessage] = useState('');
  const [errorType, setErrorType] = useState('');
  const [isCleaningUp, setIsCleaningUp] = useState(false);
  const { toast } = useToast();

  useEffect(() => {
    const handleStorageError = (event: CustomEvent) => {
      const { message, type } = event.detail;
      setErrorMessage(message);
      setErrorType(type);
      setIsOpen(true);
    };

    window.addEventListener('storageError', handleStorageError as EventListener);
    return () => {
      window.removeEventListener('storageError', handleStorageError as EventListener);
    };
  }, []);

  const handleCleanup = async () => {
    setIsCleaningUp(true);
    
    try {
      const result = storageManager.cleanup();
      
      if (result.success) {
        toast({
          title: "✅ Storage Cleaned Successfully",
          description: "Old files and large data have been removed",
          duration: 5000
        });
        
        // Try to reload the page after cleanup
        setTimeout(() => {
          window.location.reload();
        }, 2000);
      } else {
        toast({
          title: "❌ Cleanup Failed", 
          description: result.error || "Unable to free up storage space",
          variant: "destructive"
        });
      }
    } catch (error) {
      toast({
        title: "❌ Cleanup Error",
        description: "An error occurred during cleanup",
        variant: "destructive"
      });
    } finally {
      setIsCleaningUp(false);
    }
  };

  const getStorageStats = () => {
    const stats = storageManager.getStorageStats();
    return {
      used: storageManager.formatBytes(stats.used),
      available: storageManager.formatBytes(stats.available),
      percentUsed: stats.percentUsed.toFixed(1)
    };
  };

  const stats = getStorageStats();

  return (
    <Dialog open={isOpen} onOpenChange={setIsOpen}>
      <DialogContent className="max-w-md">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2 text-red-600">
            <AlertTriangle className="w-5 h-5" />
            Storage Quota Exceeded
          </DialogTitle>
        </DialogHeader>

        <div className="space-y-4">
          {/* Error Message */}
          <Card className="border-red-200 bg-red-50">
            <CardContent className="p-4">
              <div className="text-sm text-red-800">
                <strong>Error:</strong> {errorMessage}
              </div>
              {errorType && (
                <div className="text-xs text-red-600 mt-1">
                  Component: {errorType}
                </div>
              )}
            </CardContent>
          </Card>

          {/* Storage Stats */}
          <Card>
            <CardHeader className="pb-3">
              <CardTitle className="text-sm flex items-center gap-2">
                <HardDrive className="w-4 h-4" />
                Storage Usage
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-3">
              <div className="flex justify-between text-sm">
                <span>Used:</span>
                <Badge variant="destructive">{stats.used} ({stats.percentUsed}%)</Badge>
              </div>
              <div className="flex justify-between text-sm">
                <span>Available:</span>
                <span className="font-medium">{stats.available}</span>
              </div>
              
              {/* Progress Bar */}
              <div className="w-full bg-gray-200 rounded-full h-2">
                <div 
                  className={`h-2 rounded-full ${
                    parseFloat(stats.percentUsed) > 90 ? 'bg-red-500' : 
                    parseFloat(stats.percentUsed) > 70 ? 'bg-yellow-500' : 'bg-green-500'
                  }`}
                  style={{ width: `${Math.min(parseFloat(stats.percentUsed), 100)}%` }}
                ></div>
              </div>
            </CardContent>
          </Card>

          {/* Solutions */}
          <Card className="border-blue-200 bg-blue-50">
            <CardHeader className="pb-3">
              <CardTitle className="text-sm text-blue-800">💡 Solutions:</CardTitle>
            </CardHeader>
            <CardContent className="space-y-2 text-sm text-blue-700">
              <div className="flex items-center gap-2">
                <CheckCircle className="w-3 h-3" />
                <span>Large video files will be removed from browser storage</span>
              </div>
              <div className="flex items-center gap-2">
                <CheckCircle className="w-3 h-3" />
                <span>Old temporary data will be cleaned up</span>
              </div>
              <div className="flex items-center gap-2">
                <CheckCircle className="w-3 h-3" />
                <span>Course data structure will be optimized</span>
              </div>
            </CardContent>
          </Card>

          {/* Action Buttons */}
          <div className="flex gap-3 pt-2">
            <Button 
              variant="outline" 
              onClick={() => setIsOpen(false)}
              className="flex-1"
            >
              <X className="w-4 h-4 mr-2" />
              Close
            </Button>
            <Button 
              onClick={handleCleanup}
              disabled={isCleaningUp}
              className="flex-1 bg-blue-600 hover:bg-blue-700"
            >
              {isCleaningUp ? (
                <>
                  <RefreshCw className="w-4 h-4 mr-2 animate-spin" />
                  Cleaning...
                </>
              ) : (
                <>
                  <Trash2 className="w-4 h-4 mr-2" />
                  Clean Storage
                </>
              )}
            </Button>
          </div>

          {/* Additional Help */}
          <div className="text-xs text-gray-500 text-center pt-2 border-t">
            After cleanup, the page will automatically refresh to apply changes
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
};

export default StorageErrorHandler;
