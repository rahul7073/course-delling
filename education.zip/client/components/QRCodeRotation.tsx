import React, { useState, useEffect } from 'react';

// Your working UPI IDs
const UPI_PROVIDERS = [
  {
    id: 'googlepay',
    name: 'Google Pay',
    vpa: 'rahulydv9861@oksbi',
    color: '#4285f4'
  },
  {
    id: 'phonepe', 
    name: 'PhonePe',
    vpa: '7023009861@ybl',
    color: '#5f259f'
  },
  {
    id: 'paytm',
    name: 'Paytm', 
    vpa: '7023009861@ptaxis',
    color: '#00baf2'
  }
];

// Simple UPI URL creator
const createUPI = (vpa: string, amount: number) => {
  return `upi://pay?pa=${vpa}&am=${amount}&cu=INR`;
};

// Simple QR creator
const createQR = (upiURL: string) => {
  return `https://chart.googleapis.com/chart?chs=400x400&cht=qr&chl=${encodeURIComponent(upiURL)}`;
};

export const useQRRotation = (amount?: number) => {
  const [currentIndex, setCurrentIndex] = useState(0);

  useEffect(() => {
    const interval = setInterval(() => {
      setCurrentIndex(prev => (prev + 1) % UPI_PROVIDERS.length);
    }, 3600000); // Change every hour
    return () => clearInterval(interval);
  }, []);

  const provider = UPI_PROVIDERS[currentIndex];
  const finalAmount = amount || 100;
  const upiURL = createUPI(provider.vpa, finalAmount);
  const qrURL = createQR(upiURL);

  console.log(`💳 Active: ${provider.name} - ${upiURL}`);

  return {
    currentQR: {
      ...provider,
      url: qrURL,
      upiURL: upiURL,
      amount: finalAmount
    }
  };
};

interface QRDisplayProps {
  amount: number;
  paymentId: string;
  courseName?: string;
  className?: string;
}

const QRDisplay: React.FC<QRDisplayProps> = ({ amount, paymentId, courseName, className = '' }) => {
  const { currentQR } = useQRRotation(amount);

  return (
    <div className={`space-y-6 ${className}`}>
      {/* Header */}
      <div className="text-center">
        <h2 className="text-2xl font-bold text-gray-800 mb-2">Pay with UPI</h2>
        <div className="text-3xl font-bold text-green-600">₹{amount}</div>
        <div className="text-sm text-gray-600">{currentQR.name} - {currentQR.vpa}</div>
      </div>

      {/* QR Code */}
      <div className="flex justify-center">
        <div className="bg-white p-6 rounded-xl shadow-lg border">
          <img
            src={currentQR.url}
            alt={`Pay ₹${amount}`}
            className="w-80 h-80 mx-auto"
            onError={(e) => {
              // Backup QR
              const backup = `https://api.qrserver.com/v1/create-qr-code/?size=400x400&data=${encodeURIComponent(currentQR.upiURL)}`;
              if (e.currentTarget.src !== backup) {
                e.currentTarget.src = backup;
              }
            }}
          />
          <div className="text-center mt-3">
            <div className="text-lg font-bold" style={{ color: currentQR.color }}>
              {currentQR.name}
            </div>
            <div className="text-sm text-gray-500">Scan with any UPI app</div>
          </div>
        </div>
      </div>

      {/* Instructions */}
      <div className="bg-green-50 border border-green-200 rounded-lg p-4">
        <h3 className="font-bold text-green-800 mb-2">📱 How to Pay:</h3>
        <ol className="text-sm text-green-700 space-y-1">
          <li>1. Open PhonePe, Google Pay, Paytm, or any UPI app</li>
          <li>2. Scan this QR code with your camera</li>
          <li>3. Check amount is ₹{amount}</li>
          <li>4. Enter UPI PIN and pay</li>
        </ol>
      </div>

      {/* Manual UPI Link */}
      <div className="bg-blue-50 border border-blue-200 rounded-lg p-4">
        <div className="text-blue-800 font-bold mb-2">🔗 Or pay directly:</div>
        <button
          onClick={() => {
            window.open(currentQR.upiURL, '_blank');
            navigator.clipboard.writeText(currentQR.upiURL);
            alert('✅ UPI link opened! Also copied to clipboard');
          }}
          className="w-full bg-blue-600 text-white py-3 px-4 rounded-lg font-bold hover:bg-blue-700"
        >
          Open in UPI App
        </button>
        <div className="text-xs text-blue-600 mt-2 break-all">
          {currentQR.upiURL}
        </div>
      </div>

      {/* Payment ID */}
      <div className="text-center text-xs text-gray-500">
        Payment ID: {paymentId}
      </div>
    </div>
  );
};

export default QRDisplay;
