import React, { useState, useEffect, useRef } from 'react';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from './ui/dialog';
import { Badge } from './ui/badge';
import { Textarea } from './ui/textarea';
import { useToast } from '@/hooks/use-toast';
import { useData } from '../contexts/DataContext';
import { useAuth } from '../contexts/AuthContext';
import { useCart } from '../contexts/CartContext';
import QRDisplay, { useQRRotation } from './QRCodeRotation';
import {
  Smartphone,
  Clock,
  CheckCircle,
  AlertCircle,
  Copy,
  Upload,
  Timer,
  QrCode,
  Camera,
  FileText,
  RefreshCw,
  ShoppingCart,
  X
} from 'lucide-react';

interface CartQRPaymentProps {
  isOpen: boolean;
  onClose: () => void;
  onSuccess: () => void;
}

const CartQRPayment: React.FC<CartQRPaymentProps> = ({ isOpen, onClose, onSuccess }) => {
  const [step, setStep] = useState<'user-info' | 'qr-payment' | 'payment-proof' | 'verification' | 'timeout' | 'success'>('user-info');
  const [timeRemaining, setTimeRemaining] = useState(300); // 5 minutes
  const [isTimerActive, setIsTimerActive] = useState(false);
  const [paymentId, setPaymentId] = useState('');
  const { currentQR } = useQRRotation();
  
  // User info
  const [userInfo, setUserInfo] = useState({
    email: '',
    userId: '',
    phoneNumber: ''
  });

  // Payment proof
  const [paymentProof, setPaymentProof] = useState({
    utrNumber: '',
    screenshot: null as File | null,
    screenshotPreview: ''
  });

  const { addOrder, updateOrder } = useData();
  const { user } = useAuth();
  const { cartItems, cartTotal, clearCart } = useCart();
  const { toast } = useToast();
  const timerRef = useRef<NodeJS.Timeout | null>(null);

  // Timer effect
  useEffect(() => {
    if (isTimerActive && timeRemaining > 0) {
      timerRef.current = setTimeout(() => {
        setTimeRemaining(prev => prev - 1);
      }, 1000);
    } else if (timeRemaining === 0 && isTimerActive) {
      setStep('timeout');
      setIsTimerActive(false);
      if (paymentId) {
        updateOrder(paymentId, { paymentStatus: 'failed' });
      }
      toast({
        title: "Payment Timeout",
        description: "Payment session expired. Please try again.",
        variant: "destructive"
      });
    }
    
    return () => {
      if (timerRef.current) {
        clearTimeout(timerRef.current);
      }
    };
  }, [isTimerActive, timeRemaining, paymentId, updateOrder, toast]);

  // Reset state when modal opens/closes
  useEffect(() => {
    if (!isOpen) {
      setStep('user-info');
      setTimeRemaining(300);
      setIsTimerActive(false);
      setPaymentId('');
      setUserInfo({ email: '', userId: '', phoneNumber: '' });
      setPaymentProof({ utrNumber: '', screenshot: null, screenshotPreview: '' });
      if (timerRef.current) clearTimeout(timerRef.current);
    }
  }, [isOpen]);

  // Pre-fill user info if logged in
  useEffect(() => {
    if (user && isOpen) {
      setUserInfo({
        email: user.email || '',
        userId: user.id || '',
        phoneNumber: user.phone || ''
      });
    }
  }, [user, isOpen]);

  const generateQRPayment = () => {
    if (!userInfo.email || !userInfo.userId) {
      toast({
        title: "Required Information",
        description: "Please fill in your email and user ID",
        variant: "destructive"
      });
      return;
    }

    // Generate payment ID
    const newPaymentId = `CART_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
    setPaymentId(newPaymentId);

    // Create pending orders for all cart items
    cartItems.forEach((item) => {
      addOrder({
        userId: userInfo.userId,
        courseId: item.course.id,
        amount: item.course.price,
        paymentMethod: `UPI_${currentQR.name}`,
        paymentStatus: 'pending',
        orderDate: new Date().toISOString(),
        transactionId: newPaymentId,
        isUnlocked: false
      });
    });

    setStep('qr-payment');
    setTimeRemaining(300); // Reset to 5 minutes
    setIsTimerActive(true);

    toast({
      title: "QR Code Generated!",
      description: `Scan with ${currentQR.name} app to pay. Valid for 5 minutes.`,
    });
  };

  const handlePaymentProofSubmit = () => {
    if (!paymentProof.utrNumber || !paymentProof.screenshot) {
      toast({
        title: "Payment Proof Required",
        description: "Please provide UTR number and payment screenshot",
        variant: "destructive"
      });
      return;
    }

    // Update all orders with payment proof
    cartItems.forEach((item) => {
      updateOrder(paymentId, {
        utrNumber: paymentProof.utrNumber,
        paymentScreenshot: paymentProof.screenshotPreview,
        paymentDate: new Date().toISOString()
      });
    });

    setStep('verification');
    setIsTimerActive(false);

    toast({
      title: "Payment Proof Submitted!",
      description: "Admin will verify your payment and unlock all courses.",
    });
  };

  const handleScreenshotUpload = (file: File) => {
    if (file) {
      const reader = new FileReader();
      reader.onload = (e) => {
        setPaymentProof(prev => ({
          ...prev,
          screenshot: file,
          screenshotPreview: e.target?.result as string
        }));
      };
      reader.readAsDataURL(file);
    }
  };

  const formatTime = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins}:${secs.toString().padStart(2, '0')}`;
  };

  const copyUPIDetails = () => {
    const details = `Pay via: ${currentQR.name}\nAmount: ₹${cartTotal}\nPayment ID: ${paymentId}\nNote: Cart Purchase (${cartItems.length} courses)`;
    navigator.clipboard.writeText(details);
    toast({
      title: "Copied!",
      description: "Payment details copied to clipboard"
    });
  };



  const handlePaymentSuccess = () => {
    clearCart();
    onSuccess();
    onClose();
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-md">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <ShoppingCart className="w-5 h-5" />
            Cart Payment - {cartItems.length} Course{cartItems.length > 1 ? 's' : ''}
          </DialogTitle>
        </DialogHeader>

        <div className="space-y-6">
          {/* Cart Summary */}
          <Card>
            <CardContent className="p-4">
              <div className="space-y-3">
                <div className="flex items-center justify-between">
                  <div>
                    <h3 className="font-medium">{cartItems.length} Course{cartItems.length > 1 ? 's' : ''}</h3>
                    <p className="text-sm text-muted-foreground">Complete Access</p>
                  </div>
                  <div className="text-right">
                    <div className="text-2xl font-bold">₹{cartTotal.toLocaleString()}</div>
                  </div>
                </div>
                <div className="space-y-1">
                  {cartItems.map((item) => (
                    <div key={item.course.id} className="flex justify-between text-xs">
                      <span className="truncate">{item.course.title}</span>
                      <span>₹{item.course.price}</span>
                    </div>
                  ))}
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Timer (shown during active payment) */}
          {isTimerActive && (
            <Card className={`border-2 ${timeRemaining <= 60 ? 'border-red-500 bg-red-50' : timeRemaining <= 120 ? 'border-orange-500 bg-orange-50' : 'border-green-500 bg-green-50'}`}>
              <CardContent className="p-4">
                <div className="flex items-center justify-center gap-3">
                  <Timer className={`w-6 h-6 ${timeRemaining <= 60 ? 'text-red-600' : timeRemaining <= 120 ? 'text-orange-600' : 'text-green-600'}`} />
                  <div className="text-center">
                    <div className={`text-2xl font-mono font-bold ${timeRemaining <= 60 ? 'text-red-700' : timeRemaining <= 120 ? 'text-orange-700' : 'text-green-700'}`}>
                      {formatTime(timeRemaining)}
                    </div>
                    <p className="text-xs text-muted-foreground">Time remaining</p>
                  </div>
                </div>
              </CardContent>
            </Card>
          )}

          {/* Step 1: User Information */}
          {step === 'user-info' && (
            <div className="space-y-4">
              <div>
                <label className="block text-sm font-medium mb-2">Your Email</label>
                <Input
                  type="email"
                  value={userInfo.email}
                  onChange={(e) => setUserInfo(prev => ({ ...prev, email: e.target.value }))}
                  placeholder="your.email@gmail.com"
                />
              </div>

              <div>
                <label className="block text-sm font-medium mb-2">User ID (Website Login ID)</label>
                <Input
                  value={userInfo.userId}
                  onChange={(e) => setUserInfo(prev => ({ ...prev, userId: e.target.value }))}
                  placeholder="Your website user ID"
                />
              </div>

              <div>
                <label className="block text-sm font-medium mb-2">Phone Number (Optional)</label>
                <Input
                  type="tel"
                  value={userInfo.phoneNumber}
                  onChange={(e) => setUserInfo(prev => ({ ...prev, phoneNumber: e.target.value }))}
                  placeholder="+91 9876543210"
                />
              </div>

              <Button onClick={generateQRPayment} className="w-full" disabled={!userInfo.email || !userInfo.userId}>
                <QrCode className="w-4 h-4 mr-2" />
                Generate Payment QR Code
              </Button>
            </div>
          )}

          {/* Step 2: QR Code Payment */}
          {step === 'qr-payment' && (
            <div className="space-y-4">
              {/* Rotating QR Display */}
              <QRDisplay
                amount={cartTotal}
                paymentId={paymentId}
              />

              {/* Payment Instructions */}
              <Card className="bg-muted/30">
                <CardContent className="p-4">
                  <h4 className="font-medium mb-3 text-center">Cart Payment Instructions</h4>
                  <div className="space-y-2 text-sm">
                    <div className="flex items-center justify-between">
                      <span>Pay via:</span>
                      <div className="flex items-center gap-2">
                        <Badge variant="outline">{currentQR.name}</Badge>
                        <Button variant="ghost" size="sm" onClick={copyUPIDetails}>
                          <Copy className="w-3 h-3" />
                        </Button>
                      </div>
                    </div>
                    <div className="flex items-center justify-between">
                      <span>Total Amount:</span>
                      <span className="font-bold text-lg">₹{cartTotal.toLocaleString()}</span>
                    </div>
                    <div className="flex items-center justify-between">
                      <span>Courses:</span>
                      <span>{cartItems.length} course{cartItems.length > 1 ? 's' : ''}</span>
                    </div>
                    <div className="flex items-center justify-between">
                      <span>Payment ID:</span>
                      <code className="bg-background px-2 py-1 rounded text-xs font-mono">{paymentId}</code>
                    </div>
                  </div>
                  <div className="mt-3 p-2 bg-blue-50 rounded text-xs text-blue-700">
                    <strong>Note:</strong> QR codes rotate every hour between PhonePe, Google Pay, and Paytm for better availability.
                  </div>
                </CardContent>
              </Card>

              <Button onClick={() => setStep('payment-proof')} className="w-full">
                <CheckCircle className="w-4 h-4 mr-2" />
                I've Completed the Payment
              </Button>
            </div>
          )}

          {/* Step 3: Payment Proof Upload */}
          {step === 'payment-proof' && (
            <div className="space-y-4">
              <div className="text-center">
                <FileText className="w-16 h-16 mx-auto mb-4 text-blue-500" />
                <h3 className="font-medium mb-2">Upload Payment Proof</h3>
                <p className="text-sm text-muted-foreground">
                  Please provide your UTR number and payment screenshot for verification
                </p>
              </div>

              <div>
                <label className="block text-sm font-medium mb-1">UTR Number / Transaction ID</label>
                <Input
                  value={paymentProof.utrNumber}
                  onChange={(e) => setPaymentProof(prev => ({ ...prev, utrNumber: e.target.value }))}
                  placeholder="e.g., 123456789012"
                  className="font-mono"
                />
                <p className="text-xs text-muted-foreground mt-1">
                  Find this in your UPI app transaction history
                </p>
              </div>

              <div>
                <label className="block text-sm font-medium mb-1">Payment Screenshot</label>
                <div className="space-y-2">
                  <input
                    type="file"
                    accept="image/*"
                    onChange={(e) => {
                      const file = e.target.files?.[0];
                      if (file) handleScreenshotUpload(file);
                    }}
                    className="w-full p-2 border border-border rounded-md"
                  />
                  {paymentProof.screenshotPreview && (
                    <div className="border rounded-lg p-2">
                      <img 
                        src={paymentProof.screenshotPreview} 
                        alt="Payment screenshot"
                        className="w-full max-h-48 object-contain rounded"
                      />
                    </div>
                  )}
                </div>
              </div>

              <Button 
                onClick={handlePaymentProofSubmit} 
                className="w-full"
                disabled={!paymentProof.utrNumber || !paymentProof.screenshot}
              >
                <Upload className="w-4 h-4 mr-2" />
                Submit Payment Proof
              </Button>
            </div>
          )}

          {/* Step 4: Verification */}
          {step === 'verification' && (
            <div className="space-y-4 text-center">
              <AlertCircle className="w-16 h-16 mx-auto text-orange-500" />
              <div>
                <h3 className="font-medium mb-2">Payment Under Verification</h3>
                <p className="text-sm text-muted-foreground">
                  Your payment proof has been submitted. Admin will verify and unlock all courses.
                </p>
              </div>

              <Card className="bg-orange-50 border-orange-200">
                <CardContent className="p-4">
                  <div className="text-sm space-y-2">
                    <div className="flex justify-between">
                      <span>Payment ID:</span>
                      <code className="text-xs font-mono">{paymentId}</code>
                    </div>
                    <div className="flex justify-between">
                      <span>UTR Number:</span>
                      <code className="text-xs font-mono">{paymentProof.utrNumber}</code>
                    </div>
                    <div className="flex justify-between">
                      <span>Courses:</span>
                      <span>{cartItems.length}</span>
                    </div>
                    <div className="flex justify-between">
                      <span>Status:</span>
                      <Badge variant="secondary" className="bg-orange-100 text-orange-700">
                        Pending Verification
                      </Badge>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Button onClick={onClose} className="w-full">
                <CheckCircle className="w-4 h-4 mr-2" />
                Okay, I'll Wait for Approval
              </Button>
            </div>
          )}

          {/* Step 5: Timeout */}
          {step === 'timeout' && (
            <div className="space-y-4 text-center">
              <AlertCircle className="w-16 h-16 mx-auto text-red-500" />
              <div>
                <h3 className="font-medium mb-2 text-red-700">Payment Session Expired</h3>
                <p className="text-sm text-muted-foreground">
                  The 5-minute payment window has closed. Please start a new payment.
                </p>
              </div>
              
              <Button onClick={() => setStep('user-info')} className="w-full">
                <RefreshCw className="w-4 h-4 mr-2" />
                Start New Payment
              </Button>
            </div>
          )}
        </div>
      </DialogContent>
    </Dialog>
  );
};

export default CartQRPayment;
