import React from 'react';
import { Button } from './ui/button';
import { useData } from '../contexts/DataContext';
import { useToast } from '@/hooks/use-toast';
import { Plus, Video, FileText, Code } from 'lucide-react';

interface ContentTestButtonProps {
  courseId: string;
  courseName: string;
}

const ContentTestButton: React.FC<ContentTestButtonProps> = ({ courseId, courseName }) => {
  const { 
    addCourseVideo, 
    addCourseNote, 
    addCourseProject, 
    addCourseClass,
    courses 
  } = useData();
  const { toast } = useToast();

  const course = courses.find(c => c.id === courseId);

  const addTestClass = () => {
    const classNumber = (course?.classes?.length || 0) + 1;
    
    addCourseClass(courseId, {
      classNumber: classNumber,
      title: `Class ${classNumber}`,
      description: `Test class ${classNumber} description`,
      isDemo: false,
      videos: [],
      notes: [],
      projects: []
    });

    toast({
      title: "✅ Test Class Added",
      description: `Class ${classNumber} added to ${courseName}`,
    });
  };

  const addTestVideo = () => {
    const classNumber = course?.classes?.[0]?.classNumber || 1;
    
    addCourseVideo(courseId, {
      title: `Test Video ${Date.now()}`,
      description: 'Test video description',
      videoUrl: 'https://example.com/video.mp4',
      duration: '10:30',
      thumbnailUrl: 'https://example.com/thumb.jpg',
      uploadDate: new Date().toISOString(),
      order: 1,
      isPreview: false,
      classNumber: classNumber
    });

    toast({
      title: "✅ Test Video Added",
      description: `Video added to ${courseName}`,
    });
  };

  const addTestNote = () => {
    const classNumber = course?.classes?.[0]?.classNumber || 1;
    
    addCourseNote(courseId, {
      title: `Test Note ${Date.now()}`,
      description: 'Test note description',
      fileUrl: 'https://example.com/note.pdf',
      fileSize: '1.2 MB',
      uploadDate: new Date().toISOString(),
      classNumber: classNumber
    });

    toast({
      title: "✅ Test Note Added",
      description: `Note added to ${courseName}`,
    });
  };

  const addTestProject = () => {
    const classNumber = course?.classes?.[0]?.classNumber || 1;
    
    addCourseProject(courseId, {
      title: `Test Project ${Date.now()}`,
      description: 'Test project description',
      codeFiles: [
        {
          fileName: 'index.html',
          fileUrl: 'https://example.com/index.html',
          language: 'html'
        }
      ],
      liveUrl: 'https://example.com/demo',
      uploadDate: new Date().toISOString(),
      classNumber: classNumber
    });

    toast({
      title: "✅ Test Project Added",
      description: `Project added to ${courseName}`,
    });
  };

  const hasClasses = course?.classes && course.classes.length > 0;

  return (
    <div className="flex gap-2">
      <Button
        variant="outline"
        size="sm"
        onClick={addTestClass}
        className="text-xs"
      >
        <Plus className="w-3 h-3 mr-1" />
        Add Test Class
      </Button>
      
      {hasClasses && (
        <>
          <Button
            variant="outline"
            size="sm"
            onClick={addTestVideo}
            className="text-xs"
          >
            <Video className="w-3 h-3 mr-1" />
            Add Test Video
          </Button>
          
          <Button
            variant="outline"
            size="sm"
            onClick={addTestNote}
            className="text-xs"
          >
            <FileText className="w-3 h-3 mr-1" />
            Add Test Note
          </Button>
          
          <Button
            variant="outline"
            size="sm"
            onClick={addTestProject}
            className="text-xs"
          >
            <Code className="w-3 h-3 mr-1" />
            Add Test Project
          </Button>
        </>
      )}
    </div>
  );
};

export default ContentTestButton;
