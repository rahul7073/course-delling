import React from 'react';
import { Link } from 'react-router-dom';
import { Button } from './ui/button';
import { Alert, AlertDescription, AlertTitle } from './ui/alert';
import { Database, ArrowRight } from 'lucide-react';

interface MigrationBannerProps {
  show: boolean;
  courseName?: string;
}

const MigrationBanner: React.FC<MigrationBannerProps> = ({ show, courseName }) => {
  if (!show) return null;

  return (
    <Alert className="border-yellow-200 bg-yellow-50 mb-6">
      <Database className="h-4 w-4 text-yellow-600" />
      <AlertTitle className="text-yellow-800">
        Course loaded from local storage
      </AlertTitle>
      <AlertDescription className="text-yellow-700">
        <div className="mt-2">
          <p className="mb-3">
            {courseName ? `"${courseName}"` : 'This course'} hasn't been migrated to the database yet. 
            For better performance and data security, please migrate your courses to the database.
          </p>
          <Button asChild size="sm" variant="outline" className="border-yellow-300 text-yellow-800 hover:bg-yellow-100">
            <Link to="/admin/database" className="inline-flex items-center">
              Migrate Data
              <ArrowRight className="ml-1 h-3 w-3" />
            </Link>
          </Button>
        </div>
      </AlertDescription>
    </Alert>
  );
};

export default MigrationBanner;
