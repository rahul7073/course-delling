import React, { useState } from 'react';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Textarea } from './ui/textarea';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from './ui/dialog';
import { useToast } from '@/hooks/use-toast';
import { useData } from '../contexts/DataContext';
import {
  Video,
  FileText,
  Code,
  CheckCircle,
  Plus,
  X,
  Upload
} from 'lucide-react';

interface GuidedCourseSetupProps {
  course: any;
  isOpen: boolean;
  onClose: () => void;
}

const GuidedCourseSetup: React.FC<GuidedCourseSetupProps> = ({ course, isOpen, onClose }) => {
  const [currentStep, setCurrentStep] = useState<'video' | 'notes' | 'code' | 'complete'>('video');
  const [currentClass, setCurrentClass] = useState(1);
  const { addCourseClass, updateCourseClass } = useData();
  const { toast } = useToast();

  const [videoData, setVideoData] = useState({
    title: '',
    description: '',
    duration: '',
    file: null as File | null
  });

  const [notesData, setNotesData] = useState({
    title: '',
    description: '',
    file: null as File | null
  });

  const [projectData, setProjectData] = useState({
    title: '',
    description: '',
    difficulty: 'easy' as 'easy' | 'medium' | 'hard',
    codeFiles: [] as Array<{ fileName: string; file: File | null; language: string }>
  });

  const resetData = () => {
    setVideoData({ title: '', description: '', duration: '', file: null });
    setNotesData({ title: '', description: '', file: null });
    setProjectData({ title: '', description: '', difficulty: 'easy', codeFiles: [] });
  };

  const handleVideoUpload = async () => {
    if (!videoData.title || !videoData.file) {
      toast({
        title: "Missing Information",
        description: "Please provide video title and file",
        variant: "destructive"
      });
      return;
    }

    try {
      // Create class if doesn't exist
      const existingClass = course.classes?.find((c: any) => c.classNumber === currentClass);
      
      if (!existingClass) {
        addCourseClass(course.id, {
          classNumber: currentClass,
          title: `Class ${currentClass}`,
          description: `Class ${currentClass} content`,
          isDemo: currentClass === 1,
          videos: [],
          notes: [],
          projects: []
        });
      }

      // Simulate file upload
      const fileUrl = `video_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
      
      // Store file info
      const fileInfo = {
        name: videoData.file.name,
        size: videoData.file.size,
        type: videoData.file.type,
        dataUrl: await fileToDataURL(videoData.file),
        uploadDate: new Date().toISOString()
      };
      
      localStorage.setItem(fileUrl, JSON.stringify(fileInfo));

      // Add video to class
      const updatedCourse = course.classes?.find((c: any) => c.classNumber === currentClass);
      const newVideo = {
        id: Date.now().toString(),
        title: videoData.title,
        description: videoData.description,
        videoUrl: fileUrl,
        duration: videoData.duration,
        uploadDate: new Date().toISOString().split('T')[0],
        order: 1,
        isPreview: currentClass === 1,
        classNumber: currentClass
      };

      // Update class with new video
      if (updatedCourse) {
        updateCourseClass(course.id, updatedCourse.id, {
          ...updatedCourse,
          videos: [...(updatedCourse.videos || []), newVideo]
        });
      }

      toast({
        title: "Video uploaded!",
        description: "Now let's add notes for this class.",
      });
      
      setCurrentStep('notes');
    } catch (error) {
      toast({
        title: "Upload failed",
        description: "Please try again",
        variant: "destructive"
      });
    }
  };

  const handleNotesUpload = async () => {
    if (!notesData.title || !notesData.file) {
      toast({
        title: "Missing Information", 
        description: "Please provide notes title and file",
        variant: "destructive"
      });
      return;
    }

    try {
      const fileUrl = `notes_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
      
      const fileInfo = {
        name: notesData.file.name,
        size: notesData.file.size,
        type: notesData.file.type,
        dataUrl: await fileToDataURL(notesData.file),
        uploadDate: new Date().toISOString()
      };
      
      localStorage.setItem(fileUrl, JSON.stringify(fileInfo));

      const classToUpdate = course.classes?.find((c: any) => c.classNumber === currentClass);
      const newNote = {
        id: Date.now().toString(),
        title: notesData.title,
        description: notesData.description,
        fileUrl: fileUrl,
        fileSize: `${(notesData.file.size / 1024 / 1024).toFixed(1)} MB`,
        uploadDate: new Date().toISOString().split('T')[0],
        classNumber: currentClass
      };

      if (classToUpdate) {
        updateCourseClass(course.id, classToUpdate.id, {
          ...classToUpdate,
          notes: [...(classToUpdate.notes || []), newNote]
        });
      }

      toast({
        title: "Notes uploaded!",
        description: "Now let's add code projects.",
      });
      
      setCurrentStep('code');
    } catch (error) {
      toast({
        title: "Upload failed",
        description: "Please try again",
        variant: "destructive"
      });
    }
  };

  const handleCodeUpload = async () => {
    if (!projectData.title || projectData.codeFiles.length === 0) {
      toast({
        title: "Missing Information",
        description: "Please provide project title and code files",
        variant: "destructive"
      });
      return;
    }

    try {
      const uploadedFiles = await Promise.all(
        projectData.codeFiles.map(async (file) => {
          if (!file.file) return null;
          
          const fileUrl = `code_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
          const fileInfo = {
            name: file.file.name,
            size: file.file.size,
            type: file.file.type,
            dataUrl: await fileToDataURL(file.file),
            uploadDate: new Date().toISOString()
          };
          
          localStorage.setItem(fileUrl, JSON.stringify(fileInfo));
          
          return {
            fileName: file.fileName,
            fileUrl: fileUrl,
            language: file.language
          };
        })
      );

      const classToUpdate = course.classes?.find((c: any) => c.classNumber === currentClass);
      const newProject = {
        id: Date.now().toString(),
        title: projectData.title,
        description: projectData.description,
        codeFiles: uploadedFiles.filter(f => f !== null),
        uploadDate: new Date().toISOString().split('T')[0],
        difficulty: projectData.difficulty,
        classNumber: currentClass
      };

      if (classToUpdate) {
        updateCourseClass(course.id, classToUpdate.id, {
          ...classToUpdate,
          projects: [...(classToUpdate.projects || []), newProject]
        });
      }

      toast({
        title: "Code project uploaded!",
        description: "Class setup complete!",
      });
      
      setCurrentStep('complete');
    } catch (error) {
      toast({
        title: "Upload failed",
        description: "Please try again",
        variant: "destructive"
      });
    }
  };

  const fileToDataURL = (file: File): Promise<string> => {
    return new Promise((resolve, reject) => {
      const reader = new FileReader();
      reader.onload = () => resolve(reader.result as string);
      reader.onerror = reject;
      reader.readAsDataURL(file);
    });
  };

  const addCodeFile = () => {
    setProjectData(prev => ({
      ...prev,
      codeFiles: [...prev.codeFiles, { fileName: '', file: null, language: 'javascript' }]
    }));
  };

  const updateCodeFile = (index: number, field: string, value: any) => {
    setProjectData(prev => ({
      ...prev,
      codeFiles: prev.codeFiles.map((file, i) => 
        i === index ? { ...file, [field]: value } : file
      )
    }));
  };

  const removeCodeFile = (index: number) => {
    setProjectData(prev => ({
      ...prev,
      codeFiles: prev.codeFiles.filter((_, i) => i !== index)
    }));
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-4xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle>
            Setup Course Content - {course?.title} | Class {currentClass}
          </DialogTitle>
          
          {/* Progress Steps */}
          <div className="flex items-center gap-4 mt-4">
            <div className="flex items-center gap-2">
              <div className={`w-8 h-8 rounded-full flex items-center justify-center text-sm font-medium ${
                currentStep === 'video' ? 'bg-blue-500 text-white' : 
                currentStep === 'notes' || currentStep === 'code' || currentStep === 'complete' ? 'bg-green-500 text-white' : 
                'bg-gray-300 text-gray-600'
              }`}>
                1
              </div>
              <span className="text-sm">Video</span>
            </div>
            <div className="flex items-center gap-2">
              <div className={`w-8 h-8 rounded-full flex items-center justify-center text-sm font-medium ${
                currentStep === 'notes' ? 'bg-blue-500 text-white' : 
                currentStep === 'code' || currentStep === 'complete' ? 'bg-green-500 text-white' : 
                'bg-gray-300 text-gray-600'
              }`}>
                2
              </div>
              <span className="text-sm">Notes</span>
            </div>
            <div className="flex items-center gap-2">
              <div className={`w-8 h-8 rounded-full flex items-center justify-center text-sm font-medium ${
                currentStep === 'code' ? 'bg-blue-500 text-white' : 
                currentStep === 'complete' ? 'bg-green-500 text-white' : 
                'bg-gray-300 text-gray-600'
              }`}>
                3
              </div>
              <span className="text-sm">Code</span>
            </div>
            <div className="flex items-center gap-2">
              <div className={`w-8 h-8 rounded-full flex items-center justify-center text-sm font-medium ${
                currentStep === 'complete' ? 'bg-green-500 text-white' : 'bg-gray-300 text-gray-600'
              }`}>
                ✓
              </div>
              <span className="text-sm">Complete</span>
            </div>
          </div>
        </DialogHeader>

        <div className="space-y-6">
          {/* Video Upload Step */}
          {currentStep === 'video' && (
            <Card className="border-2 border-blue-500">
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Video className="w-5 h-5" />
                  Upload Class {currentClass} Video
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <label className="block text-sm font-medium mb-1">Video Title</label>
                    <Input
                      value={videoData.title}
                      onChange={(e) => setVideoData(prev => ({ ...prev, title: e.target.value }))}
                      placeholder={`Class ${currentClass} - Introduction`}
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium mb-1">Duration</label>
                    <Input
                      value={videoData.duration}
                      onChange={(e) => setVideoData(prev => ({ ...prev, duration: e.target.value }))}
                      placeholder="e.g., 15:30"
                    />
                  </div>
                </div>
                
                <div>
                  <label className="block text-sm font-medium mb-1">Description</label>
                  <Textarea
                    value={videoData.description}
                    onChange={(e) => setVideoData(prev => ({ ...prev, description: e.target.value }))}
                    placeholder={`What will students learn in Class ${currentClass}?`}
                    rows={3}
                  />
                </div>
                
                <div>
                  <label className="block text-sm font-medium mb-1">Upload Video File</label>
                  <input
                    type="file"
                    accept="video/*"
                    onChange={(e) => {
                      const file = e.target.files?.[0];
                      if (file) {
                        setVideoData(prev => ({ ...prev, file }));
                      }
                    }}
                    className="w-full p-2 border border-gray-300 rounded-md"
                  />
                  {videoData.file && (
                    <p className="text-sm text-green-600 mt-1">✓ {videoData.file.name} selected</p>
                  )}
                </div>
                
                <div className="flex justify-end space-x-2">
                  <Button variant="outline" onClick={onClose}>
                    Cancel
                  </Button>
                  <Button 
                    onClick={handleVideoUpload}
                    disabled={!videoData.title || !videoData.file}
                  >
                    Save & Continue to Notes
                  </Button>
                </div>
              </CardContent>
            </Card>
          )}

          {/* Notes Upload Step */}
          {currentStep === 'notes' && (
            <Card className="border-2 border-green-500">
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <FileText className="w-5 h-5" />
                  Upload Class {currentClass} Notes
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div>
                  <label className="block text-sm font-medium mb-1">Notes Title</label>
                  <Input
                    value={notesData.title}
                    onChange={(e) => setNotesData(prev => ({ ...prev, title: e.target.value }))}
                    placeholder={`Class ${currentClass} Study Material`}
                  />
                </div>
                
                <div>
                  <label className="block text-sm font-medium mb-1">Description</label>
                  <Textarea
                    value={notesData.description}
                    onChange={(e) => setNotesData(prev => ({ ...prev, description: e.target.value }))}
                    placeholder={`Study notes for Class ${currentClass}`}
                    rows={3}
                  />
                </div>
                
                <div>
                  <label className="block text-sm font-medium mb-1">Upload Notes File</label>
                  <input
                    type="file"
                    accept=".pdf,.doc,.docx,.txt,.md"
                    onChange={(e) => {
                      const file = e.target.files?.[0];
                      if (file) {
                        setNotesData(prev => ({ ...prev, file }));
                      }
                    }}
                    className="w-full p-2 border border-gray-300 rounded-md"
                  />
                  {notesData.file && (
                    <p className="text-sm text-green-600 mt-1">✓ {notesData.file.name} selected</p>
                  )}
                </div>
                
                <div className="flex justify-end space-x-2">
                  <Button variant="outline" onClick={() => setCurrentStep('video')}>
                    ← Back
                  </Button>
                  <Button variant="outline" onClick={() => setCurrentStep('code')}>
                    Skip Notes
                  </Button>
                  <Button 
                    onClick={handleNotesUpload}
                    disabled={!notesData.title || !notesData.file}
                  >
                    Save & Continue to Code
                  </Button>
                </div>
              </CardContent>
            </Card>
          )}

          {/* Code Upload Step */}
          {currentStep === 'code' && (
            <Card className="border-2 border-purple-500">
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Code className="w-5 h-5" />
                  Upload Class {currentClass} Code Projects
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <label className="block text-sm font-medium mb-1">Project Title</label>
                    <Input
                      value={projectData.title}
                      onChange={(e) => setProjectData(prev => ({ ...prev, title: e.target.value }))}
                      placeholder={`Class ${currentClass} Project`}
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium mb-1">Difficulty</label>
                    <select
                      value={projectData.difficulty}
                      onChange={(e) => setProjectData(prev => ({ ...prev, difficulty: e.target.value as 'easy' | 'medium' | 'hard' }))}
                      className="w-full px-3 py-2 border border-gray-300 rounded-md text-sm"
                    >
                      <option value="easy">Easy</option>
                      <option value="medium">Medium</option>
                      <option value="hard">Hard</option>
                    </select>
                  </div>
                </div>
                
                <div>
                  <label className="block text-sm font-medium mb-1">Description</label>
                  <Textarea
                    value={projectData.description}
                    onChange={(e) => setProjectData(prev => ({ ...prev, description: e.target.value }))}
                    placeholder={`Project description for Class ${currentClass}`}
                    rows={3}
                  />
                </div>
                
                <div>
                  <label className="block text-sm font-medium mb-1">Code Files</label>
                  {projectData.codeFiles.map((file, index) => (
                    <div key={index} className="grid grid-cols-4 gap-2 mb-2">
                      <Input
                        placeholder="File name"
                        value={file.fileName}
                        onChange={(e) => updateCodeFile(index, 'fileName', e.target.value)}
                      />
                      <select
                        value={file.language}
                        onChange={(e) => updateCodeFile(index, 'language', e.target.value)}
                        className="px-3 py-2 border border-gray-300 rounded-md text-sm"
                      >
                        <option value="javascript">JavaScript</option>
                        <option value="html">HTML</option>
                        <option value="css">CSS</option>
                        <option value="python">Python</option>
                      </select>
                      <input
                        type="file"
                        onChange={(e) => {
                          const selectedFile = e.target.files?.[0];
                          if (selectedFile) {
                            updateCodeFile(index, 'file', selectedFile);
                          }
                        }}
                        className="text-sm"
                      />
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={() => removeCodeFile(index)}
                      >
                        <X className="w-4 h-4" />
                      </Button>
                    </div>
                  ))}
                  <Button variant="outline" onClick={addCodeFile} className="w-full">
                    <Plus className="w-4 h-4 mr-2" />
                    Add Code File
                  </Button>
                </div>
                
                <div className="flex justify-end space-x-2">
                  <Button variant="outline" onClick={() => setCurrentStep('notes')}>
                    ← Back
                  </Button>
                  <Button variant="outline" onClick={() => setCurrentStep('complete')}>
                    Skip Code
                  </Button>
                  <Button 
                    onClick={handleCodeUpload}
                    disabled={!projectData.title || projectData.codeFiles.length === 0}
                  >
                    Save & Complete Class
                  </Button>
                </div>
              </CardContent>
            </Card>
          )}

          {/* Complete Step */}
          {currentStep === 'complete' && (
            <Card className="border-2 border-green-500 bg-green-50">
              <CardContent className="p-6 text-center">
                <CheckCircle className="w-16 h-16 text-green-500 mx-auto mb-4" />
                <h3 className="text-xl font-semibold mb-2">Class {currentClass} Complete!</h3>
                <p className="text-muted-foreground mb-6">
                  Successfully uploaded content for Class {currentClass}. What's next?
                </p>
                
                <div className="flex justify-center space-x-4">
                  <Button onClick={() => {
                    setCurrentClass(prev => prev + 1);
                    setCurrentStep('video');
                    resetData();
                    toast({
                      title: "Starting next class",
                      description: `Now setting up Class ${currentClass + 1}`,
                    });
                  }}>
                    + Add Class {currentClass + 1}
                  </Button>
                  <Button variant="outline" onClick={onClose}>
                    Finish Setup
                  </Button>
                </div>
              </CardContent>
            </Card>
          )}
        </div>
      </DialogContent>
    </Dialog>
  );
};

export default GuidedCourseSetup;
