import React from 'react';
import { Button } from './ui/button';
import { useToast } from '@/hooks/use-toast';
import { Globe, ExternalLink, Eye } from 'lucide-react';

interface WebsitePreviewButtonProps {
  courseId: string;
  courseName: string;
}

const WebsitePreviewButton: React.FC<WebsitePreviewButtonProps> = ({ courseId, courseName }) => {
  const { toast } = useToast();

  const handlePreviewOnWebsite = () => {
    // Open course detail page in new tab
    const url = `/course/${courseId}`;
    window.open(url, '_blank');
    
    toast({
      title: "🌐 Opening Website Preview",
      description: `Preview how "${courseName}" appears to students on the website`,
    });
  };

  return (
    <Button
      onClick={handlePreviewOnWebsite}
      variant="outline"
      size="sm"
      className="bg-blue-50 border-blue-200 text-blue-700 hover:bg-blue-100"
    >
      <Globe className="w-4 h-4 mr-2" />
      👁️ Preview on Website
      <ExternalLink className="w-3 h-3 ml-1" />
    </Button>
  );
};

export default WebsitePreviewButton;
