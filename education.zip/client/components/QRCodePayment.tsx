import React, { useState, useEffect, useRef } from 'react';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from './ui/dialog';
import { Badge } from './ui/badge';
import { Textarea } from './ui/textarea';
import { useToast } from '@/hooks/use-toast';
import { useData } from '../contexts/DataContext';
import { useAuth } from '../contexts/AuthContext';
import QRDisplay, { useQRRotation } from './QRCodeRotation';
import AutoPaymentVerification from './AutoPaymentVerification';
import {
  Smartphone,
  Clock,
  CheckCircle,
  AlertCircle,
  Copy,
  Upload,
  Timer,
  QrCode,
  Camera,
  FileText,
  RefreshCw
} from 'lucide-react';

interface QRCodePaymentProps {
  course: any;
  isOpen: boolean;
  onClose: () => void;
  onSuccess: () => void;
}

const QRCodePayment: React.FC<QRCodePaymentProps> = ({ course, isOpen, onClose, onSuccess }) => {
  const [step, setStep] = useState<'user-info' | 'qr-payment' | 'auto-verification' | 'payment-proof' | 'verification' | 'timeout' | 'success'>('user-info');
  const [timeRemaining, setTimeRemaining] = useState(300); // 5 minutes
  const [isTimerActive, setIsTimerActive] = useState(false);
  const [paymentId, setPaymentId] = useState('');
  const [showAutoVerification, setShowAutoVerification] = useState(false);
  const { currentQR } = useQRRotation();

  // Debug logging
  useEffect(() => {
    if (isOpen) {
      console.log('💳 Payment Modal Opened:', { course, isOpen, step });
    }
  }, [isOpen, course, step]);
  
  // User info
  const [userInfo, setUserInfo] = useState({
    email: '',
    userId: '',
    phoneNumber: ''
  });

  // Payment proof
  const [paymentProof, setPaymentProof] = useState({
    utrNumber: '',
    screenshot: null as File | null,
    screenshotPreview: ''
  });

  const { addOrder, updateOrder } = useData();
  const { user } = useAuth();
  const { toast } = useToast();
  const timerRef = useRef<NodeJS.Timeout | null>(null);

  // Timer effect
  useEffect(() => {
    if (isTimerActive && timeRemaining > 0) {
      timerRef.current = setTimeout(() => {
        setTimeRemaining(prev => prev - 1);
      }, 1000);
    } else if (timeRemaining === 0 && isTimerActive) {
      setStep('timeout');
      setIsTimerActive(false);
      if (paymentId) {
        updateOrder(paymentId, { paymentStatus: 'failed' });
      }
      toast({
        title: "Payment Timeout",
        description: "Payment session expired. Please try again.",
        variant: "destructive"
      });
    }
    
    return () => {
      if (timerRef.current) {
        clearTimeout(timerRef.current);
      }
    };
  }, [isTimerActive, timeRemaining, paymentId, updateOrder, toast]);

  // Reset state when modal opens/closes
  useEffect(() => {
    if (!isOpen) {
      setStep('user-info');
      setTimeRemaining(300);
      setIsTimerActive(false);
      setPaymentId('');
      setShowAutoVerification(false);
      setUserInfo({ email: '', userId: '', phoneNumber: '' });
      setPaymentProof({ utrNumber: '', screenshot: null, screenshotPreview: '' });
      if (timerRef.current) clearTimeout(timerRef.current);
    }
  }, [isOpen]);

  // Pre-fill user info if logged in
  useEffect(() => {
    if (user && isOpen) {
      setUserInfo({
        email: user.email || '',
        userId: user.id || '',
        phoneNumber: user.phone || ''
      });
    }
  }, [user, isOpen]);

  const generateQRPayment = () => {
    if (!userInfo.email || !userInfo.userId) {
      toast({
        title: "Required Information",
        description: "Please fill in your email and user ID",
        variant: "destructive"
      });
      return;
    }

    // Generate payment ID
    const newPaymentId = `PAY_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
    setPaymentId(newPaymentId);

    // Create pending order
    addOrder({
      userId: userInfo.userId,
      courseId: course.id,
      amount: course.price,
      paymentMethod: `UPI_${currentQR.name}`,
      paymentStatus: 'pending',
      orderDate: new Date().toISOString(),
      transactionId: newPaymentId,
      isUnlocked: false
    });

    setStep('qr-payment');
    setTimeRemaining(300); // Reset to 5 minutes
    setIsTimerActive(true);

    toast({
      title: "QR Code Generated!",
      description: `Scan to pay. We'll verify automatically!`,
    });

    // Start auto-verification after a short delay
    setTimeout(() => {
      setShowAutoVerification(true);
    }, 3000);
  };

  const handlePaymentProofSubmit = () => {
    if (!paymentProof.utrNumber || !paymentProof.screenshot) {
      toast({
        title: "Payment Proof Required",
        description: "Please provide UTR number and payment screenshot",
        variant: "destructive"
      });
      return;
    }

    // Update order with payment proof
    updateOrder(paymentId, {
      utrNumber: paymentProof.utrNumber,
      paymentScreenshot: paymentProof.screenshotPreview,
      paymentDate: new Date().toISOString()
    });

    setStep('verification');
    setIsTimerActive(false);

    toast({
      title: "Payment Proof Submitted!",
      description: "Admin will verify your payment and unlock the course.",
    });
  };

  const handleAutoVerificationSuccess = () => {
    setStep('success');
    setIsTimerActive(false);
    setShowAutoVerification(false);

    // Auto-close after success
    setTimeout(() => {
      onSuccess();
      onClose();
    }, 3000);
  };

  const handleAutoVerificationFailed = () => {
    setShowAutoVerification(false);
    // Fall back to manual proof submission
    setStep('payment-proof');

    toast({
      title: "⚠️ Auto-verification failed",
      description: "Please provide payment proof manually",
      variant: "default"
    });
  };

  const handleScreenshotUpload = (file: File) => {
    if (file) {
      const reader = new FileReader();
      reader.onload = (e) => {
        setPaymentProof(prev => ({
          ...prev,
          screenshot: file,
          screenshotPreview: e.target?.result as string
        }));
      };
      reader.readAsDataURL(file);
    }
  };

  const formatTime = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins}:${secs.toString().padStart(2, '0')}`;
  };

  const copyUPIDetails = () => {
    const details = `Pay via: ${currentQR.name}\nAmount: ₹${course.price}\nPayment ID: ${paymentId}\nNote: Course ${course.title}`;
    navigator.clipboard.writeText(details);
    toast({
      title: "Copied!",
      description: "Payment details copied to clipboard"
    });
  };



  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-lg max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2 text-lg">
            <QrCode className="w-6 h-6 text-blue-600" />
            Pay ₹{course?.price.toLocaleString()} - {course?.title}
          </DialogTitle>
        </DialogHeader>

        <div className="space-y-6">
          {/* Course Info */}
          <Card className="border-2 border-blue-200 bg-blue-50">
            <CardContent className="p-4">
              <div className="flex items-center justify-between">
                <div>
                  <h3 className="font-semibold text-blue-900">{course.title}</h3>
                  <p className="text-sm text-blue-700">Complete Course Access</p>
                  <div className="flex items-center gap-1 mt-1 text-xs text-blue-600">
                    <CheckCircle className="w-3 h-3" />
                    <span>Instant Access After Payment</span>
                  </div>
                </div>
                <div className="text-right">
                  <div className="text-3xl font-bold text-blue-900">₹{course.price.toLocaleString()}</div>
                  <div className="text-xs text-blue-600">One-time payment</div>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Timer (shown during active payment) */}
          {isTimerActive && (
            <Card className={`border-2 ${timeRemaining <= 60 ? 'border-red-500 bg-red-50' : timeRemaining <= 120 ? 'border-orange-500 bg-orange-50' : 'border-green-500 bg-green-50'}`}>
              <CardContent className="p-4">
                <div className="flex items-center justify-center gap-3">
                  <Timer className={`w-6 h-6 ${timeRemaining <= 60 ? 'text-red-600' : timeRemaining <= 120 ? 'text-orange-600' : 'text-green-600'}`} />
                  <div className="text-center">
                    <div className={`text-2xl font-mono font-bold ${timeRemaining <= 60 ? 'text-red-700' : timeRemaining <= 120 ? 'text-orange-700' : 'text-green-700'}`}>
                      {formatTime(timeRemaining)}
                    </div>
                    <p className="text-xs text-muted-foreground">Time remaining</p>
                  </div>
                </div>
              </CardContent>
            </Card>
          )}

          {/* Step 1: User Information */}
          {step === 'user-info' && (
            <div className="space-y-6">
              <div className="text-center">
                <h3 className="text-lg font-semibold text-gray-800 mb-2">📝 Confirm Your Details</h3>
                <p className="text-sm text-gray-600">We need this info to link your payment to your account</p>
              </div>

              <div className="space-y-4">
                <div>
                  <label className="block text-sm font-semibold mb-2 text-gray-700">
                    <span className="text-red-500">*</span> Your Email
                  </label>
                  <Input
                    type="email"
                    value={userInfo.email}
                    onChange={(e) => setUserInfo(prev => ({ ...prev, email: e.target.value }))}
                    placeholder="your.email@gmail.com"
                    className="border-2 focus:border-blue-500"
                  />
                </div>

                <div>
                  <label className="block text-sm font-semibold mb-2 text-gray-700">
                    <span className="text-red-500">*</span> User ID
                  </label>
                  <Input
                    value={userInfo.userId}
                    onChange={(e) => setUserInfo(prev => ({ ...prev, userId: e.target.value }))}
                    placeholder="Your account username"
                    className="border-2 focus:border-blue-500"
                  />
                  <p className="text-xs text-gray-500 mt-1">The ID you use to login to this website</p>
                </div>

                <div>
                  <label className="block text-sm font-semibold mb-2 text-gray-700">
                    Phone Number (Optional)
                  </label>
                  <Input
                    type="tel"
                    value={userInfo.phoneNumber}
                    onChange={(e) => setUserInfo(prev => ({ ...prev, phoneNumber: e.target.value }))}
                    placeholder="+91 9876543210"
                    className="border-2 focus:border-blue-500"
                  />
                </div>

                <Button
                  onClick={generateQRPayment}
                  className="w-full bg-blue-600 hover:bg-blue-700 text-white py-3 text-lg font-semibold"
                  disabled={!userInfo.email || !userInfo.userId}
                >
                  <QrCode className="w-5 h-5 mr-2" />
                  Proceed to Payment ₹{course.price}
                </Button>

                {(!userInfo.email || !userInfo.userId) && (
                  <p className="text-center text-xs text-red-500">
                    Please fill in all required fields (marked with *)
                  </p>
                )}
              </div>
            </div>
          )}

          {/* Step 2: QR Code Payment */}
          {step === 'qr-payment' && (
            <div className="space-y-4">
              {/* Rotating QR Display */}
              <QRDisplay
                amount={course.price}
                paymentId={paymentId}
                courseName={course.title}
              />

              {/* Auto Payment Verification */}
              {showAutoVerification && (
                <AutoPaymentVerification
                  paymentId={paymentId}
                  amount={course.price}
                  courseId={course.id}
                  courseName={course.title}
                  upiVPA={currentQR.vpa}
                  onPaymentSuccess={handleAutoVerificationSuccess}
                  onPaymentFailed={handleAutoVerificationFailed}
                />
              )}

              {!showAutoVerification && (
                <>
                  {/* Auto-Verification Starting Soon */}
                  <div className="bg-yellow-50 border border-yellow-200 rounded-lg p-3 text-center">
                    <div className="text-yellow-800 font-semibold">🔄 Auto-Verification Starting...</div>
                    <div className="text-yellow-700 text-sm">Once you pay, we'll verify automatically!</div>
                  </div>
                </>
              )}

              {/* Payment Instructions */}
              <Card className="bg-muted/30">
                <CardContent className="p-4">
                  <h4 className="font-medium mb-3 text-center">Payment Instructions</h4>
                  <div className="space-y-3 text-sm">
                    {/* Auto-Payment Notice */}
                    <div className="bg-green-50 border border-green-200 rounded-lg p-3 text-center">
                      <div className="text-green-800 font-semibold text-lg">🚀 AUTOMATIC PAYMENT</div>
                      <div className="text-green-700 font-bold text-xl mt-1">₹{course.price.toLocaleString()} Auto-Filled</div>
                      <div className="text-green-600 text-xs mt-1">Just scan → Enter UPI PIN → Payment done!</div>
                    </div>

                    <div className="space-y-2">
                      <div className="flex items-center justify-between">
                        <span>Pay via:</span>
                        <div className="flex items-center gap-2">
                          <Badge variant="outline">{currentQR.name}</Badge>
                          <Button variant="ghost" size="sm" onClick={copyUPIDetails}>
                            <Copy className="w-3 h-3" />
                          </Button>
                        </div>
                      </div>
                      <div className="flex items-center justify-between">
                        <span>Course:</span>
                        <span className="text-xs truncate max-w-32">{course.title}</span>
                      </div>
                      <div className="flex items-center justify-between">
                        <span>Payment ID:</span>
                        <code className="bg-background px-2 py-1 rounded text-xs font-mono">{paymentId}</code>
                      </div>
                    </div>
                  </div>
                  {/* Step by Step Instructions */}
                  <div className="mt-4 p-3 bg-blue-50 rounded-lg">
                    <h5 className="font-semibold text-blue-800 mb-2">📱 Easy Payment Steps:</h5>
                    <div className="space-y-1 text-xs text-blue-700">
                      <div className="flex items-center gap-2">
                        <span className="bg-blue-500 text-white rounded-full w-4 h-4 flex items-center justify-center text-xs">1</span>
                        <span>Open any UPI app (PhonePe/GPay/Paytm/BHIM)</span>
                      </div>
                      <div className="flex items-center gap-2">
                        <span className="bg-blue-500 text-white rounded-full w-4 h-4 flex items-center justify-center text-xs">2</span>
                        <span>Tap 'Scan QR' and scan above QR code</span>
                      </div>
                      <div className="flex items-center gap-2">
                        <span className="bg-green-500 text-white rounded-full w-4 h-4 flex items-center justify-center text-xs">3</span>
                        <span><strong>Amount ₹{course.price.toLocaleString()} will auto-fill!</strong></span>
                      </div>
                      <div className="flex items-center gap-2">
                        <span className="bg-blue-500 text-white rounded-full w-4 h-4 flex items-center justify-center text-xs">4</span>
                        <span>Enter your UPI PIN and tap 'Pay'</span>
                      </div>
                      <div className="flex items-center gap-2">
                        <span className="bg-purple-500 text-white rounded-full w-4 h-4 flex items-center justify-center text-xs">5</span>
                        <span>Come back here and click 'I've Completed Payment'</span>
                      </div>
                    </div>
                    <div className="mt-2 text-xs text-blue-600 bg-white/50 p-2 rounded">
                      <strong>💡 Tip:</strong> No need to type amount manually - it's automatic!
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Button onClick={() => setStep('payment-proof')} className="w-full">
                <CheckCircle className="w-4 h-4 mr-2" />
                I've Completed the Payment
              </Button>
            </div>
          )}

          {/* Step 3: Payment Proof Upload */}
          {step === 'payment-proof' && (
            <div className="space-y-4">
              <div className="text-center">
                <FileText className="w-16 h-16 mx-auto mb-4 text-blue-500" />
                <h3 className="font-medium mb-2">Upload Payment Proof</h3>
                <p className="text-sm text-muted-foreground mb-3">
                  Please provide your UTR number and payment screenshot for verification
                </p>

                {/* Amount Verification */}
                <div className="bg-green-50 border border-green-200 rounded-lg p-3 mb-4">
                  <div className="text-green-800 font-semibold text-sm">✅ Verify Payment Amount</div>
                  <div className="text-green-700 font-bold text-lg">₹{course.price.toLocaleString()}</div>
                  <div className="text-green-600 text-xs">Ensure your payment shows this exact amount</div>
                </div>
              </div>

              <div>
                <label className="block text-sm font-medium mb-1">UTR Number / Transaction ID</label>
                <Input
                  value={paymentProof.utrNumber}
                  onChange={(e) => setPaymentProof(prev => ({ ...prev, utrNumber: e.target.value }))}
                  placeholder="e.g., 123456789012"
                  className="font-mono"
                />
                <p className="text-xs text-muted-foreground mt-1">
                  Find this in your UPI app transaction history
                </p>
              </div>

              <div>
                <label className="block text-sm font-medium mb-1">Payment Screenshot</label>
                <div className="space-y-2">
                  <input
                    type="file"
                    accept="image/*"
                    onChange={(e) => {
                      const file = e.target.files?.[0];
                      if (file) handleScreenshotUpload(file);
                    }}
                    className="w-full p-2 border border-border rounded-md"
                  />
                  {paymentProof.screenshotPreview && (
                    <div className="border rounded-lg p-2">
                      <img 
                        src={paymentProof.screenshotPreview} 
                        alt="Payment screenshot"
                        className="w-full max-h-48 object-contain rounded"
                      />
                    </div>
                  )}
                </div>
              </div>

              <Button 
                onClick={handlePaymentProofSubmit} 
                className="w-full"
                disabled={!paymentProof.utrNumber || !paymentProof.screenshot}
              >
                <Upload className="w-4 h-4 mr-2" />
                Submit Payment Proof
              </Button>
            </div>
          )}

          {/* Step 4: Verification */}
          {step === 'verification' && (
            <div className="space-y-4 text-center">
              <AlertCircle className="w-16 h-16 mx-auto text-orange-500" />
              <div>
                <h3 className="font-medium mb-2">Payment Under Verification</h3>
                <p className="text-sm text-muted-foreground">
                  Your payment proof has been submitted. Admin will verify and unlock your course.
                </p>
              </div>

              <Card className="bg-orange-50 border-orange-200">
                <CardContent className="p-4">
                  <div className="text-sm space-y-2">
                    <div className="flex justify-between">
                      <span>Payment ID:</span>
                      <code className="text-xs font-mono">{paymentId}</code>
                    </div>
                    <div className="flex justify-between">
                      <span>UTR Number:</span>
                      <code className="text-xs font-mono">{paymentProof.utrNumber}</code>
                    </div>
                    <div className="flex justify-between">
                      <span>Status:</span>
                      <Badge variant="secondary" className="bg-orange-100 text-orange-700">
                        Pending Verification
                      </Badge>
                    </div>
                    <div className="flex justify-between">
                      <span>Submitted:</span>
                      <span>{new Date().toLocaleTimeString()}</span>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Button onClick={onClose} className="w-full">
                <CheckCircle className="w-4 h-4 mr-2" />
                Okay, I'll Wait for Approval
              </Button>
            </div>
          )}

          {/* Step 5: Timeout */}
          {step === 'timeout' && (
            <div className="space-y-4 text-center">
              <AlertCircle className="w-16 h-16 mx-auto text-red-500" />
              <div>
                <h3 className="font-medium mb-2 text-red-700">Payment Session Expired</h3>
                <p className="text-sm text-muted-foreground">
                  The 5-minute payment window has closed. Please start a new payment.
                </p>
              </div>
              
              <Button onClick={() => setStep('user-info')} className="w-full">
                <RefreshCw className="w-4 h-4 mr-2" />
                Start New Payment
              </Button>
            </div>
          )}

          {/* Step 6: Success */}
          {step === 'success' && (
            <div className="space-y-4 text-center">
              <CheckCircle className="w-16 h-16 mx-auto text-green-500" />
              <div>
                <h3 className="font-medium mb-2 text-green-700">🎉 Payment Successful!</h3>
                <p className="text-lg font-bold text-green-800">Course Unlocked Successfully</p>
                <p className="text-sm text-muted-foreground mt-2">
                  Welcome to "{course.title}"! You can now access all course content.
                </p>
              </div>

              <div className="bg-green-50 border border-green-200 rounded-lg p-4">
                <div className="text-sm space-y-1">
                  <div><strong>Course:</strong> {course.title}</div>
                  <div><strong>Amount Paid:</strong> ₹{course.price.toLocaleString()}</div>
                  <div><strong>Payment ID:</strong> {paymentId}</div>
                  <div><strong>Status:</strong> <span className="text-green-600 font-semibold">COMPLETED ✅</span></div>
                </div>
              </div>

              <div className="text-xs text-gray-500">
                This window will close automatically in 3 seconds...
              </div>
            </div>
          )}
        </div>
      </DialogContent>
    </Dialog>
  );
};

export default QRCodePayment;
