import React, { useState, useEffect, useRef } from 'react';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from './ui/dialog';
import { Badge } from './ui/badge';
import { useToast } from '@/hooks/use-toast';
import { useData } from '../contexts/DataContext';
import { useAuth } from '../contexts/AuthContext';
import {
  Smartphone,
  QrCode,
  Clock,
  CheckCircle,
  AlertCircle,
  Copy,
  ExternalLink,
  RefreshCw,
  Timer
} from 'lucide-react';

interface UPIPaymentProps {
  course: any;
  isOpen: boolean;
  onClose: () => void;
  onSuccess: () => void;
}

const UPIPaymentEnhanced: React.FC<UPIPaymentProps> = ({ course, isOpen, onClose, onSuccess }) => {
  const [step, setStep] = useState<'upi-input' | 'payment-link' | 'waiting' | 'verification' | 'timeout' | 'success'>('upi-input');
  const [upiId, setUpiId] = useState('');
  const [paymentId, setPaymentId] = useState('');
  const [paymentLink, setPaymentLink] = useState('');
  const [timeRemaining, setTimeRemaining] = useState(180); // 3 minutes
  const [isTimerActive, setIsTimerActive] = useState(false);
  const [paymentProvider, setPaymentProvider] = useState<'phonepe' | 'googlepay' | 'paytm' | 'custom'>('phonepe');
  const { addOrder, updateOrder } = useData();
  const { user } = useAuth();
  const { toast } = useToast();
  const timerRef = useRef<NodeJS.Timeout | null>(null);
  const webhookSimulationRef = useRef<NodeJS.Timeout | null>(null);

  // Timer effect
  useEffect(() => {
    if (isTimerActive && timeRemaining > 0) {
      timerRef.current = setTimeout(() => {
        setTimeRemaining(prev => prev - 1);
      }, 1000);
    } else if (timeRemaining === 0 && isTimerActive) {
      setStep('timeout');
      setIsTimerActive(false);
      // Mark payment as expired
      if (paymentId) {
        updateOrder(paymentId, { paymentStatus: 'failed' });
      }
      toast({
        title: "Payment Timeout",
        description: "Payment session expired. Please try again.",
        variant: "destructive"
      });
    }
    
    return () => {
      if (timerRef.current) {
        clearTimeout(timerRef.current);
      }
    };
  }, [isTimerActive, timeRemaining, paymentId, updateOrder, toast]);

  // Cleanup on unmount
  useEffect(() => {
    return () => {
      if (timerRef.current) clearTimeout(timerRef.current);
      if (webhookSimulationRef.current) clearTimeout(webhookSimulationRef.current);
    };
  }, []);

  // Reset state when modal opens/closes
  useEffect(() => {
    if (!isOpen) {
      setStep('upi-input');
      setTimeRemaining(180);
      setIsTimerActive(false);
      setUpiId('');
      setPaymentId('');
      setPaymentLink('');
      if (timerRef.current) clearTimeout(timerRef.current);
      if (webhookSimulationRef.current) clearTimeout(webhookSimulationRef.current);
    }
  }, [isOpen]);

  const generatePaymentLink = () => {
    if (!upiId) {
      toast({
        title: "UPI ID Required",
        description: "Please enter a valid UPI ID",
        variant: "destructive"
      });
      return;
    }

    // Generate payment ID with real timestamp
    const newPaymentId = `PAY_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
    setPaymentId(newPaymentId);

    // Create provider-specific payment link
    const merchantVPA = "edumaster@paytm"; 
    const amount = course.price;
    const note = `Course: ${course.title}`;
    
    let upiLink;
    
    switch (paymentProvider) {
      case 'phonepe':
        upiLink = `phonepe://pay?pa=${merchantVPA}&pn=EduMaster&am=${amount}&cu=INR&tn=${encodeURIComponent(note)}&tr=${newPaymentId}`;
        break;
      case 'googlepay':
        upiLink = `tez://upi/pay?pa=${merchantVPA}&pn=EduMaster&am=${amount}&cu=INR&tn=${encodeURIComponent(note)}&tr=${newPaymentId}`;
        break;
      case 'paytm':
        upiLink = `paytmmp://pay?pa=${merchantVPA}&pn=EduMaster&am=${amount}&cu=INR&tn=${encodeURIComponent(note)}&tr=${newPaymentId}`;
        break;
      default:
        upiLink = `upi://pay?pa=${merchantVPA}&pn=EduMaster&am=${amount}&cu=INR&tn=${encodeURIComponent(note)}&tr=${newPaymentId}`;
    }
    
    setPaymentLink(upiLink);
    setStep('payment-link');
    
    // Start 3-minute timer
    setTimeRemaining(180);
    setIsTimerActive(true);

    // Create pending order immediately
    if (user) {
      addOrder({
        userId: user.id,
        courseId: course.id,
        amount: amount,
        paymentMethod: 'UPI',
        paymentStatus: 'pending',
        orderDate: new Date().toISOString(),
        transactionId: newPaymentId,
        isUnlocked: false
      });
    }

    toast({
      title: "Payment Link Generated",
      description: "You have 3 minutes to complete the payment",
    });
  };

  const openPaymentApp = () => {
    // Try to open the specific app first, fallback to generic UPI
    const success = window.open(paymentLink, '_blank');
    
    if (!success) {
      // Fallback to generic UPI link
      const genericLink = paymentLink.replace(/^[^:]+:/, 'upi:');
      window.open(genericLink, '_blank');
    }
    
    setStep('waiting');
    
    // Simulate real webhook behavior
    // In production, this would be handled by actual payment gateway webhooks
    const webhookDelay = 15000 + Math.random() * 30000; // 15-45 seconds realistic delay
    
    webhookSimulationRef.current = setTimeout(() => {
      // Simulate 85% success rate for demo
      const isSuccessful = Math.random() > 0.15;
      
      if (isSuccessful && timeRemaining > 0 && step !== 'timeout') {
        // Simulate payment received by merchant
        updateOrder(paymentId, { 
          paymentStatus: 'pending', // Still needs admin approval
          paymentDate: new Date().toISOString() 
        });
        
        setStep('verification');
        setIsTimerActive(false);
        
        // Simulate admin notification
        console.log('🔔 ADMIN NOTIFICATION: New payment received!', {
          orderId: paymentId,
          amount: course.price,
          course: course.title,
          user: user?.name,
          timestamp: new Date().toISOString()
        });
        
        // Simulate browser notification to admin (if they have the admin panel open)
        if ('Notification' in window && Notification.permission === 'granted') {
          new Notification('New Payment Received!', {
            body: `₹${course.price} payment for ${course.title}`,
            icon: '/favicon.ico',
            tag: paymentId
          });
        }
        
        toast({
          title: "Payment Detected! 🎉",
          description: "Your payment has been received. Waiting for admin approval.",
        });
        
        // Auto-check for admin approval every 5 seconds
        const approvalChecker = setInterval(() => {
          // In real app, this would make an API call
          // For demo, we'll simulate admin approval after 30-60 seconds
          const shouldApprove = Math.random() > 0.7; // 30% chance every 5 seconds
          
          if (shouldApprove) {
            clearInterval(approvalChecker);
            updateOrder(paymentId, { 
              paymentStatus: 'completed',
              isUnlocked: true 
            });
            setStep('success');
            
            toast({
              title: "Course Unlocked! 🚀",
              description: "Payment approved! You now have full access to the course.",
            });
          }
        }, 5000);
        
        // Stop checking after 2 minutes
        setTimeout(() => clearInterval(approvalChecker), 120000);
        
      } else if (timeRemaining > 0 && step !== 'timeout') {
        setStep('verification');
        updateOrder(paymentId, { paymentStatus: 'failed' });
        
        toast({
          title: "Payment Failed",
          description: "Payment was not completed. Please try again.",
          variant: "destructive"
        });
      }
    }, webhookDelay);
  };

  const copyPaymentLink = () => {
    navigator.clipboard.writeText(paymentLink);
    toast({
      title: "Copied!",
      description: "Payment link copied to clipboard"
    });
  };

  const copyUpiId = () => {
    navigator.clipboard.writeText("edumaster@paytm");
    toast({
      title: "Copied!",
      description: "UPI ID copied to clipboard"
    });
  };

  const retryPayment = () => {
    setStep('upi-input');
    setTimeRemaining(180);
    setIsTimerActive(false);
    setPaymentId('');
    setPaymentLink('');
    if (timerRef.current) clearTimeout(timerRef.current);
    if (webhookSimulationRef.current) clearTimeout(webhookSimulationRef.current);
  };

  const formatTime = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins}:${secs.toString().padStart(2, '0')}`;
  };

  const handlePaymentComplete = () => {
    toast({
      title: "Payment Submitted!",
      description: "We'll notify you once admin approves your payment.",
    });
    onClose();
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-md">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <Smartphone className="w-5 h-5" />
            UPI Payment - {course?.title}
          </DialogTitle>
        </DialogHeader>

        <div className="space-y-6">
          {/* Course Info */}
          <Card>
            <CardContent className="p-4">
              <div className="flex items-center justify-between">
                <div>
                  <h3 className="font-medium">{course.title}</h3>
                  <p className="text-sm text-muted-foreground">Complete Course Access</p>
                </div>
                <div className="text-right">
                  <div className="text-2xl font-bold">₹{course.price.toLocaleString()}</div>
                  {course.originalPrice && (
                    <div className="text-sm text-muted-foreground line-through">
                      ₹{course.originalPrice.toLocaleString()}
                    </div>
                  )}
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Timer (shown during active payment) */}
          {isTimerActive && (
            <Card className={`border-2 ${timeRemaining <= 60 ? 'border-red-500 bg-red-50' : timeRemaining <= 120 ? 'border-orange-500 bg-orange-50' : 'border-green-500 bg-green-50'}`}>
              <CardContent className="p-4">
                <div className="flex items-center justify-center gap-3">
                  <Timer className={`w-6 h-6 ${timeRemaining <= 60 ? 'text-red-600' : timeRemaining <= 120 ? 'text-orange-600' : 'text-green-600'}`} />
                  <div className="text-center">
                    <div className={`text-2xl font-mono font-bold ${timeRemaining <= 60 ? 'text-red-700' : timeRemaining <= 120 ? 'text-orange-700' : 'text-green-700'}`}>
                      {formatTime(timeRemaining)}
                    </div>
                    <p className="text-xs text-muted-foreground">Time remaining</p>
                  </div>
                </div>
              </CardContent>
            </Card>
          )}

          {/* Step 1: UPI Provider & ID Input */}
          {step === 'upi-input' && (
            <div className="space-y-4">
              <div>
                <label className="block text-sm font-medium mb-3">Choose Your UPI App</label>
                <div className="grid grid-cols-2 gap-3">
                  {[
                    { key: 'phonepe', label: 'PhonePe', icon: '📱', color: 'purple' },
                    { key: 'googlepay', label: 'Google Pay', icon: '🟢', color: 'blue' },
                    { key: 'paytm', label: 'Paytm', icon: '💙', color: 'blue' },
                    { key: 'custom', label: 'Other UPI', icon: '🏦', color: 'gray' }
                  ].map((provider) => (
                    <button
                      key={provider.key}
                      type="button"
                      onClick={() => setPaymentProvider(provider.key as any)}
                      className={`p-4 rounded-lg border-2 text-sm font-medium transition-all transform hover:scale-105 ${
                        paymentProvider === provider.key
                          ? 'border-primary bg-primary/10 text-primary shadow-lg'
                          : 'border-border hover:bg-accent hover:border-primary/50'
                      }`}
                    >
                      <div className="text-2xl mb-2">{provider.icon}</div>
                      <div>{provider.label}</div>
                    </button>
                  ))}
                </div>
              </div>
              
              <div>
                <label className="block text-sm font-medium mb-2">Enter Your UPI ID</label>
                <Input
                  value={upiId}
                  onChange={(e) => setUpiId(e.target.value)}
                  placeholder={`yourname@${
                    paymentProvider === 'phonepe' ? 'ybl' : 
                    paymentProvider === 'googlepay' ? 'okaxis' : 
                    paymentProvider === 'paytm' ? 'paytm' : 'upi'
                  }`}
                  className="text-center text-lg"
                />
                <p className="text-xs text-muted-foreground mt-2">
                  Enter the UPI ID linked to your {paymentProvider === 'custom' ? 'UPI app' : 
                  paymentProvider === 'phonepe' ? 'PhonePe' :
                  paymentProvider === 'googlepay' ? 'Google Pay' : 'Paytm'} account
                </p>
              </div>
              
              <Button onClick={generatePaymentLink} className="w-full" disabled={!upiId}>
                <QrCode className="w-4 h-4 mr-2" />
                Generate Payment Link
              </Button>
            </div>
          )}

          {/* Step 2: Payment Link Generated */}
          {step === 'payment-link' && (
            <div className="space-y-4">
              <div className="text-center">
                <QrCode className="w-20 h-20 mx-auto mb-4 text-primary" />
                <h3 className="font-medium mb-2">Payment Link Ready!</h3>
                <p className="text-sm text-muted-foreground">
                  Click below to open your {paymentProvider === 'custom' ? 'UPI app' : 
                  paymentProvider === 'phonepe' ? 'PhonePe' :
                  paymentProvider === 'googlepay' ? 'Google Pay' : 'Paytm'} and complete payment
                </p>
              </div>

              <div className="space-y-3">
                <Button onClick={openPaymentApp} className="w-full text-lg py-6">
                  <ExternalLink className="w-5 h-5 mr-2" />
                  Pay ₹{course.price.toLocaleString()} Now
                </Button>
                
                <Button variant="outline" onClick={copyPaymentLink} className="w-full">
                  <Copy className="w-4 h-4 mr-2" />
                  Copy Payment Link
                </Button>
              </div>

              {/* Manual Payment Info */}
              <Card className="bg-muted/30">
                <CardContent className="p-4">
                  <h4 className="font-medium mb-3">Manual Payment Details:</h4>
                  <div className="space-y-2 text-sm">
                    <div className="flex items-center justify-between">
                      <span>Pay to UPI ID:</span>
                      <div className="flex items-center gap-2">
                        <code className="bg-background px-2 py-1 rounded font-mono">edumaster@paytm</code>
                        <Button variant="ghost" size="sm" onClick={copyUpiId}>
                          <Copy className="w-3 h-3" />
                        </Button>
                      </div>
                    </div>
                    <div className="flex items-center justify-between">
                      <span>Amount:</span>
                      <span className="font-bold text-lg">₹{course.price.toLocaleString()}</span>
                    </div>
                    <div className="flex items-center justify-between">
                      <span>Reference ID:</span>
                      <code className="bg-background px-2 py-1 rounded text-xs font-mono">{paymentId}</code>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Button variant="outline" onClick={() => setStep('waiting')} className="w-full">
                I've Completed the Payment
              </Button>
            </div>
          )}

          {/* Step 3: Waiting for Payment */}
          {step === 'waiting' && (
            <div className="space-y-4 text-center">
              <div className="relative">
                <Clock className="w-16 h-16 mx-auto text-blue-500 animate-pulse" />
                <div className="absolute -top-2 -right-2 w-6 h-6 bg-blue-500 rounded-full flex items-center justify-center">
                  <div className="w-2 h-2 bg-white rounded-full animate-ping"></div>
                </div>
              </div>
              <div>
                <h3 className="font-medium mb-2">Processing Payment...</h3>
                <p className="text-sm text-muted-foreground">
                  We're checking with your bank. This usually takes 10-30 seconds.
                </p>
              </div>
              
              <Card className="bg-blue-50 border-blue-200">
                <CardContent className="p-4">
                  <div className="text-sm space-y-1">
                    <div className="flex justify-between">
                      <span>Payment ID:</span>
                      <code className="text-xs font-mono">{paymentId}</code>
                    </div>
                    <div className="flex justify-between">
                      <span>Status:</span>
                      <Badge className="bg-blue-500">Processing</Badge>
                    </div>
                    <div className="flex justify-between">
                      <span>Time:</span>
                      <span>{new Date().toLocaleTimeString()}</span>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Button variant="outline" onClick={() => setStep('verification')} className="w-full">
                <RefreshCw className="w-4 h-4 mr-2" />
                Check Status Manually
              </Button>
            </div>
          )}

          {/* Step 4: Verification - Waiting for Admin */}
          {step === 'verification' && (
            <div className="space-y-4 text-center">
              <AlertCircle className="w-16 h-16 mx-auto text-orange-500" />
              <div>
                <h3 className="font-medium mb-2">Awaiting Admin Approval</h3>
                <p className="text-sm text-muted-foreground">
                  Your payment has been received! Our admin will verify and unlock your course shortly.
                </p>
              </div>

              <Card className="bg-orange-50 border-orange-200">
                <CardContent className="p-4">
                  <div className="text-sm space-y-2">
                    <div className="flex justify-between">
                      <span>Payment ID:</span>
                      <code className="text-xs font-mono">{paymentId}</code>
                    </div>
                    <div className="flex justify-between">
                      <span>Status:</span>
                      <Badge variant="secondary" className="bg-orange-100 text-orange-700">
                        Pending Approval
                      </Badge>
                    </div>
                    <div className="flex justify-between">
                      <span>Amount:</span>
                      <span className="font-medium">₹{course.price.toLocaleString()}</span>
                    </div>
                    <div className="flex justify-between">
                      <span>Time:</span>
                      <span>{new Date().toLocaleTimeString()}</span>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <div className="space-y-2">
                <Button onClick={handlePaymentComplete} className="w-full">
                  <CheckCircle className="w-4 h-4 mr-2" />
                  Okay, I'll Wait for Approval
                </Button>
                <p className="text-xs text-muted-foreground">
                  You'll get email/SMS notification once approved (usually within 5-10 minutes)
                </p>
              </div>
            </div>
          )}

          {/* Step 5: Timeout */}
          {step === 'timeout' && (
            <div className="space-y-4 text-center">
              <AlertCircle className="w-16 h-16 mx-auto text-red-500" />
              <div>
                <h3 className="font-medium mb-2 text-red-700">Payment Session Expired</h3>
                <p className="text-sm text-muted-foreground">
                  The 3-minute payment window has closed. Don't worry, you can start a new payment.
                </p>
              </div>
              
              <Card className="bg-red-50 border-red-200">
                <CardContent className="p-4">
                  <div className="text-sm space-y-1">
                    <div className="flex justify-between">
                      <span>Payment ID:</span>
                      <code className="text-xs font-mono">{paymentId}</code>
                    </div>
                    <div className="flex justify-between">
                      <span>Status:</span>
                      <Badge variant="destructive">Expired</Badge>
                    </div>
                    <div className="flex justify-between">
                      <span>Session Duration:</span>
                      <span>3 minutes</span>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <div className="space-y-2">
                <Button onClick={retryPayment} className="w-full">
                  <RefreshCw className="w-4 h-4 mr-2" />
                  Start New Payment
                </Button>
                <Button variant="outline" onClick={onClose} className="w-full">
                  Cancel
                </Button>
              </div>
            </div>
          )}

          {/* Step 6: Success */}
          {step === 'success' && (
            <div className="space-y-4 text-center">
              <CheckCircle className="w-20 h-20 mx-auto text-green-500" />
              <div>
                <h3 className="font-medium mb-2 text-green-700 text-xl">🎉 Course Unlocked!</h3>
                <p className="text-sm text-muted-foreground">
                  Payment approved! You now have complete access to all course content.
                </p>
              </div>
              
              <Card className="bg-green-50 border-green-200">
                <CardContent className="p-4">
                  <div className="text-sm space-y-1">
                    <div className="flex justify-between">
                      <span>Course:</span>
                      <span className="font-medium">{course.title}</span>
                    </div>
                    <div className="flex justify-between">
                      <span>Access:</span>
                      <Badge className="bg-green-500">Full Access Granted</Badge>
                    </div>
                    <div className="flex justify-between">
                      <span>Valid:</span>
                      <span>Lifetime</span>
                    </div>
                  </div>
                </CardContent>
              </Card>
              
              <Button onClick={onSuccess} className="w-full text-lg py-6 bg-green-600 hover:bg-green-700">
                <CheckCircle className="w-5 h-5 mr-2" />
                Start Learning Now! 🚀
              </Button>
            </div>
          )}
        </div>
        
        {/* Progress indicator */}
        {step !== 'timeout' && step !== 'success' && (
          <div className="mt-6 border-t pt-4">
            <div className="flex items-center justify-between text-xs text-muted-foreground mb-2">
              <span className={step === 'upi-input' ? 'text-primary font-medium' : ''}>Setup</span>
              <span className={step === 'payment-link' ? 'text-primary font-medium' : ''}>Pay</span>
              <span className={step === 'waiting' ? 'text-primary font-medium' : ''}>Processing</span>
              <span className={step === 'verification' ? 'text-primary font-medium' : ''}>Approval</span>
            </div>
            <div className="bg-muted rounded-full h-2">
              <div 
                className="bg-primary h-2 rounded-full transition-all duration-500 ease-out"
                style={{
                  width: step === 'upi-input' ? '25%' : 
                         step === 'payment-link' ? '50%' : 
                         step === 'waiting' ? '75%' : 
                         step === 'verification' ? '100%' : '0%'
                }}
              />
            </div>
          </div>
        )}
      </DialogContent>
    </Dialog>
  );
};

export default UPIPaymentEnhanced;
