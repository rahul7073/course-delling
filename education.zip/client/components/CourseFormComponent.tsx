import React, { useState } from 'react';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Textarea } from './ui/textarea';

interface CourseFormData {
  title?: string;
  description?: string;
  price?: number;
  originalPrice?: number;
  category?: string;
  level?: string;
  duration?: string;
  thumbnail?: string;
}

interface CourseFormComponentProps {
  initialData?: CourseFormData;
  onSave: (data: CourseFormData) => void;
  onCancel: () => void;
  isEditing?: boolean;
}

const CourseFormComponent: React.FC<CourseFormComponentProps> = ({
  initialData = {},
  onSave,
  onCancel,
  isEditing = false
}) => {
  const [formData, setFormData] = useState<CourseFormData>(initialData);

  const handleInputChange = (field: keyof CourseFormData, value: any) => {
    setFormData(prev => ({
      ...prev,
      [field]: value
    }));
  };

  const handleSubmit = () => {
    onSave(formData);
  };

  return (
    <div className="space-y-4">
      <div>
        <label className="block text-sm font-medium mb-1">Course Title</label>
        <Input
          value={formData.title || ''}
          onChange={(e) => handleInputChange('title', e.target.value)}
          placeholder="Enter course title"
          autoComplete="off"
        />
      </div>
      
      <div>
        <label className="block text-sm font-medium mb-1">Description</label>
        <Textarea
          value={formData.description || ''}
          onChange={(e) => handleInputChange('description', e.target.value)}
          placeholder="Enter course description"
          rows={3}
          autoComplete="off"
        />
      </div>
      
      <div className="grid grid-cols-2 gap-4">
        <div>
          <label className="block text-sm font-medium mb-1">Price (₹)</label>
          <Input
            type="number"
            value={formData.price || ''}
            onChange={(e) => handleInputChange('price', Number(e.target.value) || 0)}
            placeholder="0"
            autoComplete="off"
          />
        </div>
        <div>
          <label className="block text-sm font-medium mb-1">Original Price (₹)</label>
          <Input
            type="number"
            value={formData.originalPrice || ''}
            onChange={(e) => handleInputChange('originalPrice', Number(e.target.value) || 0)}
            placeholder="Optional"
            autoComplete="off"
          />
        </div>
      </div>
      
      <div className="grid grid-cols-2 gap-4">
        <div>
          <label className="block text-sm font-medium mb-1">Category</label>
          <Input
            value={formData.category || ''}
            onChange={(e) => handleInputChange('category', e.target.value)}
            placeholder="e.g., Web Development"
            autoComplete="off"
          />
        </div>
        <div>
          <label className="block text-sm font-medium mb-1">Level</label>
          <select
            value={formData.level || ''}
            onChange={(e) => handleInputChange('level', e.target.value)}
            className="w-full px-3 py-2 border border-gray-300 rounded-md text-sm"
          >
            <option value="">Select Level</option>
            <option value="beginner">Beginner</option>
            <option value="intermediate">Intermediate</option>
            <option value="advanced">Advanced</option>
          </select>
        </div>
      </div>
      
      <div className="grid grid-cols-2 gap-4">
        <div>
          <label className="block text-sm font-medium mb-1">Duration</label>
          <Input
            value={formData.duration || ''}
            onChange={(e) => handleInputChange('duration', e.target.value)}
            placeholder="e.g., 30 hours"
            autoComplete="off"
          />
        </div>
        <div>
          <label className="block text-sm font-medium mb-1">Thumbnail URL</label>
          <Input
            value={formData.thumbnail || ''}
            onChange={(e) => handleInputChange('thumbnail', e.target.value)}
            placeholder="Image URL"
            autoComplete="off"
          />
        </div>
      </div>
      
      <div className="flex justify-end space-x-2">
        <Button variant="outline" onClick={onCancel}>
          Cancel
        </Button>
        <Button onClick={handleSubmit}>
          {isEditing ? 'Update Course' : 'Add Course'}
        </Button>
      </div>
    </div>
  );
};

export default CourseFormComponent;
