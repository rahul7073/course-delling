import React, { useState, useRef } from 'react';
import { useData } from '../contexts/DataContext';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Textarea } from './ui/textarea';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Badge } from './ui/badge';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from './ui/dialog';
import { Tabs, TabsContent, TabsList, TabsTrigger } from './ui/tabs';
import { Switch } from './ui/switch';
import { Label } from './ui/label';
import { useToast } from '@/hooks/use-toast';
import { fileToDataURL, formatFileSize, getFileIcon } from '../utils/fileDownload';
import { validateUpload, getStorageInfo, troubleshootUploadFailure } from '../utils/uploadHelpers';
import {
  Plus,
  Edit,
  Trash2,
  Upload,
  FileText,
  Play,
  Code,
  Save,
  X,
  Download,
  BookOpen,
  Video,
  Github,
  ExternalLink,
  FolderOpen
} from 'lucide-react';

interface EnhancedCourseManagerProps {
  course: any;
  isOpen: boolean;
  onClose: () => void;
}

const EnhancedCourseManager: React.FC<EnhancedCourseManagerProps> = ({ course, isOpen, onClose }) => {
  const {
    addCourseClass,
    updateCourseClass,
    deleteCourseClass,
    addCourseVideo,
    addCourseNote,
    addCourseProject,
    deleteCourseVideo,
    deleteCourseNote,
    deleteCourseProject
  } = useData();

  const [activeTab, setActiveTab] = useState('overview');
  const [selectedClass, setSelectedClass] = useState<any>(null);
  const [isAddClassOpen, setIsAddClassOpen] = useState(false);
  const [isUploadOpen, setIsUploadOpen] = useState(false);
  const [uploadType, setUploadType] = useState<'video' | 'note' | 'project'>('video');
  
  // Refs for file inputs
  const videoFileRef = useRef<HTMLInputElement>(null);
  const noteFileRef = useRef<HTMLInputElement>(null);
  
  // Form states
  const [classForm, setClassForm] = useState({
    title: '',
    description: '',
    isDemo: false
  });
  
  const [contentForm, setContentForm] = useState({
    title: '',
    description: '',
    githubUrl: '',
    liveUrl: ''
  });
  
  const [uploadedFile, setUploadedFile] = useState<File | null>(null);
  const [isUploading, setIsUploading] = useState(false);
  
  const { toast } = useToast();

  // Add new class
  const handleAddClass = () => {
    if (!classForm.title.trim()) {
      toast({
        title: "❌ Title Required",
        description: "Please enter a class title",
        variant: "destructive"
      });
      return;
    }

    const classNumber = (course.classes?.length || 0) + 1;
    
    addCourseClass(course.id, {
      classNumber,
      title: classForm.title,
      description: classForm.description,
      isDemo: classForm.isDemo,
      videos: [],
      notes: [],
      projects: []
    });

    toast({
      title: "✅ Class Added Successfully",
      description: `${classForm.title} has been added to the course`,
    });

    setClassForm({ title: '', description: '', isDemo: false });
    setIsAddClassOpen(false);
  };

  // Handle file selection
  const handleFileSelect = (type: 'video' | 'note') => {
    if (!contentForm.title.trim()) {
      toast({
        title: "❌ Title Required",
        description: "Please enter a title before selecting a file",
        variant: "destructive"
      });
      return;
    }

    const fileRef = type === 'video' ? videoFileRef : noteFileRef;
    fileRef.current?.click();
  };

  // Handle file upload
  const handleFileUpload = async (event: React.ChangeEvent<HTMLInputElement>, type: 'video' | 'note') => {
    const file = event.target.files?.[0];
    if (!file || !selectedClass) return;

    // Validate file before proceeding
    const validation = validateUpload(file, type);

    if (!validation.isValid) {
      toast({
        title: "❌ Invalid File",
        description: validation.errors.join('. '),
        variant: "destructive"
      });
      return;
    }

    // Show warnings if any
    if (validation.warnings.length > 0) {
      toast({
        title: "⚠️ Upload Warning",
        description: validation.warnings.join('. '),
        duration: 6000
      });
    }

    // Check storage space
    const storageInfo = getStorageInfo();
    if (storageInfo.isNearFull) {
      toast({
        title: "⚠️ Storage Nearly Full",
        description: `Browser storage is ${storageInfo.percentUsed}% full. Upload may fail.`,
        variant: "destructive",
        duration: 8000
      });
    }

    setUploadedFile(file);
    setIsUploading(true);

    try {
      const maxSize = type === 'video' ? 50 : 10; // 50MB for videos, 10MB for notes
      const fileUrl = await fileToDataURL(file, maxSize);

      if (type === 'video') {
        addCourseVideo(course.id, {
          title: contentForm.title || `${selectedClass.title} - Video`,
          description: contentForm.description || 'Class video content',
          videoUrl: fileUrl,
          duration: '00:00', // Would be calculated in real implementation
          thumbnailUrl: '',
          uploadDate: new Date().toISOString(),
          order: (selectedClass.videos?.length || 0) + 1,
          isPreview: selectedClass.isDemo,
          classNumber: selectedClass.classNumber
        });
      } else {
        addCourseNote(course.id, {
          title: contentForm.title || `${selectedClass.title} - Notes`,
          description: contentForm.description || 'Class notes and materials',
          fileUrl: fileUrl,
          fileSize: formatFileSize(file.size),
          uploadDate: new Date().toISOString(),
          classNumber: selectedClass.classNumber
        });
      }

      toast({
        title: "✅ Upload Successful",
        description: `${type === 'video' ? 'Video' : 'Notes'} uploaded to ${selectedClass.title}`,
      });

      resetUploadForm();
    } catch (error) {
      console.error('Upload error:', error);
      const troubleshootMessage = error instanceof Error ? troubleshootUploadFailure(error) : 'Upload failed. Please try again.';

      toast({
        title: "❌ Upload Failed",
        description: troubleshootMessage,
        variant: "destructive",
        duration: 10000
      });

      // Clear the uploaded file on error so user can try again
      setUploadedFile(null);
    } finally {
      setIsUploading(false);
    }
  };

  // Add project/code
  const handleAddProject = () => {
    if (!selectedClass || !contentForm.title.trim()) {
      toast({
        title: "❌ Required Fields Missing",
        description: "Please enter project title",
        variant: "destructive"
      });
      return;
    }

    addCourseProject(course.id, {
      title: contentForm.title,
      description: contentForm.description,
      codeFiles: [{
        fileName: 'README.md',
        fileUrl: contentForm.githubUrl || '#',
        language: 'markdown'
      }],
      liveUrl: contentForm.liveUrl || '',
      uploadDate: new Date().toISOString(),
      classNumber: selectedClass.classNumber
    });

    toast({
      title: "✅ Project Added",
      description: `Project "${contentForm.title}" added to ${selectedClass.title}`,
    });

    resetUploadForm();
  };

  const resetUploadForm = () => {
    setContentForm({ title: '', description: '', githubUrl: '', liveUrl: '' });
    setUploadedFile(null);
    setIsUploadOpen(false);
    setUploadType('video');
  };

  const getClassStats = (cls: any) => {
    return {
      videos: cls.videos?.length || 0,
      notes: cls.notes?.length || 0,
      projects: cls.projects?.length || 0
    };
  };

  const openUploadDialog = (type: 'video' | 'note' | 'project', cls: any) => {
    setSelectedClass(cls);
    setUploadType(type);
    setIsUploadOpen(true);
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-6xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <BookOpen className="w-5 h-5 text-blue-600" />
            Manage Classes: {course.title}
          </DialogTitle>
        </DialogHeader>

        <Tabs value={activeTab} onValueChange={setActiveTab}>
          <TabsList className="grid w-full grid-cols-2">
            <TabsTrigger value="overview">Classes Overview</TabsTrigger>
            <TabsTrigger value="content">Content Management</TabsTrigger>
          </TabsList>

          {/* Classes Overview Tab */}
          <TabsContent value="overview" className="space-y-4">
            <div className="flex justify-between items-center">
              <h3 className="text-lg font-semibold">Course Classes ({course.classes?.length || 0})</h3>
              <Button onClick={() => setIsAddClassOpen(true)}>
                <Plus className="w-4 h-4 mr-2" />
                Add New Class
              </Button>
            </div>

            {/* Classes List */}
            <div className="grid gap-4">
              {course.classes?.map((cls: any, index: number) => {
                const stats = getClassStats(cls);
                return (
                  <Card key={cls.id || index} className="border-2">
                    <CardHeader className="pb-3">
                      <div className="flex items-center justify-between">
                        <div className="flex items-center gap-3">
                          <div className="w-10 h-10 bg-blue-100 rounded-full flex items-center justify-center">
                            <span className="text-blue-600 font-bold">{cls.classNumber}</span>
                          </div>
                          <div>
                            <CardTitle className="text-lg">{cls.title}</CardTitle>
                            <p className="text-sm text-gray-600">{cls.description}</p>
                          </div>
                        </div>
                        <div className="flex items-center gap-2">
                          {cls.isDemo && <Badge variant="secondary">Demo</Badge>}
                          <Button 
                            variant="outline" 
                            size="sm"
                            onClick={() => setActiveTab('content')}
                          >
                            <Edit className="w-3 h-3 mr-1" />
                            Manage Content
                          </Button>
                        </div>
                      </div>
                    </CardHeader>
                    <CardContent>
                      <div className="grid grid-cols-3 gap-4">
                        <div className="text-center p-3 bg-red-50 rounded-lg">
                          <Video className="w-6 h-6 mx-auto text-red-500 mb-1" />
                          <div className="text-lg font-bold">{stats.videos}</div>
                          <div className="text-xs text-gray-600">Videos</div>
                        </div>
                        <div className="text-center p-3 bg-blue-50 rounded-lg">
                          <FileText className="w-6 h-6 mx-auto text-blue-500 mb-1" />
                          <div className="text-lg font-bold">{stats.notes}</div>
                          <div className="text-xs text-gray-600">Notes</div>
                        </div>
                        <div className="text-center p-3 bg-purple-50 rounded-lg">
                          <Code className="w-6 h-6 mx-auto text-purple-500 mb-1" />
                          <div className="text-lg font-bold">{stats.projects}</div>
                          <div className="text-xs text-gray-600">Projects</div>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                );
              })}

              {(!course.classes || course.classes.length === 0) && (
                <Card className="border-dashed border-2 border-gray-300">
                  <CardContent className="text-center py-8">
                    <BookOpen className="w-12 h-12 mx-auto text-gray-400 mb-3" />
                    <h3 className="text-lg font-semibold text-gray-600 mb-2">No Classes Yet</h3>
                    <p className="text-gray-500 mb-4">Start building your course by adding the first class</p>
                    <Button onClick={() => setIsAddClassOpen(true)}>
                      <Plus className="w-4 h-4 mr-2" />
                      Add First Class
                    </Button>
                  </CardContent>
                </Card>
              )}
            </div>
          </TabsContent>

          {/* Content Management Tab */}
          <TabsContent value="content" className="space-y-4">
            <h3 className="text-lg font-semibold">Upload Content to Classes</h3>
            
            <div className="grid gap-4">
              {course.classes?.map((cls: any, index: number) => (
                <Card key={cls.id || index}>
                  <CardHeader className="pb-3">
                    <CardTitle className="flex items-center gap-2">
                      <span className="w-6 h-6 bg-blue-100 rounded-full flex items-center justify-center text-xs font-bold text-blue-600">
                        {cls.classNumber}
                      </span>
                      {cls.title}
                      {cls.isDemo && <Badge variant="secondary">Demo</Badge>}
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
                      <Button 
                        variant="outline" 
                        onClick={() => openUploadDialog('video', cls)}
                        className="flex items-center gap-2"
                      >
                        <Video className="w-4 h-4 text-red-500" />
                        Upload Video
                      </Button>
                      <Button 
                        variant="outline" 
                        onClick={() => openUploadDialog('note', cls)}
                        className="flex items-center gap-2"
                      >
                        <FileText className="w-4 h-4 text-blue-500" />
                        Upload Notes
                      </Button>
                      <Button 
                        variant="outline" 
                        onClick={() => openUploadDialog('project', cls)}
                        className="flex items-center gap-2"
                      >
                        <Code className="w-4 h-4 text-purple-500" />
                        Add Project
                      </Button>
                    </div>

                    {/* Show existing content */}
                    {(cls.videos?.length > 0 || cls.notes?.length > 0 || cls.projects?.length > 0) && (
                      <div className="mt-4 pt-4 border-t">
                        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-sm">
                          <div>
                            <div className="font-semibold text-red-600 mb-1">Videos ({cls.videos?.length || 0})</div>
                            {cls.videos?.map((video: any, i: number) => (
                              <div key={i} className="text-xs text-gray-600">• {video.title}</div>
                            ))}
                          </div>
                          <div>
                            <div className="font-semibold text-blue-600 mb-1">Notes ({cls.notes?.length || 0})</div>
                            {cls.notes?.map((note: any, i: number) => (
                              <div key={i} className="text-xs text-gray-600">• {note.title}</div>
                            ))}
                          </div>
                          <div>
                            <div className="font-semibold text-purple-600 mb-1">Projects ({cls.projects?.length || 0})</div>
                            {cls.projects?.map((project: any, i: number) => (
                              <div key={i} className="text-xs text-gray-600">• {project.title}</div>
                            ))}
                          </div>
                        </div>
                      </div>
                    )}
                  </CardContent>
                </Card>
              ))}
            </div>
          </TabsContent>
        </Tabs>

        {/* Add Class Dialog */}
        <Dialog open={isAddClassOpen} onOpenChange={setIsAddClassOpen}>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>Add New Class</DialogTitle>
            </DialogHeader>
            <div className="space-y-4">
              <div>
                <Label htmlFor="classTitle">Class Title *</Label>
                <Input
                  id="classTitle"
                  placeholder="e.g., Introduction to React"
                  value={classForm.title}
                  onChange={(e) => setClassForm(prev => ({ ...prev, title: e.target.value }))}
                />
              </div>
              <div>
                <Label htmlFor="classDesc">Description</Label>
                <Textarea
                  id="classDesc"
                  placeholder="What will students learn in this class?"
                  value={classForm.description}
                  onChange={(e) => setClassForm(prev => ({ ...prev, description: e.target.value }))}
                />
              </div>
              <div className="flex items-center space-x-2">
                <Switch
                  id="isDemo"
                  checked={classForm.isDemo}
                  onCheckedChange={(checked) => setClassForm(prev => ({ ...prev, isDemo: checked }))}
                />
                <Label htmlFor="isDemo">Make this a free demo class</Label>
              </div>
              <div className="flex gap-2 pt-4">
                <Button variant="outline" onClick={() => setIsAddClassOpen(false)} className="flex-1">
                  Cancel
                </Button>
                <Button onClick={handleAddClass} className="flex-1">
                  Add Class
                </Button>
              </div>
            </div>
          </DialogContent>
        </Dialog>

        {/* Upload Content Dialog */}
        <Dialog open={isUploadOpen} onOpenChange={setIsUploadOpen}>
          <DialogContent className="max-w-md">
            <DialogHeader>
              <DialogTitle className="flex items-center gap-2">
                {uploadType === 'video' && <Video className="w-5 h-5 text-red-500" />}
                {uploadType === 'note' && <FileText className="w-5 h-5 text-blue-500" />}
                {uploadType === 'project' && <Code className="w-5 h-5 text-purple-500" />}
                {uploadType === 'video' ? 'Upload Video' : uploadType === 'note' ? 'Upload Notes' : 'Add Project'}
              </DialogTitle>

              {/* Storage Info */}
              {uploadType !== 'project' && (() => {
                const storageInfo = getStorageInfo();
                return (
                  <div className={`text-xs px-3 py-2 rounded-md ${
                    storageInfo.isNearFull ? 'bg-orange-50 text-orange-700' : 'bg-gray-50 text-gray-600'
                  }`}>
                    Browser Storage: {storageInfo.used} used ({storageInfo.percentUsed}%)
                    {storageInfo.isNearFull && " - Storage nearly full!"}
                  </div>
                );
              })()}
            </DialogHeader>

            <div className="space-y-4">
              <div>
                <Label>Title *</Label>
                <Input
                  placeholder={`${uploadType === 'video' ? 'Video' : uploadType === 'note' ? 'Notes' : 'Project'} title`}
                  value={contentForm.title}
                  onChange={(e) => setContentForm(prev => ({ ...prev, title: e.target.value }))}
                />
              </div>

              <div>
                <Label>Description</Label>
                <Textarea
                  placeholder="Brief description"
                  value={contentForm.description}
                  onChange={(e) => setContentForm(prev => ({ ...prev, description: e.target.value }))}
                />
              </div>

              {uploadType === 'video' && (
                <div>
                  <Label>Video File *</Label>
                  <div className={`border-2 border-dashed rounded-lg p-4 text-center ${
                    uploadedFile ? 'border-green-300 bg-green-50' : 'border-gray-300'
                  }`}>
                    <Video className={`w-8 h-8 mx-auto mb-2 ${
                      uploadedFile ? 'text-green-500' : 'text-gray-400'
                    }`} />
                    {uploadedFile ? (
                      <div>
                        <p className="text-sm font-medium text-green-700">{uploadedFile.name}</p>
                        <p className="text-xs text-green-600">{formatFileSize(uploadedFile.size)}</p>
                        <Button
                          variant="outline"
                          size="sm"
                          onClick={() => handleFileSelect('video')}
                          className="mt-2"
                        >
                          Change File
                        </Button>
                      </div>
                    ) : (
                      <>
                        <Button onClick={() => handleFileSelect('video')}>
                          <Upload className="w-4 h-4 mr-2" />
                          Select Video File
                        </Button>
                        <p className="text-xs text-gray-500 mt-1">MP4, AVI, MOV supported (max 50MB)</p>
                      </>
                    )}
                  </div>
                </div>
              )}

              {uploadType === 'note' && (
                <div>
                  <Label>Notes File *</Label>
                  <div className={`border-2 border-dashed rounded-lg p-4 text-center ${
                    uploadedFile ? 'border-green-300 bg-green-50' : 'border-gray-300'
                  }`}>
                    <FileText className={`w-8 h-8 mx-auto mb-2 ${
                      uploadedFile ? 'text-green-500' : 'text-gray-400'
                    }`} />
                    {uploadedFile ? (
                      <div>
                        <p className="text-sm font-medium text-green-700">{uploadedFile.name}</p>
                        <p className="text-xs text-green-600">{formatFileSize(uploadedFile.size)}</p>
                        <Button
                          variant="outline"
                          size="sm"
                          onClick={() => handleFileSelect('note')}
                          className="mt-2"
                        >
                          Change File
                        </Button>
                      </div>
                    ) : (
                      <>
                        <Button onClick={() => handleFileSelect('note')}>
                          <Upload className="w-4 h-4 mr-2" />
                          Select Notes File
                        </Button>
                        <p className="text-xs text-gray-500 mt-1">PDF, DOC, TXT supported (max 10MB)</p>
                      </>
                    )}
                  </div>
                </div>
              )}

              {uploadType === 'project' && (
                <>
                  <div>
                    <Label>GitHub URL</Label>
                    <Input
                      placeholder="https://github.com/username/repository"
                      value={contentForm.githubUrl}
                      onChange={(e) => setContentForm(prev => ({ ...prev, githubUrl: e.target.value }))}
                    />
                  </div>
                  <div>
                    <Label>Live Demo URL</Label>
                    <Input
                      placeholder="https://your-project.netlify.app"
                      value={contentForm.liveUrl}
                      onChange={(e) => setContentForm(prev => ({ ...prev, liveUrl: e.target.value }))}
                    />
                  </div>
                </>
              )}

              <div className="flex gap-2 pt-4">
                <Button variant="outline" onClick={resetUploadForm} className="flex-1">
                  Cancel
                </Button>
                {uploadType === 'project' ? (
                  <Button onClick={handleAddProject} className="flex-1">
                    Add Project
                  </Button>
                ) : (
                  <Button
                    onClick={() => {
                      if (uploadedFile && uploadType !== 'project') {
                        const event = {
                          target: { files: [uploadedFile] }
                        } as React.ChangeEvent<HTMLInputElement>;
                        handleFileUpload(event, uploadType);
                      }
                    }}
                    disabled={!uploadedFile || isUploading || !contentForm.title.trim()}
                    className="flex-1"
                  >
                    {isUploading ? 'Uploading...' : 'Upload'}
                  </Button>
                )}
              </div>
            </div>

            {/* Hidden file inputs */}
            <input
              ref={videoFileRef}
              type="file"
              accept="video/*"
              className="hidden"
              onChange={(e) => handleFileUpload(e, 'video')}
            />
            <input
              ref={noteFileRef}
              type="file"
              accept=".pdf,.doc,.docx,.txt"
              className="hidden"
              onChange={(e) => handleFileUpload(e, 'note')}
            />
          </DialogContent>
        </Dialog>
      </DialogContent>
    </Dialog>
  );
};

export default EnhancedCourseManager;
