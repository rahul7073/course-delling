import React from 'react';
import { useData } from '../contexts/DataContext';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Badge } from './ui/badge';

interface CourseDataDebugProps {
  courseId: string;
}

const CourseDataDebug: React.FC<CourseDataDebugProps> = ({ courseId }) => {
  const { courses } = useData();
  const course = courses.find(c => c.id === courseId);

  if (!course) {
    return <div>Course not found</div>;
  }

  return (
    <Card className="mt-4">
      <CardHeader>
        <CardTitle className="text-sm">Course Data Debug - {course.title}</CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        <div>
          <h4 className="font-medium mb-2">Classes ({course.classes?.length || 0}):</h4>
          {course.classes?.map((cls: any) => (
            <div key={cls.id} className="ml-4 p-2 border rounded mb-2">
              <div className="flex items-center gap-2 mb-1">
                <Badge variant="outline">Class {cls.classNumber}</Badge>
                <span className="font-medium">{cls.title}</span>
              </div>
              
              <div className="text-xs space-y-1">
                <div>Videos: {cls.videos?.length || 0}</div>
                {cls.videos?.map((video: any) => (
                  <div key={video.id} className="ml-4 text-blue-600">
                    • {video.title} ({video.duration})
                  </div>
                ))}
                
                <div>Notes: {cls.notes?.length || 0}</div>
                {cls.notes?.map((note: any) => (
                  <div key={note.id} className="ml-4 text-green-600">
                    • {note.title} ({note.fileSize})
                  </div>
                ))}
                
                <div>Projects: {cls.projects?.length || 0}</div>
                {cls.projects?.map((project: any) => (
                  <div key={project.id} className="ml-4 text-purple-600">
                    • {project.title} ({project.codeFiles?.length || 0} files)
                  </div>
                ))}
              </div>
            </div>
          ))}
        </div>

        <div>
          <h4 className="font-medium mb-2">Local Storage Files:</h4>
          <div className="text-xs">
            {Object.keys(localStorage).filter(key => 
              key.startsWith('edumaster_file_') || key.startsWith('video_') || key.startsWith('notes_') || key.startsWith('code_')
            ).map(key => {
              try {
                const fileInfo = JSON.parse(localStorage.getItem(key) || '{}');
                return (
                  <div key={key} className="ml-4 text-gray-600">
                    • {fileInfo.name} ({(fileInfo.size / 1024 / 1024).toFixed(1)}MB) - {key}
                  </div>
                );
              } catch {
                return (
                  <div key={key} className="ml-4 text-red-600">
                    • Invalid file data - {key}
                  </div>
                );
              }
            })}
          </div>
        </div>

        <div>
          <h4 className="font-medium mb-2">Course Updated:</h4>
          <div className="text-xs text-gray-600">
            {new Date(course.updatedAt).toLocaleString()}
          </div>
        </div>
      </CardContent>
    </Card>
  );
};

export default CourseDataDebug;
