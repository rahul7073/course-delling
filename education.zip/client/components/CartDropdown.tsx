import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import { Button } from './ui/button';
import { Badge } from './ui/badge';
import { Card, CardContent, CardFooter, CardHeader } from './ui/card';
import { Separator } from './ui/separator';
import { ScrollArea } from './ui/scroll-area';
import { useCart } from '../contexts/CartContext';
import { useToast } from '@/hooks/use-toast';
import { setupCartNotifications } from '../utils/cartNotifications';
import CartQRPayment from './CartQRPayment';
import {
  Trash2,
  Plus,
  Minus,
  ShoppingCart,
  Smartphone,
  X,
  Star,
  Clock
} from 'lucide-react';

interface CartDropdownProps {
  isOpen: boolean;
  onClose: () => void;
}

export function CartDropdown({ isOpen, onClose }: CartDropdownProps) {
  const { cartItems, removeFromCart, cartTotal, cartCount, clearCart } = useCart();
  const { toast } = useToast();
  const [isQRPaymentOpen, setIsQRPaymentOpen] = useState(false);

  // Setup cart notifications
  React.useEffect(() => {
    const cleanup = setupCartNotifications(toast);
    return cleanup;
  }, [toast]);

  if (!isOpen) return null;

  const handleRemoveItem = (courseId: string, courseTitle: string) => {
    removeFromCart(courseId);
    // Success notification is automatically handled by cart context
  };

  const handleClearCart = () => {
    clearCart();
    toast({
      title: "🗑️ Cart Cleared",
      description: "All items have been removed from your cart.",
    });
  };

  const handleBuyNow = () => {
    setIsQRPaymentOpen(true);
  };

  const handlePaymentSuccess = () => {
    toast({
      title: "Payment Submitted!",
      description: "Your payment is being verified. Courses will be unlocked once approved.",
    });
  };

  return (
    <>
      {/* Overlay */}
      <div 
        className="fixed inset-0 z-40 bg-black/20" 
        onClick={onClose}
      />
      
      {/* Cart Dropdown */}
      <Card className="fixed top-16 right-4 z-50 w-96 max-w-[calc(100vw-2rem)] shadow-2xl border-0">
        <CardHeader className="flex flex-row items-center justify-between pb-4">
          <div className="flex items-center space-x-2">
            <ShoppingCart className="h-5 w-5" />
            <h3 className="font-semibold">Shopping Cart</h3>
            {cartCount > 0 && (
              <Badge variant="secondary">{cartCount} item{cartCount !== 1 ? 's' : ''}</Badge>
            )}
          </div>
          <Button variant="ghost" size="sm" onClick={onClose}>
            <X className="h-4 w-4" />
          </Button>
        </CardHeader>

        <CardContent className="p-0">
          {cartItems.length === 0 ? (
            <div className="flex flex-col items-center justify-center py-8 px-6 text-center">
              <ShoppingCart className="h-12 w-12 text-muted-foreground mb-4" />
              <h4 className="font-medium mb-2">Your cart is empty</h4>
              <p className="text-sm text-muted-foreground mb-4">
                Start learning by adding some courses to your cart
              </p>
              <Button asChild onClick={onClose}>
                <Link to="/courses">Browse Courses</Link>
              </Button>
            </div>
          ) : (
            <>
              <ScrollArea className="max-h-96">
                <div className="p-4 space-y-4">
                  {cartItems.map((item) => (
                    <div key={item.course.id} className="flex gap-3 p-3 bg-muted/30 rounded-lg">
                      {/* Course Thumbnail */}
                      <div className="relative flex-shrink-0">
                        <img
                          src={item.course.thumbnail}
                          alt={item.course.title}
                          className="w-16 h-12 object-cover rounded"
                        />
                        {item.course.isFree && (
                          <Badge className="absolute -top-1 -right-1 text-xs bg-success text-success-foreground">
                            Free
                          </Badge>
                        )}
                      </div>

                      {/* Course Info */}
                      <div className="flex-1 min-w-0">
                        <Link
                          to={`/course/${item.course.id}`}
                          onClick={onClose}
                          className="block"
                        >
                          <h4 className="font-medium text-sm line-clamp-2 hover:text-primary transition-colors">
                            {item.course.title}
                          </h4>
                        </Link>
                        
                        <div className="flex items-center gap-2 mt-1 text-xs text-muted-foreground">
                          <span>{item.course.instructor.name}</span>
                          <div className="flex items-center gap-1">
                            <Star className="w-3 h-3 fill-yellow-400 text-yellow-400" />
                            <span>{item.course.rating}</span>
                          </div>
                          <div className="flex items-center gap-1">
                            <Clock className="w-3 h-3" />
                            <span>{item.course.duration}</span>
                          </div>
                        </div>

                        <div className="flex items-center justify-between mt-2">
                          <div className="flex items-center space-x-2">
                            {item.course.isFree ? (
                              <span className="font-semibold text-success">Free</span>
                            ) : (
                              <>
                                <span className="font-semibold">${item.course.price}</span>
                                {item.course.originalPrice && (
                                  <span className="text-xs text-muted-foreground line-through">
                                    ${item.course.originalPrice}
                                  </span>
                                )}
                              </>
                            )}
                          </div>
                          
                          <Button
                            variant="ghost"
                            size="sm"
                            onClick={() => handleRemoveItem(item.course.id, item.course.title)}
                            className="h-8 w-8 p-0 text-muted-foreground hover:text-destructive"
                          >
                            <Trash2 className="h-3 w-3" />
                          </Button>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </ScrollArea>

              <Separator />

              {/* Cart Summary */}
              <div className="p-4 space-y-4">
                <div className="flex items-center justify-between">
                  <span className="font-medium">Total:</span>
                  <span className="text-lg font-bold">
                    ${cartTotal.toFixed(2)}
                  </span>
                </div>

                {cartTotal > 0 && (
                  <div className="text-xs text-muted-foreground">
                    <p>• 30-day money-back guarantee</p>
                    <p>• Lifetime access to purchased courses</p>
                  </div>
                )}
              </div>
            </>
          )}
        </CardContent>

        {cartItems.length > 0 && (
          <CardFooter className="flex flex-col gap-2 pt-0">
            <Button
              className="w-full"
              onClick={handleBuyNow}
              disabled={cartItems.length === 0}
            >
              <Smartphone className="w-4 h-4 mr-2" />
              {cartTotal > 0 ? `Pay via UPI (₹${(cartTotal * 83).toFixed(0)})` : 'Start Learning (Free)'}
            </Button>
            
            <div className="flex gap-2 w-full">
              <Button variant="outline" size="sm" className="flex-1" asChild onClick={onClose}>
                <Link to="/courses">
                  <Plus className="w-4 h-4 mr-1" />
                  Add More
                </Link>
              </Button>
              <Button 
                variant="outline" 
                size="sm" 
                onClick={handleClearCart}
                className="text-muted-foreground hover:text-destructive"
              >
                <Trash2 className="w-4 h-4" />
              </Button>
            </div>
          </CardFooter>
        )}

        {/* QR Payment Modal */}
        <CartQRPayment
          isOpen={isQRPaymentOpen}
          onClose={() => setIsQRPaymentOpen(false)}
          onSuccess={handlePaymentSuccess}
        />
      </Card>
    </>
  );
}
