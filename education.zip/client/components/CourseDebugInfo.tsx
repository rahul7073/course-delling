import React, { useState } from 'react';
import { Button } from './ui/button';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from './ui/dialog';
import { Badge } from './ui/badge';
import { useData } from '../contexts/DataContext';
import { databaseService } from '../services/DatabaseService';
import {
  Bug,
  CheckCircle,
  AlertTriangle,
  X,
  Eye,
  Database
} from 'lucide-react';

interface CourseDebugInfoProps {
  courseId: string;
  courseName: string;
}

const CourseDebugInfo: React.FC<CourseDebugInfoProps> = ({ courseId, courseName }) => {
  const [isOpen, setIsOpen] = useState(false);
  const { courses } = useData();
  
  const course = courses.find(c => c.id === courseId);

  const getValidationResult = () => {
    if (!course) return { valid: false, errors: ['Course not found'] };
    
    // Use the same validation logic as DatabaseService
    const errors: string[] = [];
    
    if (!course.title?.trim()) {
      errors.push('Course title is required');
    }
    
    if (!course.price && course.price !== 0) {
      errors.push('Course price is required');
    }
    
    return {
      valid: errors.length === 0,
      errors
    };
  };

  const getCourseStructure = () => {
    if (!course) return null;

    return {
      basic: {
        title: course.title || 'No title',
        description: course.description || 'No description',
        price: course.price ?? 'No price set',
        isPublished: course.isPublished || false,
        isFree: course.isFree || false
      },
      content: {
        classesCount: course.classes?.length || 0,
        totalVideos: course.classes?.reduce((total: number, cls: any) => total + (cls.videos?.length || 0), 0) || 0,
        totalNotes: course.classes?.reduce((total: number, cls: any) => total + (cls.notes?.length || 0), 0) || 0,
        totalProjects: course.classes?.reduce((total: number, cls: any) => total + (cls.projects?.length || 0), 0) || 0
      },
      classes: course.classes?.map((cls: any, index: number) => ({
        index: index + 1,
        title: cls.title || 'No title',
        description: cls.description || 'No description',
        isDemo: cls.isDemo || false,
        videosCount: cls.videos?.length || 0,
        notesCount: cls.notes?.length || 0,
        projectsCount: cls.projects?.length || 0,
        hasContent: (cls.videos?.length || 0) + (cls.notes?.length || 0) + (cls.projects?.length || 0) > 0
      })) || []
    };
  };

  const testPublish = async () => {
    if (!course) return;
    
    console.log('🧪 Testing publish validation for course:', course.title);
    
    try {
      const result = await databaseService.publishCourse(courseId);
      console.log('Publish test result:', result);
      
      if (result.success) {
        alert('✅ Course validation passed! Publishing should work.');
      } else {
        alert(`❌ Publish would fail: ${result.message}`);
      }
    } catch (error) {
      alert(`❌ Publish test failed: ${error instanceof Error ? error.message : 'Unknown error'}`);
    }
  };

  const validation = getValidationResult();
  const structure = getCourseStructure();

  if (!course || !structure) {
    return (
      <Button variant="outline" size="sm" disabled>
        <Bug className="w-3 h-3 mr-1" />
        Debug (Course Not Found)
      </Button>
    );
  }

  return (
    <>
      <Button variant="outline" size="sm" onClick={() => setIsOpen(true)}>
        <Bug className="w-3 h-3 mr-1" />
        Debug Info
      </Button>

      <Dialog open={isOpen} onOpenChange={setIsOpen}>
        <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <Bug className="w-5 h-5 text-blue-600" />
              Course Debug Info: {courseName}
            </DialogTitle>
          </DialogHeader>

          <div className="space-y-4">
            {/* Validation Status */}
            <Card className={validation.valid ? 'border-green-200 bg-green-50' : 'border-red-200 bg-red-50'}>
              <CardHeader className="pb-3">
                <CardTitle className="text-sm flex items-center gap-2">
                  {validation.valid ? (
                    <CheckCircle className="w-4 h-4 text-green-600" />
                  ) : (
                    <AlertTriangle className="w-4 h-4 text-red-600" />
                  )}
                  Publish Validation
                </CardTitle>
              </CardHeader>
              <CardContent>
                {validation.valid ? (
                  <div className="text-green-700 text-sm">
                    ✅ Course meets all requirements for publishing
                  </div>
                ) : (
                  <div className="space-y-1">
                    <div className="text-red-700 text-sm font-semibold">❌ Validation Errors:</div>
                    {validation.errors.map((error, index) => (
                      <div key={index} className="text-red-600 text-xs">• {error}</div>
                    ))}
                  </div>
                )}
              </CardContent>
            </Card>

            {/* Basic Info */}
            <Card>
              <CardHeader className="pb-3">
                <CardTitle className="text-sm">Basic Information</CardTitle>
              </CardHeader>
              <CardContent className="space-y-2 text-xs">
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <span className="font-semibold">Title:</span> {structure.basic.title}
                  </div>
                  <div>
                    <span className="font-semibold">Price:</span> ₹{structure.basic.price}
                  </div>
                  <div>
                    <span className="font-semibold">Published:</span> 
                    <Badge variant={structure.basic.isPublished ? 'default' : 'secondary'} className="ml-1">
                      {structure.basic.isPublished ? 'Yes' : 'No'}
                    </Badge>
                  </div>
                  <div>
                    <span className="font-semibold">Free:</span>
                    <Badge variant={structure.basic.isFree ? 'secondary' : 'outline'} className="ml-1">
                      {structure.basic.isFree ? 'Yes' : 'No'}
                    </Badge>
                  </div>
                </div>
                <div>
                  <span className="font-semibold">Description:</span> {structure.basic.description}
                </div>
              </CardContent>
            </Card>

            {/* Content Summary */}
            <Card>
              <CardHeader className="pb-3">
                <CardTitle className="text-sm">Content Summary</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-4 gap-4 text-center">
                  <div>
                    <div className="text-lg font-bold">{structure.content.classesCount}</div>
                    <div className="text-xs text-gray-600">Classes</div>
                  </div>
                  <div>
                    <div className="text-lg font-bold text-red-600">{structure.content.totalVideos}</div>
                    <div className="text-xs text-gray-600">Videos</div>
                  </div>
                  <div>
                    <div className="text-lg font-bold text-blue-600">{structure.content.totalNotes}</div>
                    <div className="text-xs text-gray-600">Notes</div>
                  </div>
                  <div>
                    <div className="text-lg font-bold text-purple-600">{structure.content.totalProjects}</div>
                    <div className="text-xs text-gray-600">Projects</div>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Classes Detail */}
            {structure.classes.length > 0 && (
              <Card>
                <CardHeader className="pb-3">
                  <CardTitle className="text-sm">Classes Breakdown</CardTitle>
                </CardHeader>
                <CardContent className="space-y-2">
                  {structure.classes.map((cls, index) => (
                    <div key={index} className="border rounded p-2">
                      <div className="flex items-center justify-between mb-1">
                        <span className="font-semibold text-sm">Class {cls.index}: {cls.title}</span>
                        <div className="flex items-center gap-1">
                          {cls.isDemo && <Badge variant="secondary" className="text-xs">Demo</Badge>}
                          <Badge variant={cls.hasContent ? 'default' : 'outline'} className="text-xs">
                            {cls.hasContent ? 'Has Content' : 'Empty'}
                          </Badge>
                        </div>
                      </div>
                      <div className="text-xs text-gray-600 mb-1">{cls.description}</div>
                      <div className="flex gap-4 text-xs">
                        <span>Videos: {cls.videosCount}</span>
                        <span>Notes: {cls.notesCount}</span>
                        <span>Projects: {cls.projectsCount}</span>
                      </div>
                    </div>
                  ))}
                </CardContent>
              </Card>
            )}

            {/* Action Buttons */}
            <div className="flex gap-3 pt-4">
              <Button variant="outline" onClick={() => setIsOpen(false)} className="flex-1">
                <X className="w-4 h-4 mr-2" />
                Close
              </Button>
              <Button onClick={testPublish} className="flex-1">
                <Database className="w-4 h-4 mr-2" />
                Test Publish
              </Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>
    </>
  );
};

export default CourseDebugInfo;
