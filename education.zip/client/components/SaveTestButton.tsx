import React from 'react';
import { Button } from './ui/button';
import { useToast } from '@/hooks/use-toast';
import { useData } from '../contexts/DataContext';

interface SaveTestButtonProps {
  courseId: string;
}

const SaveTestButton: React.FC<SaveTestButtonProps> = ({ courseId }) => {
  const { courses, addCourseClass, updateCourseClass } = useData();
  const { toast } = useToast();

  const testSave = () => {
    const course = courses.find(c => c.id === courseId);
    if (!course) {
      toast({
        title: "Course not found",
        variant: "destructive"
      });
      return;
    }

    // Test adding a new class with content
    const testClassNumber = (course.classes?.length || 0) + 1;
    
    addCourseClass(courseId, {
      classNumber: testClassNumber,
      title: `Test Class ${testClassNumber}`,
      description: `Test class ${testClassNumber} description`,
      isDemo: false,
      videos: [
        {
          id: `test_video_${Date.now()}`,
          title: 'Test Video',
          description: 'Test video description',
          videoUrl: 'test_video_url',
          duration: '10:00',
          uploadDate: new Date().toISOString().split('T')[0],
          order: 1,
          isPreview: false,
          classNumber: testClassNumber
        }
      ],
      notes: [
        {
          id: `test_note_${Date.now()}`,
          title: 'Test Notes',
          description: 'Test notes description',
          fileUrl: 'test_notes_url',
          fileSize: '1.5 MB',
          uploadDate: new Date().toISOString().split('T')[0],
          classNumber: testClassNumber
        }
      ],
      projects: [
        {
          id: `test_project_${Date.now()}`,
          title: 'Test Project',
          description: 'Test project description',
          codeFiles: [
            {
              fileName: 'test.js',
              fileUrl: 'test_code_url',
              language: 'javascript'
            }
          ],
          uploadDate: new Date().toISOString().split('T')[0],
          difficulty: 'easy' as const,
          classNumber: testClassNumber
        }
      ]
    });

    toast({
      title: "Test class added!",
      description: `Test Class ${testClassNumber} with video, notes, and code has been added`,
    });

    // Verify localStorage
    setTimeout(() => {
      const savedCourses = localStorage.getItem('edumaster_courses');
      if (savedCourses) {
        const coursesData = JSON.parse(savedCourses);
        const updatedCourse = coursesData.find((c: any) => c.id === courseId);
        if (updatedCourse && updatedCourse.classes?.length > 0) {
          const lastClass = updatedCourse.classes[updatedCourse.classes.length - 1];
          toast({
            title: "Save verification ✓",
            description: `Course saved with ${updatedCourse.classes.length} classes. Last class has ${lastClass.videos?.length || 0} videos, ${lastClass.notes?.length || 0} notes, ${lastClass.projects?.length || 0} projects`,
          });
        }
      }
    }, 500);
  };

  return (
    <Button onClick={testSave} variant="outline" size="sm">
      🧪 Test Save
    </Button>
  );
};

export default SaveTestButton;
