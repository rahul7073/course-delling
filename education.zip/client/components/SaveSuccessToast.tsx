import { useToast } from '@/hooks/use-toast';

export const useSaveSuccessToast = () => {
  const { toast } = useToast();

  const showVideoSaveSuccess = (classNumber: number, videoTitle: string) => {
    toast({
      title: "✅ Video Content Saved Successfully!",
      description: (
        <div className="space-y-2">
          <p>📹 <strong>{videoTitle}</strong> saved to Class {classNumber}</p>
          <div className="text-sm text-green-700 bg-green-50 p-2 rounded">
            ✓ Video is now playable on website<br/>
            ✓ Available to students who purchase the course<br/>
            ✓ Demo class content is publicly visible
          </div>
        </div>
      ),
    });
  };

  const showNotesSaveSuccess = (classNumber: number, notesTitle: string) => {
    toast({
      title: "✅ Notes Content Saved Successfully!",
      description: (
        <div className="space-y-2">
          <p>📝 <strong>{notesTitle}</strong> saved to Class {classNumber}</p>
          <div className="text-sm text-blue-700 bg-blue-50 p-2 rounded">
            ✓ Notes are now downloadable on website<br/>
            ✓ Real file download functionality active<br/>
            ✓ Available after course purchase
          </div>
        </div>
      ),
    });
  };

  const showProjectSaveSuccess = (classNumber: number, projectTitle: string, fileCount: number) => {
    toast({
      title: "✅ Project Content Saved Successfully!",
      description: (
        <div className="space-y-2">
          <p>💻 <strong>{projectTitle}</strong> with {fileCount} code files saved to Class {classNumber}</p>
          <div className="text-sm text-purple-700 bg-purple-50 p-2 rounded">
            ✓ All code files are downloadable on website<br/>
            ✓ Project details visible to students<br/>
            ✓ Available after course purchase
          </div>
        </div>
      ),
    });
  };

  return {
    showVideoSaveSuccess,
    showNotesSaveSuccess,
    showProjectSaveSuccess
  };
};
