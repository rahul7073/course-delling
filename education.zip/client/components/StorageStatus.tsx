import React, { useState, useEffect } from 'react';
import { Button } from './ui/button';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Badge } from './ui/badge';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from './ui/dialog';
import { storageManager } from '../utils/storageManager';
import { HardDrive, Trash2, AlertTriangle, CheckCircle } from 'lucide-react';

const StorageStatus: React.FC = () => {
  const [storageStats, setStorageStats] = useState<any>(null);
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const [isCleaningUp, setIsCleaningUp] = useState(false);

  useEffect(() => {
    updateStorageStats();
  }, []);

  const updateStorageStats = () => {
    const stats = storageManager.getStorageStats();
    const warningLevel = storageManager.getStorageWarningLevel();
    setStorageStats({ ...stats, warningLevel });
  };

  const handleCleanup = async () => {
    setIsCleaningUp(true);
    try {
      const result = storageManager.cleanup();
      if (result.success) {
        updateStorageStats();
        alert('Storage cleanup completed successfully!');
      } else {
        alert('Cleanup failed: ' + result.error);
      }
    } catch (error) {
      alert('Cleanup error: ' + (error instanceof Error ? error.message : 'Unknown error'));
    } finally {
      setIsCleaningUp(false);
    }
  };

  const handleEmergencyCleanup = async () => {
    if (!confirm('Emergency cleanup will remove ALL uploaded files to free space. Continue?')) {
      return;
    }

    setIsCleaningUp(true);
    try {
      const result = storageManager.emergencyCleanup();
      if (result.success) {
        updateStorageStats();
        alert('Emergency cleanup completed! Storage has been optimized for essential data only.');
      } else {
        alert('Emergency cleanup failed: ' + result.error);
      }
    } catch (error) {
      alert('Emergency cleanup error: ' + (error instanceof Error ? error.message : 'Unknown error'));
    } finally {
      setIsCleaningUp(false);
    }
  };

  const handleClearAll = async () => {
    if (!confirm('This will clear ALL data except user accounts. Are you sure?')) {
      return;
    }

    setIsCleaningUp(true);
    try {
      // Clear everything except users
      localStorage.removeItem('edumaster_courses');
      localStorage.removeItem('edumaster_orders');
      localStorage.removeItem('edumaster_cart');
      localStorage.removeItem('edumaster_user_progress');

      updateStorageStats();
      alert('All data cleared! Storage is now available for new content.');
    } catch (error) {
      alert('Clear all failed: ' + (error instanceof Error ? error.message : 'Unknown error'));
    } finally {
      setIsCleaningUp(false);
    }
  };

  const handleNuclearCleanup = async () => {
    if (!confirm('NUCLEAR CLEANUP: This will completely clear ALL browser storage including user accounts. Only use if storage is completely locked. Continue?')) {
      return;
    }

    setIsCleaningUp(true);
    try {
      const result = storageManager.nuclearCleanup();
      if (result.success) {
        updateStorageStats();
        alert('Nuclear cleanup completed! ALL storage has been cleared. Please refresh the page.');
        window.location.reload();
      } else {
        alert('Nuclear cleanup failed: ' + result.error);
      }
    } catch (error) {
      alert('Nuclear cleanup error: ' + (error instanceof Error ? error.message : 'Unknown error'));
    } finally {
      setIsCleaningUp(false);
    }
  };

  if (!storageStats) return null;

  const getStatusColor = () => {
    switch (storageStats.warningLevel) {
      case 'safe': return 'text-green-600';
      case 'warning': return 'text-yellow-600';
      case 'critical': return 'text-red-600';
      default: return 'text-gray-600';
    }
  };

  const getStatusIcon = () => {
    switch (storageStats.warningLevel) {
      case 'safe': return <CheckCircle className="w-4 h-4 text-green-600" />;
      case 'warning': return <AlertTriangle className="w-4 h-4 text-yellow-600" />;
      case 'critical': return <AlertTriangle className="w-4 h-4 text-red-600" />;
      default: return <HardDrive className="w-4 h-4 text-gray-600" />;
    }
  };

  return (
    <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
      <DialogTrigger asChild>
        <Button variant="outline" size="sm" className="flex items-center gap-2">
          {getStatusIcon()}
          Storage: {storageStats.percentUsed.toFixed(1)}%
          <Badge variant={storageStats.warningLevel === 'critical' ? 'destructive' : 'secondary'}>
            {storageStats.warningLevel}
          </Badge>
        </Button>
      </DialogTrigger>
      <DialogContent>
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <HardDrive className="w-5 h-5" />
            Browser Storage Status
          </DialogTitle>
        </DialogHeader>
        
        <div className="space-y-4">
          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-lg">Storage Usage</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-2">
                <div className="flex justify-between">
                  <span>Used:</span>
                  <span className={getStatusColor()}>{storageManager.formatBytes(storageStats.used)}</span>
                </div>
                <div className="flex justify-between">
                  <span>Total:</span>
                  <span>{storageManager.formatBytes(storageStats.total)}</span>
                </div>
                <div className="flex justify-between">
                  <span>Available:</span>
                  <span>{storageManager.formatBytes(storageStats.available)}</span>
                </div>
                <div className="w-full bg-gray-200 rounded-full h-2">
                  <div 
                    className={`h-2 rounded-full ${
                      storageStats.warningLevel === 'critical' ? 'bg-red-500' :
                      storageStats.warningLevel === 'warning' ? 'bg-yellow-500' :
                      'bg-green-500'
                    }`}
                    style={{ width: `${Math.min(storageStats.percentUsed, 100)}%` }}
                  ></div>
                </div>
                <p className="text-sm text-center">
                  {storageStats.percentUsed.toFixed(1)}% used
                </p>
              </div>
            </CardContent>
          </Card>

          {storageStats.warningLevel !== 'safe' && (
            <Card className="border-yellow-200 bg-yellow-50">
              <CardContent className="pt-4">
                <div className="flex items-center gap-2 mb-2">
                  <AlertTriangle className="w-4 h-4 text-yellow-600" />
                  <span className="font-medium text-yellow-800">Storage Warning</span>
                </div>
                <p className="text-sm text-yellow-700 mb-3">
                  {storageStats.warningLevel === 'critical' 
                    ? 'Storage is critically full. New uploads may fail.'
                    : 'Storage usage is high. Consider cleaning up old data.'
                  }
                </p>
                <div className="flex gap-2">
                  <Button 
                    onClick={handleCleanup} 
                    disabled={isCleaningUp}
                    size="sm"
                    variant="outline"
                  >
                    <Trash2 className="w-3 h-3 mr-1" />
                    {isCleaningUp ? 'Cleaning...' : 'Clean Storage'}
                  </Button>
                  {storageStats.warningLevel === 'critical' && (
                    <>
                      <Button
                        onClick={handleEmergencyCleanup}
                        disabled={isCleaningUp}
                        size="sm"
                        variant="destructive"
                      >
                        Emergency Cleanup
                      </Button>
                      {storageStats.percentUsed > 95 && (
                        <>
                          <Button
                            onClick={handleClearAll}
                            disabled={isCleaningUp}
                            size="sm"
                            variant="destructive"
                            className="bg-red-600 hover:bg-red-700"
                          >
                            Clear All Data
                          </Button>
                          {storageStats.percentUsed > 98 && (
                            <Button
                              onClick={handleNuclearCleanup}
                              disabled={isCleaningUp}
                              size="sm"
                              variant="destructive"
                              className="bg-black hover:bg-gray-800 text-white"
                            >
                              ☢️ Nuclear Cleanup
                            </Button>
                          )}
                        </>
                      )}
                    </>
                  )}
                </div>
              </CardContent>
            </Card>
          )}

          <div className="text-xs text-gray-500 space-y-1">
            <p>• Regular cleanup removes temporary files and old data</p>
            <p>• Emergency cleanup removes ALL uploaded files to free maximum space</p>
            <p>• Large video files consume the most storage space</p>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
};

export default StorageStatus;
