import React, { useEffect } from 'react';
import { autoMigrate } from '../utils/dataMigration';

const AutoMigration: React.FC = () => {
  useEffect(() => {
    // Run auto-migration on app start
    const runMigration = async () => {
      try {
        await autoMigrate();
      } catch (error) {
        console.error('Auto-migration failed:', error);
      }
    };

    // Run migration after a short delay to avoid blocking initial render
    const timeoutId = setTimeout(runMigration, 1000);
    
    return () => clearTimeout(timeoutId);
  }, []);

  // This component doesn't render anything
  return null;
};

export default AutoMigration;
