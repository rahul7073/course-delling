import React from 'react';
import { Button } from './ui/button';
import { Card, CardContent } from './ui/card';
import { Construction, ArrowLeft } from 'lucide-react';
import { Link } from 'react-router-dom';

interface PlaceholderPageProps {
  title: string;
  description: string;
  suggestions?: string[];
}

export function PlaceholderPage({ title, description, suggestions = [] }: PlaceholderPageProps) {
  return (
    <div className="min-h-[60vh] flex items-center justify-center py-12">
      <Card className="max-w-md w-full mx-4">
        <CardContent className="pt-6 text-center">
          <div className="w-16 h-16 mx-auto mb-4 bg-muted rounded-full flex items-center justify-center">
            <Construction className="w-8 h-8 text-muted-foreground" />
          </div>
          
          <h1 className="text-2xl font-bold mb-2">{title}</h1>
          <p className="text-muted-foreground mb-6">{description}</p>
          
          {suggestions.length > 0 && (
            <div className="mb-6">
              <p className="text-sm font-medium mb-3">You can help us build this by asking for:</p>
              <ul className="text-sm text-muted-foreground space-y-1">
                {suggestions.map((suggestion, index) => (
                  <li key={index}>• {suggestion}</li>
                ))}
              </ul>
            </div>
          )}
          
          <div className="space-y-3">
            <Button asChild>
              <Link to="/">
                <ArrowLeft className="w-4 h-4 mr-2" />
                Back to Home
              </Link>
            </Button>
            <p className="text-xs text-muted-foreground">
              Continue prompting to help us build this page with the features you need!
            </p>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
