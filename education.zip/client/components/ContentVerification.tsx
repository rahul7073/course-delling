import React from 'react';
import { useData } from '../contexts/DataContext';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Badge } from './ui/badge';
import { Button } from './ui/button';
import { useToast } from '@/hooks/use-toast';
import { BookOpen, Play, FileText, Code, CheckCircle, AlertCircle } from 'lucide-react';

interface ContentVerificationProps {
  courseId: string;
}

const ContentVerification: React.FC<ContentVerificationProps> = ({ courseId }) => {
  const { courses } = useData();
  const { toast } = useToast();
  const course = courses.find(c => c.id === courseId);

  if (!course) {
    return <div>Course not found</div>;
  }

  const verifyAndShowStatus = () => {
    const totalClasses = course.classes?.length || 0;
    const totalVideos = course.classes?.reduce((total, cls) => total + (cls.videos?.length || 0), 0) || 0;
    const totalNotes = course.classes?.reduce((total, cls) => total + (cls.notes?.length || 0), 0) || 0;
    const totalProjects = course.classes?.reduce((total, cls) => total + (cls.projects?.length || 0), 0) || 0;
    const totalContent = totalVideos + totalNotes + totalProjects;

    // Check localStorage
    const savedCourses = localStorage.getItem('edumaster_courses');
    let savedCourse = null;
    if (savedCourses) {
      const coursesData = JSON.parse(savedCourses);
      savedCourse = coursesData.find((c: any) => c.id === courseId);
    }

    const status = {
      isCourseSaved: !!savedCourse,
      hasClasses: totalClasses > 0,
      hasContent: totalContent > 0,
      classDetails: course.classes?.map((cls: any) => ({
        classNumber: cls.classNumber,
        title: cls.title,
        videos: cls.videos?.length || 0,
        notes: cls.notes?.length || 0,
        projects: cls.projects?.length || 0,
        hasContent: (cls.videos?.length || 0) + (cls.notes?.length || 0) + (cls.projects?.length || 0) > 0
      })) || []
    };

    toast({
      title: status.hasContent ? "✅ Content Verification Passed!" : "⚠️ No Content Found",
      description: `Course has ${totalClasses} classes with ${totalContent} total items (${totalVideos} videos, ${totalNotes} notes, ${totalProjects} projects)`,
    });

    return status;
  };

  const totalContent = course.classes?.reduce((total, cls) => 
    total + (cls.videos?.length || 0) + (cls.notes?.length || 0) + (cls.projects?.length || 0), 0) || 0;

  return (
    <Card className="mt-4 border-2 border-blue-200">
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <CheckCircle className="w-5 h-5 text-green-600" />
          Content Verification - {course.title}
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        {/* Overall Status */}
        <div className="grid grid-cols-4 gap-4 p-4 bg-gray-50 rounded-lg">
          <div className="text-center">
            <div className="text-2xl font-bold text-blue-600">{course.classes?.length || 0}</div>
            <div className="text-sm text-gray-600">Classes</div>
          </div>
          <div className="text-center">
            <div className="text-2xl font-bold text-green-600">
              {course.classes?.reduce((total, cls) => total + (cls.videos?.length || 0), 0) || 0}
            </div>
            <div className="text-sm text-gray-600">Videos</div>
          </div>
          <div className="text-center">
            <div className="text-2xl font-bold text-purple-600">
              {course.classes?.reduce((total, cls) => total + (cls.notes?.length || 0), 0) || 0}
            </div>
            <div className="text-sm text-gray-600">Notes</div>
          </div>
          <div className="text-center">
            <div className="text-2xl font-bold text-orange-600">
              {course.classes?.reduce((total, cls) => total + (cls.projects?.length || 0), 0) || 0}
            </div>
            <div className="text-sm text-gray-600">Projects</div>
          </div>
        </div>

        {/* Classes Detail */}
        <div className="space-y-2">
          <h4 className="font-medium">Classes Status:</h4>
          {course.classes?.length > 0 ? (
            course.classes.map((cls: any) => {
              const classContent = (cls.videos?.length || 0) + (cls.notes?.length || 0) + (cls.projects?.length || 0);
              return (
                <div key={cls.id} className="flex items-center justify-between p-3 bg-white border rounded-lg">
                  <div className="flex items-center gap-3">
                    <div className="w-8 h-8 bg-blue-100 rounded-full flex items-center justify-center">
                      <span className="text-sm font-bold text-blue-600">{cls.classNumber}</span>
                    </div>
                    <div>
                      <h5 className="font-medium">{cls.title}</h5>
                      <div className="flex items-center gap-2 text-xs">
                        <Badge variant="outline" className="text-green-600">🎥 {cls.videos?.length || 0}</Badge>
                        <Badge variant="outline" className="text-blue-600">📝 {cls.notes?.length || 0}</Badge>
                        <Badge variant="outline" className="text-purple-600">💻 {cls.projects?.length || 0}</Badge>
                      </div>
                    </div>
                  </div>
                  <div className="flex items-center gap-2">
                    {classContent > 0 ? (
                      <Badge className="bg-green-100 text-green-800">
                        ✅ {classContent} items saved
                      </Badge>
                    ) : (
                      <Badge variant="secondary" className="bg-gray-100">
                        ⚪ No content
                      </Badge>
                    )}
                  </div>
                </div>
              );
            })
          ) : (
            <div className="text-center py-4 text-gray-500">
              No classes created yet
            </div>
          )}
        </div>

        {/* Verification Button */}
        <div className="flex justify-center">
          <Button 
            onClick={verifyAndShowStatus}
            className="bg-blue-600 hover:bg-blue-700"
          >
            🔍 Verify Content & Show on Website
          </Button>
        </div>

        {/* Website Status */}
        <div className="p-4 bg-green-50 border border-green-200 rounded-lg">
          <div className="flex items-center gap-2 mb-2">
            <CheckCircle className="w-5 h-5 text-green-600" />
            <h4 className="font-medium text-green-800">Website Display Status</h4>
          </div>
          <div className="text-sm text-green-700">
            {totalContent > 0 ? (
              <>
                ✅ Course content is saved and will display on website<br/>
                ✅ Videos will be playable for purchased users<br/>
                ✅ Notes and projects will be downloadable<br/>
                ✅ Demo class (Class 1) content is publicly visible
              </>
            ) : (
              <>
                ⚠️ No content uploaded yet<br/>
                📝 Upload videos, notes, and projects to make them visible on website
              </>
            )}
          </div>
        </div>
      </CardContent>
    </Card>
  );
};

export default ContentVerification;
