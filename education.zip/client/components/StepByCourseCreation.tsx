import React, { useState, useRef } from 'react';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Textarea } from './ui/textarea';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Badge } from './ui/badge';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from './ui/dialog';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from './ui/select';
import { Switch } from './ui/switch';
import { Label } from './ui/label';
import { useToast } from '@/hooks/use-toast';
import { useData } from '../contexts/DataContext';
import { fileToDataURL } from '../utils/fileDownload';
import {
  Plus,
  Upload,
  Save,
  ChevronRight,
  ChevronLeft,
  BookOpen,
  Video,
  FileText,
  Code,
  User,
  Clock,
  DollarSign,
  Star,
  Play,
  CheckCircle,
  Edit,
  X
} from 'lucide-react';

interface StepByCourseCreationProps {
  isOpen: boolean;
  onClose: () => void;
  onSuccess: () => void;
}

type Step = 'course-info' | 'class-setup' | 'class-video' | 'class-notes' | 'class-projects' | 'complete';

const StepByCourseCreation: React.FC<StepByCourseCreationProps> = ({ isOpen, onClose, onSuccess }) => {
  const [currentStep, setCurrentStep] = useState<Step>('course-info');
  const [courseData, setCourseData] = useState<any>({});
  const [currentClass, setCurrentClass] = useState<any>({});
  const [createdCourse, setCreatedCourse] = useState<any>(null);
  const [classNumber, setClassNumber] = useState(1);
  const [allClasses, setAllClasses] = useState<any[]>([]);
  
  const { addCourse, addCourseClass, addCourseVideo, addCourseNote, addCourseProject } = useData();
  const { toast } = useToast();
  
  const thumbnailRef = useRef<HTMLInputElement>(null);
  const videoRef = useRef<HTMLInputElement>(null);
  const noteRef = useRef<HTMLInputElement>(null);

  // Step 1: Course Information
  const handleCourseSubmit = async () => {
    if (!courseData.title || !courseData.price || !courseData.duration || !courseData.expectedClasses) {
      toast({
        title: "❌ Required Fields Missing",
        description: "Please fill in all required fields",
        variant: "destructive"
      });
      return;
    }

    // Create the course
    const courseId = addCourse({
      title: courseData.title,
      description: courseData.description || `Complete ${courseData.title} course`,
      shortDescription: courseData.shortDescription || courseData.title,
      instructor: {
        id: '1',
        name: courseData.instructorName || 'Code Nest',
        avatar: '',
        bio: 'Experienced instructor'
      },
      category: courseData.category || 'Programming',
      tags: [courseData.level || 'beginner'],
      price: parseInt(courseData.price) || 0,
      currency: 'INR',
      level: courseData.level as 'beginner' | 'intermediate' | 'advanced' || 'beginner',
      duration: courseData.duration,
      totalLessons: parseInt(courseData.expectedClasses) || 1,
      totalStudents: 0,
      rating: 0,
      reviewCount: 0,
      thumbnail: courseData.thumbnailUrl || 'https://images.unsplash.com/photo-1516321318423-f06f85e504b3?w=400',
      previewVideo: '',
      isFree: parseInt(courseData.price) === 0,
      isPopular: false,
      isNew: true,
      isPublished: false,
      features: ['Video Lessons', 'Notes', 'Projects', 'Certificate'],
      learningOutcomes: ['Master the fundamentals', 'Build real projects', 'Get certified'],
      requirements: ['Basic computer knowledge'],
      classes: [],
      notes: [],
      videos: [],
      projects: [],
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString()
    });

    const newCourse = { id: courseId, ...courseData };
    setCreatedCourse(newCourse);

    toast({
      title: "✅ Course Created Successfully!",
      description: `"${courseData.title}" is ready for content`,
      duration: 3000
    });

    setCurrentStep('class-setup');
  };

  // Step 2: Class Setup
  const handleClassSetup = () => {
    if (!currentClass.title || !currentClass.description) {
      toast({
        title: "❌ Class Information Required",
        description: "Please fill in class title and description",
        variant: "destructive"
      });
      return;
    }

    setCurrentStep('class-video');
  };

  // Step 3: Class Video Upload
  const handleVideoUpload = async () => {
    const file = videoRef.current?.files?.[0];
    if (!file) {
      toast({
        title: "❌ Video Required",
        description: "Please select a video file",
        variant: "destructive"
      });
      return;
    }

    try {
      const videoUrl = await fileToDataURL(file);
      setCurrentClass(prev => ({ ...prev, videoUrl, videoFile: file }));
      
      toast({
        title: "✅ Video Uploaded",
        description: "Video uploaded successfully",
      });

      setCurrentStep('class-notes');
    } catch (error) {
      toast({
        title: "❌ Video Upload Failed",
        description: "Please try again",
        variant: "destructive"
      });
    }
  };

  // Step 4: Class Notes Upload  
  const handleNotesUpload = async () => {
    const file = noteRef.current?.files?.[0];
    if (file) {
      try {
        const noteUrl = await fileToDataURL(file);
        setCurrentClass(prev => ({ ...prev, noteUrl, noteFile: file }));
        
        toast({
          title: "✅ Notes Uploaded",
          description: "Notes uploaded successfully",
        });
      } catch (error) {
        toast({
          title: "❌ Notes Upload Failed",
          description: "Please try again",
          variant: "destructive"
        });
        return;
      }
    }

    setCurrentStep('class-projects');
  };

  // Step 5: Projects Setup
  const handleProjectSetup = () => {
    setCurrentStep('complete');
  };

  // Step 6: Complete Class and Save
  const handleCompleteClass = async () => {
    if (!createdCourse) return;

    // Add class to course
    addCourseClass(createdCourse.id, {
      classNumber: classNumber,
      title: currentClass.title,
      description: currentClass.description,
      isDemo: currentClass.isDemo || false,
      videos: [],
      notes: [],
      projects: []
    });

    // Add video if uploaded
    if (currentClass.videoUrl) {
      addCourseVideo(createdCourse.id, {
        title: `${currentClass.title} - Main Video`,
        description: currentClass.description,
        videoUrl: currentClass.videoUrl,
        duration: currentClass.duration || '10:00',
        thumbnailUrl: '',
        uploadDate: new Date().toISOString(),
        order: 1,
        isPreview: currentClass.isDemo || false,
        classNumber: classNumber
      });
    }

    // Add notes if uploaded
    if (currentClass.noteUrl) {
      addCourseNote(createdCourse.id, {
        title: `${currentClass.title} - Notes`,
        description: 'Class notes and materials',
        fileUrl: currentClass.noteUrl,
        fileSize: currentClass.noteFile ? `${(currentClass.noteFile.size / 1024 / 1024).toFixed(2)} MB` : '1 MB',
        uploadDate: new Date().toISOString(),
        classNumber: classNumber
      });
    }

    // Add project if specified
    if (currentClass.projectTitle) {
      addCourseProject(createdCourse.id, {
        title: currentClass.projectTitle,
        description: currentClass.projectDescription || 'Class project',
        codeFiles: [],
        liveUrl: '',
        uploadDate: new Date().toISOString(),
        classNumber: classNumber
      });
    }

    // Add to all classes list
    setAllClasses(prev => [...prev, { ...currentClass, classNumber }]);

    toast({
      title: `✅ Class ${classNumber} Added Successfully!`,
      description: `${currentClass.title} has been saved to the course`,
      duration: 3000
    });

    // Reset for next class
    setCurrentClass({});
    setClassNumber(prev => prev + 1);
    setCurrentStep('class-setup');
  };

  const handleThumbnailUpload = async () => {
    const file = thumbnailRef.current?.files?.[0];
    if (file) {
      try {
        const thumbnailUrl = await fileToDataURL(file);
        setCourseData(prev => ({ ...prev, thumbnailUrl }));
        
        toast({
          title: "✅ Thumbnail Uploaded",
          description: "Course thumbnail uploaded successfully",
        });
      } catch (error) {
        toast({
          title: "❌ Thumbnail Upload Failed",
          description: "Please try again",
          variant: "destructive"
        });
      }
    }
  };

  const getStepTitle = () => {
    switch (currentStep) {
      case 'course-info': return 'Create New Course';
      case 'class-setup': return `${createdCourse?.title} - Add Class ${classNumber}`;
      case 'class-video': return `Class ${classNumber}: Upload Video`;
      case 'class-notes': return `Class ${classNumber}: Upload Notes`;
      case 'class-projects': return `Class ${classNumber}: Add Projects`;
      case 'complete': return `Class ${classNumber}: Review & Save`;
      default: return 'Course Creation';
    }
  };

  const renderCurrentStep = () => {
    switch (currentStep) {
      case 'course-info':
        return (
          <div className="space-y-6">
            <div className="text-center mb-6">
              <BookOpen className="w-12 h-12 mx-auto text-blue-600 mb-3" />
              <h3 className="text-xl font-bold">Create Your Course</h3>
              <p className="text-gray-600">Fill in the basic course information</p>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="md:col-span-2">
                <Label htmlFor="title" className="text-sm font-semibold">
                  Course Title <span className="text-red-500">*</span>
                </Label>
                <Input
                  id="title"
                  placeholder="e.g., Web Development - Complete Course"
                  value={courseData.title || ''}
                  onChange={(e) => setCourseData(prev => ({ ...prev, title: e.target.value }))}
                  className="mt-1"
                />
              </div>

              <div>
                <Label htmlFor="price" className="text-sm font-semibold">
                  Price (₹) <span className="text-red-500">*</span>
                </Label>
                <Input
                  id="price"
                  type="number"
                  placeholder="799"
                  value={courseData.price || ''}
                  onChange={(e) => setCourseData(prev => ({ ...prev, price: e.target.value }))}
                  className="mt-1"
                />
              </div>

              <div>
                <Label htmlFor="duration" className="text-sm font-semibold">
                  Duration <span className="text-red-500">*</span>
                </Label>
                <Input
                  id="duration"
                  placeholder="e.g., 8 hours, 4 weeks"
                  value={courseData.duration || ''}
                  onChange={(e) => setCourseData(prev => ({ ...prev, duration: e.target.value }))}
                  className="mt-1"
                />
              </div>

              <div>
                <Label htmlFor="expectedClasses" className="text-sm font-semibold">
                  Expected Classes <span className="text-red-500">*</span>
                </Label>
                <Input
                  id="expectedClasses"
                  type="number"
                  placeholder="10"
                  value={courseData.expectedClasses || ''}
                  onChange={(e) => setCourseData(prev => ({ ...prev, expectedClasses: e.target.value }))}
                  className="mt-1"
                />
              </div>

              <div>
                <Label htmlFor="level" className="text-sm font-semibold">
                  Target Level <span className="text-red-500">*</span>
                </Label>
                <Select value={courseData.level || ''} onValueChange={(value) => setCourseData(prev => ({ ...prev, level: value }))}>
                  <SelectTrigger className="mt-1">
                    <SelectValue placeholder="Select level" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="beginner">Beginner</SelectItem>
                    <SelectItem value="intermediate">Intermediate</SelectItem>
                    <SelectItem value="advanced">Advanced</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div>
                <Label htmlFor="category" className="text-sm font-semibold">Category</Label>
                <Select value={courseData.category || ''} onValueChange={(value) => setCourseData(prev => ({ ...prev, category: value }))}>
                  <SelectTrigger className="mt-1">
                    <SelectValue placeholder="Select category" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="programming">Programming</SelectItem>
                    <SelectItem value="web-development">Web Development</SelectItem>
                    <SelectItem value="mobile-development">Mobile Development</SelectItem>
                    <SelectItem value="data-science">Data Science</SelectItem>
                    <SelectItem value="design">Design</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div>
                <Label htmlFor="instructor" className="text-sm font-semibold">Instructor Name</Label>
                <Input
                  id="instructor"
                  placeholder="Your name"
                  value={courseData.instructorName || ''}
                  onChange={(e) => setCourseData(prev => ({ ...prev, instructorName: e.target.value }))}
                  className="mt-1"
                />
              </div>

              <div className="md:col-span-2">
                <Label htmlFor="description" className="text-sm font-semibold">Course Description</Label>
                <Textarea
                  id="description"
                  placeholder="Describe what students will learn in this course..."
                  value={courseData.description || ''}
                  onChange={(e) => setCourseData(prev => ({ ...prev, description: e.target.value }))}
                  className="mt-1"
                  rows={3}
                />
              </div>

              <div className="md:col-span-2">
                <Label className="text-sm font-semibold">Course Thumbnail</Label>
                <div className="mt-2 border-2 border-dashed border-gray-300 rounded-lg p-6 text-center">
                  {courseData.thumbnailUrl ? (
                    <div className="space-y-2">
                      <img src={courseData.thumbnailUrl} alt="Thumbnail" className="w-32 h-32 mx-auto rounded-lg object-cover" />
                      <Button variant="outline" size="sm" onClick={() => thumbnailRef.current?.click()}>
                        Change Thumbnail
                      </Button>
                    </div>
                  ) : (
                    <div className="space-y-2">
                      <Upload className="w-12 h-12 mx-auto text-gray-400" />
                      <div>
                        <Button variant="outline" onClick={() => thumbnailRef.current?.click()}>
                          <Upload className="w-4 h-4 mr-2" />
                          Upload Thumbnail
                        </Button>
                      </div>
                      <p className="text-xs text-gray-500">Recommended: 400x300px, JPG/PNG</p>
                    </div>
                  )}
                  <input
                    ref={thumbnailRef}
                    type="file"
                    accept="image/*"
                    className="hidden"
                    onChange={handleThumbnailUpload}
                  />
                </div>
              </div>
            </div>

            <div className="flex justify-end pt-4">
              <Button onClick={handleCourseSubmit} className="px-8">
                <Save className="w-4 h-4 mr-2" />
                Create Course & Add Classes
              </Button>
            </div>
          </div>
        );

      case 'class-setup':
        return (
          <div className="space-y-6">
            <div className="text-center mb-6">
              <div className="flex items-center justify-center mb-4">
                <BookOpen className="w-8 h-8 text-blue-600 mr-2" />
                <ChevronRight className="w-4 h-4 text-gray-400 mx-2" />
                <Play className="w-8 h-8 text-green-600" />
              </div>
              <h3 className="text-xl font-bold">Class {classNumber} Setup</h3>
              <p className="text-gray-600">Configure your class details</p>
              {allClasses.length > 0 && (
                <div className="mt-2">
                  <Badge variant="secondary">{allClasses.length} classes already added</Badge>
                </div>
              )}
            </div>

            <div className="space-y-4">
              <div>
                <Label htmlFor="classTitle" className="text-sm font-semibold">
                  Class Title <span className="text-red-500">*</span>
                </Label>
                <Input
                  id="classTitle"
                  placeholder={`Class ${classNumber}: Introduction to...`}
                  value={currentClass.title || ''}
                  onChange={(e) => setCurrentClass(prev => ({ ...prev, title: e.target.value }))}
                  className="mt-1"
                />
              </div>

              <div>
                <Label htmlFor="classDescription" className="text-sm font-semibold">
                  Class Description <span className="text-red-500">*</span>
                </Label>
                <Textarea
                  id="classDescription"
                  placeholder="What will students learn in this class?"
                  value={currentClass.description || ''}
                  onChange={(e) => setCurrentClass(prev => ({ ...prev, description: e.target.value }))}
                  className="mt-1"
                  rows={3}
                />
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="classDuration" className="text-sm font-semibold">
                    Class Duration
                  </Label>
                  <Input
                    id="classDuration"
                    placeholder="e.g., 15:30"
                    value={currentClass.duration || ''}
                    onChange={(e) => setCurrentClass(prev => ({ ...prev, duration: e.target.value }))}
                    className="mt-1"
                  />
                </div>

                <div>
                  <Label htmlFor="teacherName" className="text-sm font-semibold">
                    Teacher Name
                  </Label>
                  <Input
                    id="teacherName"
                    placeholder="Instructor name"
                    value={currentClass.teacherName || courseData.instructorName || ''}
                    onChange={(e) => setCurrentClass(prev => ({ ...prev, teacherName: e.target.value }))}
                    className="mt-1"
                  />
                </div>
              </div>

              <div className="flex items-center space-x-3 p-4 bg-gray-50 rounded-lg">
                <Switch
                  id="isDemo"
                  checked={currentClass.isDemo || false}
                  onCheckedChange={(checked) => setCurrentClass(prev => ({ ...prev, isDemo: checked }))}
                />
                <div className="flex-1">
                  <Label htmlFor="isDemo" className="text-sm font-semibold">
                    Demo Class
                  </Label>
                  <p className="text-xs text-gray-600">
                    {currentClass.isDemo ? 'This class will be free for preview' : 'This class requires purchase'}
                  </p>
                </div>
                <Badge variant={currentClass.isDemo ? 'default' : 'secondary'}>
                  {currentClass.isDemo ? 'FREE' : 'PAID'}
                </Badge>
              </div>
            </div>

            <div className="flex justify-between pt-4">
              <Button variant="outline" onClick={() => setCurrentStep('course-info')}>
                <ChevronLeft className="w-4 h-4 mr-2" />
                Back to Course Info
              </Button>
              <Button onClick={handleClassSetup}>
                Continue to Video Upload
                <ChevronRight className="w-4 h-4 ml-2" />
              </Button>
            </div>
          </div>
        );

      case 'class-video':
        return (
          <div className="space-y-6">
            <div className="text-center mb-6">
              <Video className="w-12 h-12 mx-auto text-red-600 mb-3" />
              <h3 className="text-xl font-bold">Upload Class Video</h3>
              <p className="text-gray-600">Upload the main video for {currentClass.title}</p>
            </div>

            <div className="border-2 border-dashed border-gray-300 rounded-lg p-8 text-center">
              {currentClass.videoUrl ? (
                <div className="space-y-4">
                  <video 
                    src={currentClass.videoUrl} 
                    controls 
                    className="w-full max-w-md mx-auto rounded-lg"
                  />
                  <div>
                    <p className="text-sm text-green-600 font-semibold">✅ Video uploaded successfully</p>
                    <Button variant="outline" size="sm" className="mt-2" onClick={() => videoRef.current?.click()}>
                      Change Video
                    </Button>
                  </div>
                </div>
              ) : (
                <div className="space-y-4">
                  <Video className="w-16 h-16 mx-auto text-gray-400" />
                  <div>
                    <Button onClick={() => videoRef.current?.click()}>
                      <Upload className="w-4 h-4 mr-2" />
                      Select Video File
                    </Button>
                  </div>
                  <p className="text-xs text-gray-500">Supported formats: MP4, AVI, MOV</p>
                </div>
              )}
              <input
                ref={videoRef}
                type="file"
                accept="video/*"
                className="hidden"
                onChange={handleVideoUpload}
              />
            </div>

            <div className="flex justify-between pt-4">
              <Button variant="outline" onClick={() => setCurrentStep('class-setup')}>
                <ChevronLeft className="w-4 h-4 mr-2" />
                Back to Class Setup
              </Button>
              <Button onClick={() => setCurrentStep('class-notes')} disabled={!currentClass.videoUrl}>
                Continue to Notes
                <ChevronRight className="w-4 h-4 ml-2" />
              </Button>
            </div>
          </div>
        );

      case 'class-notes':
        return (
          <div className="space-y-6">
            <div className="text-center mb-6">
              <FileText className="w-12 h-12 mx-auto text-blue-600 mb-3" />
              <h3 className="text-xl font-bold">Upload Class Notes</h3>
              <p className="text-gray-600">Add study materials for {currentClass.title} (Optional)</p>
            </div>

            <div className="border-2 border-dashed border-gray-300 rounded-lg p-8 text-center">
              {currentClass.noteUrl ? (
                <div className="space-y-4">
                  <FileText className="w-16 h-16 mx-auto text-green-600" />
                  <div>
                    <p className="text-sm text-green-600 font-semibold">✅ Notes uploaded successfully</p>
                    <p className="text-xs text-gray-500">File: {currentClass.noteFile?.name}</p>
                    <Button variant="outline" size="sm" className="mt-2" onClick={() => noteRef.current?.click()}>
                      Change Notes
                    </Button>
                  </div>
                </div>
              ) : (
                <div className="space-y-4">
                  <FileText className="w-16 h-16 mx-auto text-gray-400" />
                  <div>
                    <Button onClick={() => noteRef.current?.click()} variant="outline">
                      <Upload className="w-4 h-4 mr-2" />
                      Upload Notes (Optional)
                    </Button>
                  </div>
                  <p className="text-xs text-gray-500">Supported formats: PDF, DOC, TXT</p>
                </div>
              )}
              <input
                ref={noteRef}
                type="file"
                accept=".pdf,.doc,.docx,.txt"
                className="hidden"
                onChange={handleNotesUpload}
              />
            </div>

            <div className="flex justify-between pt-4">
              <Button variant="outline" onClick={() => setCurrentStep('class-video')}>
                <ChevronLeft className="w-4 h-4 mr-2" />
                Back to Video
              </Button>
              <Button onClick={handleProjectSetup}>
                Continue to Projects
                <ChevronRight className="w-4 h-4 ml-2" />
              </Button>
            </div>
          </div>
        );

      case 'class-projects':
        return (
          <div className="space-y-6">
            <div className="text-center mb-6">
              <Code className="w-12 h-12 mx-auto text-purple-600 mb-3" />
              <h3 className="text-xl font-bold">Add Class Project</h3>
              <p className="text-gray-600">Optional project for {currentClass.title}</p>
            </div>

            <div className="space-y-4">
              <div>
                <Label htmlFor="projectTitle" className="text-sm font-semibold">Project Title</Label>
                <Input
                  id="projectTitle"
                  placeholder="e.g., Build a Portfolio Website"
                  value={currentClass.projectTitle || ''}
                  onChange={(e) => setCurrentClass(prev => ({ ...prev, projectTitle: e.target.value }))}
                  className="mt-1"
                />
              </div>

              <div>
                <Label htmlFor="projectDescription" className="text-sm font-semibold">Project Description</Label>
                <Textarea
                  id="projectDescription"
                  placeholder="Describe what students will build..."
                  value={currentClass.projectDescription || ''}
                  onChange={(e) => setCurrentClass(prev => ({ ...prev, projectDescription: e.target.value }))}
                  className="mt-1"
                  rows={3}
                />
              </div>
            </div>

            <div className="flex justify-between pt-4">
              <Button variant="outline" onClick={() => setCurrentStep('class-notes')}>
                <ChevronLeft className="w-4 h-4 mr-2" />
                Back to Notes
              </Button>
              <Button onClick={() => setCurrentStep('complete')}>
                Review & Save Class
                <ChevronRight className="w-4 h-4 ml-2" />
              </Button>
            </div>
          </div>
        );

      case 'complete':
        return (
          <div className="space-y-6">
            <div className="text-center mb-6">
              <CheckCircle className="w-12 h-12 mx-auto text-green-600 mb-3" />
              <h3 className="text-xl font-bold">Review Class {classNumber}</h3>
              <p className="text-gray-600">Review and save your class content</p>
            </div>

            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Play className="w-5 h-5" />
                  {currentClass.title}
                  {currentClass.isDemo && <Badge variant="secondary">Demo</Badge>}
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <p className="text-gray-600">{currentClass.description}</p>
                
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <Label className="text-xs text-gray-500">Duration</Label>
                    <p className="font-medium">{currentClass.duration || 'Not specified'}</p>
                  </div>
                  <div>
                    <Label className="text-xs text-gray-500">Teacher</Label>
                    <p className="font-medium">{currentClass.teacherName || 'Not specified'}</p>
                  </div>
                </div>

                <div className="space-y-2">
                  <div className="flex items-center gap-2">
                    <Video className="w-4 h-4 text-red-500" />
                    <span className="text-sm">Video: {currentClass.videoUrl ? '✅ Uploaded' : '❌ Missing'}</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <FileText className="w-4 h-4 text-blue-500" />
                    <span className="text-sm">Notes: {currentClass.noteUrl ? '✅ Uploaded' : '⚪ Optional'}</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <Code className="w-4 h-4 text-purple-500" />
                    <span className="text-sm">Project: {currentClass.projectTitle ? '✅ Added' : '⚪ Optional'}</span>
                  </div>
                </div>
              </CardContent>
            </Card>

            <div className="flex justify-between pt-4">
              <Button variant="outline" onClick={() => setCurrentStep('class-projects')}>
                <ChevronLeft className="w-4 h-4 mr-2" />
                Back to Edit
              </Button>
              <div className="flex gap-2">
                <Button onClick={handleCompleteClass}>
                  <Save className="w-4 h-4 mr-2" />
                  Save Class {classNumber}
                </Button>
                <Button 
                  variant="outline" 
                  onClick={() => {
                    handleCompleteClass();
                    onSuccess();
                    onClose();
                  }}
                >
                  Save & Finish Course
                </Button>
              </div>
            </div>
          </div>
        );

      default:
        return null;
    }
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-4xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <BookOpen className="w-5 h-5 text-blue-600" />
            {getStepTitle()}
          </DialogTitle>
        </DialogHeader>

        {/* Progress Steps */}
        <div className="flex items-center justify-center space-x-2 pb-6 border-b">
          <div className={`w-8 h-8 rounded-full flex items-center justify-center text-xs font-bold ${
            currentStep === 'course-info' ? 'bg-blue-600 text-white' : 
            ['class-setup', 'class-video', 'class-notes', 'class-projects', 'complete'].includes(currentStep) ? 'bg-green-600 text-white' : 'bg-gray-200'
          }`}>
            1
          </div>
          <div className="w-8 h-0.5 bg-gray-200"></div>
          <div className={`w-8 h-8 rounded-full flex items-center justify-center text-xs font-bold ${
            ['class-setup', 'class-video', 'class-notes', 'class-projects', 'complete'].includes(currentStep) ? 'bg-blue-600 text-white' : 'bg-gray-200'
          }`}>
            2
          </div>
          <div className="w-8 h-0.5 bg-gray-200"></div>
          <div className={`w-8 h-8 rounded-full flex items-center justify-center text-xs font-bold ${
            ['class-video', 'class-notes', 'class-projects', 'complete'].includes(currentStep) ? 'bg-blue-600 text-white' : 'bg-gray-200'
          }`}>
            3
          </div>
          <div className="w-8 h-0.5 bg-gray-200"></div>
          <div className={`w-8 h-8 rounded-full flex items-center justify-center text-xs font-bold ${
            ['class-notes', 'class-projects', 'complete'].includes(currentStep) ? 'bg-blue-600 text-white' : 'bg-gray-200'
          }`}>
            4
          </div>
          <div className="w-8 h-0.5 bg-gray-200"></div>
          <div className={`w-8 h-8 rounded-full flex items-center justify-center text-xs font-bold ${
            ['complete'].includes(currentStep) ? 'bg-green-600 text-white' : 'bg-gray-200'
          }`}>
            5
          </div>
        </div>

        {renderCurrentStep()}
      </DialogContent>
    </Dialog>
  );
};

export default StepByCourseCreation;
