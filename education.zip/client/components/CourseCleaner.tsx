import React from 'react';
import { Button } from './ui/button';
import { Trash2, RefreshCw } from 'lucide-react';
import { clearAllCourses } from '../utils/clearCourses';

const CourseCleaner: React.FC = () => {
  const handleClearCourses = () => {
    if (window.confirm('⚠️ Are you sure you want to delete ALL existing courses?\n\nThis will:\n• Clear all courses from localStorage\n• Clear all uploaded files\n• Clear all orders\n• Allow fresh admin uploads\n\nThis action cannot be undone!')) {
      clearAllCourses();
    }
  };

  return (
    <div className="fixed bottom-4 right-4 z-50">
      <Button
        onClick={handleClearCourses}
        variant="destructive"
        size="sm"
        className="shadow-lg"
      >
        <Trash2 className="w-4 h-4 mr-2" />
        Clear All Courses
      </Button>
    </div>
  );
};

export default CourseCleaner;
