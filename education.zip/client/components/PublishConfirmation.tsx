import React, { useState } from 'react';
import { Button } from './ui/button';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from './ui/dialog';
import { Badge } from './ui/badge';
import { Card, CardContent } from './ui/card';
import { useToast } from '@/hooks/use-toast';
import { databaseService } from '../services/DatabaseService';
import {
  CheckCircle,
  AlertTriangle,
  Upload,
  Database,
  Loader2,
  Globe,
  Eye,
  Video,
  FileText,
  Code,
  Users
} from 'lucide-react';

interface PublishConfirmationProps {
  course: any;
  isOpen: boolean;
  onClose: () => void;
  onConfirm: () => void;
}

const PublishConfirmation: React.FC<PublishConfirmationProps> = ({
  course,
  isOpen,
  onClose,
  onConfirm
}) => {
  const [isPublishing, setIsPublishing] = useState(false);
  const [publishStep, setPublishStep] = useState<'confirm' | 'validating' | 'syncing' | 'success' | 'error'>('confirm');
  const [errorMessage, setErrorMessage] = useState('');
  const { toast } = useToast();

  const getContentStats = () => {
    if (!course.classes) return { classes: 0, videos: 0, notes: 0, projects: 0 };
    
    return {
      classes: course.classes.length,
      videos: course.classes.reduce((total: number, cls: any) => total + (cls.videos?.length || 0), 0),
      notes: course.classes.reduce((total: number, cls: any) => total + (cls.notes?.length || 0), 0),
      projects: course.classes.reduce((total: number, cls: any) => total + (cls.projects?.length || 0), 0)
    };
  };

  const handlePublish = async () => {
    setIsPublishing(true);
    setPublishStep('validating');

    try {
      // Step 1: Validate course
      await new Promise(resolve => setTimeout(resolve, 1000));
      
      // Step 2: Sync to database
      setPublishStep('syncing');
      const result = await databaseService.publishCourse(course.id);
      
      if (result.success) {
        setPublishStep('success');
        
        // Mark as published in local state
        onConfirm();
        
        toast({
          title: "🎉 Course Published!",
          description: `"${course.title}" is now live on your website`,
          duration: 5000
        });
        
        // Auto-close after success
        setTimeout(() => {
          onClose();
          setPublishStep('confirm');
          setIsPublishing(false);
        }, 3000);
        
      } else {
        throw new Error(result.message);
      }
      
    } catch (error) {
      setPublishStep('error');
      setErrorMessage(error instanceof Error ? error.message : 'Unknown error occurred');
      setIsPublishing(false);
      
      toast({
        title: "❌ Publish Failed",
        description: error instanceof Error ? error.message : 'Unknown error',
        variant: "destructive"
      });
    }
  };

  const stats = getContentStats();

  const renderContent = () => {
    switch (publishStep) {
      case 'confirm':
        return (
          <div className="space-y-6">
            {/* Course Preview */}
            <Card className="border-2 border-blue-200 bg-blue-50">
              <CardContent className="p-4">
                <div className="flex items-start gap-4">
                  <img
                    src={course.thumbnail}
                    alt={course.title}
                    className="w-20 h-20 rounded-lg object-cover"
                  />
                  <div className="flex-1">
                    <h3 className="font-bold text-lg text-blue-900">{course.title}</h3>
                    <p className="text-sm text-blue-700 mt-1">{course.description}</p>
                    <div className="flex items-center gap-4 mt-2">
                      <Badge variant="outline" className="bg-white">₹{course.price}</Badge>
                      <Badge variant="outline" className="bg-white">
                        {course.isFree ? 'Free' : 'Paid'}
                      </Badge>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Content Summary */}
            <div className="grid grid-cols-2 gap-4">
              <Card>
                <CardContent className="p-4 text-center">
                  <Video className="w-8 h-8 mx-auto text-red-500 mb-2" />
                  <div className="text-2xl font-bold">{stats.videos}</div>
                  <div className="text-sm text-gray-600">Videos</div>
                </CardContent>
              </Card>
              <Card>
                <CardContent className="p-4 text-center">
                  <FileText className="w-8 h-8 mx-auto text-blue-500 mb-2" />
                  <div className="text-2xl font-bold">{stats.notes}</div>
                  <div className="text-sm text-gray-600">Notes</div>
                </CardContent>
              </Card>
              <Card>
                <CardContent className="p-4 text-center">
                  <Code className="w-8 h-8 mx-auto text-green-500 mb-2" />
                  <div className="text-2xl font-bold">{stats.projects}</div>
                  <div className="text-sm text-gray-600">Projects</div>
                </CardContent>
              </Card>
              <Card>
                <CardContent className="p-4 text-center">
                  <Users className="w-8 h-8 mx-auto text-purple-500 mb-2" />
                  <div className="text-2xl font-bold">{stats.classes}</div>
                  <div className="text-sm text-gray-600">Classes</div>
                </CardContent>
              </Card>
            </div>

            {/* Validation Checklist */}
            <Card className="bg-green-50 border-green-200">
              <CardContent className="p-4">
                <h4 className="font-semibold text-green-800 mb-3">✅ Ready to Publish</h4>
                <div className="space-y-2 text-sm">
                  <div className="flex items-center gap-2 text-green-700">
                    <CheckCircle className="w-4 h-4" />
                    <span>Course has title and description</span>
                  </div>
                  <div className="flex items-center gap-2 text-green-700">
                    <CheckCircle className="w-4 h-4" />
                    <span>Price is set</span>
                  </div>
                  <div className="flex items-center gap-2 text-green-700">
                    <CheckCircle className="w-4 h-4" />
                    <span>Has {stats.classes} class(es) with content</span>
                  </div>
                  <div className="flex items-center gap-2 text-green-700">
                    <CheckCircle className="w-4 h-4" />
                    <span>Course thumbnail is set</span>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* What happens when published */}
            <Card className="bg-yellow-50 border-yellow-200">
              <CardContent className="p-4">
                <h4 className="font-semibold text-yellow-800 mb-3">📢 What happens when you publish:</h4>
                <div className="space-y-2 text-sm text-yellow-700">
                  <div className="flex items-center gap-2">
                    <Globe className="w-4 h-4" />
                    <span>Course goes live on your website</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <Database className="w-4 h-4" />
                    <span>All content saved to database</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <Eye className="w-4 h-4" />
                    <span>Visible to website visitors</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <Users className="w-4 h-4" />
                    <span>Students can enroll and purchase</span>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Action Buttons */}
            <div className="flex gap-3">
              <Button variant="outline" onClick={onClose} className="flex-1">
                Cancel
              </Button>
              <Button 
                onClick={handlePublish} 
                className="flex-1 bg-green-600 hover:bg-green-700"
                disabled={isPublishing}
              >
                <Upload className="w-4 h-4 mr-2" />
                Publish Course
              </Button>
            </div>
          </div>
        );

      case 'validating':
        return (
          <div className="text-center py-8">
            <Loader2 className="w-12 h-12 mx-auto animate-spin text-blue-500 mb-4" />
            <h3 className="text-lg font-semibold mb-2">Validating Course Content</h3>
            <p className="text-gray-600 text-sm">Checking all videos, notes, and projects...</p>
          </div>
        );

      case 'syncing':
        return (
          <div className="text-center py-8">
            <Database className="w-12 h-12 mx-auto text-green-500 mb-4 animate-pulse" />
            <h3 className="text-lg font-semibold mb-2">Syncing to Database</h3>
            <p className="text-gray-600 text-sm">Uploading course content to database...</p>
            <div className="mt-4 text-xs text-gray-500">
              This ensures your course is saved permanently
            </div>
          </div>
        );

      case 'success':
        return (
          <div className="text-center py-8">
            <CheckCircle className="w-16 h-16 mx-auto text-green-500 mb-4" />
            <h3 className="text-xl font-bold text-green-800 mb-2">🎉 Published Successfully!</h3>
            <p className="text-gray-600 mb-4">
              "{course.title}" is now live on your website
            </p>
            <div className="bg-green-50 border border-green-200 rounded-lg p-4">
              <div className="text-sm text-green-700">
                ✅ Course content saved to database<br />
                ✅ Available for student enrollment<br />
                ✅ Visible on website
              </div>
            </div>
          </div>
        );

      case 'error':
        return (
          <div className="text-center py-8">
            <AlertTriangle className="w-16 h-16 mx-auto text-red-500 mb-4" />
            <h3 className="text-xl font-bold text-red-800 mb-2">Publish Failed</h3>
            <p className="text-gray-600 mb-4">{errorMessage}</p>
            <div className="flex gap-3 justify-center">
              <Button variant="outline" onClick={onClose}>
                Close
              </Button>
              <Button onClick={handlePublish} variant="destructive">
                Retry
              </Button>
            </div>
          </div>
        );

      default:
        return null;
    }
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-md max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <Upload className="w-5 h-5 text-blue-600" />
            {publishStep === 'confirm' ? 'Publish Course' : 
             publishStep === 'success' ? 'Published Successfully' : 'Publishing...'}
          </DialogTitle>
        </DialogHeader>

        {renderContent()}
      </DialogContent>
    </Dialog>
  );
};

export default PublishConfirmation;
