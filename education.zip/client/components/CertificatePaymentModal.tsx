import React, { useState } from 'react';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Label } from './ui/label';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from './ui/card';
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from './ui/dialog';
import { Tabs, TabsContent, TabsList, TabsTrigger } from './ui/tabs';
import { Badge } from './ui/badge';
import { useToast } from '@/hooks/use-toast';
import { 
  CreditCard, 
  Smartphone, 
  Download,
  Shield,
  CheckCircle,
  Award
} from 'lucide-react';

interface CertificatePaymentModalProps {
  isOpen: boolean;
  onClose: () => void;
  courseName: string;
  onSuccess: () => void;
}

export function CertificatePaymentModal({ 
  isOpen, 
  onClose, 
  courseName, 
  onSuccess 
}: CertificatePaymentModalProps) {
  const [selectedMethod, setSelectedMethod] = useState('upi');
  const [isProcessing, setIsProcessing] = useState(false);
  const [paymentSuccess, setPaymentSuccess] = useState(false);
  const [formData, setFormData] = useState({
    upiId: '',
    cardNumber: '',
    expiryDate: '',
    cvv: '',
    cardName: ''
  });

  const { toast } = useToast();

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setFormData(prev => ({
      ...prev,
      [e.target.name]: e.target.value
    }));
  };

  const processPayment = async () => {
    setIsProcessing(true);
    
    // Simulate payment processing
    await new Promise(resolve => setTimeout(resolve, 2000));
    
    setPaymentSuccess(true);
    setIsProcessing(false);
    
    // Clear form and close modal after showing success
    setTimeout(() => {
      setPaymentSuccess(false);
      onSuccess();
      onClose();
      toast({
        title: "Certificate Downloaded!",
        description: "Your certificate has been downloaded successfully.",
        duration: 5000,
      });
    }, 3000);
  };

  const handleUPIPayment = async () => {
    if (!formData.upiId) {
      toast({
        title: "UPI ID Required",
        description: "Please enter your UPI ID to proceed.",
        variant: "destructive",
      });
      return;
    }

    await processPayment();
    
    toast({
      title: "UPI Payment Request Sent",
      description: `Payment request sent to ${formData.upiId}. Please check your UPI app to complete the payment.`,
      duration: 7000,
    });
  };

  const handleCardPayment = async () => {
    if (!formData.cardNumber || !formData.expiryDate || !formData.cvv || !formData.cardName) {
      toast({
        title: "Card Details Required",
        description: "Please fill in all card details to proceed.",
        variant: "destructive",
      });
      return;
    }

    await processPayment();
  };

  if (paymentSuccess) {
    return (
      <Dialog open={isOpen} onOpenChange={onClose}>
        <DialogContent className="sm:max-w-md">
          <div className="flex flex-col items-center text-center py-6">
            <div className="w-16 h-16 bg-success/10 rounded-full flex items-center justify-center mb-4">
              <CheckCircle className="w-8 h-8 text-success" />
            </div>
            <h3 className="text-xl font-semibold mb-2">Payment Successful!</h3>
            <p className="text-muted-foreground mb-4">
              Your payment of ₹10 has been processed successfully.
            </p>
            <div className="text-sm text-muted-foreground">
              <p>✅ Certificate is being generated</p>
              <p>✅ Download will start automatically</p>
              <p>✅ Certificate sent to your email</p>
            </div>
          </div>
        </DialogContent>
      </Dialog>
    );
  }

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="sm:max-w-2xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <Award className="w-5 h-5" />
            Download Certificate
          </DialogTitle>
          <DialogDescription>
            Pay ₹10 to download your {courseName} certification
          </DialogDescription>
        </DialogHeader>

        <div className="grid md:grid-cols-3 gap-6">
          {/* Certificate Preview */}
          <div className="md:col-span-1">
            <Card>
              <CardHeader>
                <CardTitle className="text-sm">Certificate Preview</CardTitle>
              </CardHeader>
              <CardContent className="space-y-3">
                <div className="aspect-square bg-gradient-to-br from-primary/10 to-brand-200/50 rounded-lg p-4 flex flex-col items-center justify-center text-center">
                  <Award className="w-8 h-8 text-primary mb-2" />
                  <div className="text-xs font-medium">EduMaster</div>
                  <div className="text-xs text-muted-foreground">Certificate of Completion</div>
                  <div className="text-xs font-medium mt-2">{courseName}</div>
                </div>
                
                <div className="text-xs space-y-1">
                  <div className="flex justify-between">
                    <span>Format:</span>
                    <span>PDF</span>
                  </div>
                  <div className="flex justify-between">
                    <span>Size:</span>
                    <span>A4</span>
                  </div>
                  <div className="flex justify-between">
                    <span>Verification:</span>
                    <span>QR Code</span>
                  </div>
                </div>

                <div className="flex items-center gap-1 text-xs text-muted-foreground">
                  <Shield className="w-3 h-3" />
                  <span>Digitally signed certificate</span>
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Payment Options */}
          <div className="md:col-span-2">
            <Tabs value={selectedMethod} onValueChange={setSelectedMethod}>
              <TabsList className="grid w-full grid-cols-2">
                <TabsTrigger value="upi" className="flex items-center gap-2">
                  <Smartphone className="w-4 h-4" />
                  UPI
                </TabsTrigger>
                <TabsTrigger value="card" className="flex items-center gap-2">
                  <CreditCard className="w-4 h-4" />
                  Card
                </TabsTrigger>
              </TabsList>

              {/* UPI Payment */}
              <TabsContent value="upi" className="space-y-4">
                <Card>
                  <CardHeader>
                    <CardTitle className="flex items-center gap-2">
                      <Smartphone className="w-5 h-5" />
                      UPI Payment - ₹10
                    </CardTitle>
                    <CardDescription>
                      Pay using any UPI app like PhonePe, Google Pay, Paytm, etc.
                    </CardDescription>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div>
                      <Label htmlFor="upiId">UPI ID</Label>
                      <Input
                        id="upiId"
                        name="upiId"
                        placeholder="yourname@upi"
                        value={formData.upiId}
                        onChange={handleInputChange}
                      />
                      <p className="text-xs text-muted-foreground mt-1">
                        Enter your UPI ID (e.g., 9876543210@paytm)
                      </p>
                    </div>
                    
                    <div className="bg-muted/30 p-3 rounded-lg">
                      <p className="text-sm font-medium mb-2">Payment will be processed as:</p>
                      <div className="text-xs space-y-1">
                        <p>• Payment request sent to your UPI app</p>
                        <p>• Complete payment in your UPI app</p>
                        <p>• Certificate download starts automatically</p>
                      </div>
                    </div>

                    <Button 
                      className="w-full" 
                      onClick={handleUPIPayment}
                      disabled={isProcessing}
                    >
                      {isProcessing ? "Processing..." : "Pay ₹10 via UPI"}
                    </Button>
                  </CardContent>
                </Card>
              </TabsContent>

              {/* Card Payment */}
              <TabsContent value="card" className="space-y-4">
                <Card>
                  <CardHeader>
                    <CardTitle className="flex items-center gap-2">
                      <CreditCard className="w-5 h-5" />
                      Credit/Debit Card - ₹10
                    </CardTitle>
                    <CardDescription>
                      Pay securely with your credit or debit card
                    </CardDescription>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div>
                      <Label htmlFor="cardName">Cardholder Name</Label>
                      <Input
                        id="cardName"
                        name="cardName"
                        placeholder="Name on card"
                        value={formData.cardName}
                        onChange={handleInputChange}
                      />
                    </div>
                    
                    <div>
                      <Label htmlFor="cardNumber">Card Number</Label>
                      <Input
                        id="cardNumber"
                        name="cardNumber"
                        placeholder="1234 5678 9012 3456"
                        value={formData.cardNumber}
                        onChange={handleInputChange}
                        maxLength={19}
                      />
                    </div>

                    <div className="grid grid-cols-2 gap-4">
                      <div>
                        <Label htmlFor="expiryDate">Expiry Date</Label>
                        <Input
                          id="expiryDate"
                          name="expiryDate"
                          placeholder="MM/YY"
                          value={formData.expiryDate}
                          onChange={handleInputChange}
                          maxLength={5}
                        />
                      </div>
                      <div>
                        <Label htmlFor="cvv">CVV</Label>
                        <Input
                          id="cvv"
                          name="cvv"
                          placeholder="123"
                          value={formData.cvv}
                          onChange={handleInputChange}
                          maxLength={4}
                        />
                      </div>
                    </div>

                    <Button 
                      className="w-full" 
                      onClick={handleCardPayment}
                      disabled={isProcessing}
                    >
                      {isProcessing ? "Processing..." : "Pay ₹10"}
                    </Button>
                  </CardContent>
                </Card>
              </TabsContent>
            </Tabs>
          </div>
        </div>

        <div className="flex items-center justify-center gap-2 text-xs text-muted-foreground">
          <Shield className="w-3 h-3" />
          <span>Your payment information is secure and encrypted</span>
        </div>
      </DialogContent>
    </Dialog>
  );
}
