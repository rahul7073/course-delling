import React from 'react';
import { Card, CardContent } from './ui/card';
import { Badge } from './ui/badge';
import { Button } from './ui/button';
import { useToast } from '@/hooks/use-toast';
import { useData } from '../contexts/DataContext';
import { useAuth } from '../contexts/AuthContext';
import { downloadFile, getFileIcon, formatFileSize } from '../utils/fileDownload';
import {
  BookOpen,
  Play,
  FileText,
  Code,
  Download,
  Globe,
  Lock,
  Check,
  CheckCircle2
} from 'lucide-react';

interface CourseClassDisplayProps {
  course: any;
  isPurchased: boolean;
  currentVideo: any;
  setCurrentVideo: (video: any) => void;
  setIsPlaying: (playing: boolean) => void;
}

const CourseClassDisplay: React.FC<CourseClassDisplayProps> = ({
  course,
  isPurchased,
  currentVideo,
  setCurrentVideo,
  setIsPlaying
}) => {
  const { toast } = useToast();
  const { isClassCompleted, markClassComplete } = useData();
  const { user } = useAuth();

  const handleRealDownload = async (fileUrl: string, fileName: string) => {
    try {
      // First, show download starting message
      toast({
        title: "📥 Starting Download...",
        description: `Preparing ${fileName} for download`,
      });

      console.log('Attempting download:', { fileUrl, fileName });

      // Try multiple storage lookup strategies
      let fileInfo = null;
      let dataUrl = null;
      let actualFileName = fileName;

      // Strategy 1: Direct localStorage lookup with fileUrl as key
      const storedInfo = localStorage.getItem(fileUrl);
      if (storedInfo) {
        try {
          fileInfo = JSON.parse(storedInfo);
          dataUrl = fileInfo.dataUrl;
          actualFileName = fileInfo.name || fileName;
          console.log('Found file in localStorage:', fileInfo);
        } catch (parseError) {
          console.warn('Failed to parse stored file info:', parseError);
        }
      }

      // Strategy 2: Check if fileUrl is already a data URL
      if (!dataUrl && fileUrl.startsWith('data:')) {
        dataUrl = fileUrl;
        actualFileName = fileName;
        console.log('Using direct data URL');
      }

      // Strategy 3: Skip blob URLs since they expire and cause fetch errors
      if (!dataUrl && fileUrl.startsWith('blob:')) {
        console.warn('Blob URL detected but skipping due to expiration issues:', fileUrl);
        // Don't try to fetch blob URLs as they commonly expire
      }

      // Strategy 3b: Handle legacy sample files and project code files
      if (!dataUrl && (fileUrl.includes('/notes/sample.pdf') || fileName.includes('CODE') || fileName.includes('README'))) {
        // Create a simple text file as fallback for sample/project files
        let sampleContent = '';
        let fileExtension = '.txt';

        if (fileName.toLowerCase().includes('html')) {
          sampleContent = `<!DOCTYPE html>\n<html>\n<head>\n    <title>${fileName}</title>\n</head>\n<body>\n    <h1>Sample HTML Code</h1>\n    <p>This is a sample HTML file for "${fileName}".</p>\n    <p>Re-upload actual files through the admin panel for real downloads.</p>\n</body>\n</html>`;
          fileExtension = '.html';
        } else if (fileName.toLowerCase().includes('css')) {
          sampleContent = `/* ${fileName} */\nbody {\n    font-family: Arial, sans-serif;\n    margin: 0;\n    padding: 20px;\n}\n\n/* Add your styles here */`;
          fileExtension = '.css';
        } else if (fileName.toLowerCase().includes('js')) {
          sampleContent = `// ${fileName}\nconsole.log("Sample JavaScript file for ${fileName}");\n\n// Add your JavaScript code here\nfunction init() {\n    console.log("Initialized!");\n}\n\ninit();`;
          fileExtension = '.js';
        } else {
          sampleContent = `Sample File: ${fileName}\n\nThis is a sample file.\nRe-upload actual files through the admin panel for real downloads.\n\nContent type: ${fileName}\nGenerated: ${new Date().toISOString()}`;
        }

        const blob = new Blob([sampleContent], { type: 'text/plain' });
        dataUrl = URL.createObjectURL(blob);
        actualFileName = fileName.includes('.') ? fileName : `${fileName}${fileExtension}`;
        console.log('Using sample/project file fallback for:', fileName);
      }

      // Strategy 4: Fallback - try to find by searching localStorage for similar keys
      if (!dataUrl) {
        console.log('Searching localStorage for similar files...');

        // Get all file keys from localStorage
        const allKeys = Array.from({length: localStorage.length}, (_, i) => localStorage.key(i))
          .filter(key => key && (key.includes('note-file') || key.includes('video-file') || key.includes('project-file')));

        console.log('Available file keys:', allKeys);

        for (const key of allKeys) {
          try {
            const item = JSON.parse(localStorage.getItem(key) || '{}');

            // Try multiple matching strategies
            const nameMatch = item.name && (
              item.name.toLowerCase().includes(fileName.toLowerCase()) ||
              fileName.toLowerCase().includes(item.name.toLowerCase().split('.')[0]) ||
              item.name.toLowerCase().split('.')[0] === fileName.toLowerCase().split('.')[0]
            );

            if (nameMatch && item.dataUrl) {
              dataUrl = item.dataUrl;
              actualFileName = item.name || fileName;
              console.log('Found matching file by flexible name search:', {
                key,
                storedName: item.name,
                requestedName: fileName,
                match: 'success'
              });
              break;
            }
          } catch (e) {
            console.warn('Error parsing localStorage item:', key, e);
          }
        }
      }

      // Final fallback: Create a placeholder file if nothing else works
      if (!dataUrl) {
        const availableFiles = Array.from({length: localStorage.length}, (_, i) => localStorage.key(i))
          .filter(key => key?.includes('file'));

        console.warn('Creating placeholder file for:', fileName);

        // Create a placeholder file with useful information
        const placeholderContent = `File: ${fileName}\nRequested URL: ${fileUrl}\n\nThis file was not found in storage.\n\nTo fix this:\n1. Go to the admin panel\n2. Re-upload this file\n3. Make sure to save the course content\n\nAvailable files in storage: ${availableFiles.length}\nGenerated: ${new Date().toISOString()}`;

        const blob = new Blob([placeholderContent], { type: 'text/plain' });
        dataUrl = URL.createObjectURL(blob);
        actualFileName = `${fileName.replace(/\.[^/.]+$/, '')}-placeholder.txt`;

        console.log('Using placeholder file for missing:', fileName);
      }

      // Show file info
      if (fileInfo) {
        console.log('Downloading file:', {
          name: actualFileName,
          size: fileInfo.size ? `${(fileInfo.size / 1024 / 1024).toFixed(2)} MB` : 'Unknown',
          type: fileInfo.type || 'Unknown'
        });
      }

      await downloadFile(dataUrl, actualFileName);

      toast({
        title: "✅ Download Successful!",
        description: `${actualFileName} has been saved to your downloads folder`,
      });
    } catch (error) {
      console.error('Download error:', error);
      toast({
        title: "❌ Download Failed",
        description: error.message || "Please try again or contact support",
        variant: "destructive"
      });
    }
  };

  const handleCompleteClass = (classId: string) => {
    if (user) {
      markClassComplete(user.id, course.id, classId);
      toast({
        title: "Class completed!",
        description: "Great job! Keep up the learning.",
      });
    }
  };

  if (!course.classes || course.classes.length === 0) {
    return (
      <div className="text-center py-8 text-muted-foreground">
        <BookOpen className="w-12 h-12 mx-auto mb-4 opacity-50" />
        <p>No classes available for this course</p>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <h3 className="text-lg font-semibold mb-4 flex items-center gap-2">
        <BookOpen className="w-5 h-5" />
        Course Classes ({course.classes.length})
      </h3>
      
      {course.classes
        .sort((a: any, b: any) => a.classNumber - b.classNumber)
        .map((classItem: any, classIndex: number) => {
          const isDemo = classItem.isDemo || classIndex === 0; // First class is always demo
          const isLocked = !isDemo && !isPurchased && !(course && course.isFree);
          const isCompleted = user ? isClassCompleted(user.id, course.id, classItem.id) : false;

          return (
            <Card
              key={classItem.id || `class-${classItem.classNumber}-${classIndex}`}
              className={`transition-all hover:shadow-md ${
                isLocked ? 'opacity-70' : ''
              } ${
                currentVideo?.classNumber === classItem.classNumber ? 'ring-2 ring-primary' : ''
              }`}
            >
              <CardContent className="p-6">
                <div className="flex items-start justify-between mb-4">
                  <div className="flex items-start gap-4">
                    <div className="w-12 h-12 bg-primary/10 rounded-lg flex items-center justify-center">
                      <span className="font-bold text-primary">{classItem.classNumber}</span>
                    </div>
                    <div>
                      <h4 className="font-medium text-lg flex items-center gap-2">
                        {classItem.title}
                        {isDemo && <Badge variant="secondary">Demo</Badge>}
                        {isLocked && <Lock className="w-4 h-4 text-muted-foreground" />}
                        {isCompleted && <CheckCircle2 className="w-5 h-5 text-green-600" />}
                      </h4>
                      <p className="text-sm text-muted-foreground mt-1">{classItem.description}</p>
                    </div>
                  </div>

                  {/* Class Completion Button */}
                  {!isLocked && !isCompleted && (
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => handleCompleteClass(classItem.id)}
                      className="shrink-0"
                    >
                      <CheckCircle2 className="w-4 h-4 mr-2" />
                      Mark Complete
                    </Button>
                  )}

                  {isCompleted && (
                    <Badge variant="secondary" className="shrink-0 bg-green-100 text-green-700">
                      <CheckCircle2 className="w-4 h-4 mr-1" />
                      Completed
                    </Badge>
                  )}
                </div>

                {/* Class Videos */}
                {classItem.videos && classItem.videos.length > 0 && (
                  <div className="mb-4">
                    <h5 className="text-sm font-medium mb-3 flex items-center gap-2">
                      <Play className="w-4 h-4" />
                      Videos ({classItem.videos.length})
                    </h5>
                    <div className="space-y-2">
                      {classItem.videos.map((video: any, videoIndex: number) => (
                        <div
                          key={video.id || `video-${classItem.classNumber}-${videoIndex}`}
                          className={`flex items-center justify-between p-3 bg-muted/30 rounded-lg transition-all ${
                            isLocked ? 'cursor-not-allowed' : 'cursor-pointer hover:bg-muted/50'
                          }`}
                          onClick={() => {
                            if (!isLocked) {
                              setCurrentVideo(video);
                              setIsPlaying(true);
                            } else {
                              toast({
                                title: "Video locked",
                                description: "Purchase the course to access this video.",
                                variant: "destructive",
                              });
                            }
                          }}
                        >
                          <div className="flex items-center space-x-3">
                            <Play className="h-5 w-5 text-red-600" />
                            <div>
                              <h6 className="font-medium text-sm">{video.title}</h6>
                              <p className="text-xs text-muted-foreground">{video.description}</p>
                              <p className="text-xs text-muted-foreground">Duration: {video.duration}</p>
                            </div>
                          </div>
                          {isLocked && <Lock className="w-4 h-4 text-muted-foreground" />}
                        </div>
                      ))}
                    </div>
                  </div>
                )}

                {/* Class Notes */}
                {classItem.notes && classItem.notes.length > 0 && (
                  <div className="mb-4">
                    <h5 className="text-sm font-medium mb-3 flex items-center gap-2">
                      <FileText className="w-4 h-4" />
                      Notes ({classItem.notes.length})
                    </h5>
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                      {classItem.notes.map((note: any, noteIndex: number) => (
                        <div
                          key={note.id || `note-${classItem.classNumber}-${noteIndex}`}
                          className={`p-3 rounded-lg border transition-all ${
                            isLocked
                              ? 'bg-muted/50 cursor-not-allowed'
                              : 'bg-muted/30 hover:bg-muted/50 cursor-pointer'
                          }`}
                          onClick={(e) => {
                            e.stopPropagation();
                            if (!isLocked) {
                              handleRealDownload(note.fileUrl, note.title);
                            } else {
                              toast({
                                title: "Notes locked",
                                description: "Purchase the course to download notes.",
                                variant: "destructive",
                              });
                            }
                          }}
                        >
                          <div className="flex items-start justify-between">
                            <div className="flex-1">
                              <h6 className="font-medium text-sm">{note.title}</h6>
                              <p className="text-xs text-muted-foreground mt-1">{note.description}</p>
                              <p className="text-xs text-muted-foreground mt-1">Size: {note.fileSize}</p>
                              {!isLocked && (
                                <p className="text-xs text-green-600 mt-1">🔓 Click to download • Saves to your Downloads folder</p>
                              )}
                            </div>
                            <div className="flex items-center gap-2">
                              {isLocked ? (
                                <Lock className="w-4 h-4 text-muted-foreground" />
                              ) : (
                                <div className="flex items-center gap-1 text-primary">
                                  <Download className="w-4 h-4" />
                                  <span className="text-xs font-medium">Download</span>
                                </div>
                              )}
                            </div>
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>
                )}

                {/* Class Projects */}
                {classItem.projects && classItem.projects.length > 0 && (
                  <div>
                    <h5 className="text-sm font-medium mb-3 flex items-center gap-2">
                      <Code className="w-4 h-4" />
                      Projects ({classItem.projects.length})
                    </h5>
                    <div className="space-y-3">
                      {classItem.projects.map((project: any, projectIndex: number) => (
                        <div key={project.id || `project-${classItem.classNumber}-${projectIndex}`} className="p-3 bg-muted/30 rounded-lg">
                          <div className="flex items-start justify-between">
                            <div className="flex items-start space-x-3">
                              <Code className="h-5 w-5 text-purple-600 mt-1" />
                              <div>
                                <h6 className="font-medium text-sm">{project.title}</h6>
                                <p className="text-xs text-muted-foreground mb-2">{project.description}</p>
                                <div className="flex items-center gap-3 text-xs text-muted-foreground mb-2">
                                  <Badge variant="outline" className="text-xs">{project.difficulty}</Badge>
                                  <span>{project.codeFiles.length} files</span>
                                </div>
                                <div className="flex flex-wrap gap-1">
                                  {project.codeFiles.map((file: any, fileIndex: number) => (
                                    <Badge key={`${project.id || projectIndex}-file-${fileIndex}`} variant="secondary" className="text-xs">
                                      {file.fileName}
                                    </Badge>
                                  ))}
                                </div>
                              </div>
                            </div>
                            <div className="flex items-center gap-2">
                              {isLocked ? (
                                <Lock className="w-4 h-4 text-muted-foreground" />
                              ) : (
                                <>
                                  <Button
                                    variant="outline"
                                    size="sm"
                                    onClick={async () => {
                                      try {
                                        let successCount = 0;
                                        let errorCount = 0;

                                        for (const file of project.codeFiles) {
                                          try {
                                            await handleRealDownload(file.fileUrl || '#', file.fileName);
                                            successCount++;
                                          } catch (fileError) {
                                            console.warn(`Failed to download ${file.fileName}:`, fileError);
                                            errorCount++;
                                          }
                                        }

                                        if (successCount > 0) {
                                          toast({
                                            title: "✅ Project Downloaded!",
                                            description: `${successCount} files downloaded successfully${errorCount > 0 ? ` (${errorCount} failed)` : ''}`,
                                          });
                                        } else {
                                          toast({
                                            title: "⚠️ Download Issues",
                                            description: "Some files may be placeholders. Check admin panel to re-upload real files.",
                                          });
                                        }
                                      } catch (error) {
                                        toast({
                                          title: "❌ Download Failed",
                                          description: "Please try again or contact support.",
                                          variant: "destructive"
                                        });
                                      }
                                    }}
                                  >
                                    <Download className="w-4 h-4" />
                                  </Button>
                                  {project.demoUrl && (
                                    <Button 
                                      variant="outline" 
                                      size="sm"
                                      onClick={() => window.open(project.demoUrl, '_blank')}
                                    >
                                      <Globe className="w-4 h-4" />
                                    </Button>
                                  )}
                                </>
                              )}
                            </div>
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>
                )}

                {/* No content message */}
                {(!classItem.videos || classItem.videos.length === 0) &&
                 (!classItem.notes || classItem.notes.length === 0) &&
                 (!classItem.projects || classItem.projects.length === 0) && (
                  <div className="text-center py-6 text-muted-foreground">
                    <BookOpen className="w-8 h-8 mx-auto mb-2 opacity-50" />
                    <p className="text-sm">No content uploaded for this class yet</p>
                  </div>
                )}
              </CardContent>
            </Card>
          );
        })}
    </div>
  );
};

export default CourseClassDisplay;
