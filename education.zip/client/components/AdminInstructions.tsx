import React from 'react';
import { Alert, AlertDescription, AlertTitle } from './ui/alert';
import { Info, CheckCircle, Upload, Eye } from 'lucide-react';

const AdminInstructions: React.FC = () => {
  return (
    <div className="mb-6 space-y-4">
      <Alert className="border-blue-200 bg-blue-50">
        <Info className="h-4 w-4 text-blue-600" />
        <AlertTitle className="text-blue-800">Course Visibility Guide</AlertTitle>
        <AlertDescription className="text-blue-700">
          <div className="mt-2 space-y-2">
            <div className="flex items-center space-x-2">
              <Upload className="h-4 w-4" />
              <span><strong>Step 1:</strong> Create course with title, description, category & price</span>
            </div>
            <div className="flex items-center space-x-2">
              <CheckCircle className="h-4 w-4" />
              <span><strong>Step 2:</strong> Courses are automatically published to website</span>
            </div>
            <div className="flex items-center space-x-2">
              <Eye className="h-4 w-4" />
              <span><strong>Step 3:</strong> Add classes, notes & code - they'll appear on website immediately</span>
            </div>
          </div>
        </AlertDescription>
      </Alert>
    </div>
  );
};

export default AdminInstructions;
