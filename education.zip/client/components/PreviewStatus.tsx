import React from 'react';
import { Badge } from './ui/badge';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { useData } from '../contexts/DataContext';
import { 
  Eye, 
  EyeOff, 
  Globe, 
  Database,
  CheckCircle,
  Clock,
  Users,
  TrendingUp
} from 'lucide-react';

const PreviewStatus: React.FC = () => {
  const { courses, orders } = useData();

  const stats = {
    total: courses.length,
    published: courses.filter(c => c.isPublished).length,
    draft: courses.filter(c => !c.isPublished).length,
    revenue: orders
      .filter(o => o.paymentStatus === 'completed')
      .reduce((total, order) => total + order.amount, 0),
    enrollments: orders.filter(o => o.paymentStatus === 'completed').length
  };

  const publishedCourses = courses.filter(c => c.isPublished);
  const draftCourses = courses.filter(c => !c.isPublished);

  return (
    <div className="space-y-6">
      {/* Overview Stats */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        <Card>
          <CardContent className="p-4 text-center">
            <Globe className="w-8 h-8 mx-auto text-green-500 mb-2" />
            <div className="text-2xl font-bold text-green-600">{stats.published}</div>
            <div className="text-sm text-gray-600">Published</div>
          </CardContent>
        </Card>
        
        <Card>
          <CardContent className="p-4 text-center">
            <Clock className="w-8 h-8 mx-auto text-orange-500 mb-2" />
            <div className="text-2xl font-bold text-orange-600">{stats.draft}</div>
            <div className="text-sm text-gray-600">Draft</div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-4 text-center">
            <Users className="w-8 h-8 mx-auto text-blue-500 mb-2" />
            <div className="text-2xl font-bold text-blue-600">{stats.enrollments}</div>
            <div className="text-sm text-gray-600">Enrollments</div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-4 text-center">
            <TrendingUp className="w-8 h-8 mx-auto text-purple-500 mb-2" />
            <div className="text-2xl font-bold text-purple-600">₹{stats.revenue.toLocaleString()}</div>
            <div className="text-sm text-gray-600">Revenue</div>
          </CardContent>
        </Card>
      </div>

      {/* Published Courses - What Users See */}
      <Card className="border-green-200 bg-green-50">
        <CardHeader>
          <CardTitle className="flex items-center gap-2 text-green-800">
            <Eye className="w-5 h-5" />
            Live on Website ({stats.published} courses)
          </CardTitle>
        </CardHeader>
        <CardContent>
          {publishedCourses.length > 0 ? (
            <div className="space-y-3">
              {publishedCourses.map(course => (
                <div key={course.id} className="flex items-center justify-between p-3 bg-white rounded-lg border">
                  <div className="flex items-center gap-3">
                    <img 
                      src={course.thumbnail} 
                      alt={course.title}
                      className="w-12 h-12 rounded object-cover"
                    />
                    <div>
                      <div className="font-medium text-green-900">{course.title}</div>
                      <div className="text-sm text-green-700">
                        ₹{course.price} • {course.classes?.length || 0} classes
                      </div>
                    </div>
                  </div>
                  <div className="flex items-center gap-2">
                    <Badge variant="default" className="bg-green-600">
                      <Globe className="w-3 h-3 mr-1" />
                      Live
                    </Badge>
                    <Badge variant="outline">
                      {course.isFree ? 'Free' : 'Paid'}
                    </Badge>
                  </div>
                </div>
              ))}
              
              <div className="mt-4 p-3 bg-green-100 rounded-lg border border-green-200">
                <div className="text-sm text-green-800">
                  ✅ These courses are visible to website visitors<br />
                  ✅ Students can enroll and purchase<br />
                  ✅ Content is saved in database
                </div>
              </div>
            </div>
          ) : (
            <div className="text-center py-8 text-green-700">
              <Globe className="w-12 h-12 mx-auto mb-4 opacity-50" />
              <div className="font-medium">No courses published yet</div>
              <div className="text-sm">Create and publish courses to make them visible on your website</div>
            </div>
          )}
        </CardContent>
      </Card>

      {/* Draft Courses - Admin Only */}
      {draftCourses.length > 0 && (
        <Card className="border-orange-200 bg-orange-50">
          <CardHeader>
            <CardTitle className="flex items-center gap-2 text-orange-800">
              <EyeOff className="w-5 h-5" />
              Draft Courses ({stats.draft} courses)
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              {draftCourses.map(course => (
                <div key={course.id} className="flex items-center justify-between p-3 bg-white rounded-lg border">
                  <div className="flex items-center gap-3">
                    <img 
                      src={course.thumbnail} 
                      alt={course.title}
                      className="w-12 h-12 rounded object-cover opacity-60"
                    />
                    <div>
                      <div className="font-medium text-orange-900">{course.title}</div>
                      <div className="text-sm text-orange-700">
                        ₹{course.price} • {course.classes?.length || 0} classes
                      </div>
                    </div>
                  </div>
                  <div className="flex items-center gap-2">
                    <Badge variant="secondary" className="bg-orange-200 text-orange-800">
                      <EyeOff className="w-3 h-3 mr-1" />
                      Draft
                    </Badge>
                  </div>
                </div>
              ))}
              
              <div className="mt-4 p-3 bg-orange-100 rounded-lg border border-orange-200">
                <div className="text-sm text-orange-800">
                  ⚠️ These courses are NOT visible to website visitors<br />
                  ⚠️ Only admins can see them<br />
                  📝 Publish them to make them available for students
                </div>
              </div>
            </div>
          </CardContent>
        </Card>
      )}

      {/* Website Preview Link */}
      <Card className="border-blue-200 bg-blue-50">
        <CardContent className="p-4">
          <div className="flex items-center justify-between">
            <div>
              <h3 className="font-semibold text-blue-900">Preview Your Website</h3>
              <p className="text-sm text-blue-700">See exactly what your students see</p>
            </div>
            <div className="flex gap-2">
              <Badge variant="outline" className="bg-white">
                {stats.published} courses visible
              </Badge>
              <a 
                href="/courses" 
                target="_blank" 
                rel="noopener noreferrer"
                className="inline-flex items-center gap-2 bg-blue-600 text-white px-4 py-2 rounded-lg text-sm font-medium hover:bg-blue-700"
              >
                <Eye className="w-4 h-4" />
                Preview Website
              </a>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
};

export default PreviewStatus;
