import React, { useState } from 'react';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Label } from './ui/label';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from './ui/card';
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from './ui/dialog';
import { Tabs, TabsContent, TabsList, TabsTrigger } from './ui/tabs';
import { Separator } from './ui/separator';
import { Badge } from './ui/badge';
import { useToast } from '@/hooks/use-toast';
import { useCart } from '../contexts/CartContext';
import { 
  CreditCard, 
  Smartphone, 
  Banknote, 
  QrCode, 
  Shield,
  CheckCircle,
  X,
  Lock
} from 'lucide-react';

interface PaymentModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export function PaymentModal({ isOpen, onClose }: PaymentModalProps) {
  const [selectedMethod, setSelectedMethod] = useState('upi');
  const [isProcessing, setIsProcessing] = useState(false);
  const [paymentSuccess, setPaymentSuccess] = useState(false);
  const [formData, setFormData] = useState({
    upiId: '',
    cardNumber: '',
    expiryDate: '',
    cvv: '',
    cardName: '',
    cashAmount: ''
  });

  const { cartItems, cartTotal, clearCart, purchaseCart } = useCart();
  const { toast } = useToast();

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setFormData(prev => ({
      ...prev,
      [e.target.name]: e.target.value
    }));
  };

  const processPayment = async () => {
    setIsProcessing(true);

    try {
      // Simulate payment processing
      await new Promise(resolve => setTimeout(resolve, 2000));

      // Create real orders
      const orderIds = await purchaseCart(selectedMethod === 'upi' ? 'UPI' : selectedMethod === 'card' ? 'Credit Card' : 'Cash');

      setPaymentSuccess(true);
      setIsProcessing(false);

      // Show success and close modal
      setTimeout(() => {
        setPaymentSuccess(false);
        onClose();
        toast({
          title: "Payment Successful!",
          description: `${orderIds.length} courses purchased successfully! Check your dashboard to access them.`,
          duration: 5000,
        });
      }, 3000);
    } catch (error) {
      setIsProcessing(false);
      toast({
        title: "Payment Failed",
        description: "There was an error processing your payment. Please try again.",
        variant: "destructive",
      });
    }
  };

  const handleUPIPayment = async () => {
    if (!formData.upiId) {
      toast({
        title: "UPI ID Required",
        description: "Please enter your UPI ID to proceed.",
        variant: "destructive",
      });
      return;
    }

    await processPayment();
    
    // Show UPI specific message
    toast({
      title: "UPI Payment Request Sent",
      description: `Payment request sent to ${formData.upiId}. Please check your UPI app to complete the payment.`,
      duration: 7000,
    });
  };

  const handleCardPayment = async () => {
    if (!formData.cardNumber || !formData.expiryDate || !formData.cvv || !formData.cardName) {
      toast({
        title: "Card Details Required",
        description: "Please fill in all card details to proceed.",
        variant: "destructive",
      });
      return;
    }

    await processPayment();
  };

  const handleCashPayment = async () => {
    await processPayment();
    
    toast({
      title: "Cash Payment Confirmed",
      description: "Your cash payment has been recorded. Please complete payment at our office.",
      duration: 5000,
    });
  };

  if (paymentSuccess) {
    return (
      <Dialog open={isOpen} onOpenChange={onClose}>
        <DialogContent className="sm:max-w-md">
          <div className="flex flex-col items-center text-center py-6">
            <div className="w-16 h-16 bg-success/10 rounded-full flex items-center justify-center mb-4">
              <CheckCircle className="w-8 h-8 text-success" />
            </div>
            <h3 className="text-xl font-semibold mb-2">Payment Successful!</h3>
            <p className="text-muted-foreground mb-4">
              Your payment of ${cartTotal.toFixed(2)} has been processed successfully.
            </p>
            <div className="text-sm text-muted-foreground">
              <p>✅ Payment confirmation sent to your email</p>
              <p>✅ Courses added to your account</p>
              <p>✅ Start learning immediately!</p>
            </div>
          </div>
        </DialogContent>
      </Dialog>
    );
  }

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="sm:max-w-2xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <Lock className="w-5 h-5" />
            Secure Payment
          </DialogTitle>
          <DialogDescription>
            Complete your purchase of {cartItems.length} course{cartItems.length !== 1 ? 's' : ''} for ${cartTotal.toFixed(2)}
          </DialogDescription>
        </DialogHeader>

        <div className="grid md:grid-cols-3 gap-6">
          {/* Order Summary */}
          <div className="md:col-span-1">
            <Card>
              <CardHeader>
                <CardTitle className="text-sm">Order Summary</CardTitle>
              </CardHeader>
              <CardContent className="space-y-3">
                {cartItems.map((item) => (
                  <div key={item.course.id} className="flex justify-between text-sm">
                    <span className="line-clamp-1">{item.course.title}</span>
                    <span>${item.course.price}</span>
                  </div>
                ))}
                <Separator />
                <div className="flex justify-between font-semibold">
                  <span>Total</span>
                  <span>${cartTotal.toFixed(2)}</span>
                </div>
                <div className="flex items-center gap-1 text-xs text-muted-foreground">
                  <Shield className="w-3 h-3" />
                  <span>Secure SSL encrypted payment</span>
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Payment Methods */}
          <div className="md:col-span-2">
            <Tabs value={selectedMethod} onValueChange={setSelectedMethod}>
              <TabsList className="grid w-full grid-cols-3">
                <TabsTrigger value="upi" className="flex items-center gap-2">
                  <QrCode className="w-4 h-4" />
                  UPI
                </TabsTrigger>
                <TabsTrigger value="card" className="flex items-center gap-2">
                  <CreditCard className="w-4 h-4" />
                  Card
                </TabsTrigger>
                <TabsTrigger value="cash" className="flex items-center gap-2">
                  <Banknote className="w-4 h-4" />
                  Cash
                </TabsTrigger>
              </TabsList>

              {/* UPI Payment */}
              <TabsContent value="upi" className="space-y-4">
                <Card>
                  <CardHeader>
                    <CardTitle className="flex items-center gap-2">
                      <Smartphone className="w-5 h-5" />
                      UPI Payment
                    </CardTitle>
                    <CardDescription>
                      Pay using any UPI app like PhonePe, Google Pay, Paytm, etc.
                    </CardDescription>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div>
                      <Label htmlFor="upiId">UPI ID</Label>
                      <Input
                        id="upiId"
                        name="upiId"
                        placeholder="yourname@upi"
                        value={formData.upiId}
                        onChange={handleInputChange}
                      />
                      <p className="text-xs text-muted-foreground mt-1">
                        Enter your UPI ID (e.g., 9876543210@paytm)
                      </p>
                    </div>
                    
                    <div className="bg-muted/30 p-3 rounded-lg">
                      <p className="text-sm font-medium mb-2">Payment will be processed as:</p>
                      <div className="text-xs space-y-1">
                        <p>• Payment request sent to your UPI app</p>
                        <p>• Complete payment in your UPI app</p>
                        <p>• Instant confirmation after payment</p>
                      </div>
                    </div>

                    <Button 
                      className="w-full" 
                      onClick={handleUPIPayment}
                      disabled={isProcessing}
                    >
                      {isProcessing ? "Processing..." : `Pay ₹${(cartTotal * 83).toFixed(2)} via UPI`}
                    </Button>
                  </CardContent>
                </Card>
              </TabsContent>

              {/* Card Payment */}
              <TabsContent value="card" className="space-y-4">
                <Card>
                  <CardHeader>
                    <CardTitle className="flex items-center gap-2">
                      <CreditCard className="w-5 h-5" />
                      Credit/Debit Card
                    </CardTitle>
                    <CardDescription>
                      Pay securely with your credit or debit card
                    </CardDescription>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div>
                      <Label htmlFor="cardName">Cardholder Name</Label>
                      <Input
                        id="cardName"
                        name="cardName"
                        placeholder="Name on card"
                        value={formData.cardName}
                        onChange={handleInputChange}
                      />
                    </div>
                    
                    <div>
                      <Label htmlFor="cardNumber">Card Number</Label>
                      <Input
                        id="cardNumber"
                        name="cardNumber"
                        placeholder="1234 5678 9012 3456"
                        value={formData.cardNumber}
                        onChange={handleInputChange}
                        maxLength={19}
                      />
                    </div>

                    <div className="grid grid-cols-2 gap-4">
                      <div>
                        <Label htmlFor="expiryDate">Expiry Date</Label>
                        <Input
                          id="expiryDate"
                          name="expiryDate"
                          placeholder="MM/YY"
                          value={formData.expiryDate}
                          onChange={handleInputChange}
                          maxLength={5}
                        />
                      </div>
                      <div>
                        <Label htmlFor="cvv">CVV</Label>
                        <Input
                          id="cvv"
                          name="cvv"
                          placeholder="123"
                          value={formData.cvv}
                          onChange={handleInputChange}
                          maxLength={4}
                        />
                      </div>
                    </div>

                    <Button 
                      className="w-full" 
                      onClick={handleCardPayment}
                      disabled={isProcessing}
                    >
                      {isProcessing ? "Processing..." : `Pay $${cartTotal.toFixed(2)}`}
                    </Button>
                  </CardContent>
                </Card>
              </TabsContent>

              {/* Cash Payment */}
              <TabsContent value="cash" className="space-y-4">
                <Card>
                  <CardHeader>
                    <CardTitle className="flex items-center gap-2">
                      <Banknote className="w-5 h-5" />
                      Cash Payment
                    </CardTitle>
                    <CardDescription>
                      Pay with cash at our office or authorized centers
                    </CardDescription>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div className="bg-muted/30 p-4 rounded-lg">
                      <h4 className="font-medium mb-2">Payment Instructions:</h4>
                      <div className="text-sm space-y-1">
                        <p>• Visit our office at: 123 Education Street, Learning City</p>
                        <p>• Office hours: Mon-Fri 9 AM to 6 PM</p>
                        <p>• Bring this payment reference: ED{Date.now()}</p>
                        <p>• Amount to pay: ${cartTotal.toFixed(2)}</p>
                      </div>
                    </div>

                    <div className="text-xs text-muted-foreground">
                      <p>Your courses will be activated within 2 hours of payment verification.</p>
                    </div>

                    <Button 
                      className="w-full" 
                      onClick={handleCashPayment}
                      disabled={isProcessing}
                    >
                      {isProcessing ? "Processing..." : "Confirm Cash Payment"}
                    </Button>
                  </CardContent>
                </Card>
              </TabsContent>
            </Tabs>
          </div>
        </div>

        <div className="flex items-center justify-center gap-2 text-xs text-muted-foreground">
          <Shield className="w-3 h-3" />
          <span>Your payment information is secure and encrypted</span>
        </div>
      </DialogContent>
    </Dialog>
  );
}
