import React, { useState } from 'react';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from './ui/dialog';
import { Badge } from './ui/badge';
import { useToast } from '@/hooks/use-toast';
import { useData } from '../contexts/DataContext';
import { useAuth } from '../contexts/AuthContext';
import {
  Smartphone,
  QrCode,
  Clock,
  CheckCircle,
  AlertCircle,
  Copy,
  ExternalLink
} from 'lucide-react';

interface UPIPaymentProps {
  course: any;
  isOpen: boolean;
  onClose: () => void;
  onSuccess: () => void;
}

const UPIPayment: React.FC<UPIPaymentProps> = ({ course, isOpen, onClose, onSuccess }) => {
  const [step, setStep] = useState<'upi-input' | 'payment-link' | 'waiting' | 'verification'>('upi-input');
  const [upiId, setUpiId] = useState('');
  const [paymentId, setPaymentId] = useState('');
  const [paymentLink, setPaymentLink] = useState('');
  const { addOrder } = useData();
  const { user } = useAuth();
  const { toast } = useToast();

  const generatePaymentLink = () => {
    if (!upiId) {
      toast({
        title: "UPI ID Required",
        description: "Please enter a valid UPI ID",
        variant: "destructive"
      });
      return;
    }

    // Generate payment ID
    const newPaymentId = `PAY_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
    setPaymentId(newPaymentId);

    // Create UPI payment link
    const merchantVPA = "your-merchant@paytm"; // Replace with your actual UPI ID
    const amount = course.price;
    const note = `Course: ${course.title}`;
    
    // Standard UPI payment link format
    const upiLink = `upi://pay?pa=${merchantVPA}&pn=EduMaster&am=${amount}&cu=INR&tn=${encodeURIComponent(note)}&tr=${newPaymentId}`;
    
    setPaymentLink(upiLink);
    setStep('payment-link');

    // Create pending order
    if (user) {
      addOrder({
        userId: user.id,
        courseId: course.id,
        amount: amount,
        paymentMethod: 'UPI',
        paymentStatus: 'pending',
        orderDate: new Date().toISOString(),
        transactionId: newPaymentId,
        isUnlocked: false
      });
    }
  };

  const openPaymentApp = () => {
    // Open payment link in default UPI app
    window.open(paymentLink, '_blank');
    setStep('waiting');
    
    // Start checking payment status
    setTimeout(() => {
      setStep('verification');
    }, 5000);
  };

  const copyPaymentLink = () => {
    navigator.clipboard.writeText(paymentLink);
    toast({
      title: "Copied!",
      description: "Payment link copied to clipboard"
    });
  };

  const copyUpiId = () => {
    navigator.clipboard.writeText("your-merchant@paytm");
    toast({
      title: "Copied!",
      description: "UPI ID copied to clipboard"
    });
  };

  const handlePaymentComplete = () => {
    toast({
      title: "Payment Submitted!",
      description: "Your payment is being verified. You'll receive access once approved by admin.",
    });
    onClose();
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-md">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <Smartphone className="w-5 h-5" />
            UPI Payment
          </DialogTitle>
        </DialogHeader>

        <div className="space-y-6">
          {/* Course Info */}
          <Card>
            <CardContent className="p-4">
              <div className="flex items-center justify-between">
                <div>
                  <h3 className="font-medium">{course.title}</h3>
                  <p className="text-sm text-muted-foreground">Complete Course Access</p>
                </div>
                <div className="text-right">
                  <div className="text-2xl font-bold">₹{course.price.toLocaleString()}</div>
                  {course.originalPrice && (
                    <div className="text-sm text-muted-foreground line-through">
                      ₹{course.originalPrice.toLocaleString()}
                    </div>
                  )}
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Step 1: UPI ID Input */}
          {step === 'upi-input' && (
            <div className="space-y-4">
              <div>
                <label className="block text-sm font-medium mb-2">Enter Your UPI ID</label>
                <Input
                  value={upiId}
                  onChange={(e) => setUpiId(e.target.value)}
                  placeholder="yourname@paytm"
                  className="text-center"
                />
                <p className="text-xs text-muted-foreground mt-1">
                  This will be used to send payment confirmation
                </p>
              </div>
              
              <Button onClick={generatePaymentLink} className="w-full" disabled={!upiId}>
                Generate Payment Link
              </Button>
            </div>
          )}

          {/* Step 2: Payment Link */}
          {step === 'payment-link' && (
            <div className="space-y-4">
              <div className="text-center">
                <QrCode className="w-16 h-16 mx-auto mb-4 text-primary" />
                <h3 className="font-medium mb-2">Payment Link Generated</h3>
                <p className="text-sm text-muted-foreground">
                  Click the button below to open your UPI app and complete the payment
                </p>
              </div>

              <div className="space-y-3">
                <Button onClick={openPaymentApp} className="w-full">
                  <ExternalLink className="w-4 h-4 mr-2" />
                  Pay ₹{course.price.toLocaleString()} via UPI
                </Button>
                
                <Button variant="outline" onClick={copyPaymentLink} className="w-full">
                  <Copy className="w-4 h-4 mr-2" />
                  Copy Payment Link
                </Button>
              </div>

              {/* Manual Payment Info */}
              <Card className="bg-muted/30">
                <CardContent className="p-4">
                  <h4 className="font-medium mb-2">Manual Payment Option:</h4>
                  <div className="space-y-2 text-sm">
                    <div className="flex items-center justify-between">
                      <span>UPI ID:</span>
                      <div className="flex items-center gap-2">
                        <code className="bg-background px-2 py-1 rounded">your-merchant@paytm</code>
                        <Button variant="ghost" size="sm" onClick={copyUpiId}>
                          <Copy className="w-3 h-3" />
                        </Button>
                      </div>
                    </div>
                    <div className="flex items-center justify-between">
                      <span>Amount:</span>
                      <span className="font-medium">₹{course.price.toLocaleString()}</span>
                    </div>
                    <div className="flex items-center justify-between">
                      <span>Reference:</span>
                      <code className="bg-background px-2 py-1 rounded text-xs">{paymentId}</code>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Button variant="outline" onClick={() => setStep('waiting')} className="w-full">
                I've Completed the Payment
              </Button>
            </div>
          )}

          {/* Step 3: Waiting for Payment */}
          {step === 'waiting' && (
            <div className="space-y-4 text-center">
              <Clock className="w-16 h-16 mx-auto text-orange-500 animate-pulse" />
              <div>
                <h3 className="font-medium mb-2">Processing Payment...</h3>
                <p className="text-sm text-muted-foreground">
                  Please wait while we verify your payment. This may take a few moments.
                </p>
              </div>
              
              <Badge variant="outline" className="mx-auto">
                Payment ID: {paymentId}
              </Badge>

              <Button variant="outline" onClick={() => setStep('verification')} className="w-full">
                Check Payment Status
              </Button>
            </div>
          )}

          {/* Step 4: Verification */}
          {step === 'verification' && (
            <div className="space-y-4 text-center">
              <AlertCircle className="w-16 h-16 mx-auto text-blue-500" />
              <div>
                <h3 className="font-medium mb-2">Payment Under Review</h3>
                <p className="text-sm text-muted-foreground">
                  Your payment has been received and is being verified by our admin team. 
                  You'll get course access once approved.
                </p>
              </div>

              <Card className="bg-blue-50 border-blue-200">
                <CardContent className="p-4">
                  <div className="text-sm space-y-1">
                    <div className="flex justify-between">
                      <span>Payment ID:</span>
                      <code className="text-xs">{paymentId}</code>
                    </div>
                    <div className="flex justify-between">
                      <span>Status:</span>
                      <Badge variant="secondary">Pending Approval</Badge>
                    </div>
                    <div className="flex justify-between">
                      <span>Time:</span>
                      <span>{new Date().toLocaleTimeString()}</span>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <div className="space-y-2">
                <Button onClick={handlePaymentComplete} className="w-full">
                  <CheckCircle className="w-4 h-4 mr-2" />
                  Confirm Payment Submitted
                </Button>
                <p className="text-xs text-muted-foreground">
                  You'll receive an email confirmation once your payment is approved
                </p>
              </div>
            </div>
          )}
        </div>
      </DialogContent>
    </Dialog>
  );
};

export default UPIPayment;
