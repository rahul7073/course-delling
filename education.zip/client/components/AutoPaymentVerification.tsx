import React, { useState, useEffect, useRef } from 'react';
import { CheckCircle, Loader2, XCircle, Clock } from 'lucide-react';
import { useData } from '../contexts/DataContext';
import { useAuth } from '../contexts/AuthContext';
import { useToast } from '@/hooks/use-toast';

interface AutoPaymentVerificationProps {
  paymentId: string;
  amount: number;
  courseId: string;
  courseName: string;
  upiVPA: string;
  onPaymentSuccess: () => void;
  onPaymentFailed?: () => void;
}

const AutoPaymentVerification: React.FC<AutoPaymentVerificationProps> = ({
  paymentId,
  amount,
  courseId,
  courseName,
  upiVPA,
  onPaymentSuccess,
  onPaymentFailed
}) => {
  const [status, setStatus] = useState<'checking' | 'success' | 'failed' | 'timeout'>('checking');
  const [checkCount, setCheckCount] = useState(0);
  const [timeRemaining, setTimeRemaining] = useState(300); // 5 minutes
  const { addOrder, updateOrder, users } = useData();
  const { user } = useAuth();
  const { toast } = useToast();
  
  const intervalRef = useRef<NodeJS.Timeout>();
  const timeoutRef = useRef<NodeJS.Timeout>();

  // Simulate payment verification (in real app, this would call actual payment API)
  const checkPaymentStatus = async () => {
    console.log(`🔍 Checking payment ${paymentId}... (Attempt ${checkCount + 1})`);
    
    // Simulate API call to check payment status
    // In real implementation, this would check with your payment provider
    try {
      // Simulate payment verification logic
      const paymentExists = await simulatePaymentCheck(paymentId, amount, upiVPA);
      
      if (paymentExists) {
        console.log('✅ Payment confirmed!');
        handlePaymentSuccess();
        return true;
      }
      
      setCheckCount(prev => prev + 1);
      return false;
    } catch (error) {
      console.error('❌ Payment check failed:', error);
      return false;
    }
  };

  // Simulate payment verification (replace with real API)
  const simulatePaymentCheck = async (paymentId: string, amount: number, vpa: string): Promise<boolean> => {
    // For demo purposes, simulate payment after 30 seconds
    // In production, this would check actual payment gateway
    const elapsed = (300 - timeRemaining);
    
    // Simulate payment success after 30 seconds for demo
    if (elapsed > 30) {
      return Math.random() > 0.3; // 70% success rate for demo
    }
    
    return false;
  };

  const handlePaymentSuccess = () => {
    setStatus('success');
    
    // Clear intervals
    if (intervalRef.current) clearInterval(intervalRef.current);
    if (timeoutRef.current) clearTimeout(timeoutRef.current);

    // Create order record
    const orderId = addOrder({
      userId: user?.id || 'guest',
      courseId: courseId,
      courseName: courseName,
      amount: amount,
      paymentMethod: 'UPI',
      paymentStatus: 'completed',
      orderDate: new Date().toISOString(),
      paymentDate: new Date().toISOString(),
      transactionId: paymentId,
      utrNumber: paymentId,
      isUnlocked: true
    });

    // Show success message
    toast({
      title: "✅ Payment Successful!",
      description: `Course "${courseName}" has been unlocked. Amount: ₹${amount}`,
      duration: 5000
    });

    console.log(`🎉 Course unlocked! Order ID: ${orderId}`);
    
    // Trigger success callback
    setTimeout(() => {
      onPaymentSuccess();
    }, 2000);
  };

  const handlePaymentTimeout = () => {
    setStatus('timeout');
    
    if (intervalRef.current) clearInterval(intervalRef.current);
    if (timeoutRef.current) clearTimeout(timeoutRef.current);

    toast({
      title: "⏰ Payment Verification Timeout",
      description: "Payment not detected. Please try again or contact support.",
      variant: "destructive"
    });

    if (onPaymentFailed) onPaymentFailed();
  };

  const handlePaymentFailed = () => {
    setStatus('failed');
    
    if (intervalRef.current) clearInterval(intervalRef.current);
    if (timeoutRef.current) clearTimeout(timeoutRef.current);

    toast({
      title: "❌ Payment Not Found",
      description: "No payment detected. Please ensure payment was completed successfully.",
      variant: "destructive"
    });

    if (onPaymentFailed) onPaymentFailed();
  };

  useEffect(() => {
    // Start payment verification
    console.log('🚀 Starting automatic payment verification...');
    
    // Check immediately
    checkPaymentStatus();

    // Set up periodic checking (every 5 seconds)
    intervalRef.current = setInterval(async () => {
      const success = await checkPaymentStatus();
      
      if (!success && checkCount >= 60) { // Stop after 60 attempts (5 minutes)
        handlePaymentFailed();
      }
    }, 5000);

    // Set up timeout (5 minutes)
    timeoutRef.current = setTimeout(handlePaymentTimeout, 300000);

    // Timer countdown
    const timerInterval = setInterval(() => {
      setTimeRemaining(prev => {
        if (prev <= 1) {
          clearInterval(timerInterval);
          return 0;
        }
        return prev - 1;
      });
    }, 1000);

    return () => {
      if (intervalRef.current) clearInterval(intervalRef.current);
      if (timeoutRef.current) clearTimeout(timeoutRef.current);
      clearInterval(timerInterval);
    };
  }, []);

  const formatTime = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins}:${secs.toString().padStart(2, '0')}`;
  };

  const getStatusDisplay = () => {
    switch (status) {
      case 'checking':
        return {
          icon: <Loader2 className="w-8 h-8 animate-spin text-blue-500" />,
          title: "🔍 Verifying Payment...",
          message: "Please wait while we verify your payment automatically",
          bgColor: "bg-blue-50 border-blue-200",
          textColor: "text-blue-800"
        };
      case 'success':
        return {
          icon: <CheckCircle className="w-8 h-8 text-green-500" />,
          title: "✅ Payment Successful!",
          message: `Course "${courseName}" has been unlocked successfully`,
          bgColor: "bg-green-50 border-green-200", 
          textColor: "text-green-800"
        };
      case 'failed':
        return {
          icon: <XCircle className="w-8 h-8 text-red-500" />,
          title: "❌ Payment Not Detected",
          message: "No payment found. Please ensure payment was completed.",
          bgColor: "bg-red-50 border-red-200",
          textColor: "text-red-800"
        };
      case 'timeout':
        return {
          icon: <Clock className="w-8 h-8 text-orange-500" />,
          title: "⏰ Verification Timeout",
          message: "Payment verification timed out. Contact support if payment was made.",
          bgColor: "bg-orange-50 border-orange-200",
          textColor: "text-orange-800"
        };
      default:
        return {
          icon: <Loader2 className="w-8 h-8 animate-spin text-gray-500" />,
          title: "Checking...",
          message: "Please wait",
          bgColor: "bg-gray-50 border-gray-200",
          textColor: "text-gray-800"
        };
    }
  };

  const statusDisplay = getStatusDisplay();

  return (
    <div className={`border rounded-lg p-6 ${statusDisplay.bgColor} ${statusDisplay.textColor}`}>
      <div className="flex items-center justify-center mb-4">
        {statusDisplay.icon}
      </div>
      
      <div className="text-center">
        <h3 className="text-lg font-bold mb-2">{statusDisplay.title}</h3>
        <p className="text-sm mb-4">{statusDisplay.message}</p>
        
        {status === 'checking' && (
          <div className="space-y-2">
            <div className="text-xs">
              <strong>Payment ID:</strong> {paymentId}
            </div>
            <div className="text-xs">
              <strong>Amount:</strong> ₹{amount}
            </div>
            <div className="text-xs">
              <strong>UPI:</strong> {upiVPA}
            </div>
            <div className="text-xs">
              <strong>Time Remaining:</strong> {formatTime(timeRemaining)}
            </div>
            <div className="text-xs">
              <strong>Check #{checkCount + 1}</strong>
            </div>
            
            <div className="mt-4 p-3 bg-white/50 rounded border text-xs">
              <strong>💡 How it works:</strong>
              <ul className="mt-1 space-y-1 text-left">
                <li>• Payment is verified automatically every 5 seconds</li>
                <li>• Once detected, course unlocks immediately</li>
                <li>• Verification continues for 5 minutes</li>
                <li>• No manual proof needed!</li>
              </ul>
            </div>
          </div>
        )}

        {status === 'success' && (
          <div className="space-y-2">
            <div className="text-sm font-bold">🎉 Congratulations!</div>
            <div className="text-xs">Course access granted immediately</div>
            <div className="text-xs">You can now access all course content</div>
          </div>
        )}
      </div>
    </div>
  );
};

export default AutoPaymentVerification;
