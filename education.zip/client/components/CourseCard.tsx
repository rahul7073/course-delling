import React from 'react';
import { Link } from 'react-router-dom';
import { Course } from '@shared/types';
import { Badge } from './ui/badge';
import { Button } from './ui/button';
import { Card, CardContent, CardFooter, CardHeader } from './ui/card';
import { useCart } from '../contexts/CartContext';
import { useToast } from '@/hooks/use-toast';
import { setupCartNotifications } from '../utils/cartNotifications';
import {
  Star,
  Users,
  Clock,
  PlayCircle,
  BookOpen,
  ShoppingCart,
  Heart,
  Check
} from 'lucide-react';

interface CourseCardProps {
  course: Course;
  variant?: 'default' | 'compact';
}

export function CourseCard({ course, variant = 'default' }: CourseCardProps) {
  const isCompact = variant === 'compact';
  const { addToCart, isInCart } = useCart();
  const { toast } = useToast();

  // Setup cart notifications
  React.useEffect(() => {
    const cleanup = setupCartNotifications(toast);
    return cleanup;
  }, [toast]);

  const handleAddToCart = () => {
    if (!isInCart(course.id)) {
      addToCart(course);
      // Success notification is automatically handled by cart context
    }
  };

  return (
    <Card className="group overflow-hidden hover:shadow-lg transition-all duration-300 border-0 shadow-sm bg-card">
      <CardHeader className="p-0">
        <Link to={`/course/${course.id}`}>
          <div className="relative overflow-hidden">
            <img
              src={course.thumbnail}
              alt={course.title}
              className={`w-full object-cover transition-transform duration-300 group-hover:scale-105 ${
                isCompact ? 'h-32' : 'h-48'
              }`}
            />
            
            {/* Overlay badges */}
            <div className="absolute top-3 left-3 flex flex-wrap gap-1">
              {course.isFree && (
                <Badge className="bg-success text-success-foreground">
                  Free
                </Badge>
              )}
              {course.isPopular && (
                <Badge className="bg-orange-500 text-white">
                  Popular
                </Badge>
              )}
              {course.isNew && (
                <Badge className="bg-blue-500 text-white">
                  New
                </Badge>
              )}
            </div>

            {/* Play button overlay */}
            <div className="absolute inset-0 flex items-center justify-center bg-black/20 opacity-0 group-hover:opacity-100 transition-opacity duration-300">
              <div className="flex items-center justify-center w-16 h-16 bg-white/90 rounded-full">
                <PlayCircle className="w-8 h-8 text-primary" />
              </div>
            </div>

            {/* Wishlist button */}
            <Button
              variant="ghost"
              size="sm"
              className="absolute top-3 right-3 h-8 w-8 p-0 bg-white/80 hover:bg-white opacity-0 group-hover:opacity-100 transition-all duration-300"
            >
              <Heart className="h-4 w-4" />
            </Button>
          </div>
        </Link>
      </CardHeader>

      <CardContent className={isCompact ? 'p-4' : 'p-6'}>
        {/* Category */}
        <div className="flex items-center justify-between mb-2">
          <Badge variant="secondary" className="text-xs">
            {course.category}
          </Badge>
          <div className="flex items-center space-x-1 text-xs text-muted-foreground">
            <Clock className="w-3 h-3" />
            <span>{course.duration}</span>
          </div>
        </div>

        {/* Title */}
        <Link to={`/course/${course.id}`}>
          <h3 className={`font-semibold text-foreground hover:text-primary transition-colors line-clamp-2 ${
            isCompact ? 'text-sm' : 'text-base'
          }`}>
            {course.title}
          </h3>
        </Link>

        {/* Instructor */}
        {course.instructor && (
          <div className="flex items-center space-x-2 mt-2 mb-3">
            <img
              src={course.instructor.avatar || 'https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=150'}
              alt={course.instructor.name || 'Instructor'}
              className="w-6 h-6 rounded-full object-cover"
            />
            <span className="text-sm text-muted-foreground">
              {course.instructor.name || 'Unknown Instructor'}
            </span>
          </div>
        )}

        {/* Stats */}
        <div className="flex items-center justify-between text-xs text-muted-foreground mb-3">
          <div className="flex items-center space-x-3">
            <div className="flex items-center space-x-1">
              <Star className="w-3 h-3 fill-yellow-400 text-yellow-400" />
              <span className="font-medium">{course.rating || 0}</span>
              <span>({course.reviewCount || 0})</span>
            </div>
            <div className="flex items-center space-x-1">
              <Users className="w-3 h-3" />
              <span>{(course.totalStudents || 0).toLocaleString()}</span>
            </div>
          </div>
          <div className="flex items-center space-x-1">
            <BookOpen className="w-3 h-3" />
            <span>{course.totalLessons || 0} lessons</span>
          </div>
        </div>

        {!isCompact && course.shortDescription && (
          <p className="text-sm text-muted-foreground line-clamp-2 mb-4">
            {course.shortDescription}
          </p>
        )}
      </CardContent>

      <CardFooter className={`flex items-center justify-between ${isCompact ? 'p-4 pt-0' : 'p-6 pt-0'}`}>
        {/* Price */}
        <div className="flex items-center space-x-2">
          {course.isFree ? (
            <span className="text-lg font-bold text-success">Free</span>
          ) : (
            <>
              <span className="text-lg font-bold text-foreground">
                ${course.price}
              </span>
              {course.originalPrice && (
                <span className="text-sm text-muted-foreground line-through">
                  ${course.originalPrice}
                </span>
              )}
            </>
          )}
        </div>

        {/* Action buttons */}
        <div className="flex items-center space-x-2">
          {course.isFree ? (
            <Button size="sm" asChild>
              <Link to={`/course/${course.id}`}>
                Start Learning
              </Link>
            </Button>
          ) : (
            <Button
              size="sm"
              variant={isInCart(course.id) ? "default" : "outline"}
              onClick={handleAddToCart}
              disabled={isInCart(course.id)}
            >
              {isInCart(course.id) ? (
                <>
                  <Check className="w-4 h-4 mr-1" />
                  In Cart
                </>
              ) : (
                <>
                  <ShoppingCart className="w-4 h-4 mr-1" />
                  Add to Cart
                </>
              )}
            </Button>
          )}
        </div>
      </CardFooter>
    </Card>
  );
}
