import "./global.css";

import { Toaster } from "@/components/ui/toaster";
import { createRoot } from "react-dom/client";
import { Toaster as Sonner } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { BrowserRouter, Routes, Route } from "react-router-dom";
import { Header } from "./components/Header";
import { Footer } from "./components/Footer";
import { CartProvider } from "./contexts/CartContext";
import { AuthProvider } from "./contexts/AuthContext";
import { AdminProvider } from "./contexts/AdminContext";
import { DataProvider } from "./contexts/DataContext";
import { ThemeProvider } from "./components/ThemeProvider";
import Index from "./pages/Index";
import Courses from "./pages/Courses";
import Categories from "./pages/Categories";
import Certifications from "./pages/Certifications";
import About from "./pages/About";
import Contact from "./pages/Contact";
import Login from "./pages/Login";
import Register from "./pages/Register";
import UserDashboard from "./pages/UserDashboard";
import CourseDetail from "./pages/CourseDetail";
import NotFound from "./pages/NotFound";
import { PlaceholderPage } from "./components/PlaceholderPage";
import AdminRoute from "./components/AdminRoute";
import AdminLayout from "./components/AdminLayout";
import AdminLogin from "./pages/AdminLogin";
import AutoMigration from "./components/AutoMigration";
import AdminDashboard from "./pages/AdminDashboard";
import AdminCourses from "./pages/AdminCourses";
import AdminUsers from "./pages/AdminUsers";
import AdminOrders from "./pages/AdminOrders";
import AdminCertifications from "./pages/AdminCertifications";
import AdminMessages from "./pages/AdminMessages";
import AdminPayments from "./pages/AdminPayments";
import AdminPaymentApproval from "./pages/AdminPaymentApproval";
import AdminSettings from "./pages/AdminSettings";
import AdminDatabase from "./pages/AdminDatabase";
import StorageErrorHandler from "./components/StorageErrorHandler";

const queryClient = new QueryClient();

function Layout({ children }: { children: React.ReactNode }) {
  return (
    <div className="min-h-screen flex flex-col">
      <AutoMigration />
      <Header />
      <main className="flex-1">
        {children}
      </main>
      <Footer />
    </div>
  );
}

const App = () => (
  <QueryClientProvider client={queryClient}>
    <ThemeProvider defaultTheme="system">
      <TooltipProvider>
        <DataProvider>
          <AuthProvider>
            <AdminProvider>
              <CartProvider>
            <Toaster />
            <Sonner />
            <BrowserRouter>
              <Layout>
                <Routes>
                  <Route path="/" element={<Index />} />
                  <Route path="/courses" element={<Courses />} />
                  <Route path="/course/:id" element={<CourseDetail />} />
                  <Route path="/login" element={<Login />} />
                  <Route path="/register" element={<Register />} />
                  <Route path="/dashboard" element={<UserDashboard />} />
                  <Route path="/categories" element={<Categories />} />
                  <Route path="/certifications" element={<Certifications />} />
                  <Route path="/about" element={<About />} />
                  <Route path="/contact" element={<Contact />} />

                  {/* Admin Routes */}
                  <Route path="/admin/login" element={<AdminLogin />} />
                  <Route path="/admin" element={
                    <AdminRoute>
                      <AdminLayout>
                        <AdminDashboard />
                      </AdminLayout>
                    </AdminRoute>
                  } />
                  <Route path="/admin/courses" element={
                    <AdminRoute>
                      <AdminLayout>
                        <AdminCourses />
                      </AdminLayout>
                    </AdminRoute>
                  } />
                  <Route path="/admin/users" element={
                    <AdminRoute>
                      <AdminLayout>
                        <AdminUsers />
                      </AdminLayout>
                    </AdminRoute>
                  } />
                  <Route path="/admin/orders" element={
                    <AdminRoute>
                      <AdminLayout>
                        <AdminOrders />
                      </AdminLayout>
                    </AdminRoute>
                  } />
                  <Route path="/admin/certifications" element={
                    <AdminRoute>
                      <AdminLayout>
                        <AdminCertifications />
                      </AdminLayout>
                    </AdminRoute>
                  } />
                  <Route path="/admin/messages" element={
                    <AdminRoute>
                      <AdminLayout>
                        <AdminMessages />
                      </AdminLayout>
                    </AdminRoute>
                  } />
                  <Route path="/admin/payments" element={
                    <AdminRoute>
                      <AdminLayout>
                        <AdminPayments />
                      </AdminLayout>
                    </AdminRoute>
                  } />
                  <Route path="/admin/payment-approval" element={
                    <AdminRoute>
                      <AdminLayout>
                        <AdminPaymentApproval />
                      </AdminLayout>
                    </AdminRoute>
                  } />
                  <Route path="/admin/settings" element={
                    <AdminRoute>
                      <AdminLayout>
                        <AdminSettings />
                      </AdminLayout>
                    </AdminRoute>
                  } />
                  <Route path="/admin/database" element={
                    <AdminRoute>
                      <AdminLayout>
                        <AdminDatabase />
                      </AdminLayout>
                    </AdminRoute>
                  } />

                  {/* ADD ALL CUSTOM ROUTES ABOVE THE CATCH-ALL "*" ROUTE */}
                  <Route path="*" element={<NotFound />} />
                </Routes>
              </Layout>
            </BrowserRouter>
              </CartProvider>
            </AdminProvider>
          </AuthProvider>
        </DataProvider>

        {/* Global Storage Error Handler */}
        <StorageErrorHandler />
      </TooltipProvider>
    </ThemeProvider>
  </QueryClientProvider>
);

createRoot(document.getElementById("root")!).render(<App />);
