// Test course creation with video
const testCourse = {
  id: 'test-video-course',
  title: 'HTML Test Course',
  description: 'Test course with video',
  classes: [
    {
      id: 'class-1',
      classNumber: 1,
      title: 'HTML Basics',
      description: 'Learn HTML fundamentals',
      isDemo: true,
      videos: [
        {
          id: 'video-1',
          title: 'HTML Introduction',
          description: 'Introduction to HTML',
          duration: '10:00',
          fileUrl: 'https://www.w3schools.com/html/mov_bbb.mp4', // Test video URL
          classNumber: 1
        }
      ]
    }
  ]
};

// Save to localStorage
localStorage.setItem('edumaster_courses', JSON.stringify([testCourse]));
console.log('Test course created:', testCourse);
