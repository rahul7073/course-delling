import React, { createContext, useContext, useState, useEffect } from 'react';
import { Course } from '@shared/types';
import { useData } from './DataContext';
import { useAuth } from './AuthContext';
import { saveToLocalStorage } from '../utils/storageManager';

interface CartItem {
  course: Course;
  addedAt: Date;
}

interface CartContextType {
  cartItems: CartItem[];
  addToCart: (course: Course) => void;
  removeFromCart: (courseId: string) => void;
  clearCart: () => void;
  isInCart: (courseId: string) => boolean;
  cartTotal: number;
  cartCount: number;
  purchaseCart: (paymentMethod: string) => Promise<string[]>;
  isMemoryOnly: boolean;
}

const CartContext = createContext<CartContextType | undefined>(undefined);

export function CartProvider({ children }: { children: React.ReactNode }) {
  // Try to use contexts, but handle gracefully if not available
  let dataContext;
  let authContext;
  try {
    dataContext = useData();
  } catch (error) {
    dataContext = { addOrder: () => '' };
  }
  try {
    authContext = useAuth();
  } catch (error) {
    authContext = { user: null };
  }

  const { addOrder } = dataContext;
  const { user } = authContext;
  const [cartItems, setCartItems] = useState<CartItem[]>([]);
  const [isStorageFull, setIsStorageFull] = useState(false);

  // Load cart from localStorage on mount
  useEffect(() => {
    try {
      const savedCart = localStorage.getItem('edumaster-cart');
      if (savedCart) {
        const parsedCart = JSON.parse(savedCart);
        // Validate cart data before setting
        if (Array.isArray(parsedCart)) {
          setCartItems(parsedCart.map((item: any) => ({
            ...item,
            addedAt: new Date(item.addedAt)
          })));
        } else {
          console.warn('Invalid cart data format, switching to memory-only mode');
          try {
            localStorage.removeItem('edumaster-cart');
          } catch {
            setIsStorageFull(true);
          }
        }
      }
    } catch (error) {
      console.error('Error loading cart, switching to memory-only mode:', error);
      setIsStorageFull(true);
      setCartItems([]);
    }
  }, []);

  // Save cart to localStorage whenever it changes with smart fallback
  useEffect(() => {
    // Skip saving if we're already in memory-only mode or cart is empty
    if (isStorageFull || cartItems.length === 0) {
      return;
    }

    const result = saveToLocalStorage('edumaster-cart', cartItems);
    if (!result.success) {
      console.log('💾 Cart storage full, switching to memory-only mode');
      setIsStorageFull(true);
      // Cart continues to work perfectly in memory
    }
  }, [cartItems, isStorageFull]);

  const addToCart = (course: Course) => {
    try {
      if (!isInCart(course.id)) {
        const newItem: CartItem = {
          course,
          addedAt: new Date()
        };
        setCartItems(prev => [...prev, newItem]);

        // Show success feedback to user
        window.dispatchEvent(new CustomEvent('cartUpdated', {
          detail: {
            action: 'added',
            courseName: course.title,
            cartCount: cartItems.length + 1
          }
        }));
      }
    } catch (error) {
      console.error('Error adding to cart:', error);
      // Cart operation continues in memory even if storage fails
    }
  };

  const removeFromCart = (courseId: string) => {
    try {
      const itemToRemove = cartItems.find(item => item.course.id === courseId);
      setCartItems(prev => prev.filter(item => item.course.id !== courseId));

      // Show success feedback to user
      if (itemToRemove) {
        window.dispatchEvent(new CustomEvent('cartUpdated', {
          detail: {
            action: 'removed',
            courseName: itemToRemove.course.title,
            cartCount: cartItems.length - 1
          }
        }));
      }
    } catch (error) {
      console.error('Error removing from cart:', error);
    }
  };

  const clearCart = () => {
    setCartItems([]);
  };

  const isInCart = (courseId: string) => {
    return cartItems.some(item => item.course.id === courseId);
  };

  const cartTotal = cartItems.reduce((total, item) => {
    return total + (item.course.isFree ? 0 : item.course.price);
  }, 0);

  const cartCount = cartItems.length;

  const purchaseCart = async (paymentMethod: string): Promise<string[]> => {
    if (!user) {
      throw new Error('User must be logged in to purchase');
    }

    const orderIds: string[] = [];

    // Create orders for each cart item
    for (const item of cartItems) {
      const orderId = addOrder({
        userId: user.id,
        courseId: item.course.id,
        amount: item.course.price,
        paymentMethod: paymentMethod,
        paymentStatus: 'completed', // Auto-complete for demo
        orderDate: new Date().toISOString(),
        paymentDate: new Date().toISOString(),
        transactionId: `TXN${Date.now()}${Math.random().toString(36).substring(2, 7)}`,
        isUnlocked: true
      });
      orderIds.push(orderId);
    }

    // Clear cart after successful purchase
    clearCart();

    return orderIds;
  };

  const value: CartContextType = {
    cartItems,
    addToCart,
    removeFromCart,
    clearCart,
    isInCart,
    cartTotal,
    cartCount,
    purchaseCart,
    isMemoryOnly: isStorageFull
  };

  return (
    <CartContext.Provider value={value}>
      {children}
    </CartContext.Provider>
  );
}

export function useCart() {
  const context = useContext(CartContext);
  if (context === undefined) {
    throw new Error('useCart must be used within a CartProvider');
  }
  return context;
}
