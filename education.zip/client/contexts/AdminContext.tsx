import React, { createContext, useContext, useState, useEffect, ReactNode } from 'react';

interface Admin {
  id: string;
  email: string;
  name: string;
  role: 'super_admin' | 'admin';
}

interface AdminContextType {
  admin: Admin | null;
  isLoading: boolean;
  login: (email: string, password: string) => Promise<boolean>;
  logout: () => void;
  isAdminAuthenticated: boolean;
}

const AdminContext = createContext<AdminContextType | undefined>(undefined);

export const useAdmin = () => {
  const context = useContext(AdminContext);
  if (context === undefined) {
    throw new Error('useAdmin must be used within an AdminProvider');
  }
  return context;
};

interface AdminProviderProps {
  children: ReactNode;
}

export const AdminProvider: React.FC<AdminProviderProps> = ({ children }) => {
  const [admin, setAdmin] = useState<Admin | null>(null);
  const [isLoading, setIsLoading] = useState(false);

  useEffect(() => {
    const savedAdmin = localStorage.getItem('admin');
    if (savedAdmin) {
      setAdmin(JSON.parse(savedAdmin));
    }
  }, []);

  const login = async (email: string, password: string): Promise<boolean> => {
    setIsLoading(true);
    
    // Simulate API call
    await new Promise(resolve => setTimeout(resolve, 1000));
    
    // Admin credentials - you can change these
    const validAdmins = [
      { email: 'admin@edumaster.com', password: 'admin123', name: 'Admin', role: 'super_admin' as const },
      { email: 'codenest@edumaster.com', password: 'codenest123', name: 'Code Nest', role: 'super_admin' as const }
    ];
    
    const validAdmin = validAdmins.find(a => a.email === email && a.password === password);
    
    if (validAdmin) {
      const adminData: Admin = {
        id: '1',
        email: validAdmin.email,
        name: validAdmin.name,
        role: validAdmin.role
      };
      setAdmin(adminData);
      localStorage.setItem('admin', JSON.stringify(adminData));
      setIsLoading(false);
      return true;
    }
    
    setIsLoading(false);
    return false;
  };

  const logout = () => {
    setAdmin(null);
    localStorage.removeItem('admin');
  };

  return (
    <AdminContext.Provider
      value={{
        admin,
        isLoading,
        login,
        logout,
        isAdminAuthenticated: !!admin,
      }}
    >
      {children}
    </AdminContext.Provider>
  );
};
