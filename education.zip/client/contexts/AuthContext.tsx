import React, { createContext, useContext, useState, useEffect } from 'react';
import { useData } from './DataContext';

interface User {
  id: string;
  name: string;
  email: string;
  avatar?: string;
  enrolledCourses: string[];
  completedCourses: string[];
  certificates: string[];
}

interface AuthContextType {
  user: User | null;
  login: (email: string, password: string) => Promise<void>;
  register: (name: string, email: string, password: string) => Promise<void>;
  logout: () => void;
  isAuthenticated: boolean;
  isLoading: boolean;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export function AuthProvider({ children }: { children: React.ReactNode }) {
  // Try to use data context, but handle gracefully if not available
  let dataContext;
  try {
    dataContext = useData();
  } catch (error) {
    dataContext = { users: [], addUser: () => '', updateUser: () => {} };
  }
  const { users, addUser, updateUser } = dataContext;

  const [user, setUser] = useState<User | null>(null);
  const [isLoading, setIsLoading] = useState(true);

  // Check if user is logged in on app start
  useEffect(() => {
    const savedUser = localStorage.getItem('edumaster-user');
    if (savedUser) {
      try {
        setUser(JSON.parse(savedUser));
      } catch (error) {
        console.error('Error loading user from localStorage:', error);
        localStorage.removeItem('edumaster-user');
      }
    }
    setIsLoading(false);
  }, []);

  // Save user to localStorage whenever user state changes
  useEffect(() => {
    if (user) {
      localStorage.setItem('edumaster-user', JSON.stringify(user));
    } else {
      localStorage.removeItem('edumaster-user');
    }
  }, [user]);

  const login = async (email: string, password: string) => {
    setIsLoading(true);

    // Simulate API call
    await new Promise(resolve => setTimeout(resolve, 1000));

    // Find existing user or create demo user
    let foundUser = users.find(u => u.email === email);

    if (!foundUser) {
      // Create demo user if not found
      const newUserId = addUser({
        name: email === 'demo@edumaster.com' ? 'Demo User' : 'John Doe',
        email: email,
        avatar: 'https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=150',
        joinDate: new Date().toISOString().split('T')[0],
        status: 'active',
        enrolledCourses: email === 'demo@edumaster.com' ? ['1', '2'] : [],
        completedCourses: email === 'demo@edumaster.com' ? ['2'] : [],
        certificates: email === 'demo@edumaster.com' ? ['2'] : [],
        totalSpent: email === 'demo@edumaster.com' ? 6998 : 0,
        lastActive: new Date().toISOString(),
        location: 'India'
      });
      foundUser = users.find(u => u.id === newUserId);
    } else {
      // Update last active time
      updateUser(foundUser.id, { lastActive: new Date().toISOString() });
    }

    if (foundUser) {
      const authUser: User = {
        id: foundUser.id,
        name: foundUser.name,
        email: foundUser.email,
        avatar: foundUser.avatar,
        enrolledCourses: foundUser.enrolledCourses,
        completedCourses: foundUser.completedCourses,
        certificates: foundUser.certificates
      };
      setUser(authUser);
    }

    setIsLoading(false);
  };

  const register = async (name: string, email: string, password: string) => {
    setIsLoading(true);

    // Simulate API call
    await new Promise(resolve => setTimeout(resolve, 1500));

    // Create new user in real data store
    const newUserId = addUser({
      name: name,
      email: email,
      avatar: 'https://images.unsplash.com/photo-1494790108755-2616b612b786?w=150',
      joinDate: new Date().toISOString().split('T')[0],
      status: 'active',
      enrolledCourses: [],
      completedCourses: [],
      certificates: [],
      totalSpent: 0,
      lastActive: new Date().toISOString(),
      location: 'India'
    });

    const newUser: User = {
      id: newUserId,
      name: name,
      email: email,
      avatar: 'https://images.unsplash.com/photo-1494790108755-2616b612b786?w=150',
      enrolledCourses: [],
      completedCourses: [],
      certificates: []
    };

    setUser(newUser);
    setIsLoading(false);
  };

  const logout = () => {
    setUser(null);
  };

  const value: AuthContextType = {
    user,
    login,
    register,
    logout,
    isAuthenticated: !!user,
    isLoading
  };

  return (
    <AuthContext.Provider value={value}>
      {children}
    </AuthContext.Provider>
  );
}

export function useAuth() {
  const context = useContext(AuthContext);
  if (context === undefined) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
}
