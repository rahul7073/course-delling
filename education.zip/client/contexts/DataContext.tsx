import React, { createContext, useContext, useState, useEffect, ReactNode } from 'react';
import { saveToLocalStorage, storageManager, checkStorageHealth } from '../utils/storageManager';

// Types for real data
interface RealUser {
  id: string;
  name: string;
  email: string;
  avatar: string;
  joinDate: string;
  status: 'active' | 'blocked' | 'pending';
  enrolledCourses: string[];
  completedCourses: string[];
  certificates: string[];
  totalSpent: number;
  lastActive: string;
  location: string;
  phone?: string;
}

interface CourseNote {
  id: string;
  title: string;
  description: string;
  fileUrl: string;
  fileSize: string;
  uploadDate: string;
  classNumber: number;
}

interface CourseVideo {
  id: string;
  title: string;
  description: string;
  videoUrl: string;
  duration: string;
  thumbnailUrl?: string;
  uploadDate: string;
  order: number;
  isPreview: boolean;
  classNumber: number;
}

interface CourseProject {
  id: string;
  title: string;
  description: string;
  codeFiles: {
    fileName: string;
    fileUrl: string;
    language: string;
  }[];
  projectUrl?: string;
  demoUrl?: string;
  uploadDate: string;
  difficulty: 'easy' | 'medium' | 'hard';
  classNumber: number;
}

interface CourseClass {
  id: string;
  classNumber: number;
  title: string;
  description: string;
  isDemo: boolean;
  videos: CourseVideo[];
  notes: CourseNote[];
  projects: CourseProject[];
}

interface RealCourse {
  id: string;
  title: string;
  description: string;
  shortDescription: string;
  instructor: {
    id: string;
    name: string;
    avatar?: string;
    bio: string;
  };
  category: string;
  tags: string[];
  price: number;
  originalPrice?: number;
  currency: string;
  level: 'beginner' | 'intermediate' | 'advanced';
  duration: string;
  totalLessons: number;
  totalStudents: number;
  rating: number;
  reviewCount: number;
  thumbnail: string;
  previewVideo?: string;
  isFree: boolean;
  isPopular?: boolean;
  isNew?: boolean;
  isPublished: boolean;
  features: string[];
  learningOutcomes: string[];
  requirements: string[];
  classes: CourseClass[];
  notes: CourseNote[];
  videos: CourseVideo[];
  projects: CourseProject[];
  createdAt: string;
  updatedAt: string;
}

interface RealOrder {
  id: string;
  userId: string;
  courseId: string;
  amount: number;
  paymentMethod: string;
  paymentStatus: 'pending' | 'completed' | 'failed' | 'refunded';
  orderDate: string;
  paymentDate?: string;
  transactionId?: string;
  utrNumber?: string;
  paymentScreenshot?: string;
  isUnlocked: boolean;
}

interface UserProgress {
  id: string;
  userId: string;
  courseId: string;
  completedClasses: string[]; // Array of class IDs that are completed
  currentClass: string; // Current class ID being studied
  progressPercentage: number;
  lastAccessed: string;
  totalTimeSpent: number; // in minutes
}

interface ClassCompletion {
  classId: string;
  completedAt: string;
  timeSpent: number; // in minutes
}

interface DataContextType {
  // Users
  users: RealUser[];
  addUser: (user: Omit<RealUser, 'id'>) => string;
  updateUser: (id: string, updates: Partial<RealUser>) => void;
  deleteUser: (id: string) => void;
  getUserById: (id: string) => RealUser | undefined;
  
  // Courses
  courses: RealCourse[];
  addCourse: (course: Omit<RealCourse, 'id' | 'totalStudents' | 'rating' | 'reviewCount' | 'createdAt' | 'updatedAt'>) => string;
  updateCourse: (id: string, updates: Partial<RealCourse>) => void;
  deleteCourse: (id: string) => void;
  getCourseById: (id: string) => RealCourse | undefined;
  addCourseNote: (courseId: string, note: Omit<CourseNote, 'id'>) => void;
  deleteCourseNote: (courseId: string, noteId: string) => void;

  // Video management
  addCourseVideo: (courseId: string, video: Omit<CourseVideo, 'id'>) => void;
  deleteCourseVideo: (courseId: string, videoId: string) => void;
  updateCourseVideo: (courseId: string, videoId: string, updates: Partial<CourseVideo>) => void;

  // Project management
  addCourseProject: (courseId: string, project: Omit<CourseProject, 'id'>) => void;
  deleteCourseProject: (courseId: string, projectId: string) => void;
  updateCourseProject: (courseId: string, projectId: string, updates: Partial<CourseProject>) => void;

  // Class management
  addCourseClass: (courseId: string, classData: Omit<CourseClass, 'id'>) => void;
  updateCourseClass: (courseId: string, classId: string, updates: Partial<CourseClass>) => void;
  deleteCourseClass: (courseId: string, classId: string) => void;
  
  // Orders
  orders: RealOrder[];
  addOrder: (order: Omit<RealOrder, 'id'>) => string;
  updateOrder: (id: string, updates: Partial<RealOrder>) => void;
  deleteOrder: (id: string) => void;

  // User Progress
  userProgress: UserProgress[];
  getUserProgress: (userId: string, courseId: string) => UserProgress | undefined;
  updateUserProgress: (userId: string, courseId: string, updates: Partial<UserProgress>) => void;
  markClassComplete: (userId: string, courseId: string, classId: string) => void;
  isClassCompleted: (userId: string, courseId: string, classId: string) => boolean;

  // Statistics
  getStats: () => {
    totalUsers: number;
    activeUsers: number;
    totalCourses: number;
    totalOrders: number;
    totalRevenue: number;
    onlineUsers: number;
  };

  // Real-time functionality
  triggerDataUpdate: () => void;
}

const DataContext = createContext<DataContextType | undefined>(undefined);

export const useData = () => {
  const context = useContext(DataContext);
  if (context === undefined) {
    throw new Error('useData must be used within a DataProvider');
  }
  return context;
};

interface DataProviderProps {
  children: ReactNode;
}

export const DataProvider: React.FC<DataProviderProps> = ({ children }) => {
  const [users, setUsers] = useState<RealUser[]>([]);
  const [courses, setCourses] = useState<RealCourse[]>([]);
  const [orders, setOrders] = useState<RealOrder[]>([]);
  const [userProgress, setUserProgress] = useState<UserProgress[]>([]);
  const [dataVersion, setDataVersion] = useState(0);

  // Initialize with existing data from localStorage
  useEffect(() => {
    // Check storage health on startup
    checkStorageHealth();

    const savedUsers = localStorage.getItem('edumaster_users');
    const savedCourses = localStorage.getItem('edumaster_courses');
    const savedOrders = localStorage.getItem('edumaster_orders');
    const savedProgress = localStorage.getItem('edumaster_user_progress');

    if (savedUsers) {
      setUsers(JSON.parse(savedUsers));
    } else {
      // Initialize with demo data if no saved data
      const initialUsers: RealUser[] = [
        {
          id: '1',
          name: 'Rahul Sharma',
          email: 'rahul.sharma@gmail.com',
          avatar: 'https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=150',
          joinDate: '2024-01-10',
          status: 'active',
          enrolledCourses: ['1', '2'],
          completedCourses: ['2'],
          certificates: ['2'],
          totalSpent: 6998,
          lastActive: new Date().toISOString(),
          location: 'Mumbai, India',
          phone: '+91 9876543210'
        },
        {
          id: '2',
          name: 'Priya Patel',
          email: 'priya.patel@gmail.com',
          avatar: 'https://images.unsplash.com/photo-1494790108755-2616b612b786?w=150',
          joinDate: '2024-01-08',
          status: 'active',
          enrolledCourses: ['2'],
          completedCourses: ['2'],
          certificates: ['2'],
          totalSpent: 3999,
          lastActive: new Date().toISOString(),
          location: 'Delhi, India',
          phone: '+91 9876543211'
        }
      ];
      setUsers(initialUsers);
      const userResult = saveToLocalStorage('edumaster_users', initialUsers);
      if (!userResult.success) {
        console.error('Failed to save initial users:', userResult.error);
      }
    }

    if (savedCourses) {
      try {
        const parsedCourses = JSON.parse(savedCourses);
        setCourses(parsedCourses);
        console.log('Loaded courses from localStorage:', parsedCourses.length, 'courses');
      } catch (error) {
        console.error('Error parsing saved courses:', error);
        // If there's an error, start fresh
        setCourses([]);
      }
    } else {
      // Initialize with demo courses ONLY if no saved data exists
      const initialCourses: RealCourse[] = [
        {
          id: '1',
          title: 'Complete React Development Course',
          description: 'Master React from basics to advanced concepts with hands-on projects',
          shortDescription: 'Master React from basics to advanced concepts with real projects',
          instructor: {
            id: 'inst1',
            name: 'Sarah Johnson',
            avatar: 'https://images.unsplash.com/photo-1494790108755-2616b612b786?w=150',
            bio: 'Senior React Developer with 8+ years experience'
          },
          tags: ['React', 'JavaScript', 'Frontend'],
          price: 2999,
          originalPrice: 4999,
          currency: 'INR',
          category: 'Web Development',
          level: 'intermediate',
          duration: '40 hours',
          totalLessons: 156,
          totalStudents: 1247,
          rating: 4.8,
          reviewCount: 234,
          thumbnail: 'https://images.unsplash.com/photo-1633356122544-f134324a6cee?w=400',
          isPublished: true,
          isFree: false,
          isPopular: true,
          features: ['156 hands-on lessons', 'Downloadable resources', 'Certificate of completion'],
          learningOutcomes: ['Build modern React applications', 'Master React hooks'],
          requirements: ['Basic JavaScript knowledge'],
          notes: [
            {
              id: '1',
              title: 'React Fundamentals - Chapter 1',
              description: 'Introduction to React components and JSX',
              fileUrl: '/notes/react-fundamentals-ch1.pdf',
              fileSize: '2.5 MB',
              uploadDate: '2024-01-01'
            },
            {
              id: '2',
              title: 'React Hooks - Chapter 2',
              description: 'Understanding useState, useEffect and custom hooks',
              fileUrl: '/notes/react-hooks-ch2.pdf',
              fileSize: '3.1 MB',
              uploadDate: '2024-01-02'
            }
          ],
          videos: [
            {
              id: '1',
              title: 'Introduction to React',
              description: 'Getting started with React development',
              videoUrl: 'https://www.youtube.com/watch?v=LX4JUscM9Sk',
              duration: '15:30',
              thumbnailUrl: 'https://img.youtube.com/vi/LX4JUscM9Sk/maxresdefault.jpg',
              uploadDate: '2024-01-01',
              order: 1,
              isPreview: true
            },
            {
              id: '2',
              title: 'React Components Deep Dive',
              description: 'Understanding React components and props',
              videoUrl: 'https://www.youtube.com/watch?v=Tn6-PIqc4UM',
              duration: '22:45',
              uploadDate: '2024-01-02',
              order: 2,
              isPreview: false
            }
          ],
          projects: [
            {
              id: '1',
              title: 'Todo App with React',
              description: 'Build a complete todo application using React hooks',
              codeFiles: [
                {
                  fileName: 'App.js',
                  fileUrl: '/code/react-todo/App.js',
                  language: 'javascript'
                },
                {
                  fileName: 'TodoList.js',
                  fileUrl: '/code/react-todo/TodoList.js',
                  language: 'javascript'
                }
              ],
              projectUrl: '/projects/react-todo.zip',
              demoUrl: 'https://react-todo-demo.netlify.app',
              uploadDate: '2024-01-03',
              difficulty: 'medium'
            }
          ],
          classes: [
            {
              id: '1',
              classNumber: 1,
              title: 'Introduction to React',
              description: 'Learn the basics of React components and JSX',
              isDemo: true,
              videos: [
                {
                  id: '1',
                  title: 'React Fundamentals',
                  description: 'Getting started with React',
                  videoUrl: 'https://www.youtube.com/watch?v=LX4JUscM9Sk',
                  duration: '15:30',
                  uploadDate: '2024-01-01',
                  order: 1,
                  isPreview: true,
                  classNumber: 1
                }
              ],
              notes: [
                {
                  id: '1',
                  title: 'React Basics Notes',
                  description: 'Introduction to React concepts',
                  fileUrl: '/notes/react-basics.pdf',
                  fileSize: '2.5 MB',
                  uploadDate: '2024-01-01',
                  classNumber: 1
                }
              ],
              projects: []
            },
            {
              id: '2',
              classNumber: 2,
              title: 'React Hooks Deep Dive',
              description: 'Master useState, useEffect and custom hooks',
              isDemo: false,
              videos: [
                {
                  id: '2',
                  title: 'Understanding Hooks',
                  description: 'Complete guide to React hooks',
                  videoUrl: 'https://www.youtube.com/watch?v=Tn6-PIqc4UM',
                  duration: '22:45',
                  uploadDate: '2024-01-02',
                  order: 1,
                  isPreview: false,
                  classNumber: 2
                }
              ],
              notes: [
                {
                  id: '2',
                  title: 'Hooks Cheat Sheet',
                  description: 'Complete reference for React hooks',
                  fileUrl: '/notes/react-hooks.pdf',
                  fileSize: '3.1 MB',
                  uploadDate: '2024-01-02',
                  classNumber: 2
                }
              ],
              projects: [
                {
                  id: '1',
                  title: 'Todo App with Hooks',
                  description: 'Build a todo app using React hooks',
                  codeFiles: [
                    {
                      fileName: 'TodoApp.js',
                      fileUrl: '/code/TodoApp.js',
                      language: 'javascript'
                    }
                  ],
                  uploadDate: '2024-01-03',
                  difficulty: 'medium',
                  classNumber: 2
                }
              ]
            }
          ],
          createdAt: '2024-01-01',
          updatedAt: '2024-01-15'
        },
        {
          id: '2',
          title: 'Machine Learning with Python',
          description: 'Learn ML algorithms and implementation with Python',
          shortDescription: 'Learn ML fundamentals with Python and build real projects',
          instructor: {
            id: 'inst2',
            name: 'Dr. Michael Chen',
            avatar: 'https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=150',
            bio: 'ML Engineer, PhD in Computer Science'
          },
          tags: ['Machine Learning', 'Python', 'AI'],
          price: 3999,
          originalPrice: 5999,
          currency: 'INR',
          category: 'Data Science',
          level: 'intermediate',
          duration: '35 hours',
          totalLessons: 98,
          totalStudents: 892,
          rating: 4.7,
          reviewCount: 156,
          thumbnail: 'https://images.unsplash.com/photo-1555949963-aa79dcee981c?w=400',
          isPublished: true,
          isFree: false,
          features: ['98 comprehensive lessons', 'Python code examples', 'Real datasets'],
          learningOutcomes: ['Understand ML algorithms', 'Implement models in Python'],
          requirements: ['Basic Python knowledge'],
          notes: [
            {
              id: '3',
              title: 'ML Basics - Chapter 1',
              description: 'Introduction to Machine Learning concepts',
              fileUrl: '/notes/ml-basics-ch1.pdf',
              fileSize: '4.2 MB',
              uploadDate: '2024-01-01'
            }
          ],
          videos: [
            {
              id: '3',
              title: 'ML Fundamentals',
              description: 'Introduction to Machine Learning',
              videoUrl: 'https://www.youtube.com/watch?v=aircAruvnKk',
              duration: '18:20',
              uploadDate: '2024-01-01',
              order: 1,
              isPreview: true
            }
          ],
          projects: [
            {
              id: '2',
              title: 'Linear Regression Model',
              description: 'Implement linear regression from scratch',
              codeFiles: [
                {
                  fileName: 'linear_regression.py',
                  fileUrl: '/code/ml-basics/linear_regression.py',
                  language: 'python'
                }
              ],
              uploadDate: '2024-01-02',
              difficulty: 'easy'
            }
          ],
          createdAt: '2024-01-01',
          updatedAt: '2024-01-15'
        },
        {
          id: '3',
          title: 'JavaScript Fundamentals',
          description: 'Master JavaScript from scratch with practical examples',
          shortDescription: 'Master JavaScript basics with hands-on projects',
          instructor: {
            id: 'inst3',
            name: 'Alex Rodriguez',
            avatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=150',
            bio: 'Senior JavaScript Developer'
          },
          tags: ['JavaScript', 'Programming', 'Frontend'],
          price: 0,
          currency: 'INR',
          category: 'Programming',
          level: 'beginner',
          duration: '20 hours',
          totalLessons: 89,
          totalStudents: 2341,
          rating: 4.6,
          reviewCount: 345,
          thumbnail: 'https://images.unsplash.com/photo-1627398242454-45a1465c2479?w=400',
          isPublished: true,
          isFree: true,
          features: ['89 practical lessons', 'Code examples', 'Certificate included'],
          learningOutcomes: ['Master JavaScript fundamentals', 'Build interactive websites'],
          requirements: ['No programming experience needed'],
          classes: [],
          notes: [],
          videos: [],
          projects: [],
          createdAt: '2024-01-01',
          updatedAt: '2024-01-15'
        }
      ];
      setCourses(initialCourses);
      const result = saveToLocalStorage('edumaster_courses', initialCourses);
      if (!result.success) {
        console.error('Failed to save initial courses:', result.error);
      }
    }

    if (savedOrders) {
      setOrders(JSON.parse(savedOrders));
    } else {
      // Initialize with demo orders
      const initialOrders: RealOrder[] = [
        {
          id: 'ORD-001',
          userId: '1',
          courseId: '1',
          amount: 2999,
          paymentMethod: 'UPI',
          paymentStatus: 'completed',
          orderDate: '2024-01-15T10:30:00Z',
          paymentDate: '2024-01-15T10:32:00Z',
          transactionId: 'TXN123456789',
          isUnlocked: true
        },
        {
          id: 'ORD-002',
          userId: '2',
          courseId: '2',
          amount: 3999,
          paymentMethod: 'Credit Card',
          paymentStatus: 'completed',
          orderDate: '2024-01-14T14:20:00Z',
          paymentDate: '2024-01-14T14:22:00Z',
          transactionId: 'TXN123456790',
          isUnlocked: true
        }
      ];
      setOrders(initialOrders);
      const orderResult = saveToLocalStorage('edumaster_orders', initialOrders);
      if (!orderResult.success) {
        console.error('Failed to save initial orders:', orderResult.error);
      }
    }

    if (savedProgress) {
      setUserProgress(JSON.parse(savedProgress));
    } else {
      // Initialize with empty progress
      setUserProgress([]);
      const progressResult = saveToLocalStorage('edumaster_user_progress', []);
      if (!progressResult.success) {
        console.error('Failed to save initial user progress:', progressResult.error);
      }
    }
  }, []);

  // Save to localStorage whenever data changes - with safe storage management
  useEffect(() => {
    const result = saveToLocalStorage('edumaster_users', users);
    if (!result.success) {
      console.error('Failed to save users:', result.error);
    }
  }, [users]);

  useEffect(() => {
    const result = saveToLocalStorage('edumaster_courses', courses);
    if (!result.success) {
      if (result.error === 'STORAGE_FULL') {
        console.log('💾 Courses running in memory-only mode due to full storage');
        // Don't show any error to users - just continue in memory
      } else {
        console.error('Failed to save courses:', result.error);

        // Only show error for admin users, not regular users
        if (window.location.pathname.includes('/admin')) {
          const errorMessage = result.error?.includes('completely full')
            ? 'Storage full - courses running in memory only. Use Storage Status to free space.'
            : result.error || 'Failed to save course data due to storage limitations.';

          window.dispatchEvent(new CustomEvent('storageError', {
            detail: {
              message: errorMessage,
              type: 'courses',
              isCritical: false
            }
          }));
        }
      }
    }
  }, [courses]);

  useEffect(() => {
    const result = saveToLocalStorage('edumaster_orders', orders);
    if (!result.success) {
      console.error('Failed to save orders:', result.error);
    }
  }, [orders]);

  useEffect(() => {
    const result = saveToLocalStorage('edumaster_user_progress', userProgress);
    if (!result.success) {
      console.error('Failed to save user progress:', result.error);
    }
  }, [userProgress]);

  // User functions
  const addUser = (userData: Omit<RealUser, 'id'>): string => {
    const newUser: RealUser = {
      ...userData,
      id: Date.now().toString(),
    };
    setUsers(prev => [...prev, newUser]);
    triggerDataUpdate();
    return newUser.id;
  };

  const updateUser = (id: string, updates: Partial<RealUser>) => {
    setUsers(prev => prev.map(user => 
      user.id === id ? { ...user, ...updates } : user
    ));
    triggerDataUpdate();
  };

  const deleteUser = (id: string) => {
    setUsers(prev => prev.filter(user => user.id !== id));
    triggerDataUpdate();
  };

  const getUserById = (id: string): RealUser | undefined => {
    return users.find(user => user.id === id);
  };

  // Course functions
  const addCourse = (courseData: Omit<RealCourse, 'id' | 'totalStudents' | 'rating' | 'reviewCount' | 'createdAt' | 'updatedAt'>): string => {
    const newCourse: RealCourse = {
      ...courseData,
      id: Date.now().toString(),
      totalStudents: 0,
      rating: 0,
      reviewCount: 0,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };
    setCourses(prev => [...prev, newCourse]);
    triggerDataUpdate();
    return newCourse.id;
  };

  const updateCourse = (id: string, updates: Partial<RealCourse>) => {
    setCourses(prev => prev.map(course => 
      course.id === id ? { ...course, ...updates, updatedAt: new Date().toISOString() } : course
    ));
    triggerDataUpdate();
  };

  const deleteCourse = (id: string) => {
    setCourses(prev => prev.filter(course => course.id !== id));
    triggerDataUpdate();
  };

  const getCourseById = (id: string): RealCourse | undefined => {
    return courses.find(course => course.id === id);
  };

  const addCourseNote = (courseId: string, noteData: Omit<CourseNote, 'id'>) => {
    const newNote: CourseNote = {
      ...noteData,
      id: Date.now().toString(),
    };

    setCourses(prev => prev.map(course => {
      if (course.id === courseId) {
        // Add to both course-level AND class-level for compatibility
        const updatedClasses = course.classes.map(cls =>
          cls.classNumber === noteData.classNumber
            ? { ...cls, notes: [...(cls.notes || []), newNote] }
            : cls
        );

        return {
          ...course,
          notes: [...course.notes, newNote],
          classes: updatedClasses,
          updatedAt: new Date().toISOString()
        };
      }
      return course;
    }));
    triggerDataUpdate();
  };

  const deleteCourseNote = (courseId: string, noteId: string) => {
    setCourses(prev => prev.map(course => {
      if (course.id === courseId) {
        // Remove from both course-level AND class-level
        const updatedClasses = course.classes.map(cls => ({
          ...cls,
          notes: (cls.notes || []).filter(note => note.id !== noteId)
        }));

        return {
          ...course,
          notes: course.notes.filter(note => note.id !== noteId),
          classes: updatedClasses,
          updatedAt: new Date().toISOString()
        };
      }
      return course;
    }));
    triggerDataUpdate();
  };

  // Video management functions
  const addCourseVideo = (courseId: string, videoData: Omit<CourseVideo, 'id'>) => {
    const newVideo: CourseVideo = {
      ...videoData,
      id: Date.now().toString(),
    };

    setCourses(prev => prev.map(course => {
      if (course.id === courseId) {
        // Add to both course-level AND class-level for compatibility
        const updatedClasses = course.classes.map(cls =>
          cls.classNumber === videoData.classNumber
            ? { ...cls, videos: [...(cls.videos || []), newVideo] }
            : cls
        );

        return {
          ...course,
          videos: [...course.videos, newVideo],
          classes: updatedClasses,
          updatedAt: new Date().toISOString()
        };
      }
      return course;
    }));
    triggerDataUpdate();
  };

  const deleteCourseVideo = (courseId: string, videoId: string) => {
    setCourses(prev => prev.map(course => {
      if (course.id === courseId) {
        // Remove from both course-level AND class-level
        const updatedClasses = course.classes.map(cls => ({
          ...cls,
          videos: (cls.videos || []).filter(video => video.id !== videoId)
        }));

        return {
          ...course,
          videos: course.videos.filter(video => video.id !== videoId),
          classes: updatedClasses,
          updatedAt: new Date().toISOString()
        };
      }
      return course;
    }));
    triggerDataUpdate();
  };

  const updateCourseVideo = (courseId: string, videoId: string, updates: Partial<CourseVideo>) => {
    setCourses(prev => prev.map(course => {
      if (course.id === courseId) {
        // Update in both course-level AND class-level
        const updatedClasses = course.classes.map(cls => ({
          ...cls,
          videos: (cls.videos || []).map(video =>
            video.id === videoId ? { ...video, ...updates } : video
          )
        }));

        return {
          ...course,
          videos: course.videos.map(video =>
            video.id === videoId ? { ...video, ...updates } : video
          ),
          classes: updatedClasses,
          updatedAt: new Date().toISOString()
        };
      }
      return course;
    }));
    triggerDataUpdate();
  };

  // Project management functions
  const addCourseProject = (courseId: string, projectData: Omit<CourseProject, 'id'>) => {
    const newProject: CourseProject = {
      ...projectData,
      id: Date.now().toString(),
    };

    setCourses(prev => prev.map(course => {
      if (course.id === courseId) {
        // Add to both course-level AND class-level for compatibility
        const updatedClasses = course.classes.map(cls =>
          cls.classNumber === projectData.classNumber
            ? { ...cls, projects: [...(cls.projects || []), newProject] }
            : cls
        );

        return {
          ...course,
          projects: [...course.projects, newProject],
          classes: updatedClasses,
          updatedAt: new Date().toISOString()
        };
      }
      return course;
    }));
    triggerDataUpdate();
  };

  const deleteCourseProject = (courseId: string, projectId: string) => {
    setCourses(prev => prev.map(course => {
      if (course.id === courseId) {
        // Remove from both course-level AND class-level
        const updatedClasses = course.classes.map(cls => ({
          ...cls,
          projects: (cls.projects || []).filter(project => project.id !== projectId)
        }));

        return {
          ...course,
          projects: course.projects.filter(project => project.id !== projectId),
          classes: updatedClasses,
          updatedAt: new Date().toISOString()
        };
      }
      return course;
    }));
    triggerDataUpdate();
  };

  const updateCourseProject = (courseId: string, projectId: string, updates: Partial<CourseProject>) => {
    setCourses(prev => prev.map(course =>
      course.id === courseId
        ? {
            ...course,
            projects: course.projects.map(project =>
              project.id === projectId ? { ...project, ...updates } : project
            ),
            updatedAt: new Date().toISOString()
          }
        : course
    ));
    triggerDataUpdate();
  };

  // Class management functions
  const addCourseClass = (courseId: string, classData: Omit<CourseClass, 'id'>) => {
    const newClass: CourseClass = {
      ...classData,
      id: Date.now().toString(),
    };

    setCourses(prev => prev.map(course =>
      course.id === courseId
        ? { ...course, classes: [...course.classes, newClass], updatedAt: new Date().toISOString() }
        : course
    ));
    triggerDataUpdate();
  };

  const updateCourseClass = (courseId: string, classId: string, updates: Partial<CourseClass>) => {
    setCourses(prev => prev.map(course =>
      course.id === courseId
        ? {
            ...course,
            classes: course.classes.map(cls =>
              cls.id === classId ? { ...cls, ...updates } : cls
            ),
            updatedAt: new Date().toISOString()
          }
        : course
    ));
    triggerDataUpdate();
  };

  const deleteCourseClass = (courseId: string, classId: string) => {
    setCourses(prev => prev.map(course =>
      course.id === courseId
        ? {
            ...course,
            classes: course.classes.filter(cls => cls.id !== classId),
            updatedAt: new Date().toISOString()
          }
        : course
    ));
    triggerDataUpdate();
  };

  // Order functions
  const addOrder = (orderData: Omit<RealOrder, 'id'>): string => {
    const newOrder: RealOrder = {
      ...orderData,
      id: `ORD-${Date.now()}`,
    };
    setOrders(prev => [...prev, newOrder]);
    
    // Update course student count
    setCourses(prev => prev.map(course =>
      course.id === orderData.courseId
        ? { ...course, totalStudents: course.totalStudents + 1 }
        : course
    ));
    
    triggerDataUpdate();
    return newOrder.id;
  };

  const updateOrder = (id: string, updates: Partial<RealOrder>) => {
    setOrders(prev => prev.map(order => 
      order.id === id ? { ...order, ...updates } : order
    ));
    triggerDataUpdate();
  };

  const deleteOrder = (id: string) => {
    setOrders(prev => prev.filter(order => order.id !== id));
    triggerDataUpdate();
  };

  // User Progress Functions
  const getUserProgress = (userId: string, courseId: string): UserProgress | undefined => {
    return userProgress.find(p => p.userId === userId && p.courseId === courseId);
  };

  const updateUserProgress = (userId: string, courseId: string, updates: Partial<UserProgress>) => {
    setUserProgress(prev => {
      const existingIndex = prev.findIndex(p => p.userId === userId && p.courseId === courseId);

      if (existingIndex >= 0) {
        // Update existing progress
        const updated = [...prev];
        updated[existingIndex] = { ...updated[existingIndex], ...updates };
        return updated;
      } else {
        // Create new progress record
        const newProgress: UserProgress = {
          id: Date.now().toString(),
          userId,
          courseId,
          completedClasses: [],
          currentClass: '',
          progressPercentage: 0,
          lastAccessed: new Date().toISOString(),
          totalTimeSpent: 0,
          ...updates
        };
        return [...prev, newProgress];
      }
    });
    triggerDataUpdate();
  };

  const markClassComplete = (userId: string, courseId: string, classId: string) => {
    const progress = getUserProgress(userId, courseId);
    const course = getCourseById(courseId);

    if (!course) return;

    const totalClasses = course.classes?.length || 0;
    const completedClasses = progress?.completedClasses || [];

    if (!completedClasses.includes(classId)) {
      const updatedCompleted = [...completedClasses, classId];
      const progressPercentage = totalClasses > 0 ? (updatedCompleted.length / totalClasses) * 100 : 0;

      updateUserProgress(userId, courseId, {
        completedClasses: updatedCompleted,
        progressPercentage,
        lastAccessed: new Date().toISOString()
      });
    }
  };

  const isClassCompleted = (userId: string, courseId: string, classId: string): boolean => {
    const progress = getUserProgress(userId, courseId);
    return progress?.completedClasses.includes(classId) || false;
  };

  // Statistics
  const getStats = () => {
    const completedOrders = orders.filter(order => order.paymentStatus === 'completed');
    const totalRevenue = completedOrders.reduce((sum, order) => sum + order.amount, 0);
    const activeUsers = users.filter(user => user.status === 'active').length;
    
    // Simulate online users (random between 10-50% of active users)
    const onlineUsers = Math.floor(activeUsers * (0.1 + Math.random() * 0.4));

    return {
      totalUsers: users.length,
      activeUsers,
      totalCourses: courses.length,
      totalOrders: orders.length,
      totalRevenue,
      onlineUsers
    };
  };

  // Real-time update trigger
  const triggerDataUpdate = () => {
    setDataVersion(prev => prev + 1);
    // Broadcast event for real-time updates
    window.dispatchEvent(new CustomEvent('dataUpdated', { detail: { version: dataVersion + 1 } }));
  };

  const value: DataContextType = {
    users,
    addUser,
    updateUser,
    deleteUser,
    getUserById,
    courses,
    addCourse,
    updateCourse,
    deleteCourse,
    getCourseById,
    addCourseNote,
    deleteCourseNote,
    addCourseVideo,
    deleteCourseVideo,
    updateCourseVideo,
    addCourseProject,
    deleteCourseProject,
    updateCourseProject,
    addCourseClass,
    updateCourseClass,
    deleteCourseClass,
    orders,
    addOrder,
    updateOrder,
    deleteOrder,
    userProgress,
    getUserProgress,
    updateUserProgress,
    markClassComplete,
    isClassCompleted,
    getStats,
    triggerDataUpdate,
  };

  return (
    <DataContext.Provider value={value}>
      {children}
    </DataContext.Provider>
  );
};
