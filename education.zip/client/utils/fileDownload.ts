// Real file download utility for course materials
export const downloadFile = async (fileUrl: string, fileName: string): Promise<void> => {
  try {
    // Check if it's a data URL (base64 encoded file)
    if (fileUrl.startsWith('data:')) {
      // Handle data URL downloads
      const link = document.createElement('a');
      link.href = fileUrl;
      link.download = fileName;
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
      return;
    }

    // Handle regular URL downloads
    const response = await fetch(fileUrl);
    if (!response.ok) {
      throw new Error(`Failed to download file: ${response.statusText}`);
    }

    const blob = await response.blob();
    const url = window.URL.createObjectURL(blob);
    
    const link = document.createElement('a');
    link.href = url;
    link.download = fileName;
    document.body.appendChild(link);
    link.click();
    
    // Cleanup
    document.body.removeChild(link);
    window.URL.revokeObjectURL(url);
  } catch (error) {
    console.error('Download failed:', error);
    throw new Error('Failed to download file. Please try again.');
  }
};

// Convert file to data URL for storage
export const fileToDataURL = (file: File, maxSizeMB: number = 10): Promise<string> => {
  return new Promise((resolve, reject) => {
    // Check file size before processing
    const fileSizeMB = file.size / (1024 * 1024);

    if (fileSizeMB > maxSizeMB) {
      reject(new Error(`File size (${fileSizeMB.toFixed(2)}MB) exceeds maximum allowed size of ${maxSizeMB}MB. Large files may cause storage issues.`));
      return;
    }

    // Warn about large files
    if (fileSizeMB > 5) {
      console.warn(`⚠️ Large file detected: ${fileSizeMB.toFixed(2)}MB. This may use significant browser storage.`);
    }

    const reader = new FileReader();
    reader.onload = () => {
      let result = reader.result as string;

      // Fix MIME type for video files if browser doesn't detect correctly
      const fileName = file.name.toLowerCase();

      // Force correct MIME types for video files
      if (fileName.endsWith('.mov')) {
        // MOV files often get detected as application/octet-stream
        result = result.replace(/^data:[^;]+/, 'data:video/quicktime');
        console.log('Fixed MOV file MIME type:', result.substring(0, 50));
      } else if (fileName.endsWith('.mp4')) {
        if (!result.includes('video/')) {
          result = result.replace(/^data:[^;]+/, 'data:video/mp4');
        }
      } else if (fileName.endsWith('.avi')) {
        if (!result.includes('video/')) {
          result = result.replace(/^data:[^;]+/, 'data:video/avi');
        }
      } else if (fileName.endsWith('.webm')) {
        if (!result.includes('video/')) {
          result = result.replace(/^data:[^;]+/, 'data:video/webm');
        }
      }

      console.log('File converted:', {
        name: file.name,
        originalType: file.type,
        size: file.size,
        finalDataUrlType: result.substring(0, 50)
      });

      resolve(result);
    };
    reader.onerror = reject;
    reader.readAsDataURL(file);
  });
};

// Get file extension from name
export const getFileExtension = (fileName: string): string => {
  return fileName.split('.').pop()?.toLowerCase() || '';
};

// Get file type icon based on extension
export const getFileIcon = (fileName: string): string => {
  const ext = getFileExtension(fileName);
  switch (ext) {
    case 'pdf':
      return '📄';
    case 'doc':
    case 'docx':
      return '📝';
    case 'txt':
      return '📄';
    case 'js':
    case 'jsx':
      return '🟨';
    case 'ts':
    case 'tsx':
      return '🔷';
    case 'html':
      return '🌐';
    case 'css':
      return '🎨';
    case 'json':
      return '📋';
    case 'zip':
    case 'rar':
      return '📦';
    case 'png':
    case 'jpg':
    case 'jpeg':
    case 'gif':
      return '🖼️';
    case 'mp4':
    case 'avi':
    case 'mov':
      return '🎥';
    default:
      return '📁';
  }
};

// Format file size
export const formatFileSize = (bytes: number): string => {
  if (bytes === 0) return '0 Bytes';
  const k = 1024;
  const sizes = ['Bytes', 'KB', 'MB', 'GB'];
  const i = Math.floor(Math.log(bytes) / Math.log(k));
  return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
};
