// Cart notification utilities for user feedback

export const setupCartNotifications = (toastFunction?: any) => {
  const handleCartUpdate = (event: CustomEvent) => {
    const { action, courseName, cartCount } = event.detail;
    
    if (toastFunction) {
      if (action === 'added') {
        toastFunction({
          title: "✅ Added to Cart",
          description: `"${courseName}" has been added to your cart (${cartCount} items)`,
          duration: 3000
        });
      } else if (action === 'removed') {
        toastFunction({
          title: "🗑️ Removed from Cart", 
          description: `"${courseName}" has been removed from your cart (${cartCount} items)`,
          duration: 3000
        });
      }
    } else {
      // Fallback to browser notification if no toast function provided
      if (action === 'added') {
        console.log(`✅ Added "${courseName}" to cart`);
      } else if (action === 'removed') {
        console.log(`🗑️ Removed "${courseName}" from cart`);
      }
    }
  };

  window.addEventListener('cartUpdated', handleCartUpdate as EventListener);
  
  // Return cleanup function
  return () => {
    window.removeEventListener('cartUpdated', handleCartUpdate as EventListener);
  };
};

export const showCartSuccessMessage = (action: 'added' | 'removed', courseName: string, cartCount: number) => {
  window.dispatchEvent(new CustomEvent('cartUpdated', {
    detail: { action, courseName, cartCount }
  }));
};
