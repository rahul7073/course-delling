// Data Migration Utility - Move from localStorage to Database
import { apiDatabaseService } from '../services/ApiDatabaseService';
import { fileStorageService } from '../services/FileStorageService';

interface MigrationResult {
  success: boolean;
  migratedCourses: number;
  migratedOrders: number;
  migratedFiles: number;
  errors: string[];
}

export class DataMigration {
  static async migrateAllData(): Promise<MigrationResult> {
    console.log('🚀 Starting data migration from localStorage to database...');
    
    const result: MigrationResult = {
      success: true,
      migratedCourses: 0,
      migratedOrders: 0,
      migratedFiles: 0,
      errors: []
    };

    try {
      // Migrate courses
      const courseResult = await this.migrateCourses();
      result.migratedCourses = courseResult.count;
      result.errors.push(...courseResult.errors);

      // Migrate orders
      const orderResult = await this.migrateOrders();
      result.migratedOrders = orderResult.count;
      result.errors.push(...orderResult.errors);

      // Migrate files
      const fileResult = await this.migrateFiles();
      result.migratedFiles = fileResult.count;
      result.errors.push(...fileResult.errors);

      result.success = result.errors.length === 0;
      
      console.log('✅ Migration completed:', result);
      return result;
    } catch (error) {
      console.error('❌ Migration failed:', error);
      result.success = false;
      result.errors.push(error instanceof Error ? error.message : 'Unknown error');
      return result;
    }
  }

  private static async migrateCourses(): Promise<{ count: number; errors: string[] }> {
    try {
      console.log('📚 Migrating courses...');
      
      const coursesData = localStorage.getItem('edumaster_courses');
      if (!coursesData) {
        return { count: 0, errors: [] };
      }

      const courses = JSON.parse(coursesData);
      let migratedCount = 0;
      const errors: string[] = [];

      for (const course of courses) {
        try {
          // Convert course data to database format
          const courseData = {
            title: course.title,
            description: course.description || course.shortDescription,
            price: course.price || 0,
            duration: course.duration || '0 hours',
            category: course.category || course.tags?.[0] || 'General',
            thumbnail: course.thumbnail,
            isPublished: course.isPublished || false,
            createdBy: 'migrated-admin'
          };

          const result = await apiDatabaseService.createCourse(courseData);
          if (result.success) {
            migratedCount++;
            
            // Migrate classes for this course
            if (course.classes && course.classes.length > 0) {
              for (const classItem of course.classes) {
                try {
                  await this.migrateClass(result.data?.id || course.id, classItem);
                } catch (classError) {
                  console.warn('Failed to migrate class:', classError);
                }
              }
            }
          } else {
            errors.push(`Failed to migrate course "${course.title}": ${result.message}`);
          }
        } catch (error) {
          errors.push(`Error migrating course "${course.title}": ${error}`);
        }
      }

      console.log(`✅ Migrated ${migratedCount} courses`);
      return { count: migratedCount, errors };
    } catch (error) {
      return { count: 0, errors: [error instanceof Error ? error.message : 'Course migration failed'] };
    }
  }

  private static async migrateClass(courseId: string, classItem: any): Promise<void> {
    const classData = {
      title: classItem.title,
      description: classItem.description,
      order: classItem.classNumber || 1,
      videos: classItem.videos || [],
      notes: classItem.notes || [],
      projects: classItem.projects || []
    };

    await apiDatabaseService.createClass(courseId, classData);
  }

  private static async migrateOrders(): Promise<{ count: number; errors: string[] }> {
    try {
      console.log('🛒 Migrating orders...');
      
      const ordersData = localStorage.getItem('edumaster_orders');
      if (!ordersData) {
        return { count: 0, errors: [] };
      }

      const orders = JSON.parse(ordersData);
      let migratedCount = 0;
      const errors: string[] = [];

      for (const order of orders) {
        try {
          const orderData = {
            userId: order.userId || 'migrated-user',
            courseId: order.courseId,
            courseName: order.courseName || 'Unknown Course',
            amount: order.amount || order.price || 0,
            paymentStatus: order.paymentStatus || 'pending',
            paymentMethod: order.paymentMethod || 'unknown',
            transactionId: order.transactionId
          };

          const result = await apiDatabaseService.createOrder(orderData);
          if (result.success) {
            migratedCount++;
          } else {
            errors.push(`Failed to migrate order ${order.id}: ${result.message}`);
          }
        } catch (error) {
          errors.push(`Error migrating order ${order.id}: ${error}`);
        }
      }

      console.log(`✅ Migrated ${migratedCount} orders`);
      return { count: migratedCount, errors };
    } catch (error) {
      return { count: 0, errors: [error instanceof Error ? error.message : 'Order migration failed'] };
    }
  }

  private static async migrateFiles(): Promise<{ count: number; errors: string[] }> {
    try {
      console.log('📁 Organizing files...');
      
      // File migration is primarily organizational since files are already in localStorage
      // This will organize them better and clean up orphaned files
      const cleanedFiles = await fileStorageService.cleanupOrphanedFiles();
      const stats = fileStorageService.getStorageStats();

      console.log('📊 File storage stats:', stats);
      
      return { count: cleanedFiles, errors: [] };
    } catch (error) {
      return { count: 0, errors: [error instanceof Error ? error.message : 'File organization failed'] };
    }
  }

  // Check if migration is needed
  static needsMigration(): boolean {
    const courses = localStorage.getItem('edumaster_courses');
    const orders = localStorage.getItem('edumaster_orders');
    const migrationFlag = localStorage.getItem('data_migrated');
    
    return (courses || orders) && !migrationFlag;
  }

  // Mark migration as completed
  static markMigrationCompleted(): void {
    localStorage.setItem('data_migrated', new Date().toISOString());
  }

  // Reset migration flag (for testing)
  static resetMigrationFlag(): void {
    localStorage.removeItem('data_migrated');
  }

  // Get migration status
  static getMigrationStatus(): { needed: boolean; lastMigration?: string } {
    const migrationFlag = localStorage.getItem('data_migrated');
    return {
      needed: this.needsMigration(),
      lastMigration: migrationFlag || undefined
    };
  }
}

// Auto-migration utility
export const autoMigrate = async (): Promise<void> => {
  if (DataMigration.needsMigration()) {
    console.log('🔄 Auto-migration triggered...');
    const result = await DataMigration.migrateAllData();
    
    if (result.success) {
      DataMigration.markMigrationCompleted();
      console.log('✅ Auto-migration completed successfully');
    } else {
      console.warn('⚠️ Auto-migration completed with errors:', result.errors);
    }
  }
};
