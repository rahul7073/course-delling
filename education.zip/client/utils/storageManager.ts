// Storage Manager - Handles localStorage quota and large data efficiently

interface StorageStats {
  used: number;
  available: number;
  total: number;
  percentUsed: number;
}

interface StorageResult {
  success: boolean;
  error?: string;
  stats?: StorageStats;
}

class StorageManager {
  // Get storage statistics
  getStorageStats(): StorageStats {
    let used = 0;
    let total = 0;

    try {
      // Calculate used space
      for (let key in localStorage) {
        if (localStorage.hasOwnProperty(key)) {
          used += localStorage.getItem(key)?.length || 0;
        }
      }

      // Estimate total available space (typical browsers: 5-10MB)
      total = 10 * 1024 * 1024; // 10MB estimate
      
      return {
        used,
        total,
        available: total - used,
        percentUsed: (used / total) * 100
      };
    } catch (error) {
      return {
        used: 0,
        total: 0,
        available: 0,
        percentUsed: 100
      };
    }
  }

  // Check if we have enough space for data
  hasSpaceFor(dataSize: number): boolean {
    const stats = this.getStorageStats();
    return stats.available >= dataSize * 1.2; // 20% buffer
  }

  // Clean up old or large data to make space
  cleanup(): StorageResult {
    try {
      console.log('🧹 Starting localStorage cleanup...');
      
      const stats = this.getStorageStats();
      console.log('Storage before cleanup:', this.formatBytes(stats.used));

      // Remove large video data URLs first
      this.removeVideoDataUrls();
      
      // Remove old sync logs
      this.removeOldSyncLogs();
      
      // Remove temporary data
      this.removeTemporaryData();

      const newStats = this.getStorageStats();
      console.log('Storage after cleanup:', this.formatBytes(newStats.used));
      console.log('Space freed:', this.formatBytes(stats.used - newStats.used));

      return {
        success: true,
        stats: newStats
      };
    } catch (error) {
      console.error('Cleanup failed:', error);
      return {
        success: false,
        error: error instanceof Error ? error.message : 'Cleanup failed'
      };
    }
  }

  // Remove video data URLs (largest space consumers)
  private removeVideoDataUrls(): void {
    try {
      const coursesData = localStorage.getItem('edumaster_courses');
      if (!coursesData) return;

      const courses = JSON.parse(coursesData);
      let modified = false;

      courses.forEach((course: any) => {
        // Remove video data URLs from course-level videos
        if (course.videos) {
          course.videos.forEach((video: any) => {
            if (video.videoUrl && video.videoUrl.startsWith('data:')) {
              video.videoUrl = `[LARGE_FILE_REMOVED]_${video.title}`;
              modified = true;
            }
          });
        }

        // Remove video data URLs from class-level videos
        if (course.classes) {
          course.classes.forEach((cls: any) => {
            if (cls.videos) {
              cls.videos.forEach((video: any) => {
                if (video.videoUrl && video.videoUrl.startsWith('data:')) {
                  video.videoUrl = `[LARGE_FILE_REMOVED]_${video.title}`;
                  modified = true;
                }
              });
            }
          });
        }

        // Remove large note files
        if (course.notes) {
          course.notes.forEach((note: any) => {
            if (note.fileUrl && note.fileUrl.startsWith('data:') && note.fileUrl.length > 100000) {
              note.fileUrl = `[LARGE_FILE_REMOVED]_${note.title}`;
              modified = true;
            }
          });
        }

        // Remove note data URLs from classes
        if (course.classes) {
          course.classes.forEach((cls: any) => {
            if (cls.notes) {
              cls.notes.forEach((note: any) => {
                if (note.fileUrl && note.fileUrl.startsWith('data:') && note.fileUrl.length > 100000) {
                  note.fileUrl = `[LARGE_FILE_REMOVED]_${note.title}`;
                  modified = true;
                }
              });
            }
          });
        }
      });

      if (modified) {
        localStorage.setItem('edumaster_courses', JSON.stringify(courses));
        console.log('✅ Removed large video/file data URLs');
      }
    } catch (error) {
      console.error('Failed to remove video data URLs:', error);
    }
  }

  // Remove old sync logs
  private removeOldSyncLogs(): void {
    try {
      const syncLog = localStorage.getItem('edumaster_sync_log');
      if (syncLog) {
        const logs = JSON.parse(syncLog);
        if (logs.length > 10) {
          // Keep only last 10 sync records
          const trimmedLogs = logs.slice(-10);
          localStorage.setItem('edumaster_sync_log', JSON.stringify(trimmedLogs));
          console.log('✅ Trimmed sync logs');
        }
      }
    } catch (error) {
      console.error('Failed to remove old sync logs:', error);
    }
  }

  // Remove temporary data
  private removeTemporaryData(): void {
    const temporaryKeys = [
      'temp_video_upload',
      'temp_course_data',
      'cache_',
      'preview_'
    ];

    temporaryKeys.forEach(prefix => {
      Object.keys(localStorage).forEach(key => {
        if (key.startsWith(prefix)) {
          localStorage.removeItem(key);
          console.log(`✅ Removed temporary data: ${key}`);
        }
      });
    });
  }

  // Safe storage operation with complete fallback
  safeSetItem(key: string, value: string): StorageResult {
    try {
      // First try to store normally
      localStorage.setItem(key, value);
      return { success: true };
    } catch (error) {
      if (error instanceof DOMException && error.name === 'QuotaExceededError') {
        console.warn('⚠️ localStorage quota exceeded, attempting cleanup...');

        // Try cleanup and retry
        try {
          const cleanupResult = this.cleanup();
          if (cleanupResult.success) {
            try {
              localStorage.setItem(key, value);
              console.log('✅ Storage successful after cleanup');
              return { success: true, stats: cleanupResult.stats };
            } catch (retryError) {
              console.error('❌ Storage still failed after cleanup, trying emergency cleanup...');

              // Emergency cleanup - more aggressive
              try {
                const emergencyResult = this.emergencyCleanup();
                if (emergencyResult.success) {
                  try {
                    localStorage.setItem(key, value);
                    console.log('✅ Storage successful after emergency cleanup');
                    return { success: true, stats: emergencyResult.stats };
                  } catch (finalError) {
                    console.log('💾 Storage completely full, enabling memory-only mode');
                    return {
                      success: false,
                      error: 'STORAGE_FULL'
                    };
                  }
                } else {
                  console.log('💾 Cleanup failed, enabling memory-only mode');
                  return {
                    success: false,
                    error: 'STORAGE_FULL'
                  };
                }
              } catch (emergencyError) {
                console.log('💾 Emergency cleanup failed, enabling memory-only mode');
                return {
                  success: false,
                  error: 'STORAGE_FULL'
                };
              }
            }
          } else {
            console.log('💾 Cleanup failed, enabling memory-only mode');
            return {
              success: false,
              error: 'STORAGE_FULL'
            };
          }
        } catch (cleanupError) {
          console.log('💾 Cleanup crashed, enabling memory-only mode');
          return {
            success: false,
            error: 'STORAGE_FULL'
          };
        }
      } else {
        return {
          success: false,
          error: error instanceof Error ? error.message : 'Storage operation failed'
        };
      }
    }
  }

  // Emergency cleanup - remove ALL large data URLs and keep only essential data
  emergencyCleanup(): StorageResult {
    try {
      console.log('🚨 Starting emergency localStorage cleanup...');

      const stats = this.getStorageStats();
      console.log('Storage before emergency cleanup:', this.formatBytes(stats.used));

      // Remove ALL data URLs from courses (videos and notes)
      this.removeAllDataUrls();

      // Clear all caches and temporary data
      this.clearAllCaches();

      // Remove old order history (keep only recent 5)
      this.trimOrderHistory();

      // If still full, do ultra-aggressive cleanup
      if (this.getStorageWarningLevel() === 'critical') {
        this.ultraAggressiveCleanup();
      }

      const newStats = this.getStorageStats();
      console.log('Storage after emergency cleanup:', this.formatBytes(newStats.used));
      console.log('Space freed:', this.formatBytes(stats.used - newStats.used));

      return {
        success: true,
        stats: newStats
      };
    } catch (error) {
      console.error('Emergency cleanup failed:', error);
      return {
        success: false,
        error: error instanceof Error ? error.message : 'Emergency cleanup failed'
      };
    }
  }

  // Ultra-aggressive cleanup for completely full storage
  private ultraAggressiveCleanup(): void {
    try {
      console.log('💥 Starting ultra-aggressive cleanup...');

      // Remove cart data (it can work in memory)
      localStorage.removeItem('edumaster-cart');

      // Keep only essential course structure, remove ALL content
      const coursesData = localStorage.getItem('edumaster_courses');
      if (coursesData) {
        const courses = JSON.parse(coursesData);
        const minimalCourses = courses.map((course: any) => ({
          id: course.id,
          title: course.title,
          description: course.description,
          price: course.price,
          category: course.category,
          isPublished: course.isPublished,
          thumbnail: course.thumbnail,
          // Remove all content arrays to save space
          videos: [],
          notes: [],
          projects: [],
          classes: course.classes?.map((cls: any) => ({
            id: cls.id,
            classNumber: cls.classNumber,
            title: cls.title,
            description: cls.description,
            isDemo: cls.isDemo,
            videos: [],
            notes: [],
            projects: []
          })) || []
        }));

        localStorage.setItem('edumaster_courses', JSON.stringify(minimalCourses));
        console.log('✅ Reduced courses to minimal structure');
      }

      // Remove user progress (can be rebuilt)
      localStorage.removeItem('edumaster_user_progress');

      // Keep only last 2 orders
      const ordersData = localStorage.getItem('edumaster_orders');
      if (ordersData) {
        const orders = JSON.parse(ordersData);
        if (orders.length > 2) {
          const recentOrders = orders.slice(-2);
          localStorage.setItem('edumaster_orders', JSON.stringify(recentOrders));
        }
      }

      console.log('💥 Ultra-aggressive cleanup completed');
    } catch (error) {
      console.error('Ultra-aggressive cleanup failed:', error);
    }
  }

  // Remove ALL data URLs (more aggressive than removeVideoDataUrls)
  private removeAllDataUrls(): void {
    try {
      const coursesData = localStorage.getItem('edumaster_courses');
      if (!coursesData) return;

      const courses = JSON.parse(coursesData);
      let modified = false;

      courses.forEach((course: any) => {
        // Remove ALL data URLs from videos
        if (course.videos) {
          course.videos.forEach((video: any) => {
            if (video.videoUrl && video.videoUrl.startsWith('data:')) {
              video.videoUrl = '#removed';
              modified = true;
            }
          });
        }

        // Remove ALL data URLs from notes
        if (course.notes) {
          course.notes.forEach((note: any) => {
            if (note.fileUrl && note.fileUrl.startsWith('data:')) {
              note.fileUrl = '#removed';
              modified = true;
            }
          });
        }

        // Remove ALL data URLs from class-level content
        if (course.classes) {
          course.classes.forEach((cls: any) => {
            if (cls.videos) {
              cls.videos.forEach((video: any) => {
                if (video.videoUrl && video.videoUrl.startsWith('data:')) {
                  video.videoUrl = '#removed';
                  modified = true;
                }
              });
            }
            if (cls.notes) {
              cls.notes.forEach((note: any) => {
                if (note.fileUrl && note.fileUrl.startsWith('data:')) {
                  note.fileUrl = '#removed';
                  modified = true;
                }
              });
            }
          });
        }
      });

      if (modified) {
        try {
          localStorage.setItem('edumaster_courses', JSON.stringify(courses));
          console.log('✅ Removed ALL large data URLs from courses');
        } catch (setError) {
          console.log('⚠️ Cannot save cleaned courses, storage too full');
          // If we can't even save the cleaned data, remove courses entirely
          localStorage.removeItem('edumaster_courses');
        }
      }
    } catch (error) {
      console.error('Failed to remove all data URLs, trying to clear courses:', error);
      try {
        localStorage.removeItem('edumaster_courses');
      } catch (removeError) {
        console.error('Cannot even remove courses, storage completely locked');
      }
    }
  }

  // Clear all caches and temporary data
  private clearAllCaches(): void {
    const keysToRemove: string[] = [];

    for (let i = 0; i < localStorage.length; i++) {
      const key = localStorage.key(i);
      if (key && (
        key.startsWith('cache_') ||
        key.startsWith('temp_') ||
        key.startsWith('preview_') ||
        key.startsWith('upload_') ||
        key.includes('_temp') ||
        key.includes('_cache')
      )) {
        keysToRemove.push(key);
      }
    }

    keysToRemove.forEach(key => {
      localStorage.removeItem(key);
      console.log(`🗑️ Removed cache: ${key}`);
    });
  }

  // Keep only recent 5 orders
  private trimOrderHistory(): void {
    try {
      const ordersData = localStorage.getItem('edumaster_orders');
      if (ordersData) {
        const orders = JSON.parse(ordersData);
        if (orders.length > 5) {
          const recentOrders = orders.slice(-5); // Keep last 5 orders
          localStorage.setItem('edumaster_orders', JSON.stringify(recentOrders));
          console.log('✅ Trimmed order history to last 5 orders');
        }
      }
    } catch (error) {
      console.error('Failed to trim order history:', error);
    }
  }

  // Format bytes for human readable display
  formatBytes(bytes: number): string {
    if (bytes === 0) return '0 Bytes';
    const k = 1024;
    const sizes = ['Bytes', 'KB', 'MB', 'GB'];
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
  }

  // Get storage warning level
  getStorageWarningLevel(): 'safe' | 'warning' | 'critical' {
    const stats = this.getStorageStats();
    if (stats.percentUsed < 70) return 'safe';
    if (stats.percentUsed < 90) return 'warning';
    return 'critical';
  }

  // Remove specific course data to free space
  removeCourseData(courseId: string): StorageResult {
    try {
      const coursesData = localStorage.getItem('edumaster_courses');
      if (!coursesData) return { success: true };

      const courses = JSON.parse(coursesData);
      const filteredCourses = courses.filter((course: any) => course.id !== courseId);

      localStorage.setItem('edumaster_courses', JSON.stringify(filteredCourses));

      return { success: true };
    } catch (error) {
      return {
        success: false,
        error: error instanceof Error ? error.message : 'Failed to remove course data'
      };
    }
  }

  // Nuclear cleanup - completely clear localStorage when it's locked up
  nuclearCleanup(): StorageResult {
    try {
      console.log('☢️ Starting nuclear cleanup - clearing ALL localStorage...');

      // Get list of all keys before clearing
      const keys = [];
      for (let i = 0; i < localStorage.length; i++) {
        const key = localStorage.key(i);
        if (key) keys.push(key);
      }

      // Clear everything
      localStorage.clear();

      console.log(`☢️ Nuclear cleanup completed - cleared ${keys.length} items`);
      console.log('Cleared keys:', keys);

      return { success: true };
    } catch (error) {
      console.error('Nuclear cleanup failed:', error);
      return {
        success: false,
        error: error instanceof Error ? error.message : 'Nuclear cleanup failed'
      };
    }
  }
}

// Create singleton instance
export const storageManager = new StorageManager();

// Helper function for components to use
export const saveToLocalStorage = (key: string, data: any): StorageResult => {
  const jsonData = JSON.stringify(data);
  return storageManager.safeSetItem(key, jsonData);
};

// Helper to check storage health
export const checkStorageHealth = (): void => {
  const stats = storageManager.getStorageStats();
  const warningLevel = storageManager.getStorageWarningLevel();
  
  console.log(`📊 Storage Health: ${storageManager.formatBytes(stats.used)} used (${stats.percentUsed.toFixed(1)}%)`);
  
  if (warningLevel === 'warning') {
    console.warn('��️ Storage usage is high. Consider cleaning up old data.');
  } else if (warningLevel === 'critical') {
    console.error('🚨 Storage is critically full. Cleanup required.');
  }
};

export default StorageManager;
