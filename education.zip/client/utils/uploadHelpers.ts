// Upload troubleshooting and helper utilities

export interface UploadValidation {
  isValid: boolean;
  errors: string[];
  warnings: string[];
}

export const validateUpload = (file: File, type: 'video' | 'note'): UploadValidation => {
  const errors: string[] = [];
  const warnings: string[] = [];

  // File size limits
  const maxSizes = {
    video: 50 * 1024 * 1024, // 50MB
    note: 10 * 1024 * 1024   // 10MB
  };

  const maxSize = maxSizes[type];
  
  if (file.size > maxSize) {
    errors.push(`File size (${(file.size / 1024 / 1024).toFixed(1)}MB) exceeds maximum allowed size of ${maxSize / 1024 / 1024}MB`);
  }

  // Warning for large files that might cause storage issues
  const warningSize = type === 'video' ? 25 * 1024 * 1024 : 5 * 1024 * 1024;
  if (file.size > warningSize && file.size <= maxSize) {
    warnings.push(`Large file detected. This may use significant browser storage space.`);
  }

  // File type validation
  const allowedTypes = {
    video: ['video/mp4', 'video/avi', 'video/mov', 'video/wmv', 'video/webm'],
    note: ['application/pdf', 'application/msword', 'application/vnd.openxmlformats-officedocument.wordprocessingml.document', 'text/plain']
  };

  const allowedExts = {
    video: ['.mp4', '.avi', '.mov', '.wmv', '.webm'],
    note: ['.pdf', '.doc', '.docx', '.txt']
  };

  const fileName = file.name.toLowerCase();
  const hasValidExtension = allowedExts[type].some(ext => fileName.endsWith(ext));
  
  if (!hasValidExtension && !allowedTypes[type].includes(file.type)) {
    errors.push(`Invalid file type. Allowed formats for ${type}: ${allowedExts[type].join(', ')}`);
  }

  return {
    isValid: errors.length === 0,
    errors,
    warnings
  };
};

export const getStorageInfo = () => {
  try {
    let used = 0;
    for (let key in localStorage) {
      if (localStorage.hasOwnProperty(key)) {
        used += localStorage.getItem(key)?.length || 0;
      }
    }
    
    const total = 10 * 1024 * 1024; // 10MB estimate
    const percentUsed = (used / total) * 100;
    
    return {
      used: formatBytes(used),
      total: formatBytes(total),
      percentUsed: Math.round(percentUsed),
      isNearFull: percentUsed > 80
    };
  } catch {
    return {
      used: 'Unknown',
      total: 'Unknown', 
      percentUsed: 0,
      isNearFull: false
    };
  }
};

export const formatBytes = (bytes: number): string => {
  if (bytes === 0) return '0 Bytes';
  const k = 1024;
  const sizes = ['Bytes', 'KB', 'MB', 'GB'];
  const i = Math.floor(Math.log(bytes) / Math.log(k));
  return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
};

export const generateUploadTips = (type: 'video' | 'note'): string[] => {
  const baseTips = [
    "Ensure you have a stable internet connection",
    "Close other browser tabs to free up memory",
    "Try uploading during off-peak hours"
  ];

  const videoTips = [
    "Compress videos before uploading to reduce file size",
    "Use MP4 format for best compatibility",
    "Consider splitting long videos into shorter segments"
  ];

  const noteTips = [
    "Convert large documents to PDF format",
    "Compress images in documents before saving",
    "Remove unnecessary content to reduce file size"
  ];

  return [...baseTips, ...(type === 'video' ? videoTips : noteTips)];
};

export const troubleshootUploadFailure = (error: Error): string => {
  const message = error.message.toLowerCase();

  if (message.includes('quota') || message.includes('storage')) {
    return "Browser storage is full. Try clearing old course data or use smaller files.";
  }

  if (message.includes('network') || message.includes('fetch')) {
    return "Network connection issue. Check your internet connection and try again.";
  }

  if (message.includes('size') || message.includes('large')) {
    return "File is too large. Please compress the file or use a smaller version.";
  }

  if (message.includes('type') || message.includes('format')) {
    return "Unsupported file format. Please use an allowed file type.";
  }

  return "Upload failed due to an unknown error. Please try again or contact support.";
};
