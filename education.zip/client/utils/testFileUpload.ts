// Test utility to create sample files for admin uploads
export const createSampleFiles = () => {
  // Create a sample HTML file for course content
  const htmlContent = `<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>React Introduction</title>
  <style>
    body { font-family: Arial, sans-serif; line-height: 1.6; margin: 2rem; }
    .highlight { background: #ffffcc; padding: 2px 4px; }
    code { background: #f4f4f4; padding: 2px 4px; border-radius: 3px; }
  </style>
</head>
<body>
  <h1>Introduction to React</h1>
  
  <h2>What is React?</h2>
  <p>React is a <span class="highlight">JavaScript library</span> for building user interfaces, particularly web applications.</p>
  
  <h2>Key Concepts</h2>
  <ul>
    <li><strong>Components:</strong> Reusable pieces of UI</li>
    <li><strong>JSX:</strong> JavaScript XML syntax</li>
    <li><strong>Props:</strong> Data passed to components</li>
    <li><strong>State:</strong> Data that changes over time</li>
  </ul>
  
  <h2>Your First Component</h2>
  <pre><code>
function Welcome(props) {
  return &lt;h1&gt;Hello, {props.name}!&lt;/h1&gt;;
}
  </code></pre>
  
  <p>This is a simple React component that displays a greeting message.</p>
</body>
</html>`;

  // Create a sample JavaScript code file
  const jsContent = `// Todo App Component
import React, { useState } from 'react';

function TodoApp() {
  const [todos, setTodos] = useState([]);
  const [input, setInput] = useState('');

  const addTodo = () => {
    if (input.trim()) {
      setTodos([...todos, {
        id: Date.now(),
        text: input,
        completed: false
      }]);
      setInput('');
    }
  };

  const toggleTodo = (id) => {
    setTodos(todos.map(todo =>
      todo.id === id ? { ...todo, completed: !todo.completed } : todo
    ));
  };

  const deleteTodo = (id) => {
    setTodos(todos.filter(todo => todo.id !== id));
  };

  return (
    <div className="todo-app">
      <h1>Todo App</h1>
      
      <div className="add-todo">
        <input
          type="text"
          value={input}
          onChange={(e) => setInput(e.target.value)}
          placeholder="Add a new todo..."
          onKeyPress={(e) => e.key === 'Enter' && addTodo()}
        />
        <button onClick={addTodo}>Add</button>
      </div>
      
      <ul className="todo-list">
        {todos.map(todo => (
          <li key={todo.id} className={todo.completed ? 'completed' : ''}>
            <span onClick={() => toggleTodo(todo.id)}>
              {todo.text}
            </span>
            <button onClick={() => deleteTodo(todo.id)}>Delete</button>
          </li>
        ))}
      </ul>
      
      <style jsx>{\`
        .todo-app { max-width: 400px; margin: 20px auto; }
        .add-todo { display: flex; gap: 10px; margin-bottom: 20px; }
        .add-todo input { flex: 1; padding: 8px; }
        .todo-list { list-style: none; padding: 0; }
        .todo-list li { 
          display: flex; 
          justify-content: space-between; 
          padding: 8px; 
          border-bottom: 1px solid #eee; 
        }
        .completed span { text-decoration: line-through; opacity: 0.6; }
      \`}</style>
    </div>
  );
}

export default TodoApp;`;

  // Create sample files
  const files = {
    'react-intro.html': new File([htmlContent], 'react-intro.html', { type: 'text/html' }),
    'TodoApp.js': new File([jsContent], 'TodoApp.js', { type: 'text/javascript' }),
    'notes.txt': new File(['React Notes\n\n1. Always use functional components\n2. Use hooks for state management\n3. Keep components small and focused'], 'react-notes.txt', { type: 'text/plain' })
  };

  return files;
};

// Helper to download a sample file for testing
export const downloadSampleFile = (fileName: string) => {
  const files = createSampleFiles();
  const file = files[fileName];
  
  if (file) {
    const url = URL.createObjectURL(file);
    const a = document.createElement('a');
    a.href = url;
    a.download = fileName;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  }
};
