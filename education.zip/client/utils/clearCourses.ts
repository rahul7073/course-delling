// Utility to clear all existing courses for fresh start
export const clearAllCourses = () => {
  try {
    console.log('🧹 Clearing all existing courses...');
    
    // Clear from localStorage
    localStorage.removeItem('edumaster_courses');
    localStorage.removeItem('edumaster_orders');
    localStorage.removeItem('data_migrated');
    
    // Clear any course-related file storage
    const keysToRemove: string[] = [];
    for (let i = 0; i < localStorage.length; i++) {
      const key = localStorage.key(i);
      if (key && (
        key.includes('video-file') || 
        key.includes('note-file') || 
        key.includes('project-file') ||
        key.startsWith('course-') ||
        key.startsWith('class-')
      )) {
        keysToRemove.push(key);
      }
    }
    
    keysToRemove.forEach(key => {
      localStorage.removeItem(key);
    });
    
    console.log(`✅ Cleared ${keysToRemove.length} course-related files and all course data`);
    
    // Force page reload to refresh course list
    window.location.reload();
    
    return true;
  } catch (error) {
    console.error('❌ Error clearing courses:', error);
    return false;
  }
};

// Clear just the course data but keep other settings
export const clearCourseData = () => {
  try {
    localStorage.removeItem('edumaster_courses');
    localStorage.removeItem('data_migrated');
    console.log('✅ Course data cleared');
    return true;
  } catch (error) {
    console.error('❌ Error clearing course data:', error);
    return false;
  }
};
