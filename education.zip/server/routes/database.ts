import { Request, Response } from 'express';
import { DatabaseConnection, Course, CourseClass, Order, User, Certification } from '../../shared/database';

// Mock database implementation (replace with real database connection)
class MockDatabase implements DatabaseConnection {
  private courses: Course[] = [];
  private classes: CourseClass[] = [];
  private orders: Order[] = [];
  private users: User[] = [];
  private certifications: Certification[] = [];

  // Helper to generate IDs
  private generateId(): string {
    return `${Date.now()}-${Math.random().toString(36).substr(2, 9)}`;
  }

  // Courses
  async createCourse(courseData: Omit<Course, 'id' | 'createdAt' | 'updatedAt'>) {
    const course: Course = {
      ...courseData,
      id: this.generateId(),
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };
    this.courses.push(course);
    return { success: true, data: course };
  }

  async getCourse(id: string) {
    const course = this.courses.find(c => c.id === id);
    if (!course) {
      return { success: false, error: 'Course not found' };
    }
    
    // Include classes in the course
    const courseClasses = this.classes.filter(cl => cl.courseId === id);
    return { 
      success: true, 
      data: { ...course, classes: courseClasses } 
    };
  }

  async getCourses(page = 1, limit = 10, published?: boolean) {
    let filteredCourses = this.courses;
    if (published !== undefined) {
      filteredCourses = this.courses.filter(c => c.isPublished === published);
    }

    const total = filteredCourses.length;
    const startIndex = (page - 1) * limit;
    const endIndex = startIndex + limit;
    const paginatedCourses = filteredCourses.slice(startIndex, endIndex);

    return {
      success: true,
      data: {
        data: paginatedCourses,
        total,
        page,
        limit,
        hasNext: endIndex < total,
        hasPrev: page > 1
      }
    };
  }

  async updateCourse(id: string, updates: Partial<Course>) {
    const courseIndex = this.courses.findIndex(c => c.id === id);
    if (courseIndex === -1) {
      return { success: false, error: 'Course not found' };
    }

    this.courses[courseIndex] = {
      ...this.courses[courseIndex],
      ...updates,
      updatedAt: new Date().toISOString()
    };

    return { success: true, data: this.courses[courseIndex] };
  }

  async deleteCourse(id: string) {
    const courseIndex = this.courses.findIndex(c => c.id === id);
    if (courseIndex === -1) {
      return { success: false, error: 'Course not found' };
    }

    // Also delete related classes
    this.classes = this.classes.filter(cl => cl.courseId !== id);
    this.courses.splice(courseIndex, 1);

    return { success: true, data: true };
  }

  async publishCourse(id: string) {
    return this.updateCourse(id, { isPublished: true });
  }

  // Classes
  async createClass(classData: Omit<CourseClass, 'id' | 'createdAt' | 'updatedAt'>) {
    const classItem: CourseClass = {
      ...classData,
      id: this.generateId(),
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };
    this.classes.push(classItem);
    return { success: true, data: classItem };
  }

  async getClass(id: string) {
    const classItem = this.classes.find(c => c.id === id);
    if (!classItem) {
      return { success: false, error: 'Class not found' };
    }
    return { success: true, data: classItem };
  }

  async getClassesByCourse(courseId: string) {
    const courseClasses = this.classes.filter(cl => cl.courseId === courseId);
    return { success: true, data: courseClasses };
  }

  async updateClass(id: string, updates: Partial<CourseClass>) {
    const classIndex = this.classes.findIndex(c => c.id === id);
    if (classIndex === -1) {
      return { success: false, error: 'Class not found' };
    }

    this.classes[classIndex] = {
      ...this.classes[classIndex],
      ...updates,
      updatedAt: new Date().toISOString()
    };

    return { success: true, data: this.classes[classIndex] };
  }

  async deleteClass(id: string) {
    const classIndex = this.classes.findIndex(c => c.id === id);
    if (classIndex === -1) {
      return { success: false, error: 'Class not found' };
    }

    this.classes.splice(classIndex, 1);
    return { success: true, data: true };
  }

  // Video, Notes, Projects (simplified - in real implementation, these would be separate tables)
  async addClassVideo(video: any) {
    const classIndex = this.classes.findIndex(c => c.id === video.classId);
    if (classIndex === -1) {
      return { success: false, error: 'Class not found' };
    }

    const videoWithId = {
      ...video,
      id: this.generateId(),
      createdAt: new Date().toISOString()
    };

    if (!this.classes[classIndex].videos) {
      this.classes[classIndex].videos = [];
    }
    this.classes[classIndex].videos!.push(videoWithId);

    return { success: true, data: videoWithId };
  }

  async addClassNote(note: any) {
    const classIndex = this.classes.findIndex(c => c.id === note.classId);
    if (classIndex === -1) {
      return { success: false, error: 'Class not found' };
    }

    const noteWithId = {
      ...note,
      id: this.generateId(),
      createdAt: new Date().toISOString()
    };

    if (!this.classes[classIndex].notes) {
      this.classes[classIndex].notes = [];
    }
    this.classes[classIndex].notes!.push(noteWithId);

    return { success: true, data: noteWithId };
  }

  async addClassProject(project: any) {
    const classIndex = this.classes.findIndex(c => c.id === project.classId);
    if (classIndex === -1) {
      return { success: false, error: 'Class not found' };
    }

    const projectWithId = {
      ...project,
      id: this.generateId(),
      createdAt: new Date().toISOString()
    };

    if (!this.classes[classIndex].projects) {
      this.classes[classIndex].projects = [];
    }
    this.classes[classIndex].projects!.push(projectWithId);

    return { success: true, data: projectWithId };
  }

  // Orders
  async createOrder(orderData: Omit<Order, 'id' | 'createdAt' | 'updatedAt'>) {
    const order: Order = {
      ...orderData,
      id: this.generateId(),
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };
    this.orders.push(order);
    return { success: true, data: order };
  }

  async getOrder(id: string) {
    const order = this.orders.find(o => o.id === id);
    if (!order) {
      return { success: false, error: 'Order not found' };
    }
    return { success: true, data: order };
  }

  async getOrders(page = 1, limit = 10) {
    const total = this.orders.length;
    const startIndex = (page - 1) * limit;
    const endIndex = startIndex + limit;
    const paginatedOrders = this.orders.slice(startIndex, endIndex);

    return {
      success: true,
      data: {
        data: paginatedOrders,
        total,
        page,
        limit,
        hasNext: endIndex < total,
        hasPrev: page > 1
      }
    };
  }

  async updateOrderStatus(id: string, status: Order['paymentStatus'], transactionId?: string) {
    const orderIndex = this.orders.findIndex(o => o.id === id);
    if (orderIndex === -1) {
      return { success: false, error: 'Order not found' };
    }

    this.orders[orderIndex] = {
      ...this.orders[orderIndex],
      paymentStatus: status,
      transactionId,
      updatedAt: new Date().toISOString()
    };

    return { success: true, data: this.orders[orderIndex] };
  }

  // Users
  async createUser(userData: Omit<User, 'id' | 'createdAt' | 'updatedAt'>) {
    const user: User = {
      ...userData,
      id: this.generateId(),
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };
    this.users.push(user);
    return { success: true, data: user };
  }

  async getUser(id: string) {
    const user = this.users.find(u => u.id === id);
    if (!user) {
      return { success: false, error: 'User not found' };
    }
    return { success: true, data: user };
  }

  async getUserByEmail(email: string) {
    const user = this.users.find(u => u.email === email);
    if (!user) {
      return { success: false, error: 'User not found' };
    }
    return { success: true, data: user };
  }

  // Certifications
  async createCertification(certData: Omit<Certification, 'id' | 'createdAt' | 'updatedAt'>) {
    const cert: Certification = {
      ...certData,
      id: this.generateId(),
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };
    this.certifications.push(cert);
    return { success: true, data: cert };
  }

  async getCertifications(active?: boolean) {
    let filteredCerts = this.certifications;
    if (active !== undefined) {
      filteredCerts = this.certifications.filter(c => c.isActive === active);
    }
    return { success: true, data: filteredCerts };
  }

  async updateCertification(id: string, updates: Partial<Certification>) {
    const certIndex = this.certifications.findIndex(c => c.id === id);
    if (certIndex === -1) {
      return { success: false, error: 'Certification not found' };
    }

    this.certifications[certIndex] = {
      ...this.certifications[certIndex],
      ...updates,
      updatedAt: new Date().toISOString()
    };

    return { success: true, data: this.certifications[certIndex] };
  }

  // File Storage (mock implementation)
  async uploadFile(file: File, folder: string) {
    // In real implementation, this would upload to cloud storage
    const key = `${folder}/${Date.now()}-${file.name}`;
    const url = `/uploads/${key}`;
    
    return { 
      success: true, 
      data: { url, key } 
    };
  }

  async getFileUrl(key: string) {
    return `/uploads/${key}`;
  }

  async deleteFile(key: string) {
    // In real implementation, this would delete from cloud storage
    return { success: true, data: true };
  }
}

// Create database instance
const db = new MockDatabase();

// Course routes
export async function handleGetCourses(req: Request, res: Response) {
  try {
    const { page = 1, limit = 10, published } = req.query;
    const result = await db.getCourses(
      Number(page), 
      Number(limit), 
      published === 'true' ? true : published === 'false' ? false : undefined
    );
    
    if (result.success) {
      res.json(result.data);
    } else {
      res.status(400).json({ error: result.error });
    }
  } catch (error) {
    res.status(500).json({ error: 'Internal server error' });
  }
}

export async function handleGetCourse(req: Request, res: Response) {
  try {
    const { id } = req.params;
    const result = await db.getCourse(id);
    
    if (result.success) {
      res.json(result.data);
    } else {
      res.status(404).json({ error: result.error });
    }
  } catch (error) {
    res.status(500).json({ error: 'Internal server error' });
  }
}

export async function handleCreateCourse(req: Request, res: Response) {
  try {
    const courseData = req.body;
    const result = await db.createCourse({
      ...courseData,
      isPublished: false,
      createdBy: 'admin' // In real app, get from auth
    });
    
    if (result.success) {
      res.status(201).json(result.data);
    } else {
      res.status(400).json({ error: result.error });
    }
  } catch (error) {
    res.status(500).json({ error: 'Internal server error' });
  }
}

export async function handleUpdateCourse(req: Request, res: Response) {
  try {
    const { id } = req.params;
    const updates = req.body;
    const result = await db.updateCourse(id, updates);
    
    if (result.success) {
      res.json(result.data);
    } else {
      res.status(404).json({ error: result.error });
    }
  } catch (error) {
    res.status(500).json({ error: 'Internal server error' });
  }
}

export async function handleDeleteCourse(req: Request, res: Response) {
  try {
    const { id } = req.params;
    const result = await db.deleteCourse(id);
    
    if (result.success) {
      res.json({ success: true });
    } else {
      res.status(404).json({ error: result.error });
    }
  } catch (error) {
    res.status(500).json({ error: 'Internal server error' });
  }
}

export async function handlePublishCourse(req: Request, res: Response) {
  try {
    const { id } = req.params;
    const result = await db.publishCourse(id);
    
    if (result.success) {
      res.json(result.data);
    } else {
      res.status(404).json({ error: result.error });
    }
  } catch (error) {
    res.status(500).json({ error: 'Internal server error' });
  }
}

// Class routes
export async function handleCreateClass(req: Request, res: Response) {
  try {
    const classData = req.body;
    const result = await db.createClass(classData);
    
    if (result.success) {
      res.status(201).json(result.data);
    } else {
      res.status(400).json({ error: result.error });
    }
  } catch (error) {
    res.status(500).json({ error: 'Internal server error' });
  }
}

export async function handleGetClassesByCourse(req: Request, res: Response) {
  try {
    const { courseId } = req.params;
    const result = await db.getClassesByCourse(courseId);
    
    if (result.success) {
      res.json(result.data);
    } else {
      res.status(404).json({ error: result.error });
    }
  } catch (error) {
    res.status(500).json({ error: 'Internal server error' });
  }
}

// Order routes
export async function handleCreateOrder(req: Request, res: Response) {
  try {
    const orderData = req.body;
    const result = await db.createOrder(orderData);
    
    if (result.success) {
      res.status(201).json(result.data);
    } else {
      res.status(400).json({ error: result.error });
    }
  } catch (error) {
    res.status(500).json({ error: 'Internal server error' });
  }
}

export async function handleGetOrders(req: Request, res: Response) {
  try {
    const { page = 1, limit = 10 } = req.query;
    const result = await db.getOrders(Number(page), Number(limit));
    
    if (result.success) {
      res.json(result.data);
    } else {
      res.status(400).json({ error: result.error });
    }
  } catch (error) {
    res.status(500).json({ error: 'Internal server error' });
  }
}

export async function handleUpdateOrderStatus(req: Request, res: Response) {
  try {
    const { id } = req.params;
    const { status, transactionId } = req.body;
    const result = await db.updateOrderStatus(id, status, transactionId);
    
    if (result.success) {
      res.json(result.data);
    } else {
      res.status(404).json({ error: result.error });
    }
  } catch (error) {
    res.status(500).json({ error: 'Internal server error' });
  }
}

// Export the database instance for other modules
export { db };
