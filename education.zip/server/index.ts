import "dotenv/config";
import express from "express";
import cors from "cors";
import { handleDemo } from "./routes/demo";
import {
  handleGetCourses,
  handleGetCourse,
  handleCreateCourse,
  handleUpdateCourse,
  handleDeleteCourse,
  handlePublishCourse,
  handleCreateClass,
  handleGetClassesByCourse,
  handleCreateOrder,
  handleGetOrders,
  handleUpdateOrderStatus
} from "./routes/database";
import {
  handleFileUpload,
  handleFileGet,
  handleFileDownload,
  handleFileDelete
} from "./routes/files";

export function createServer() {
  const app = express();

  // Middleware
  app.use(cors());
  app.use(express.json({ limit: '50mb' })); // Increase limit for file uploads
  app.use(express.urlencoded({ extended: true, limit: '50mb' }));

  // Example API routes
  app.get("/api/ping", (_req, res) => {
    const ping = process.env.PING_MESSAGE ?? "ping";
    res.json({ message: ping });
  });

  app.get("/api/demo", handleDemo);

  // Database API routes
  // Courses
  app.get("/api/courses", handleGetCourses);
  app.get("/api/courses/:id", handleGetCourse);
  app.post("/api/courses", handleCreateCourse);
  app.put("/api/courses/:id", handleUpdateCourse);
  app.delete("/api/courses/:id", handleDeleteCourse);
  app.post("/api/courses/:id/publish", handlePublishCourse);

  // Classes
  app.post("/api/classes", handleCreateClass);
  app.get("/api/courses/:courseId/classes", handleGetClassesByCourse);

  // Orders
  app.get("/api/orders", handleGetOrders);
  app.post("/api/orders", handleCreateOrder);
  app.put("/api/orders/:id/status", handleUpdateOrderStatus);

  // Files
  app.post("/api/files/upload", handleFileUpload);
  app.get("/api/files/:key", handleFileGet);
  app.get("/api/files/:key/download", handleFileDownload);
  app.delete("/api/files/:key", handleFileDelete);

  return app;
}
