// Database schema and types for the course management system

export interface User {
  id: string;
  email: string;
  name: string;
  isAdmin: boolean;
  createdAt: string;
  updatedAt: string;
}

export interface Course {
  id: string;
  title: string;
  description: string;
  price: number;
  duration: string;
  category: string;
  thumbnail?: string;
  thumbnailKey?: string;
  isPublished: boolean;
  createdBy: string;
  createdAt: string;
  updatedAt: string;
  classes?: CourseClass[];
}

export interface CourseClass {
  id: string;
  courseId: string;
  title: string;
  description?: string;
  order: number;
  videos?: ClassVideo[];
  notes?: ClassNote[];
  projects?: ClassProject[];
  createdAt: string;
  updatedAt: string;
}

export interface ClassVideo {
  id: string;
  classId: string;
  title: string;
  fileName: string;
  fileSize: number;
  duration?: number;
  videoUrl: string;
  videoKey: string;
  createdAt: string;
}

export interface ClassNote {
  id: string;
  classId: string;
  title: string;
  fileName: string;
  fileSize: number;
  fileUrl: string;
  fileKey: string;
  createdAt: string;
}

export interface ClassProject {
  id: string;
  classId: string;
  title: string;
  fileName: string;
  fileSize: number;
  fileUrl: string;
  fileKey: string;
  createdAt: string;
}

export interface Order {
  id: string;
  userId: string;
  courseId: string;
  courseName: string;
  amount: number;
  paymentStatus: 'pending' | 'completed' | 'failed';
  paymentMethod: string;
  transactionId?: string;
  createdAt: string;
  updatedAt: string;
}

export interface Certification {
  id: string;
  name: string;
  price: number;
  description: string;
  duration: string;
  requirements: string[];
  benefits: string[];
  isActive: boolean;
  createdAt: string;
  updatedAt: string;
}

// API Request/Response types
export interface CreateCourseRequest {
  title: string;
  description: string;
  price: number;
  duration: string;
  category: string;
  thumbnail?: File;
}

export interface CreateClassRequest {
  courseId: string;
  title: string;
  description?: string;
  order: number;
  videos?: File[];
  notes?: File[];
  projects?: File[];
}

export interface UpdateCourseRequest extends Partial<CreateCourseRequest> {
  id: string;
  isPublished?: boolean;
}

export interface DatabaseResponse<T> {
  success: boolean;
  data?: T;
  error?: string;
  message?: string;
}

export interface PaginatedResponse<T> {
  data: T[];
  total: number;
  page: number;
  limit: number;
  hasNext: boolean;
  hasPrev: boolean;
}

// Database connection interface
export interface DatabaseConnection {
  // Courses
  createCourse(course: Omit<Course, 'id' | 'createdAt' | 'updatedAt'>): Promise<DatabaseResponse<Course>>;
  getCourse(id: string): Promise<DatabaseResponse<Course>>;
  getCourses(page?: number, limit?: number, published?: boolean): Promise<DatabaseResponse<PaginatedResponse<Course>>>;
  updateCourse(id: string, updates: Partial<Course>): Promise<DatabaseResponse<Course>>;
  deleteCourse(id: string): Promise<DatabaseResponse<boolean>>;
  publishCourse(id: string): Promise<DatabaseResponse<Course>>;

  // Classes
  createClass(classData: Omit<CourseClass, 'id' | 'createdAt' | 'updatedAt'>): Promise<DatabaseResponse<CourseClass>>;
  getClass(id: string): Promise<DatabaseResponse<CourseClass>>;
  getClassesByCourse(courseId: string): Promise<DatabaseResponse<CourseClass[]>>;
  updateClass(id: string, updates: Partial<CourseClass>): Promise<DatabaseResponse<CourseClass>>;
  deleteClass(id: string): Promise<DatabaseResponse<boolean>>;

  // Videos, Notes, Projects
  addClassVideo(video: Omit<ClassVideo, 'id' | 'createdAt'>): Promise<DatabaseResponse<ClassVideo>>;
  addClassNote(note: Omit<ClassNote, 'id' | 'createdAt'>): Promise<DatabaseResponse<ClassNote>>;
  addClassProject(project: Omit<ClassProject, 'id' | 'createdAt'>): Promise<DatabaseResponse<ClassProject>>;

  // Orders
  createOrder(order: Omit<Order, 'id' | 'createdAt' | 'updatedAt'>): Promise<DatabaseResponse<Order>>;
  getOrder(id: string): Promise<DatabaseResponse<Order>>;
  getOrders(page?: number, limit?: number): Promise<DatabaseResponse<PaginatedResponse<Order>>>;
  updateOrderStatus(id: string, status: Order['paymentStatus'], transactionId?: string): Promise<DatabaseResponse<Order>>;

  // Users
  createUser(user: Omit<User, 'id' | 'createdAt' | 'updatedAt'>): Promise<DatabaseResponse<User>>;
  getUser(id: string): Promise<DatabaseResponse<User>>;
  getUserByEmail(email: string): Promise<DatabaseResponse<User>>;

  // Certifications
  createCertification(cert: Omit<Certification, 'id' | 'createdAt' | 'updatedAt'>): Promise<DatabaseResponse<Certification>>;
  getCertifications(active?: boolean): Promise<DatabaseResponse<Certification[]>>;
  updateCertification(id: string, updates: Partial<Certification>): Promise<DatabaseResponse<Certification>>;

  // File Storage
  uploadFile(file: File, folder: string): Promise<DatabaseResponse<{ url: string; key: string }>>;
  getFileUrl(key: string): Promise<string>;
  deleteFile(key: string): Promise<DatabaseResponse<boolean>>;
}
