// Course content data with lessons, demo videos, and notes for all courses

export interface Lesson {
  id: string;
  title: string;
  description: string;
  duration: string;
  videoUrl: string;
  isPreview: boolean;
  notes: {
    title: string;
    url: string;
    description: string;
  }[];
  quiz?: {
    questions: number;
    passingScore: number;
  };
}

export interface Project {
  id: string;
  title: string;
  description: string;
  difficulty: 'Beginner' | 'Intermediate' | 'Advanced';
  estimatedTime: string;
  files: string[];
  instructions: string;
}

export interface CourseContent {
  courseId: string;
  lessons: Lesson[];
  projects: Project[];
  totalDuration: string;
}

// React Development Course Content
const reactCourseContent: CourseContent = {
  courseId: '1',
  totalDuration: '32 hours',
  lessons: [
    {
      id: '1-1',
      title: 'Introduction to React',
      description: 'Learn the basics of React and component architecture',
      duration: '15:30',
      videoUrl: 'https://www.youtube.com/embed/LX4JUscM9Sk',
      isPreview: true,
      notes: [
        {
          title: 'React Fundamentals Notes',
          url: '/notes/react/lesson1-fundamentals.pdf',
          description: 'Core concepts of React, components, and virtual DOM'
        },
        {
          title: 'Setup Guide',
          url: '/notes/react/lesson1-setup.pdf', 
          description: 'Step-by-step React development environment setup'
        }
      ]
    },
    {
      id: '1-2',
      title: 'JSX and Components',
      description: 'Understanding JSX syntax and creating your first components',
      duration: '22:45',
      videoUrl: 'https://www.youtube.com/embed/SqcY0GlETPk',
      isPreview: false,
      notes: [
        {
          title: 'JSX Syntax Guide',
          url: '/notes/react/lesson2-jsx.pdf',
          description: 'Complete JSX syntax reference and best practices'
        },
        {
          title: 'Component Patterns',
          url: '/notes/react/lesson2-components.pdf',
          description: 'Functional vs class components and when to use each'
        }
      ],
      quiz: {
        questions: 10,
        passingScore: 80
      }
    },
    {
      id: '1-3',
      title: 'Props and State',
      description: 'Managing component state and passing data through props',
      duration: '28:15',
      videoUrl: 'https://www.youtube.com/embed/4UZrsTqkcW4',
      isPreview: false,
      notes: [
        {
          title: 'Props Deep Dive',
          url: '/notes/react/lesson3-props.pdf',
          description: 'Understanding props, prop types, and default props'
        },
        {
          title: 'State Management',
          url: '/notes/react/lesson3-state.pdf',
          description: 'useState hook and state management patterns'
        }
      ]
    },
    {
      id: '1-4',
      title: 'Event Handling',
      description: 'Handling user interactions and events in React',
      duration: '18:20',
      videoUrl: 'https://www.youtube.com/embed/Znqv84xi8Vs',
      isPreview: false,
      notes: [
        {
          title: 'Event Handling Guide',
          url: '/notes/react/lesson4-events.pdf',
          description: 'Synthetic events, event handlers, and common patterns'
        }
      ]
    },
    {
      id: '1-5',
      title: 'React Hooks Deep Dive',
      description: 'Master useEffect, useContext, and custom hooks',
      duration: '35:40',
      videoUrl: 'https://www.youtube.com/embed/O6P86uwfdR0',
      isPreview: false,
      notes: [
        {
          title: 'Hooks Reference',
          url: '/notes/react/lesson5-hooks.pdf',
          description: 'Complete guide to React hooks and their use cases'
        }
      ]
    }
  ],
  projects: [
    {
      id: '1-p1',
      title: 'Todo App with Hooks',
      description: 'Build a complete todo application using React hooks',
      difficulty: 'Beginner',
      estimatedTime: '3 hours',
      files: ['/projects/react/todo-starter.zip', '/projects/react/todo-solution.zip'],
      instructions: 'Create a fully functional todo app with add, edit, delete, and filter functionality'
    },
    {
      id: '1-p2',
      title: 'Weather Dashboard',
      description: 'Build a weather dashboard with API integration',
      difficulty: 'Intermediate',
      estimatedTime: '5 hours',
      files: ['/projects/react/weather-starter.zip'],
      instructions: 'Integrate with weather API and create responsive dashboard'
    }
  ]
};

// Machine Learning Course Content
const mlCourseContent: CourseContent = {
  courseId: '2',
  totalDuration: '24 hours',
  lessons: [
    {
      id: '2-1',
      title: 'Machine Learning Introduction',
      description: 'Understanding ML fundamentals and applications',
      duration: '20:15',
      videoUrl: 'https://www.youtube.com/embed/aircAruvnKk',
      isPreview: true,
      notes: [
        {
          title: 'ML Fundamentals',
          url: '/notes/ml/lesson1-fundamentals.pdf',
          description: 'Introduction to machine learning concepts and types'
        }
      ]
    },
    {
      id: '2-2',
      title: 'Python for Data Science',
      description: 'Essential Python libraries for machine learning',
      duration: '25:30',
      videoUrl: 'https://www.youtube.com/embed/LHBE6Q9XlzI',
      isPreview: false,
      notes: [
        {
          title: 'Python Libraries Guide',
          url: '/notes/ml/lesson2-python.pdf',
          description: 'NumPy, Pandas, and Matplotlib essentials'
        }
      ]
    },
    {
      id: '2-3',
      title: 'Linear Regression',
      description: 'Understanding and implementing linear regression',
      duration: '30:45',
      videoUrl: 'https://www.youtube.com/embed/7ArmBVF2dCs',
      isPreview: false,
      notes: [
        {
          title: 'Linear Regression Theory',
          url: '/notes/ml/lesson3-linear-regression.pdf',
          description: 'Mathematical foundations and implementation'
        }
      ]
    }
  ],
  projects: [
    {
      id: '2-p1',
      title: 'House Price Prediction',
      description: 'Predict house prices using linear regression',
      difficulty: 'Beginner',
      estimatedTime: '4 hours',
      files: ['/projects/ml/house-prices.zip'],
      instructions: 'Build and evaluate a house price prediction model'
    }
  ]
};

// iOS Development Course Content  
const iosCourseContent: CourseContent = {
  courseId: '3',
  totalDuration: '28 hours',
  lessons: [
    {
      id: '3-1',
      title: 'iOS Development Introduction',
      description: 'Getting started with iOS app development',
      duration: '18:20',
      videoUrl: 'https://www.youtube.com/embed/09TeUXjzpKs',
      isPreview: true,
      notes: [
        {
          title: 'iOS Development Basics',
          url: '/notes/ios/lesson1-intro.pdf',
          description: 'Xcode setup and iOS development fundamentals'
        }
      ]
    },
    {
      id: '3-2',
      title: 'Swift Programming Language',
      description: 'Master Swift syntax and programming concepts',
      duration: '32:15',
      videoUrl: 'https://www.youtube.com/embed/Ulp1Kimblg0',
      isPreview: false,
      notes: [
        {
          title: 'Swift Language Guide',
          url: '/notes/ios/lesson2-swift.pdf',
          description: 'Complete Swift programming reference'
        }
      ]
    },
    {
      id: '3-3',
      title: 'UIKit and Interface Builder',
      description: 'Building user interfaces with UIKit',
      duration: '26:40',
      videoUrl: 'https://www.youtube.com/embed/CICTXXXMOzc',
      isPreview: false,
      notes: [
        {
          title: 'UIKit Components',
          url: '/notes/ios/lesson3-uikit.pdf',
          description: 'UIKit components and interface design patterns'
        }
      ]
    }
  ],
  projects: [
    {
      id: '3-p1',
      title: 'Calculator App',
      description: 'Build a fully functional calculator app',
      difficulty: 'Beginner',
      estimatedTime: '6 hours',
      files: ['/projects/ios/calculator-starter.zip'],
      instructions: 'Create a calculator with basic arithmetic operations'
    }
  ]
};

// UI/UX Design Course Content
const designCourseContent: CourseContent = {
  courseId: '4',
  totalDuration: '20 hours',
  lessons: [
    {
      id: '4-1',
      title: 'Design Fundamentals',
      description: 'Core principles of user interface design',
      duration: '16:45',
      videoUrl: 'https://www.youtube.com/embed/YiLUYf4HDh4',
      isPreview: true,
      notes: [
        {
          title: 'Design Principles',
          url: '/notes/design/lesson1-fundamentals.pdf',
          description: 'Typography, color theory, and visual hierarchy'
        }
      ]
    },
    {
      id: '4-2',
      title: 'User Research and Personas',
      description: 'Understanding your users through research',
      duration: '22:30',
      videoUrl: 'https://www.youtube.com/embed/Qq3OiHQ-HCU',
      isPreview: false,
      notes: [
        {
          title: 'User Research Methods',
          url: '/notes/design/lesson2-research.pdf',
          description: 'Interviews, surveys, and persona creation'
        }
      ]
    },
    {
      id: '4-3',
      title: 'Wireframing and Prototyping',
      description: 'Creating wireframes and interactive prototypes',
      duration: '28:20',
      videoUrl: 'https://www.youtube.com/embed/qpH7-KFWZRI',
      isPreview: false,
      notes: [
        {
          title: 'Wireframing Best Practices',
          url: '/notes/design/lesson3-wireframes.pdf',
          description: 'Low-fi to high-fi wireframing techniques'
        }
      ]
    }
  ],
  projects: [
    {
      id: '4-p1',
      title: 'Mobile App Design',
      description: 'Design a complete mobile app interface',
      difficulty: 'Intermediate',
      estimatedTime: '8 hours',
      files: ['/projects/design/mobile-app-template.zip'],
      instructions: 'Design user flows, wireframes, and high-fidelity mockups'
    }
  ]
};

// Export all course content
export const COURSE_CONTENT: { [key: string]: CourseContent } = {
  '1': reactCourseContent,
  '2': mlCourseContent,
  '3': iosCourseContent,
  '4': designCourseContent
};

// Helper function to get course content by ID
export const getCourseContent = (courseId: string): CourseContent | null => {
  return COURSE_CONTENT[courseId] || null;
};
