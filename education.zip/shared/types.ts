export interface User {
  id: string;
  email: string;
  name: string;
  avatar?: string;
  role: 'student' | 'instructor' | 'admin';
  enrolledCourses: string[];
  createdAt: Date;
}

export interface Course {
  id: string;
  title: string;
  description: string;
  shortDescription: string;
  instructor: {
    id: string;
    name: string;
    avatar?: string;
    bio: string;
  };
  category: string;
  tags: string[];
  price: number;
  originalPrice?: number;
  currency: string;
  level: 'beginner' | 'intermediate' | 'advanced';
  duration: string;
  totalLessons: number;
  totalStudents: number;
  rating: number;
  reviewCount: number;
  thumbnail: string;
  previewVideo?: string;
  isFree: boolean;
  isPopular?: boolean;
  isNew?: boolean;
  features: string[];
  learningOutcomes: string[];
  requirements: string[];
  createdAt: Date;
  updatedAt: Date;
}

export interface Lesson {
  id: string;
  courseId: string;
  title: string;
  description: string;
  videoUrl: string;
  videoDuration: string;
  pdfNotes?: string;
  order: number;
  isPreview: boolean;
}

export interface CourseProgress {
  userId: string;
  courseId: string;
  completedLessons: string[];
  currentLesson: string;
  progressPercentage: number;
  lastAccessed: Date;
  completedAt?: Date;
}

export interface Review {
  id: string;
  courseId: string;
  userId: string;
  userName: string;
  userAvatar?: string;
  rating: number;
  comment: string;
  createdAt: Date;
}

export interface Category {
  id: string;
  name: string;
  description: string;
  icon: string;
  courseCount: number;
}

export interface Filter {
  categories: string[];
  priceRange: [number, number];
  levels: string[];
  duration: string[];
  rating: number;
  isFree?: boolean;
}

export const CATEGORIES: Category[] = [
  {
    id: '1',
    name: 'Web Development',
    description: 'Learn modern web technologies',
    icon: '💻',
    courseCount: 145
  },
  {
    id: '2',
    name: 'Data Science',
    description: 'Master data analysis and machine learning',
    icon: '📊',
    courseCount: 89
  },
  {
    id: '3',
    name: 'Mobile Development',
    description: 'Build iOS and Android apps',
    icon: '📱',
    courseCount: 67
  },
  {
    id: '4',
    name: 'Artificial Intelligence',
    description: 'Explore AI and machine learning',
    icon: '🤖',
    courseCount: 78
  },
  {
    id: '5',
    name: 'Design',
    description: 'UI/UX and graphic design',
    icon: '🎨',
    courseCount: 112
  },
  {
    id: '6',
    name: 'Business',
    description: 'Business skills and entrepreneurship',
    icon: '💼',
    courseCount: 93
  },
  {
    id: '7',
    name: 'Cybersecurity',
    description: 'Learn ethical hacking and security',
    icon: '🔒',
    courseCount: 45
  },
  {
    id: '8',
    name: 'Cloud Computing',
    description: 'Master AWS, Azure, and Google Cloud',
    icon: '☁️',
    courseCount: 56
  },
  {
    id: '9',
    name: 'DevOps',
    description: 'Learn CI/CD, Docker, and Kubernetes',
    icon: '⚙️',
    courseCount: 42
  },
  {
    id: '10',
    name: 'Digital Marketing',
    description: 'SEO, Social Media, and Online Advertising',
    icon: '📈',
    courseCount: 73
  },
  {
    id: '11',
    name: 'Photography',
    description: 'Master photography and photo editing',
    icon: '📷',
    courseCount: 38
  },
  {
    id: '12',
    name: 'Music Production',
    description: 'Create beats, mix, and master music',
    icon: '🎵',
    courseCount: 29
  },
  {
    id: '13',
    name: 'Game Development',
    description: 'Build games with Unity, Unreal, and more',
    icon: '🎮',
    courseCount: 51
  },
  {
    id: '14',
    name: 'Blockchain',
    description: 'Learn cryptocurrency and smart contracts',
    icon: '⛓️',
    courseCount: 34
  },
  {
    id: '15',
    name: 'Finance',
    description: 'Investment, trading, and financial analysis',
    icon: '💰',
    courseCount: 48
  },
  {
    id: '16',
    name: 'Health & Fitness',
    description: 'Nutrition, workout plans, and wellness',
    icon: '💪',
    courseCount: 62
  }
];

export const SAMPLE_COURSES: Course[] = [
  {
    id: '1',
    title: 'Complete React Development Bootcamp',
    description: 'Master React from basics to advanced concepts including hooks, context, Redux, and modern patterns. Build real-world applications with industry best practices.',
    shortDescription: 'Master React from basics to advanced concepts with real projects',
    instructor: {
      id: 'inst1',
      name: 'Sarah Johnson',
      avatar: 'https://images.unsplash.com/photo-1494790108755-2616b612b786?w=150',
      bio: 'Senior React Developer at Google with 8+ years experience'
    },
    category: 'Web Development',
    tags: ['React', 'JavaScript', 'Frontend', 'Redux'],
    price: 89.99,
    originalPrice: 199.99,
    currency: 'USD',
    level: 'intermediate',
    duration: '32 hours',
    totalLessons: 156,
    totalStudents: 12430,
    rating: 4.8,
    reviewCount: 2341,
    thumbnail: 'https://images.unsplash.com/photo-1633356122544-f134324a6cee?w=800',
    isFree: false,
    isPopular: true,
    features: [
      '156 hands-on lessons',
      'Downloadable resources',
      'Certificate of completion',
      'Lifetime access',
      '24/7 support'
    ],
    learningOutcomes: [
      'Build modern React applications',
      'Master React hooks and context',
      'Implement state management with Redux',
      'Deploy applications to production'
    ],
    requirements: [
      'Basic JavaScript knowledge',
      'HTML and CSS fundamentals',
      'No React experience needed'
    ],
    createdAt: new Date('2024-01-15'),
    updatedAt: new Date('2024-03-10')
  },
  {
    id: '2',
    title: 'Machine Learning Fundamentals',
    description: 'Learn the fundamentals of machine learning with Python. Covers supervised and unsupervised learning, neural networks, and real-world applications.',
    shortDescription: 'Learn ML fundamentals with Python and build real projects',
    instructor: {
      id: 'inst2',
      name: 'Dr. Michael Chen',
      avatar: 'https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=150',
      bio: 'ML Engineer at Tesla, PhD in Computer Science'
    },
    category: 'Data Science',
    tags: ['Machine Learning', 'Python', 'AI', 'Data Science'],
    price: 0,
    currency: 'USD',
    level: 'beginner',
    duration: '24 hours',
    totalLessons: 98,
    totalStudents: 18723,
    rating: 4.9,
    reviewCount: 3456,
    thumbnail: 'https://images.unsplash.com/photo-1555949963-aa79dcee981c?w=800',
    isFree: true,
    isNew: true,
    features: [
      '98 comprehensive lessons',
      'Python code examples',
      'Real datasets',
      'Certificate included',
      'Community access'
    ],
    learningOutcomes: [
      'Understand ML algorithms',
      'Implement models in Python',
      'Analyze real-world data',
      'Build predictive models'
    ],
    requirements: [
      'Basic Python knowledge',
      'High school math',
      'No ML experience needed'
    ],
    createdAt: new Date('2024-02-20'),
    updatedAt: new Date('2024-03-15')
  },
  {
    id: '3',
    title: 'iOS App Development with Swift',
    description: 'Create stunning iOS applications using Swift and SwiftUI. Learn from basics to publishing on the App Store.',
    shortDescription: 'Build iOS apps with Swift and publish to App Store',
    instructor: {
      id: 'inst3',
      name: 'Alex Rodriguez',
      avatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=150',
      bio: 'iOS Developer at Apple, 10+ apps on App Store'
    },
    category: 'Mobile Development',
    tags: ['iOS', 'Swift', 'SwiftUI', 'Mobile'],
    price: 129.99,
    originalPrice: 249.99,
    currency: 'USD',
    level: 'intermediate',
    duration: '28 hours',
    totalLessons: 132,
    totalStudents: 8934,
    rating: 4.7,
    reviewCount: 1876,
    thumbnail: 'https://images.unsplash.com/photo-1512941937669-90a1b58e7e9c?w=800',
    isFree: false,
    features: [
      '132 practical lessons',
      'Xcode projects',
      'App Store submission guide',
      'Source code included',
      'Instructor support'
    ],
    learningOutcomes: [
      'Master Swift programming',
      'Build complete iOS apps',
      'Understand SwiftUI framework',
      'Publish apps to App Store'
    ],
    requirements: [
      'Mac computer required',
      'Basic programming knowledge',
      'Xcode installed'
    ],
    createdAt: new Date('2024-01-08'),
    updatedAt: new Date('2024-02-28')
  },
  {
    id: '4',
    title: 'UI/UX Design Masterclass',
    description: 'Comprehensive course covering user interface and user experience design principles, tools, and methodologies.',
    shortDescription: 'Master UI/UX design with hands-on projects and tools',
    instructor: {
      id: 'inst4',
      name: 'Emma Thompson',
      avatar: 'https://images.unsplash.com/photo-1438761681033-6461ffad8d80?w=150',
      bio: 'Senior UX Designer at Airbnb, Design mentor'
    },
    category: 'Design',
    tags: ['UI/UX', 'Design', 'Figma', 'Prototyping'],
    price: 79.99,
    currency: 'USD',
    level: 'beginner',
    duration: '20 hours',
    totalLessons: 89,
    totalStudents: 15623,
    rating: 4.8,
    reviewCount: 2987,
    thumbnail: 'https://images.unsplash.com/photo-1586717791821-3f44a563fa4c?w=800',
    isFree: false,
    isPopular: true,
    features: [
      '89 design lessons',
      'Figma templates',
      'Portfolio projects',
      'Design resources',
      'Community feedback'
    ],
    learningOutcomes: [
      'Master design principles',
      'Create user-centered designs',
      'Use professional tools',
      'Build design portfolio'
    ],
    requirements: [
      'No prior design experience',
      'Computer with internet',
      'Figma account (free)'
    ],
    createdAt: new Date('2024-02-01'),
    updatedAt: new Date('2024-03-05')
  }
];
